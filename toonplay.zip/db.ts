import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

const {
  DB_HOST = '',
  DB_PORT = '',
  DB_USER = '',
  DB_PASS = '',                 
  DB_NAME = '',
  DB_CONNECTION_LIMIT = '10',
} = process.env;

if (!DB_HOST || !DB_PORT || !DB_USER || !DB_PASS || !DB_NAME) {
  console.warn(
    '[db] Missing DB_HOST / DB_PORT / DB_USER / DB_PASS / DB_NAME in environment. Check your .env file.'
  );
}

export const isDbConfigured = Boolean(DB_HOST && DB_PORT && DB_USER && DB_NAME);

export const pool = mysql.createPool({
  host: DB_HOST || '127.0.0.1',
  port: Number(DB_PORT || 3306),
  user: DB_USER,
  password: DB_PASS,
  database: DB_NAME,
  waitForConnections: true,
  connectionLimit: Number(DB_CONNECTION_LIMIT),
  queueLimit: 0,
  charset: 'utf8mb4',
  timezone: 'Z',
  dateStrings: true,
  enableKeepAlive: true,
  keepAliveInitialDelay: 10_000,
});

export async function query<T = any>(
  sql: string,
  params?: any[]
): Promise<T[]> {
  const [rows] = await pool.execute(sql, params);
  return rows as T[];
}

export async function queryOne<T = any>(
  sql: string,
  params?: any[]
): Promise<T | null> {
  const rows = await query<T>(sql, params);
  return rows[0] ?? null;
}

export async function execute(
  sql: string,
  params?: any[]
): Promise<mysql.ResultSetHeader> {
  const [result] = await pool.execute(sql, params);
  return result as mysql.ResultSetHeader;
}

export async function transaction<T>(
  fn: (conn: mysql.PoolConnection) => Promise<T>
): Promise<T> {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (err) {
    try { await conn.rollback(); } catch { /* ignore */ }
    throw err;
  } finally {
    conn.release();
  }
}

export async function pingDb(): Promise<boolean> {
  if (!isDbConfigured) return false;
  let conn: mysql.PoolConnection | undefined;
  try {
    conn = await pool.getConnection();
    await conn.ping();
    return true;
  } catch (err) {
    console.error('[db] Ping failed:', err);
    return false;
  } finally {
    conn?.release();
  }
}

export async function closeDb(): Promise<void> {
  try {
    await pool.end();
    console.log('[db] Pool closed.');
  } catch (err) {
    console.error('[db] Error closing pool:', err);
  }
}