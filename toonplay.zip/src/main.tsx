import { createRoot } from 'react-dom/client';
import { AuthProvider } from './context/AuthContext.tsx';
import { Toaster } from 'sonner';
import App from './App.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <AuthProvider>
    <App />
    <Toaster position="bottom-right" richColors />
  </AuthProvider>
);