export interface HeroAnime {
  title: string;
  overview: string;
  backdrop: string;
  rating: string;
  year: string;
  id: string;
  subjectId?: string;
  type: 'series' | 'movie' | string;
  anilist_id?: number;
}

export interface LatestReleaseAnime {
  title: string;
  image: string;
  id: string;
  type: 'series' | 'movie' | string;
  season?: string | null;
  episodes?: string | null;
  anilist_id?: number;
}

export interface GlobalLatestReleaseAnime {
  title: string;
  id: string;
  reanime_id?: string;
  image_url: string;
  type: 'series' | 'movie' | 'OVA' | 'ONA' | 'SPECIAL' | 'TV_SHORT' | 'MUSIC' | string;
  anilist_id?: number;
  season?: string | null;
  latest_episode?: number;
}

export interface LatestReleasesApiPagination {
  currentPage: number;
  hasNext: boolean;
  hasPrevious: boolean;
  nextCursor?: string | null;
}

export interface LatestReleasesApiResponse {
  success: boolean;
  pagination: LatestReleasesApiPagination;
  data: GlobalLatestReleaseAnime[];
}

export interface PopularSeriesAnime {
  title: string;
  image: string;
  id: string;
  type: 'series' | 'movie' | string;
  anilist_id?: number;
}

export interface PopularMovieAnime {
  title: string;
  image: string;
  id: string;
  type: 'movie' | 'series' | string;
  anilist_id?: number;
}

export interface TrendingAnime {
  title: string;
  id: string;
  type: 'series' | 'movie' | string;
  image?: string;
  poster_image?: string;
  anilist_id?: number;
}

export interface HomeApiData {
  hero: HeroAnime[];
  trending?: TrendingAnime[];
  latest_releases: LatestReleaseAnime[];
  global_latest_releases?: GlobalLatestReleaseAnime[];
  popular_series: PopularSeriesAnime[];
  popular_movies: PopularMovieAnime[];
}

export interface HomeApiResponse {
  success: boolean;
  data: HomeApiData;
  _fromCache?: boolean;
}

export interface PaginatedItem {
  title: string;
  image: string;
  id: string;
  subjectId?: string;
  type: 'series' | 'movie' | string;
  season?: string | null;
  episodes?: string | null;
}

export interface PaginatedApiResponse {
  success: boolean;
  type?: string;
  pagination: {
    currentPage: number;
    totalPages: number;
  };
  data: PaginatedItem[];
  _fromCache?: boolean;
}

export interface UnifiedAnime {
  id: string;
  subjectId?: string;
  title: string;
  image: string;
  backdrop?: string;
  type: 'series' | 'movie';
  displayType?: 'MOVIE' | 'SERIES' | 'OVA' | 'ONA' | 'SPECIAL' | 'MUSIC' | 'TV_SHORT' | (string & {});
  overview?: string;
  rating?: string;
  year?: string;
  season?: string | null;
  episodes?: string | null;
  seasonNumber?: number;
  episodeNumber?: number;
  lang?: string;
  server?: string;
  playedAt?: number;
  anilistId?: number;
  tmdbId?: number;
  category: 'hero' | 'trending' | 'latest' | 'series' | 'movie' | 'cartoon';
}

export interface AnimeWatchServer {
  name: string;
  url: string;
  lang?: string;
}

export interface StreamApiServer {
  $id: string;
  continue?: boolean;
  dataLink: string;
  dataType: string;
  hardsub?: boolean;
  serverName: string;
  softsub?: boolean;
}

export interface StreamApiResponse {
  anilist_id: number;
  episode: number;
  servers: StreamApiServer[];
  success: boolean;
  _fromCache?: boolean;
}

export interface AnimeEpisodeItem {
  number: number;
  title: string;
  id: string;
  link?: string;
  image?: string;
}

export interface AnimeSeasonItem {
  season: string;
  link?: string;
  episodeCount?: number;
  episodes?: AnimeEpisodeItem[];
}

export interface AnimeRecommendation {
  title: string;
  id: string;
  image: string;
}

export interface AnimeInfoData {
  id: string;
  subjectId?: string;
  title: string;
  type: 'series' | 'movie' | string;
  image: string;
  backdrop?: string;
  overview?: string;
  year?: string;
  genres?: string[];
  languages?: string[];
  networks?: any[];
  recommendations?: AnimeRecommendation[];
  duration?: string;
  seasons?: string;
  episodes?: string;
  episodeDuration?: string;
  watchServers?: AnimeWatchServer[];
  seasonsList?: AnimeSeasonItem[];
  anime_id?: string;
  reanime_id?: string;
  alternative_title?: string;
  alternative_titles?: string[];
  banner_image_url?: string;
  cover_image_url?: string;
  description?: string;
  external_links?: Record<string, string>;
  mal_id?: number;
  anilist_id?: number;
  season_anilist_ids?: Record<
    string,
    {
      anilist_id?: number;
      reanime_id?: string;
      animerulz_id?: string;
    }
  >;
  season?: string;
  start_date?: string;
  status?: string;              
  studios?: string[];
  stats?: Record<string, string>;
  tmdb_id?: number;
  related_seasons_and_series?: Array<{
    image_url?: string;
    label?: string;
    media_type?: string;
    title: string;
    url?: string;
    year?: number;
  }>;
  watch_url?: string;
}

export interface AnimeInfoApiResponse {
  success: boolean;
  anime: AnimeInfoData;
  _fromCache?: boolean;
}

export interface EpisodeExtractData {
  watchServers: AnimeWatchServer[];
  videoPlayerUrls?: string[];
  videoPlayerUrl?: string;
  extractedAt?: string;
  episodeUrl?: string;
}

export interface EpisodeExtractApiResponse {
  success: boolean;
  cached?: boolean;
  data: EpisodeExtractData;
}

export type FriendshipStatus =
  | 'none'
  | 'pending_sent'
  | 'pending_received'
  | 'request_sent'
  | 'request_received'
  | 'friends'
  | 'self';

export interface FriendRequest {
  id: number | string;
  senderId?: number | string;
  senderUsername: string;
  senderAvatar?: string;
  senderLevel?: number;
  receiverId?: number | string;
  receiverUsername: string;
  receiverAvatar?: string;
  status: 'pending' | 'accepted' | 'declined' | 'cancelled';
  createdAt: string;
}

export interface FriendUser {
  id: number | string;
  username: string;
  avatar?: string;
  level?: number;
  xp?: number;
  isOnline?: boolean;
  friendsSince?: string;
  mutualFriendsCount?: number;
}

export interface DownloadQuality {
  quality: string;
  size: string;
  links: Record<string, string>;
}

export interface DownloadEpisode {
  episode: number;
  uploadDate: string;
  qualities: DownloadQuality[];
  watchOnline?: string;
}

export interface DownloadSeriesMeta {
  title: string;
  image: string;
  type: 'series' | 'movie';
  episodeCount: number;
  lastUploadDate: string;
  languages?: string[];
}

export interface DownloadSeriesJson {
  slug: string;
  meta: DownloadSeriesMeta;
  countdown?: {
    title: string;
    label: string;
    displayDate: string;
    releaseDate: string;
    timezone: string;
  };
  page: {
    title: string;
    telegram?: { title: string; subtitle: string; url: string };
    episodes: DownloadEpisode[];
  };
}

export interface DownloadManifest {
  updatedAt?: string;
  series: Array<{
    slug: string;
    meta: DownloadSeriesMeta;
  }>;
}

// ── moviebox.streamindia.co.in/api/home ─────────────────────
export interface AoneroomImage {
  url: string;
  width?: number;
  height?: number;
}

export interface AoneroomSubject {
  subjectId: string;
  subjectType: 1 | 2 | 7 | number;
  title: string;
  description?: string;
  releaseDate?: string;
  genre?: string;
  countryName?: string;
  imdbRatingValue?: string;
  imdbRatingCount?: number;
  corner?: string;
  cover?: AoneroomImage;
  detailPath?: string;
  appointmentDate?: string;
  appointmentCnt?: number;
  hasResource?: boolean;
}

export interface OperatingBannerItem {
  id: string;
  title: string;
  image: AoneroomImage;
  url: string;
  subjectId: string;
  subjectType: number;
  subject: AoneroomSubject | null;
  detailPath: string;
}

export interface OperatingFilter {
  title: string;
  url: string;
  query: string;
  image: AoneroomImage;
}

export interface OperatingListEntry {
  type: 'BANNER' | 'SUBJECTS_MOVIE' | 'SPORT_LIVE' | 'FILTER' | 'APPOINTMENT_LIST' | string;
  position: number;
  title: string;
  subjects: AoneroomSubject[];
  banner: { items: OperatingBannerItem[] } | null;
  filters: OperatingFilter[];
  url: string;
  liveList: any[];
  opId?: string;
  detailPath?: string;
}

export interface MovieboxHomeApiResponse {
  code: number;
  message: string;
  data: {
    platformList: {
      name: string;
      uploadBy: string;
    }[];
    operatingList: OperatingListEntry[];
  };
}

export type InfoSource =
  | 'animesalt' 
  | 'reanime'    
  | 'moviebox';   
  
// ── moviebox.streamindia.co.in/api/info?detailPath=... ─────
export interface MovieboxRecommendation {
  id: string;
  type: 'series' | 'movie' | string;
  subjectId: string;
  title: string;
  image: string;
  year: string;
  genres: string[];
}

export interface MovieboxEpisodeItem {
  number: number;
  title: string;
  id: string;
  image?: string;
}

export interface MovieboxSeasonItem {
  season: string;
  link?: string;
  episodeCount?: number;
  episodes?: MovieboxEpisodeItem[];
}

export interface MovieboxWatchServer {
  name: string;
  url: string;
}

export interface MovieboxInfoData {
  id: string;
  subjectId?: string;
  type: 'series' | 'movie' | string;
  title: string;
  image: string;
  backdrop?: string;
  overview?: string;
  year?: string;
  genres?: string[];
  languages?: string[];
  networks?: any[];
  recommendations?: MovieboxRecommendation[];
  media?: string;
  duration?: string;
  seasons?: string;
  episodes?: string;
  episodeDuration?: string;
  seasonsList?: MovieboxSeasonItem[];
  watchServers?: MovieboxWatchServer[];
}

export interface MovieboxInfoApiResponse {
  success: boolean;
  anime: MovieboxInfoData;
}

export interface MovieboxSearchResultItem {
  title: string;
  subjectId: string;
  detailPath: string;
  subjectType: number;
  image?: string;
  type?: string;
}

export interface MovieboxSearchApiResponse {
  success: boolean;
  query: string;
  page: number;
  perPage: number;
  count: number;
  data: MovieboxSearchResultItem[];
}