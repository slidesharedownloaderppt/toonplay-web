import {
  PROFILE_FRAMES_REPO,
  PROFILE_FRAMES_COMMIT,
  PROFILE_FRAMES_DIR,
  PROFILE_FRAMES_CDN_PREFIX,
  PROFILE_FRAME_FILENAMES,
  buildProfileFrameCdnUrl,
  buildProfileFrameCatalog,
} from '../profileUrlValidation';
import {
  HomeApiData,
  HomeApiResponse,
  PaginatedApiResponse,
  UnifiedAnime,
  AnimeInfoApiResponse,
  AnimeInfoData,
  EpisodeExtractApiResponse,
  LatestReleasesApiResponse,
  StreamApiResponse,
  MovieboxHomeApiResponse,
  OperatingListEntry,
  AoneroomSubject,
  OperatingBannerItem,
  OperatingFilter,
  MovieboxInfoApiResponse,
  MovieboxInfoData,
  InfoSource,
  MovieboxSearchResultItem,
  MovieboxSearchApiResponse,
} from './types.ts';
export type {
  MovieboxHomeApiResponse,
  OperatingListEntry,
  AoneroomSubject,
  OperatingBannerItem,
  OperatingFilter,
  MovieboxInfoApiResponse,
  MovieboxInfoData,
  InfoSource,
  MovieboxSearchResultItem,
  MovieboxSearchApiResponse,
} from './types.ts';

export const API_BASE_URL = 'https://animesalt.streamindia.co.in/api';
export const MOVIEBOX_API_BASE = 'https://moviebox.streamindia.co.in';

export interface MovieboxStreamAudioOption {
  subjectId: string;
  detailPath: string;
  language: string;
  lanCode: string;
  original?: boolean;
  active?: boolean;
}

export interface MovieboxStreamData {
  title: string;
  subjectId: string;
  detailPath: string;
  subjectType: number | null;
  season: number;
  episode: number;
  streams: Array<{
    format: string;
    id: string;
    url: string;
    resolutions?: string;
    size?: string;
    duration?: number;
    codecName?: string;
    signCookie?: string;
    dashHeaders?: Record<string, string>;
    captions?: any;
  }>;
  audioOptions?: MovieboxStreamAudioOption[];
  activeAudio?: MovieboxStreamAudioOption | null;
}

export interface MovieboxStreamResponse {
  success: boolean;
  data: MovieboxStreamData;
}

export interface MovieboxDubOption {
  subjectId: string;
  language: string;
  lanCode: string;
  original?: boolean;
  type?: number;
  detailPath: string;
}

export interface MovieboxDubsResponse {
  success: boolean;
  detailPath: string;
  count: number;
  data: MovieboxDubOption[];
}


const DEFAULT_FETCH_TIMEOUT_MS = 14_000;
const MEMORY_CACHE_MAX_ENTRIES = 250;

interface CacheEntry<T> {
  value: T;
  fetchedAt: number;
}

const apiMemoryCache = new Map<string, CacheEntry<unknown>>();
const apiInFlight = new Map<string, Promise<unknown>>();

function setMemCache<T>(key: string, value: T): void {
  if (apiMemoryCache.has(key)) apiMemoryCache.delete(key);
  apiMemoryCache.set(key, { value, fetchedAt: Date.now() });
  if (apiMemoryCache.size > MEMORY_CACHE_MAX_ENTRIES) {
    const oldest = apiMemoryCache.keys().next().value;
    if (oldest !== undefined) apiMemoryCache.delete(oldest);
  }
}

function getMemCache<T>(key: string, ttlMs: number): T | null {
  const entry = apiMemoryCache.get(key);
  if (!entry) return null;
  if (Date.now() - entry.fetchedAt > ttlMs) {
    apiMemoryCache.delete(key);
    return null;
  }
  apiMemoryCache.delete(key);
  apiMemoryCache.set(key, entry);
  return entry.value as T;
}

function readLocalCache<T>(lsKey: string, maxAgeMs: number): T | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = window.localStorage.getItem(lsKey);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as { at: number; v: T };
    if (!parsed || typeof parsed.at !== 'number' || Date.now() - parsed.at > maxAgeMs) {
      return null;
    }
    return parsed.v;
  } catch {
    return null;
  }
}

function writeLocalCache<T>(lsKey: string, value: T): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(lsKey, JSON.stringify({ at: Date.now(), v: value }));
  } catch {
    /* ignore quota errors */
  }
}

async function fetchWithTimeout(
  url: string,
  options?: RequestInit & { timeoutMs?: number }
): Promise<globalThis.Response> {
  const { timeoutMs = DEFAULT_FETCH_TIMEOUT_MS, signal: externalSignal, ...init } = options || {};
  const controller = new AbortController();
  const timer = globalThis.setTimeout(() => controller.abort(), timeoutMs);

  const onExternalAbort = () => controller.abort();
  if (externalSignal) {
    if (externalSignal.aborted) {
      controller.abort();
    } else {
      externalSignal.addEventListener('abort', onExternalAbort, { once: true });
    }
  }

  try {
    return await fetch(url, {
      ...init,
      signal: controller.signal,
    });
  } finally {
    globalThis.clearTimeout(timer);
    if (externalSignal) {
      externalSignal.removeEventListener('abort', onExternalAbort);
    }
  }
}

function dedupeCached<T>(
  key: string,
  ttlMs: number,
  loader: () => Promise<T>,
  shouldCache: (val: T) => boolean = () => true
): Promise<T> {
  const cached = getMemCache<T>(key, ttlMs);
  if (cached !== null) return Promise.resolve(cached);

  const existing = apiInFlight.get(key) as Promise<T> | undefined;
  if (existing) return existing;

  const promise = loader()
    .then((data) => {
      if (shouldCache(data)) {
        setMemCache(key, data);
      }
      return data;
    })
    .finally(() => {
      apiInFlight.delete(key);
    });

  apiInFlight.set(key, promise);
  return promise;
}

const HOME_LS_KEY = 'tp_cache_home_v1';
const HOME_FRESH_TTL_MS = 3 * 60 * 1000;
const HOME_SWR_MAX_AGE_MS = 20 * 60 * 1000;

const MB_HOME_LS_KEY = 'tp_cache_mb_home_v1';
const MB_HOME_FRESH_TTL_MS = 5 * 60 * 1000;
const MB_HOME_SWR_MAX_AGE_MS = 30 * 60 * 1000;

const CATALOG_TTL_MS = 3 * 60 * 1000;
const INFO_TTL_MS = 5 * 60 * 1000;
const EXTRACT_TTL_MS = 5 * 60 * 1000;
const STREAM_TTL_MS = 3 * 60 * 1000;
const SEARCH_TTL_MS = 2 * 60 * 1000;
const STATIC_DATA_TTL_MS = 15 * 60 * 1000;

export function getCachedHomeContent(): HomeApiResponse | null {
  const mem = getMemCache<HomeApiResponse>('home', HOME_SWR_MAX_AGE_MS);
  if (mem?.success && mem.data) return mem;
  const local = readLocalCache<HomeApiResponse>(HOME_LS_KEY, HOME_SWR_MAX_AGE_MS);
  if (local?.success && local.data) return local;
  return null;
}

export function getCachedMovieboxHome(): MovieboxHomeApiResponse | null {
  const mem = getMemCache<MovieboxHomeApiResponse>('moviebox:home', MB_HOME_SWR_MAX_AGE_MS);
  if (mem?.code === 0 && mem.data) return mem;
  const local = readLocalCache<MovieboxHomeApiResponse>(MB_HOME_LS_KEY, MB_HOME_SWR_MAX_AGE_MS);
  if (local?.code === 0 && local.data) return local;
  return null;
}

export function normalizeMovieboxApiUrl(streamUrlOrPath: string): string {
  const raw = String(streamUrlOrPath || '').trim();
  if (!raw) return '';
  if (/^https?:\/\//i.test(raw)) return raw;
  if (raw.startsWith(`${MOVIEBOX_API_BASE}/`) || raw === MOVIEBOX_API_BASE) {
    return raw;
  }
  return `${MOVIEBOX_API_BASE}${raw.startsWith('/') ? '' : '/'}${raw}`;
}

export function clearMovieboxStreamDubCache(): void {
  for (const key of Array.from(apiMemoryCache.keys())) {
    if (key.startsWith('moviebox:dubs:') || key.startsWith('moviebox:stream:')) {
      apiMemoryCache.delete(key);
    }
  }
  for (const key of Array.from(apiInFlight.keys())) {
    if (key.startsWith('moviebox:dubs:') || key.startsWith('moviebox:stream:')) {
      apiInFlight.delete(key);
    }
  }
}

export async function fetchMovieboxDubs(
  detailPath: string
): Promise<MovieboxDubsResponse> {
  const key = String(detailPath || '').trim();
  if (!key) throw new Error('Moviebox detailPath is missing');

  return dedupeCached(
    `moviebox:dubs:${key}`,
    10 * 60 * 1000,
    async () => {
      const url = `${MOVIEBOX_API_BASE}/api/dubs?${new URLSearchParams({
        detailPath: key,
      })}`;

      const res = await fetchWithTimeout(url, {
        headers: { Accept: 'application/json' },
      });

      if (!res.ok) throw new Error(`Dubs HTTP ${res.status}`);
      return (await res.json()) as MovieboxDubsResponse;
    },
    (d) => Boolean(d?.success)
  );
}


export async function fetchMovieboxStream(
  streamUrlOrPath: string
): Promise<MovieboxStreamResponse> {
  const full = normalizeMovieboxApiUrl(streamUrlOrPath);
  if (!full) {
    throw new Error('Stream URL is missing');
  }

  let cacheKey = `moviebox:stream:${full}`;

  try {
    const parsed = new URL(full, 'http://moviebox.local');
    const subjectId = parsed.searchParams.get('subjectId')?.trim();

    if (subjectId) {
      const season = parsed.searchParams.get('se') || '0';
      const episode = parsed.searchParams.get('ep') || '0';

      cacheKey = `moviebox:stream:${subjectId}:${season}:${episode}`;
    }
  } catch {
  }

  return dedupeCached(
    cacheKey,
    STREAM_TTL_MS,
    async () => {
      const res = await fetchWithTimeout(full, {
        headers: { Accept: 'application/json' },
      });

      if (!res.ok) {
        throw new Error(`Stream not found`);
      }

      return (await res.json()) as MovieboxStreamResponse;
    },
    (d) => Boolean(d?.success && d?.data?.streams?.length)
  );
}

export const normalizeMovieboxLanguage = (value: string): string => {
  const code = String(value || '')
    .trim()
    .toLowerCase()
    .replace(/\s*dub$/i, '')
    .trim();

  const aliases: Record<string, string> = {
    hin: 'hi',
    hindi: 'hi',
    eng: 'en',
    english: 'en',
    jpn: 'ja',
    jap: 'ja',
    japanese: 'ja',
    tam: 'ta',
    tamil: 'ta',
    tel: 'te',
    telugu: 'te',
    mal: 'ml',
    malayalam: 'ml',
    kan: 'kn',
    kannada: 'kn',
    ben: 'bn',
    bengali: 'bn',
    kor: 'ko',
    korean: 'ko',
    mar: 'mr',
    marathi: 'mr',
    pan: 'pa',
    punjabi: 'pa',
    guj: 'gu',
    gujarati: 'gu',
    urd: 'ur',
    urdu: 'ur',
    spa: 'es',
    spanish: 'es',
    fre: 'fr',
    fra: 'fr',
    french: 'fr',
    ger: 'de',
    deu: 'de',
    german: 'de',
    por: 'pt',
    portuguese: 'pt',
    rus: 'ru',
    russian: 'ru',
    chi: 'zh',
    zho: 'zh',
    chinese: 'zh',
    ara: 'ar',
    arabic: 'ar',
    ind: 'id',
    indonesian: 'id',
    tha: 'th',
    thai: 'th',
    vie: 'vi',
    vietnamese: 'vi',
  };

  return aliases[code] || code;
};


export async function resolveMovieboxStreamUrlForLanguage(
  streamUrlOrPath: string,
  requestedLanguage: string
): Promise<string> {
  if (!requestedLanguage) return streamUrlOrPath;

  const normalized = normalizeMovieboxApiUrl(streamUrlOrPath);
  const sourceUrl = new URL(normalized, 'http://moviebox.local');

  const detailPath = sourceUrl.searchParams.get('detailPath') || '';
  const subjectId = sourceUrl.searchParams.get('subjectId') || '';

  if (!detailPath || !subjectId) return streamUrlOrPath;

  let dubs: MovieboxDubsResponse;

  try {
    dubs = await fetchMovieboxDubs(detailPath);
  } catch (error) {
    console.warn('[Moviebox] Dubs lookup failed; using original stream:', error);
    return streamUrlOrPath;
  }

  if (!dubs.success || !Array.isArray(dubs.data)) {
    return streamUrlOrPath;
  }

  const wanted = normalizeMovieboxLanguage(requestedLanguage);
  const selectedDub = dubs.data.find(
    (dub) =>
      normalizeMovieboxLanguage(dub.lanCode) === wanted ||
      normalizeMovieboxLanguage(dub.language) === wanted
  );

  if (!selectedDub?.subjectId || !selectedDub.detailPath) {
    return streamUrlOrPath;
  }

  const season = Number(sourceUrl.searchParams.get('se') || 0);
  const episode = Number(sourceUrl.searchParams.get('ep') || 0);

  return buildMovieboxStreamUrl(
    selectedDub.subjectId,
    selectedDub.detailPath,
    season,
    episode
  );
}

export function buildMovieboxStreamUrl(
  subjectId: string,
  detailPath: string,
  season = 0,
  episode = 0
): string {
  const qs = new URLSearchParams({
    subjectId: String(subjectId),
    detailPath: String(detailPath),
    se: String(season),
    ep: String(episode),
  });
  return `${MOVIEBOX_API_BASE}/api/stream?${qs.toString()}`;
}

export function detectInfoSource(id: string): InfoSource {
  const clean = String(id || '').trim();

  if (/^(anime|series|movies)[-_]/i.test(clean)) return 'animesalt';
  if (/^\d+$/.test(clean)) return 'moviebox';

  const tail = clean.split('-').pop() || '';
  if (!tail) return 'animesalt';

  if (/[A-Z]/.test(tail)) return 'moviebox';
  return 'reanime';
}

export interface SearchApiResultItem {
  title: string;
  image: string;
  type: string;
  id: string;
  link?: string;
  categories?: string[];
  anilist_id?: number;
  subjectId?: string;
  reanime_id?: string;
}

export interface SearchApiResponse {
  success: boolean;
  query: string;
  pagination?: {
    currentPage: number;
    totalPages: number;
  };
  data: SearchApiResultItem[];
}

async function apiGet<T>(
  endpoint: string,
  options?: RequestInit & { timeoutMs?: number }
): Promise<T> {
  const cleanEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
  const url = `${API_BASE_URL}${cleanEndpoint}`;

  try {
    const response = await fetchWithTimeout(url, {
      ...options,
      headers: {
        Accept: 'application/json',
        ...(options?.headers || {}),
      },
    });

    if (!response.ok) {
      throw new Error(`API request failed with HTTP ${response.status}: ${response.statusText}`);
    }

    const data = await response.json();
    return data as T;
  } catch (error: any) {
    if (error?.name !== 'AbortError') {
      console.error(`[API Error] GET ${url}:`, error?.message || error);
    }
    throw error;
  }
}

export async function fetchHomeContent(options?: { forceRefresh?: boolean }): Promise<HomeApiResponse> {
  if (options?.forceRefresh) {
    apiMemoryCache.delete('home');
  }
  return dedupeCached(
    'home',
    HOME_FRESH_TTL_MS,
    async () => {
      const data = await apiGet<HomeApiResponse>('/home');
      if (data?.success && data.data) {
        writeLocalCache(HOME_LS_KEY, data);
      }
      return data;
    },
    (d) => Boolean(d?.success && d.data)
  );
}

export function prefetchHomeContent(): void {
  void fetchHomeContent().catch(() => {});
}

export async function fetchMovieboxSearch(
  query: string,
  page: number = 1,
  signal?: AbortSignal
): Promise<MovieboxSearchApiResponse> {
  const cleanQuery = query.trim();
  if (!cleanQuery) {
    return {
      success: true,
      query: '',
      page: 1,
      perPage: 20,
      count: 0,
      data: [],
    };
  }
  const cleanPage = Math.max(1, page);
  const url = `${MOVIEBOX_API_BASE}/api/search?q=${encodeURIComponent(
    cleanQuery
  )}&page=${cleanPage}`;

  const res = await fetchWithTimeout(url, {
    signal,
    headers: { Accept: 'application/json' },
  });
  if (!res.ok) {
    throw new Error(`Search failed: HTTP ${res.status}`);
  }
  return (await res.json()) as MovieboxSearchApiResponse;
}

function normalizeSearchTitle(value: string): string {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()
    .replace(/\s+/g, ' ');
}

export async function searchCatalog(
  query: string,
  page: number = 1,
  signal?: AbortSignal
): Promise<SearchApiResponse> {
  if (!query || !query.trim()) {
    return { success: true, query: '', data: [] };
  }
  const cleanQuery = query.trim();
  const cleanPage = Math.max(1, page);
  const cacheKey = `search:${cleanQuery.toLowerCase()}:${cleanPage}`;

  const cached = getMemCache<SearchApiResponse>(cacheKey, SEARCH_TTL_MS);
  if (cached) return cached;

  const existing = apiInFlight.get(cacheKey) as Promise<SearchApiResponse> | undefined;
  if (existing && !signal) return existing;

  const runSearch = async (): Promise<SearchApiResponse> => {
    const [animesaltRes, movieboxRes] = await Promise.all([
      apiGet<SearchApiResponse>(
        `/search?q=${encodeURIComponent(cleanQuery)}&page=${cleanPage}`,
        { signal }
      ).catch((err) => {
        if (err?.name === 'AbortError') throw err;
        return null;
      }),
      fetchMovieboxSearch(cleanQuery, cleanPage, signal).catch((err) => {
        if (err?.name === 'AbortError') throw err;
        return null;
      }),
    ]);

  const animesaltItems: SearchApiResultItem[] =
    animesaltRes?.success && Array.isArray(animesaltRes.data)
      ? animesaltRes.data
      : [];

  const movieboxItems: SearchApiResultItem[] =
    movieboxRes?.success && Array.isArray(movieboxRes.data)
      ? movieboxRes.data
          .filter(
            (m) =>
              (m.detailPath && m.detailPath.trim()) ||
              (m.subjectId && m.subjectId.trim())
          )
          .map((m) => {
            const isMovie = Number(m.subjectType) === 1;
return {
  id:
    (m.detailPath && m.detailPath.trim()) ||
    m.subjectId,
  subjectId: m.subjectId || undefined,
  title: m.title,
  image: m.image || '',
  type: m.type || (isMovie ? 'movie' : 'series'),
  categories: [],
};
          })
      : [];
const normalizedQuery = normalizeSearchTitle(cleanQuery);

const titleHasQuery = (item: SearchApiResultItem): boolean => {
  const t = normalizeSearchTitle(item.title);
  if (!t || !normalizedQuery) return false;
  return t.includes(normalizedQuery);
};

// ── Bucket 1: exact matches ──
const exactAnimeSalt = animesaltItems.filter(
  (item) => normalizeSearchTitle(item.title) === normalizedQuery
);

const exactMoviebox = movieboxItems.filter(
  (item) => normalizeSearchTitle(item.title) === normalizedQuery
);

const partialAnimeSalt = animesaltItems.filter(
  (item) =>
    normalizeSearchTitle(item.title) !== normalizedQuery &&
    titleHasQuery(item)
);

const partialMoviebox = movieboxItems.filter(
  (item) =>
    normalizeSearchTitle(item.title) !== normalizedQuery &&
    titleHasQuery(item)
);

const otherAnimeSalt = animesaltItems.filter(
  (item) =>
    !exactAnimeSalt.includes(item) &&
    !partialAnimeSalt.includes(item)
);

const otherMoviebox = movieboxItems.filter(
  (item) =>
    !exactMoviebox.includes(item) &&
    !partialMoviebox.includes(item)
);

const seen = new Set<string>();
const data: SearchApiResultItem[] = [];

for (const item of [
  ...exactAnimeSalt,
  ...exactMoviebox,
  ...partialAnimeSalt,
  ...partialMoviebox,
  ...otherAnimeSalt,
  ...otherMoviebox,
]) {
  if (!item.id || seen.has(item.id)) continue;

  seen.add(item.id);
  data.push(item);
}

    const result: SearchApiResponse = {
      success: true,
      query: cleanQuery,
      pagination: animesaltRes?.pagination,
      data,
    };
    if (animesaltRes || movieboxRes) {
      setMemCache(cacheKey, result);
    }
    return result;
  };

  if (signal) {
    return runSearch();
  }

  const p = runSearch().finally(() => apiInFlight.delete(cacheKey));
  apiInFlight.set(cacheKey, p);
  return p;
}

export async function fetchMovieboxHome(options?: { forceRefresh?: boolean }): Promise<MovieboxHomeApiResponse> {
  if (options?.forceRefresh) {
    apiMemoryCache.delete('moviebox:home');
  }
  return dedupeCached(
    'moviebox:home',
    MB_HOME_FRESH_TTL_MS,
    async () => {
const res = await fetchWithTimeout('https://h5-api.aoneroom.com/wefeed-h5api-bff/home?host=movie-box.co', {
  headers: { Accept: 'application/json' },
});
      if (!res.ok) throw new Error(`Home failed: HTTP ${res.status}`);
      const json = (await res.json()) as MovieboxHomeApiResponse;
      if (json?.code === 0 && json?.data && Array.isArray(json.data.operatingList)) {
        writeLocalCache(MB_HOME_LS_KEY, json);
      }
      return json;
    },
    (d) => Boolean(d?.code === 0 && d?.data && Array.isArray(d.data.operatingList))
  );
}

export function prefetchMovieboxHome(): void {
  void fetchMovieboxHome().catch(() => {});
}

export async function fetchCategorySeries(
  category: 'anime' | 'cartoon',
  page: number = 1
): Promise<PaginatedApiResponse> {
  const cleanPage = Math.max(1, page);
  return dedupeCached(
    `cat:${category}:series:${cleanPage}`,
    CATALOG_TTL_MS,
    () => apiGet<PaginatedApiResponse>(`/${category}/series?page=${cleanPage}`),
    (d) => Boolean(d?.success)
  );
}

export async function fetchCategoryMovies(
  category: 'anime' | 'cartoon',
  page: number = 1
): Promise<PaginatedApiResponse> {
  const cleanPage = Math.max(1, page);
  return dedupeCached(
    `cat:${category}:movies:${cleanPage}`,
    CATALOG_TTL_MS,
    () => apiGet<PaginatedApiResponse>(`/${category}/movies?page=${cleanPage}`),
    (d) => Boolean(d?.success)
  );
}

export async function fetchLanguageSeries(
  language: string,
  page: number = 1
): Promise<PaginatedApiResponse> {
  const cleanLang = language.toLowerCase().trim();
  const cleanPage = Math.max(1, page);
  return dedupeCached(
    `lang:${cleanLang}:series:${cleanPage}`,
    CATALOG_TTL_MS,
    () => apiGet<PaginatedApiResponse>(`/${cleanLang}/series?page=${cleanPage}`),
    (d) => Boolean(d?.success)
  );
}

export async function fetchLanguageMovies(
  language: string,
  page: number = 1
): Promise<PaginatedApiResponse> {
  const cleanLang = language.toLowerCase().trim();
  const cleanPage = Math.max(1, page);
  return dedupeCached(
    `lang:${cleanLang}:movies:${cleanPage}`,
    CATALOG_TTL_MS,
    () => apiGet<PaginatedApiResponse>(`/${cleanLang}/movies?page=${cleanPage}`),
    (d) => Boolean(d?.success)
  );
}

export async function fetchLatestReleases(
  page: number = 1
): Promise<LatestReleasesApiResponse> {
  const cleanPage = Math.max(1, page);
  return dedupeCached(
    `latest:${cleanPage}`,
    CATALOG_TTL_MS,
    () => apiGet<LatestReleasesApiResponse>(`/latest-releases?page=${cleanPage}`),
    (d) => Boolean(d?.success)
  );
}

export async function fetchCategoryCatalog(
  category: 'anime' | 'cartoon',
  subType: 'all' | 'series' | 'movies',
  page: number = 1
): Promise<{
  seriesRes: PaginatedApiResponse | null;
  moviesRes: PaginatedApiResponse | null;
}> {
  const isAll = subType === 'all';
  const apiPage = isAll ? Math.ceil(page / 2) : page;

  const shouldFetchSeries = isAll || subType === 'series';
  const shouldFetchMovies = isAll || subType === 'movies';

  const [seriesRes, moviesRes] = await Promise.all([
    shouldFetchSeries ? fetchCategorySeries(category, apiPage) : Promise.resolve(null),
    shouldFetchMovies ? fetchCategoryMovies(category, apiPage) : Promise.resolve(null),
  ]);

  return { seriesRes, moviesRes };
}

export async function fetchLanguageCatalog(
  language: string,
  subType: 'all' | 'series' | 'movies',
  page: number = 1
): Promise<{
  seriesRes: PaginatedApiResponse | null;
  moviesRes: PaginatedApiResponse | null;
}> {
  const isAll = subType === 'all';
  const apiPage = isAll ? Math.ceil(page / 2) : page;

  const shouldFetchSeries = isAll || subType === 'series';
  const shouldFetchMovies = isAll || subType === 'movies';

  const [seriesRes, moviesRes] = await Promise.all([
    shouldFetchSeries ? fetchLanguageSeries(language, apiPage) : Promise.resolve(null),
    shouldFetchMovies ? fetchLanguageMovies(language, apiPage) : Promise.resolve(null),
  ]);

  return { seriesRes, moviesRes };
}

export interface ContactSubmissionPayload {
  name: string;
  email: string;
  subject: string;
  category: string;
  message: string;
}

export interface DmcaSubmissionPayload {
  ownerName: string;
  email: string;
  copyrightWork: string;
  infringingUrls: string;
  goodFaithStatement: boolean;
  accuracyStatement: boolean;
}

export interface ApiResponseResult {
  success: boolean;
  message?: string;
  error?: string;
  fileName?: string;
  filePath?: string;
  record?: any;
}

export async function submitContactInquiry(
  payload: ContactSubmissionPayload
): Promise<ApiResponseResult> {
  const response = await fetch('/api/contact', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const data = await response.json();
  if (!response.ok || !data.success) {
    throw new Error(data.error || 'Failed to submit contact inquiry');
  }
  return data;
}

export async function submitDmcaNotice(
  payload: DmcaSubmissionPayload
): Promise<ApiResponseResult> {
  const response = await fetch('/api/dmca', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const data = await response.json();
  if (!response.ok || !data.success) {
    throw new Error(data.error || 'Failed to submit DMCA notice');
  }
  return data;
}

function resolveDisplayTitle(raw: AnimeInfoData): string {
  const primary = String(raw.title || '').trim();
  if (primary) return primary;

  const altSingular = String(raw.alternative_title || '').trim();
  if (altSingular) return altSingular;

  const altList = Array.isArray(raw.alternative_titles)
    ? raw.alternative_titles.map((t) => String(t || '').trim()).filter(Boolean)
    : [];
  if (altList.length > 0) return altList[0];

  return 'Untitled';
}

function normalizeAnimeInfoResponse(
  res: AnimeInfoApiResponse,
  fallbackId: string
): AnimeInfoApiResponse {
  if (!res || !res.anime) return res;

  const anime = res.anime as AnimeInfoData & {
    anime_id?: string;
    reanime_id?: string;
    slug?: string;
  };

  const title = resolveDisplayTitle(anime);

  const resolvedId = String(
    anime.id ||
    anime.anime_id ||
    anime.reanime_id ||
    anime.slug ||
    fallbackId ||
    ''
  ).trim();

  return {
    ...res,
anime: {
  ...anime,
  id: resolvedId,
  title,
  subjectId: String(
    (anime as any).subjectId ??
    (anime as any).subject_id ??
    ''
  ).trim() || undefined,
},
  };
}

export async function fetchMovieboxInfo(
  detailPath: string,
  subjectId?: string
): Promise<MovieboxInfoApiResponse> {
  const clean = String(detailPath || '').trim();
  const cleanSubjectId = String(subjectId || '').trim();

  if (!clean && !cleanSubjectId) {
    throw new Error('Info requires a detailPath or subjectId.');
  }

  const cacheKey = `moviebox:info:${clean}:${cleanSubjectId}`;

  return dedupeCached(
    cacheKey,
    INFO_TTL_MS,
    async () => {
      const qs = new URLSearchParams({ detailPath: clean });

      if (cleanSubjectId) {
        qs.set('subjectId', cleanSubjectId);
      }

      const url = `${MOVIEBOX_API_BASE}/api/info?${qs.toString()}`;

      const res = await fetchWithTimeout(url, {
        headers: { Accept: 'application/json' },
      });

      if (!res.ok) {
        throw new Error(`Info failed: HTTP ${res.status}`);
      }

      return (await res.json()) as MovieboxInfoApiResponse;
    },
    (d) => Boolean(d?.success && d?.anime)
  );
}

function adaptMovieboxInfo(a: MovieboxInfoData): AnimeInfoData {
  return {
    id: a.id,
    subjectId: a.subjectId,
    title: a.title,
    type: a.type,
    image: a.image,
    backdrop: a.backdrop || a.image,
    overview: a.overview,
    year: a.year,
    genres: Array.isArray(a.genres) ? a.genres : [],
    languages: Array.isArray(a.languages) ? a.languages : [],
    networks: Array.isArray(a.networks) ? a.networks : [],
    recommendations: (a.recommendations || []).map((r) => ({
      id: r.id,
      title: r.title,
      image: r.image,
    })),
    duration: a.duration,
    seasons: a.seasons,
    episodes: a.episodes,
    episodeDuration: a.episodeDuration,
    seasonsList: (a.seasonsList || []).map((s) => ({
      season: s.season,
      link: s.link,
      episodeCount: s.episodeCount,
      episodes: (s.episodes || []).map((e) => ({
        number: e.number,
        title: e.title,
        id: e.id,
        image: e.image,
      })),
    })),
    watchServers: (a.watchServers || []).map((w) => ({
      name: w.name,
      url: w.url,
    })),
    anilist_id: undefined,
    mal_id: undefined,
    tmdb_id: undefined,
    season: undefined,
    status: undefined,
    studios: undefined,
    external_links: undefined,
    related_seasons_and_series: undefined,
  };
}

export async function fetchAnimeInfo(
  id: string,
  anilistId?: number | null,
  subjectId?: string
): Promise<AnimeInfoApiResponse> {
  const cleanId = String(id || '').trim();

  const validAnilist =
    anilistId != null && Number(anilistId) > 0
      ? Number(anilistId)
      : null;

  const cleanSubjectId = String(subjectId || '').trim();

  const cacheKey = `info:${cleanId}:${validAnilist ?? ''}:${cleanSubjectId}`;

  return dedupeCached(
    cacheKey,
    INFO_TTL_MS,
    async () => {
      const source = detectInfoSource(cleanId);

if (source === 'moviebox') {
  const isNumericId = /^\d+$/.test(cleanId);

  const detailPath = isNumericId ? '' : cleanId;

  const movieboxSubjectId = isNumericId
    ? cleanId
    : cleanSubjectId;

  const mb = await fetchMovieboxInfo(
    detailPath,
    movieboxSubjectId || undefined
  );

  if (!mb?.success || !mb.anime) {
    throw new Error('Info returned no data.');
  }

  return normalizeAnimeInfoResponse(
    { success: true, anime: adaptMovieboxInfo(mb.anime) },
    cleanId
  );
}

      const params = new URLSearchParams({ id: cleanId });

      if (validAnilist != null) {
        params.set('anilistid', String(validAnilist));
      }

      const res = await apiGet<AnimeInfoApiResponse>(
        `/info?${params.toString()}`
      );

      return normalizeAnimeInfoResponse(res, cleanId);
    },
    (d) => Boolean(d?.anime?.id)
  );
}

export function prefetchAnimeInfo(id: string, anilistId?: number | null): void {
  const cleanId = String(id || '').trim();
  if (!cleanId) return;
  void fetchAnimeInfo(cleanId, anilistId).catch(() => {});
}

export async function fetchEpisodeExtract(episodeUrl: string): Promise<EpisodeExtractApiResponse> {
  const cleanUrl = episodeUrl.trim();
  return dedupeCached(
    `extract:url:${cleanUrl}`,
    EXTRACT_TTL_MS,
    async () => {
      const url = `https://anime.streamindia.co.in/api/extract?url=${encodeURIComponent(cleanUrl)}`;

      const response = await fetchWithTimeout(url, {
        headers: {
          Accept: 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`Extract API failed with status ${response.status}`);
      }

      const data = await response.json();
      return data as EpisodeExtractApiResponse;
    },
    (d) => Boolean(d)
  );
}

export async function fetchEpisodeExtractById(episodeId: string): Promise<EpisodeExtractApiResponse> {
  const cleanId = episodeId.trim().replace(/^\/+/, '');
  if (!cleanId) {
    throw new Error('fetchEpisodeExtractById: empty episode id');
  }
  return dedupeCached(
    `extract:id:${cleanId}`,
    EXTRACT_TTL_MS,
    async () => {
      const url = `${API_BASE_URL}/extract?id=${encodeURIComponent(cleanId)}`;

      const response = await fetchWithTimeout(url, {
        headers: {
          Accept: 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`Extract API failed with status ${response.status}`);
      }

      const data = await response.json();
      return data as EpisodeExtractApiResponse;
    },
    (d) => Boolean(d)
  );
}

export interface DownloadLink {
  server: string;
  lang: string;
  quality: string;
  link: string;
}

export interface DownloadApiResponse {
  success: boolean;
  id: string;
  type: 'movie' | 'episode';
  source?: string;
  downloads: DownloadLink[];
  _fromCache?: boolean;
}

export async function fetchDownloadLinks(
  id: string
): Promise<DownloadApiResponse> {
  const cleanId = id.trim();
  const params = new URLSearchParams({ id: cleanId });
  return dedupeCached(
    `download:${cleanId}`,
    2 * 60 * 1000,
    () => apiGet<DownloadApiResponse>(`/toonplay/download?${params.toString()}`),
    (d) => Boolean(d?.success && d?.downloads?.length)
  );
}

export interface LocalDownloadSource {
  quality: string;
  url: string;
}

export interface LocalDownloadEpisode {
  episode: number;
  title?: string;
  sources: LocalDownloadSource[];
}

export interface LocalDownloadSeason {
  season: number;
  episodes: LocalDownloadEpisode[];
}

export interface LocalDownloadFile {
  title?: string;
  slug?: string;
  seasons: LocalDownloadSeason[];
}

export async function fetchLocalDownloadFile(
  animeId: string
): Promise<LocalDownloadFile | null> {
  const cleanId = animeId.trim();
  if (!cleanId) return null;

  return dedupeCached(
    `localdownload:${cleanId}`,
    STATIC_DATA_TTL_MS,
    async () => {
      const safePath = cleanId
        .split('/')
        .map((seg) => encodeURIComponent(seg))
        .join('/');

      try {
        const res = await fetchWithTimeout(`/download/${safePath}.json`, {
          headers: { Accept: 'application/json' },
        });
        if (!res.ok) return null;
        const data = await res.json();
        if (!data || !Array.isArray(data.seasons)) return null;
        return data as LocalDownloadFile;
      } catch {
        return null;
      }
    },
    (d) => d !== null
  );
}

export interface AvatarCatalogItem {
  id?: string | number;
  src: string;
  alt: string;
  tags?: string[];
  source?: 'builtin' | 'external';
}

export interface AvatarCatalogCategory {
  label: string;
  avatars: AvatarCatalogItem[];
}

export interface BannerCatalogItem {
  id: string | number;
  category: string;
  url: string;
  label: string;
  isDefault?: boolean;
}

export interface BannerCatalogCategory {
  label: string;
  banners: BannerCatalogItem[];
}

export interface FrameCatalogItem {
  id: string;
  name: string;
  category: string;
  url: string;
  filename: string;
}

export interface FrameCatalogCategory {
  label: string;
  frames: FrameCatalogItem[];
}

export const ANIMERULZ_CDN_BASE = 'https://animerulz.watch';
export const DEFAULT_PROFILE_BANNER_URL =
  'https://artworks.thetvdb.com/banners/v4/series/81797/backgrounds/6082a16f1aa8f.jpg';

const LEGACY_AVATAR_CATALOG_URL = 'https://animerulz.watch/profile-icons/icons.json';
export const PROFILE_AVATARS_EXTERNAL_URL =
  'https://animerulz.watch/apk-profile-data/avatars.json';
export const PROFILE_BANNERS_EXTERNAL_URL =
  'https://animerulz.watch/apk-profile-data/banners.json';
export {
  PROFILE_FRAMES_REPO,
  PROFILE_FRAMES_COMMIT,
  PROFILE_FRAMES_DIR,
  PROFILE_FRAME_FILENAMES,
  buildProfileFrameCdnUrl,
  buildProfileFrameCatalog,
};
export const PROFILE_FRAMES_CDN_BASE = PROFILE_FRAMES_CDN_PREFIX;
export const PROFILE_FRAMES_API_URL = '/api/profile/frames';

/**
 * Returns true only for valid URLs pointing to the authoritative pinned jsDelivr
 * dc-decorations collection. Rejects retired legacy frame sources.
 */
export function isAuthoritativeProfileFrameUrl(url?: string | null): boolean {
  const trimmed = String(url || '').trim();
  if (!trimmed || !trimmed.startsWith(PROFILE_FRAMES_CDN_BASE)) return false;
  const rest = trimmed.slice(PROFILE_FRAMES_CDN_BASE.length);
  if (!rest || rest.includes('/') || rest.includes('?') || rest.includes('#') || rest.includes('..')) {
    return false;
  }
  return /\.(png|webp|gif|apng)$/i.test(rest);
}

/**
 * Returns ordered display candidate URLs for an authoritative pinned frame URL:
 * 1) Primary jsDelivr CDN (canonical stored URL)
 * 2) Fastly jsDelivr edge (automatic fallback if cdn.jsdelivr.net is throttled/blocked by ISP)
 * 3) Raw GitHub pinned commit URL (final fallback for the exact same immutable file)
 */
export function getProfileFrameCandidateUrls(url?: string | null): string[] {
  const trimmed = String(url || '').trim();
  if (!isAuthoritativeProfileFrameUrl(trimmed)) return [];
  const encodedFile = trimmed.slice(PROFILE_FRAMES_CDN_BASE.length);
  return [
    trimmed,
    `https://fastly.jsdelivr.net/gh/${PROFILE_FRAMES_REPO}@${PROFILE_FRAMES_COMMIT}/${PROFILE_FRAMES_DIR}/${encodedFile}`,
    `https://raw.githubusercontent.com/${PROFILE_FRAMES_REPO}/${PROFILE_FRAMES_COMMIT}/${PROFILE_FRAMES_DIR}/${encodedFile}`,
  ];
}

function normalizeAssetUrl(raw: string, base: string = ANIMERULZ_CDN_BASE): string {
  const trimmed = String(raw || '').trim();
  if (!trimmed) return '';
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  return `${base.replace(/\/+$/, '')}/${trimmed.replace(/^\/+/, '')}`;
}

export async function fetchAvatarCatalog(): Promise<AvatarCatalogCategory[]> {
  return dedupeCached(
    'avatars:catalog:merged:v2',
    STATIC_DATA_TTL_MS,
    async () => {
      const [legacyRes, externalRes] = await Promise.allSettled([
        fetchWithTimeout(LEGACY_AVATAR_CATALOG_URL, {
          timeoutMs: 10000,
          credentials: 'omit',
          mode: 'cors',
          headers: { Accept: 'application/json' },
        }).then(async (res) => {
          if (!res.ok) throw new Error(`HTTP ${res.status} ${res.statusText}`);
          const text = await res.text();
          if (!text.trim().startsWith('{')) {
            throw new Error(`Non-JSON legacy avatar response: ${text.slice(0, 80)}`);
          }
          const data = JSON.parse(text);
          if (!Array.isArray(data?.categories)) {
            throw new Error('Unexpected legacy avatar catalog shape');
          }
          return data.categories as any[];
        }),
        fetchWithTimeout(PROFILE_AVATARS_EXTERNAL_URL, {
          timeoutMs: 12000,
          credentials: 'omit',
          mode: 'cors',
          headers: { Accept: 'application/json' },
        }).then(async (res) => {
          if (!res.ok) throw new Error(`HTTP ${res.status} ${res.statusText}`);
          const text = await res.text();
          if (!text.trim().startsWith('[')) {
            throw new Error(`Non-JSON external avatar response: ${text.slice(0, 80)}`);
          }
          const data = JSON.parse(text);
          if (!Array.isArray(data)) {
            throw new Error('Unexpected external avatar list shape');
          }
          return data as Array<{ id?: number | string; tags?: string[]; url?: string }>;
        }),
      ]);

      if (legacyRes.status === 'rejected' && externalRes.status === 'rejected') {
        console.warn('[fetchAvatarCatalog] both sources failed:', legacyRes.reason, externalRes.reason);
        throw new Error('Could not load avatars from external sources.');
      }

      const categoryMap = new Map<string, AvatarCatalogItem[]>();
      const seenGlobalUrls = new Set<string>();

      const addToCategory = (label: string, item: AvatarCatalogItem) => {
        const cleanLabel = String(label || 'Other').trim() || 'Other';
        let bucket = categoryMap.get(cleanLabel);
        if (!bucket) {
          bucket = [];
          categoryMap.set(cleanLabel, bucket);
        }
        if (!bucket.some((existing) => existing.src === item.src)) {
          bucket.push(item);
        }
      };

      // 1. Preserve ALL existing avatars from icons.json first
      if (legacyRes.status === 'fulfilled') {
        for (const c of legacyRes.value) {
          const label = String(c?.label || 'Other').trim() || 'Other';
          const list = Array.isArray(c?.avatars) ? c.avatars : [];
          for (const a of list) {
            if (!a || typeof a.src !== 'string') continue;
            const resolvedUrl = normalizeAssetUrl(a.src);
            if (!resolvedUrl || seenGlobalUrls.has(resolvedUrl)) continue;
            seenGlobalUrls.add(resolvedUrl);
            addToCategory(label, {
              src: resolvedUrl,
              alt: String(a.alt || a.src.split('/').pop() || 'Avatar'),
              tags: [label],
              source: 'builtin',
            });
          }
        }
      } else {
        console.warn('[fetchAvatarCatalog] legacy icons.json unavailable:', legacyRes.reason);
      }

      // 2. Append ALL external avatars from apk-profile-data/avatars.json grouped by tags
      if (externalRes.status === 'fulfilled') {
        const externalGroups = new Map<string, AvatarCatalogItem[]>();
        for (const entry of externalRes.value) {
          if (!entry || typeof entry.url !== 'string') continue;
          const resolvedUrl = normalizeAssetUrl(entry.url);
          if (!resolvedUrl || seenGlobalUrls.has(resolvedUrl)) continue;
          seenGlobalUrls.add(resolvedUrl);

          const tags = Array.isArray(entry.tags)
            ? entry.tags.map((t) => String(t || '').trim()).filter(Boolean)
            : [];
          const primaryTag = tags[0] || 'Anime';
          const labelParts = tags.length > 0 ? tags.join(' · ') : 'Anime';
          const alt = `${labelParts} #${entry.id ?? ''}`.trim();

          const item: AvatarCatalogItem = {
            id: entry.id,
            src: resolvedUrl,
            alt,
            tags: tags.length > 0 ? tags : ['Anime'],
            source: 'external',
          };

          // Place under primary tag (and secondary tags if multi-tagged) without duplicating inside a category
          const targetTags = tags.length > 0 ? tags : [primaryTag];
          for (const tag of targetTags) {
            let group = externalGroups.get(tag);
            if (!group) {
              group = [];
              externalGroups.set(tag, group);
            }
            group.push(item);
          }
        }

        const sortedExternalTags = Array.from(externalGroups.keys()).sort((a, b) =>
          a.localeCompare(b)
        );
        for (const tag of sortedExternalTags) {
          const items = externalGroups.get(tag) || [];
          for (const item of items) {
            addToCategory(tag, item);
          }
        }
      } else {
        console.warn('[fetchAvatarCatalog] external avatars.json unavailable:', externalRes.reason);
      }

      return Array.from(categoryMap.entries())
        .filter(([, avatars]) => avatars.length > 0)
        .map(([label, avatars]) => ({ label, avatars }));
    },
    (cats) => Array.isArray(cats) && cats.length > 0
  );
}

export async function fetchBannerCatalog(): Promise<{
  categories: BannerCatalogCategory[];
  all: BannerCatalogItem[];
  defaultBannerUrl: string;
}> {
  return dedupeCached(
    'banners:catalog:v1',
    STATIC_DATA_TTL_MS,
    async () => {
      const res = await fetchWithTimeout(PROFILE_BANNERS_EXTERNAL_URL, {
        timeoutMs: 12000,
        credentials: 'omit',
        mode: 'cors',
        headers: { Accept: 'application/json' },
      });

      if (!res.ok) {
        throw new Error(`HTTP ${res.status} ${res.statusText}`);
      }

      const text = await res.text();
      if (!text.trim().startsWith('[')) {
        throw new Error(`Non-JSON banner response: ${text.slice(0, 80)}`);
      }

      const raw = JSON.parse(text);
      if (!Array.isArray(raw)) {
        throw new Error('Unexpected banner list shape');
      }

      const seen = new Set<string>();
      const all: BannerCatalogItem[] = [];
      const categoryMap = new Map<string, BannerCatalogItem[]>();

      const pushItem = (item: BannerCatalogItem) => {
        if (!item.url || seen.has(item.url)) return;
        seen.add(item.url);
        all.push(item);
        let bucket = categoryMap.get(item.category);
        if (!bucket) {
          bucket = [];
          categoryMap.set(item.category, bucket);
        }
        bucket.push(item);
      };

      // Preserve existing default banner as an explicit Default option
      pushItem({
        id: 'default',
        category: 'Default',
        url: DEFAULT_PROFILE_BANNER_URL,
        label: 'Default ToonPlay Banner',
        isDefault: true,
      });

      const externalCategories = new Map<string, BannerCatalogItem[]>();
      for (const entry of raw) {
        if (!entry || typeof entry.url !== 'string') continue;
        const url = normalizeAssetUrl(entry.url);
        if (!url || seen.has(url)) continue;
        const category = String(entry.category || 'Anime').trim() || 'Anime';
        const item: BannerCatalogItem = {
          id: entry.id ?? url,
          category,
          url,
          label: `${category} #${entry.id ?? ''}`.trim(),
        };
        seen.add(url);
        all.push(item);
        let bucket = externalCategories.get(category);
        if (!bucket) {
          bucket = [];
          externalCategories.set(category, bucket);
        }
        bucket.push(item);
      }

      const sortedCategories = Array.from(externalCategories.keys()).sort((a, b) =>
        a.localeCompare(b)
      );
      for (const cat of sortedCategories) {
        categoryMap.set(cat, externalCategories.get(cat) || []);
      }

      const categories: BannerCatalogCategory[] = Array.from(categoryMap.entries())
        .filter(([, banners]) => banners.length > 0)
        .map(([label, banners]) => ({ label, banners }));

      return {
        categories,
        all,
        defaultBannerUrl: DEFAULT_PROFILE_BANNER_URL,
      };
    },
    (d) => Boolean(d && Array.isArray(d.all) && d.all.length > 0)
  );
}

export async function fetchFrameCatalog(): Promise<{
  categories: FrameCatalogCategory[];
  all: FrameCatalogItem[];
}> {
  return dedupeCached(
    `frames:catalog:dc-decorations:${PROFILE_FRAMES_COMMIT.slice(0, 10)}`,
    STATIC_DATA_TTL_MS,
    async () => {
      if (typeof window !== 'undefined' && typeof fetch === 'function') {
        try {
          const res = await fetchWithTimeout(PROFILE_FRAMES_API_URL, {
            timeoutMs: 5000,
            headers: { Accept: 'application/json' },
          });
          if (res.ok) {
            const data = await res.json();
            if (
              Array.isArray(data?.categories) &&
              Array.isArray(data?.all) &&
              data.all.length > 0
            ) {
              return {
                categories: data.categories as FrameCatalogCategory[],
                all: data.all as FrameCatalogItem[],
              };
            }
          }
        } catch {
          // Fallback to deterministic local catalog below
        }
      }
      return buildProfileFrameCatalog();
    },
    (d) => Boolean(d && Array.isArray(d.all) && d.all.length > 0)
  );
}

export async function fetchStreamServers(
  anilistId: number,
  episode: number
): Promise<StreamApiResponse> {
  const cleanId = Math.max(1, Number(anilistId) || 0);
  const cleanEp = Math.max(1, Number(episode) || 1);
  if (!cleanId) {
    return { anilist_id: 0, episode: cleanEp, servers: [], success: false };
  }
  const url = `${API_BASE_URL}/stream?anilist_id=${cleanId}&episode=${cleanEp}`;
  return dedupeCached(
    `stream:${cleanId}:${cleanEp}`,
    STREAM_TTL_MS,
    async () => {
      try {
        const res = await fetchWithTimeout(url, {
          headers: { Accept: 'application/json' },
        });
        if (!res.ok) {
          return { anilist_id: cleanId, episode: cleanEp, servers: [], success: false };
        }
        const data = await res.json();
        return data as StreamApiResponse;
      } catch {
        return { anilist_id: cleanId, episode: cleanEp, servers: [], success: false };
      }
    },
    (d) => Boolean(d?.success && d?.servers?.length)
  );
}

export async function fetchRavokLanguages(videoId: string): Promise<{
  success: boolean;
  tracks: Array<{ code: string; name: string }>;
}> {
  const cleanId = videoId.trim();
  const fallback = {
    success: true,
    tracks: [
      { code: 'hin', name: 'Hindi' },
      { code: 'eng', name: 'English' },
      { code: 'jpn', name: 'Japanese' },
    ],
  };

  if (!cleanId) return fallback;

  return dedupeCached(
    `ravok:${cleanId}`,
    STATIC_DATA_TTL_MS,
    async () => {
      try {
        const res = await fetchWithTimeout(`/api/ravok-languages?id=${encodeURIComponent(cleanId)}`, {
          timeoutMs: 8000,
        });
        if (!res.ok) return fallback;
        const data = await res.json();
        return data;
      } catch {
        return fallback;
      }
    },
    (d) => Boolean(d?.success && Array.isArray(d?.tracks) && d.tracks.length > 0)
  );
}

export default {
  API_BASE_URL,
  detectInfoSource,
  fetchHomeContent,
  getCachedHomeContent,
  prefetchHomeContent,
  searchCatalog,
  fetchMovieboxSearch,
  fetchMovieboxHome,
  getCachedMovieboxHome,
  prefetchMovieboxHome,
  fetchMovieboxInfo,
  fetchCategorySeries,
  fetchCategoryMovies,
  fetchLanguageSeries,
  fetchLanguageMovies,
  fetchLatestReleases,
  fetchCategoryCatalog,
  fetchLanguageCatalog,
  submitContactInquiry,
  submitDmcaNotice,
  fetchAnimeInfo,
  prefetchAnimeInfo,
  fetchEpisodeExtract,
  fetchEpisodeExtractById,
  fetchRavokLanguages,
  fetchStreamServers,
  fetchAvatarCatalog,
  fetchBannerCatalog,
  fetchFrameCatalog,
  fetchDownloadLinks,
  fetchLocalDownloadFile,
};