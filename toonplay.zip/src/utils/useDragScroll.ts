import {
  useRef,
  useCallback,
  useEffect,
  useMemo,
  PointerEvent as ReactPointerEvent,
} from 'react';

const DRAG_THRESHOLD_PX = 5;
const MAX_VELOCITY_PX_PER_MS = 2.8;
const MIN_MOMENTUM_VELOCITY = 0.12;
const STOP_MOMENTUM_VELOCITY = 0.04;
const VELOCITY_STALE_MS = 85;
const FRICTION_PER_60HZ_FRAME = 0.94;

/**
 * Smooth desktop mouse drag-to-scroll hook with zero React re-renders during drag.
 * - Preserves 100% native touch/trackpad scrolling (only intercepts primary mouse button).
 * - Batches `scrollLeft` updates via `requestAnimationFrame` (prevents 1000Hz mouse jank).
 * - Uses EMA-smoothed velocity + staleness cutoff + refresh-rate-normalized momentum decay.
 * - Cleans up all window listeners, rAF loops, and timers on unmount.
 */
export function useDragScroll<T extends HTMLElement = HTMLDivElement>() {
  const ref = useRef<T | null>(null);

  const isDownRef = useRef(false);
  const startXRef = useRef(0);
  const startScrollLeftRef = useRef(0);
  const pendingScrollLeftRef = useRef<number | null>(null);
  const hasDraggedRef = useRef(false);

  const lastXRef = useRef(0);
  const lastTimeRef = useRef(0);
  const velocityRef = useRef(0);

  const dragRafRef = useRef<number | null>(null);
  const momentumRafRef = useRef<number | null>(null);
  const resetTimerRef = useRef<number | null>(null);
  const cleanupActiveDragRef = useRef<(() => void) | null>(null);

  const stopMomentum = useCallback(() => {
    if (momentumRafRef.current !== null) {
      cancelAnimationFrame(momentumRafRef.current);
      momentumRafRef.current = null;
    }
  }, []);

  const stopDragRaf = useCallback(() => {
    if (dragRafRef.current !== null) {
      cancelAnimationFrame(dragRafRef.current);
      dragRafRef.current = null;
    }
    pendingScrollLeftRef.current = null;
  }, []);

  const handlePointerDown = useCallback(
    (e: ReactPointerEvent<T>) => {
      const el = ref.current;
      if (!el) return;
      // Preserve native touch/pen scrolling so horizontal drags never block vertical scroll
      if (e.pointerType !== 'mouse' || e.button !== 0) return;

      // Ignore clicks on interactive controls inside the container (buttons/inputs)
      const target = e.target as HTMLElement | null;
      if (target && target.closest('input, textarea, select')) return;

      // Only engage drag if container actually overflows horizontally
      if (el.scrollWidth <= el.clientWidth + 1) return;

      e.preventDefault();

      cleanupActiveDragRef.current?.();
      stopMomentum();
      stopDragRaf();

      if (resetTimerRef.current !== null) {
        window.clearTimeout(resetTimerRef.current);
        resetTimerRef.current = null;
      }

      const activeEl = document.activeElement as HTMLElement | null;
      const pointerId = e.pointerId;
      const originalScrollBehavior = el.style.scrollBehavior;

      isDownRef.current = true;
      startXRef.current = e.clientX;
      startScrollLeftRef.current = el.scrollLeft;
      hasDraggedRef.current = false;

      lastXRef.current = e.clientX;
      lastTimeRef.current = performance.now();
      velocityRef.current = 0;

      el.style.scrollBehavior = 'auto';
      el.classList.add('tp-is-dragging');
      el.style.cursor = 'grabbing';
      el.style.userSelect = 'none';

      const flushDragScroll = () => {
        dragRafRef.current = null;
        const container = ref.current;
        if (!container || pendingScrollLeftRef.current === null) return;
        container.scrollLeft = pendingScrollLeftRef.current;
        pendingScrollLeftRef.current = null;
      };

      const onPointerMove = (moveEvent: PointerEvent) => {
        if (!isDownRef.current || !ref.current) return;
        if (moveEvent.pointerId !== pointerId) return;

        const currentX = moveEvent.clientX;
        const currentTime = performance.now();
        const deltaX = currentX - lastXRef.current;
        const totalDiff = currentX - startXRef.current;

        if (!hasDraggedRef.current && Math.abs(totalDiff) > DRAG_THRESHOLD_PX) {
          hasDraggedRef.current = true;
        }

        const dt = currentTime - lastTimeRef.current;
        if (dt >= 4) {
          const instantVelocity = deltaX / dt;
          velocityRef.current =
            velocityRef.current === 0
              ? instantVelocity
              : velocityRef.current * 0.35 + instantVelocity * 0.65;
          lastXRef.current = currentX;
          lastTimeRef.current = currentTime;
        }

        pendingScrollLeftRef.current = startScrollLeftRef.current - totalDiff;
        if (dragRafRef.current === null) {
          dragRafRef.current = requestAnimationFrame(flushDragScroll);
        }
      };

      const restoreElementStyles = (container: T | null, restoreScrollBehavior: boolean) => {
        if (!container) return;
        container.classList.remove('tp-is-dragging');
        container.style.cursor = 'grab';
        container.style.userSelect = '';
        if (restoreScrollBehavior) {
          container.style.scrollBehavior = originalScrollBehavior;
        }
      };

      const detachWindowListeners = () => {
        window.removeEventListener('pointermove', onPointerMove);
        window.removeEventListener('pointerup', onPointerUp);
        window.removeEventListener('pointercancel', onPointerUp);
        cleanupActiveDragRef.current = null;
      };

      const onPointerUp = () => {
        if (!isDownRef.current) return;
        isDownRef.current = false;
        detachWindowListeners();

        // Flush any last pending scroll frame immediately
        if (dragRafRef.current !== null) {
          cancelAnimationFrame(dragRafRef.current);
          dragRafRef.current = null;
        }
        const container = ref.current;
        if (container && pendingScrollLeftRef.current !== null) {
          container.scrollLeft = pendingScrollLeftRef.current;
          pendingScrollLeftRef.current = null;
        }

        if (hasDraggedRef.current) {
          if (activeEl && activeEl !== document.body && typeof activeEl.blur === 'function') {
            activeEl.blur();
          }

          const preventClick = (clickEvent: MouseEvent) => {
            clickEvent.stopPropagation();
            clickEvent.preventDefault();
          };

          window.addEventListener('click', preventClick, { capture: true, once: true });
          resetTimerRef.current = window.setTimeout(() => {
            window.removeEventListener('click', preventClick, { capture: true });
            hasDraggedRef.current = false;
            resetTimerRef.current = null;
          }, 120);
        }

        if (!container) return;

        // If user paused before releasing, suppress unintended flick momentum
        const timeSinceLastMove = performance.now() - lastTimeRef.current;
        let currentVelocity = timeSinceLastMove > VELOCITY_STALE_MS ? 0 : velocityRef.current;

        if (Math.abs(currentVelocity) > MAX_VELOCITY_PX_PER_MS) {
          currentVelocity = Math.sign(currentVelocity) * MAX_VELOCITY_PX_PER_MS;
        }

        const prefersReducedMotion =
          typeof window !== 'undefined' &&
          window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

        if (!prefersReducedMotion && Math.abs(currentVelocity) > MIN_MOMENTUM_VELOCITY) {
          restoreElementStyles(container, false);
          let lastFrameTime = performance.now();

          const applyMomentum = (now: number) => {
            const targetEl = ref.current;
            if (!targetEl || isDownRef.current) {
              momentumRafRef.current = null;
              return;
            }

            const frameDt = Math.min(32, Math.max(1, now - lastFrameTime));
            lastFrameTime = now;

            const maxScroll = targetEl.scrollWidth - targetEl.clientWidth;
            const prevScroll = targetEl.scrollLeft;
            const nextScroll = Math.max(
              0,
              Math.min(maxScroll, prevScroll - currentVelocity * frameDt)
            );
            targetEl.scrollLeft = nextScroll;

            // Normalize decay to 60Hz so 60/90/120/144Hz displays feel identical
            currentVelocity *= Math.pow(FRICTION_PER_60HZ_FRAME, frameDt / 16.667);

            const hitBoundary = nextScroll <= 0 || nextScroll >= maxScroll;
            if (!hitBoundary && Math.abs(currentVelocity) > STOP_MOMENTUM_VELOCITY) {
              momentumRafRef.current = requestAnimationFrame(applyMomentum);
            } else {
              momentumRafRef.current = null;
              targetEl.style.scrollBehavior = originalScrollBehavior;
            }
          };

          momentumRafRef.current = requestAnimationFrame(applyMomentum);
        } else {
          restoreElementStyles(container, true);
        }
      };

      cleanupActiveDragRef.current = () => {
        isDownRef.current = false;
        detachWindowListeners();
        stopDragRaf();
        restoreElementStyles(ref.current, true);
      };

      window.addEventListener('pointermove', onPointerMove, { passive: true });
      window.addEventListener('pointerup', onPointerUp, { passive: true });
      window.addEventListener('pointercancel', onPointerUp, { passive: true });
    },
    [stopMomentum, stopDragRaf]
  );

  useEffect(() => {
    return () => {
      cleanupActiveDragRef.current?.();
      stopMomentum();
      stopDragRaf();
      if (resetTimerRef.current !== null) {
        window.clearTimeout(resetTimerRef.current);
        resetTimerRef.current = null;
      }
    };
  }, [stopMomentum, stopDragRaf]);

  const dragProps = useMemo(
    () => ({
      onPointerDown: handlePointerDown,
      style: { cursor: 'grab' as const },
    }),
    [handlePointerDown]
  );

  return {
    ref,
    isDragging: false,
    hasDragged: false,
    hasDraggedRef,
    dragProps,
  };
}