import { useRef, useState, useCallback, useEffect, PointerEvent as ReactPointerEvent } from 'react';

export function useDragScroll<T extends HTMLElement = HTMLDivElement>() {
  const ref = useRef<T | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [hasDraggedState, setHasDraggedState] = useState(false);

  const isDownRef = useRef(false);
  const startXRef = useRef(0);
  const scrollLeftRef = useRef(0);
  const hasDraggedRef = useRef(false);
  const lastXRef = useRef(0);
  const lastTimeRef = useRef(0);
  const velocityRef = useRef(0);
  const momentumRafRef = useRef<number | null>(null);

  const stopMomentum = useCallback(() => {
    if (momentumRafRef.current !== null) {
      cancelAnimationFrame(momentumRafRef.current);
      momentumRafRef.current = null;
    }
  }, []);

  const handlePointerDown = useCallback((e: ReactPointerEvent<T>) => {
    const el = ref.current;
    if (!el) return;
    if (e.pointerType !== 'mouse') return;
    if (e.button !== 0) return;

    e.preventDefault();

    stopMomentum();

    const activeEl = document.activeElement as HTMLElement | null;

    isDownRef.current = true;
    startXRef.current = e.clientX;
    scrollLeftRef.current = el.scrollLeft;
    hasDraggedRef.current = false;
    setHasDraggedState(false);
    setIsDragging(true);

    lastXRef.current = e.clientX;
    lastTimeRef.current = performance.now();
    velocityRef.current = 0;

    const originalScrollBehavior = el.style.scrollBehavior;
    el.style.scrollBehavior = 'auto';
    const pointerId = e.pointerId;

    const onPointerMove = (moveEvent: PointerEvent) => {
      if (!isDownRef.current || !ref.current) return;
      if (moveEvent.pointerId !== pointerId) return;

      const currentX = moveEvent.clientX;
      const currentTime = performance.now();
      const deltaX = currentX - lastXRef.current;
      const totalDiff = currentX - startXRef.current;

      if (Math.abs(totalDiff) > 4 && !hasDraggedRef.current) {
        hasDraggedRef.current = true;
        setHasDraggedState(true);
      }

      const dt = Math.max(1, currentTime - lastTimeRef.current);
      velocityRef.current = deltaX / dt;

      lastXRef.current = currentX;
      lastTimeRef.current = currentTime;

      ref.current.scrollLeft = scrollLeftRef.current - totalDiff;
    };

    const onPointerUp = () => {
      isDownRef.current = false;
      setIsDragging(false);

      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUp);
      window.removeEventListener('pointercancel', onPointerUp);

      if (hasDraggedRef.current) {
        if (activeEl && activeEl !== document.body) {
          activeEl.blur();
        }

        const preventClick = (clickEvent: MouseEvent) => {
          clickEvent.stopPropagation();
          clickEvent.preventDefault();
        };

        window.addEventListener('click', preventClick, { capture: true, once: true });
        setTimeout(() => {
          hasDraggedRef.current = false;
          setHasDraggedState(false);
        }, 100);
      }

      const container = ref.current;
      if (!container) return;

      let currentVelocity = velocityRef.current;
      if (Math.abs(currentVelocity) > 3) {
        currentVelocity = Math.sign(currentVelocity) * 3;
      }

      if (Math.abs(currentVelocity) > 0.15) {
        let lastFrameTime = performance.now();

        const applyMomentum = () => {
          if (!ref.current || isDownRef.current) return;

          const now = performance.now();
          const frameDt = Math.min(32, now - lastFrameTime);
          lastFrameTime = now;

          ref.current.scrollLeft -= currentVelocity * frameDt;
          currentVelocity *= 0.94;

          if (Math.abs(currentVelocity) > 0.05) {
            momentumRafRef.current = requestAnimationFrame(applyMomentum);
          } else {
            momentumRafRef.current = null;
            if (ref.current) {
              ref.current.style.scrollBehavior = originalScrollBehavior;
            }
          }
        };

        momentumRafRef.current = requestAnimationFrame(applyMomentum);
      } else {
        container.style.scrollBehavior = originalScrollBehavior;
      }
    };

    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);
    window.addEventListener('pointercancel', onPointerUp);
  }, [stopMomentum]);

  useEffect(() => {
    return () => {
      stopMomentum();
    };
  }, [stopMomentum]);

  return {
    ref,
    isDragging,
    hasDragged: hasDraggedState,
    hasDraggedRef,
    dragProps: {
      onPointerDown: handlePointerDown,
      style: {
        cursor: isDragging ? 'grabbing' : 'grab',
        userSelect: isDragging ? ('none' as const) : undefined,
      },
    },
  };
}