import { HomeApiData, UnifiedAnime } from '../types.ts';

export const WATCHLIST_STORAGE_KEY = 'toonplay_watchlist';
export const HISTORY_STORAGE_KEY = 'toonplay_history';

function normalizeStoredDisplayType(list: UnifiedAnime[]): UnifiedAnime[] {
  if (!Array.isArray(list)) return [];
  return list.map((item) => {
    if (!item || typeof item !== 'object') return item;
    const displayType =
      typeof item.displayType === 'string' && item.displayType.trim()
        ? item.displayType.trim().toUpperCase()
        : undefined;
    return displayType ? { ...item, displayType } : item;
  });
}

export function getStoredWatchlist(): UnifiedAnime[] {
  try {
    const raw = localStorage.getItem(WATCHLIST_STORAGE_KEY);
    if (!raw) return [];
    return normalizeStoredDisplayType(JSON.parse(raw));
  } catch (err) {
    console.error('Failed to read watchlist from localStorage', err);
    return [];
  }
}

export function saveStoredWatchlist(list: UnifiedAnime[]): void {
  try {
    localStorage.setItem(WATCHLIST_STORAGE_KEY, JSON.stringify(list));
  } catch (err) {
    console.error('Failed to save watchlist to localStorage', err);
  }
}

export function getStoredHistory(): UnifiedAnime[] {
  try {
    const raw = localStorage.getItem(HISTORY_STORAGE_KEY);
    if (!raw) return [];
    return normalizeStoredDisplayType(JSON.parse(raw));
  } catch (err) {
    console.error('Failed to read history from localStorage', err);
    return [];
  }
}

export function saveStoredHistory(list: UnifiedAnime[]): void {
  try {
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(list));
  } catch (err) {
    console.error('Failed to save history to localStorage', err);
  }
}

export function normalizeApiData(data: HomeApiData): UnifiedAnime[] {
  const result: UnifiedAnime[] = [];
  const seenIds = new Set<string>();

    data.hero?.forEach((item) => {
      if (!seenIds.has(item.id)) {
        seenIds.add(item.id);
        const raw = String(item.type || '').trim().toUpperCase();
        const isMovie = raw === 'MOVIE';
        result.push({
          id: item.id,
          title: item.title,
          image: item.backdrop,
          backdrop: item.backdrop,
          type: isMovie ? 'movie' : 'series',
          displayType: raw || (isMovie ? 'MOVIE' : 'SERIES'),
          overview: item.overview,
          rating: item.rating,
          year: item.year,
          anilistId: item.anilist_id,
          category: 'hero',
        });
      }
    });

    data.latest_releases?.forEach((item) => {
      if (!seenIds.has(item.id)) {
        seenIds.add(item.id);
        const raw = String(item.type || '').trim().toUpperCase();
        const isMovie = raw === 'MOVIE';
        result.push({
          id: item.id,
          title: item.title,
          image: item.image,
          type: isMovie ? 'movie' : 'series',
          displayType: raw || (isMovie ? 'MOVIE' : 'SERIES'),
          season: item.season,
          episodes: item.episodes,
          anilistId: item.anilist_id,
          category: 'latest',
        });
      }
    });

    data.popular_series?.forEach((item) => {
      if (!seenIds.has(item.id)) {
        seenIds.add(item.id);
        result.push({
          id: item.id,
          title: item.title,
          image: item.image,
          type: 'series',
          displayType: 'SERIES',
          anilistId: item.anilist_id,
          category: 'series',
        });
      }
    });

    data.popular_movies?.forEach((item) => {
      if (!seenIds.has(item.id)) {
        seenIds.add(item.id);
        result.push({
          id: item.id,
          title: item.title,
          image: item.image,
          type: 'movie',
          displayType: 'MOVIE',
          anilistId: item.anilist_id,
          category: 'movie',
        });
      }
    });

  return result;
}

export function generateSimulatedEpisodes(title: string, count: number = 12) {
  const episodeNames = [
    'The Awakening Call',
    'A Shadow in the Leaves',
    'Vow of the Warrior',
    'Unleashed Potential',
    'Clash of Destinies',
    'Echoes of the Past',
    'Behind the Mask',
    'The Forbidden Technique',
    'Trial of Fire and Will',
    'Bond of Brotherhood',
    'Storm Over the Horizon',
    'To the Next Horizon',
  ];

  return Array.from({ length: count }, (_, idx) => {
    const num = idx + 1;
    const name = episodeNames[idx % episodeNames.length];
    const duration = `${22 + ((idx * 3) % 4)}m`;
    return {
      episodeNumber: num,
      title: `${num}. ${name}`,
      duration,
      synopsis: `Episode ${num} of ${title}. High-stakes confrontations and revelations unfold as the heroes confront insurmountable odds.`,
    };
  });
}
