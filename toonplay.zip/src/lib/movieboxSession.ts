import {
  buildMovieboxStreamUrl,
  clearMovieboxStreamDubCache,
  fetchMovieboxDubs,
  fetchMovieboxStream,
  normalizeMovieboxApiUrl,
  normalizeMovieboxLanguage,
  type MovieboxDubOption,
  type MovieboxDubsResponse,
  type MovieboxStreamAudioOption,
  type MovieboxStreamResponse,
} from '../api';

export type MovieboxFlowType = 'with-lang' | 'without-lang';

export interface ParsedMovieboxStreamUrl {
  normalizedUrl: string;
  subjectId: string;
  detailPath: string;
  season: number;
  episode: number;
  lang: string;
}

export interface MovieboxPlaybackSession {
  contentId: string;
  originalDetailPath: string;
  originalSubjectId: string;
  originalUrl: string;
  baseStreamUrl: string;
  requestedLanguage: string;
  season: number;
  episode: number;
  flow: MovieboxFlowType;
  /** Complete raw Dub API response when Flow A was used; null in Flow B or on failure. */
  dubsResponse: MovieboxDubsResponse | null;
  /**
   * Preserved available dub/audio options for the lifetime of this session.
   * In Flow A, populated once from the Dub API response and NEVER overwritten by stream responses.
   * In Flow B, populated only from the initial default stream response (0 Dub API calls).
   */
  cachedDubOptions: MovieboxStreamAudioOption[];
  selectedLanguage: string;
  selectedDub: MovieboxStreamAudioOption | null;
  currentStreamUrl: string;
  currentStreamResponse: MovieboxStreamResponse | null;
  currentPlaybackUrl: string | null;
  /** In-memory per-stream cache for this playback session (never persisted to storage). */
  streamCache: Map<string, MovieboxStreamResponse>;
  /** Monotonic sequence guarding against stale async responses during rapid switching. */
  requestSeq: number;
}

export interface MovieboxSessionSnapshot {
  contentId: string;
  flow: MovieboxFlowType;
  requestedLanguage: string;
  dubsResponse: MovieboxDubsResponse | null;
  cachedDubOptions: MovieboxStreamAudioOption[];
  selectedLanguage: string;
  selectedDub: MovieboxStreamAudioOption | null;
  streamUrl: string;
  streamResponse: MovieboxStreamResponse;
  playbackUrl: string;
  fromStreamCache: boolean;
  stale?: boolean;
}

export interface InitializeMovieboxSessionArgs {
  contentId: string;
  originalUrl: string;
  baseStreamUrl: string;
  requestedLanguage?: string | null;
  season?: number;
  episode?: number;
  fallbackDetailPath?: string;
  /** Optional title metadata already loaded from /api/info (e.g. "Love in Disguise [Hindi]"). */
  titleHint?: string;
  /** Optional language list already loaded from /api/info (e.g. ["Original Audio", "French", "Hindi", ...]). */
  availableLanguageHints?: string[];
}

export interface SwitchMovieboxLanguageArgs {
  lanCode?: string;
  language?: string;
  subjectId?: string;
  detailPath?: string;
  label?: string;
  season?: number;
  episode?: number;
}

export interface MovieboxSessionDeps {
  fetchDubs: (detailPath: string) => Promise<MovieboxDubsResponse>;
  fetchStream: (streamUrlOrPath: string) => Promise<MovieboxStreamResponse>;
  onClearTitleCache?: () => void;
}

export function parseMovieboxStreamUrl(streamUrlOrPath: string): ParsedMovieboxStreamUrl {
  const normalizedUrl = normalizeMovieboxApiUrl(streamUrlOrPath);
  try {
    const parsed = new URL(normalizedUrl || '/', 'http://moviebox.local');
    return {
      normalizedUrl,
      subjectId: (parsed.searchParams.get('subjectId') || '').trim(),
      detailPath: (parsed.searchParams.get('detailPath') || '').trim(),
      season: Number(parsed.searchParams.get('se') || 0) || 0,
      episode: Number(parsed.searchParams.get('ep') || 0) || 0,
      lang: (
        parsed.searchParams.get('lang') ||
        parsed.searchParams.get('language') ||
        ''
      ).trim(),
    };
  } catch {
    return {
      normalizedUrl,
      subjectId: '',
      detailPath: '',
      season: 0,
      episode: 0,
      lang: '',
    };
  }
}

/**
 * Extracts a requested MovieBox language strictly from the URL query parameters
 * (either the page URL search string or the stream URL itself).
 * Returns '' when no language parameter is present so Flow B reliably skips the Dub API.
 */
export function extractMovieboxRequestedLanguage(
  pageSearch: string,
  streamUrlOrPath?: string
): string {
  try {
    const params = new URLSearchParams(pageSearch || '');
    const fromPage = (params.get('lang') || params.get('language') || '').trim();
    if (fromPage) return fromPage;
  } catch {
    /* ignore malformed search */
  }

  if (streamUrlOrPath) {
    const parsed = parseMovieboxStreamUrl(streamUrlOrPath);
    if (parsed.lang) return parsed.lang;
  }

  return '';
}

export function mapDubsToAudioOptions(
  dubs: MovieboxDubOption[] | null | undefined
): MovieboxStreamAudioOption[] {
  if (!Array.isArray(dubs)) return [];
  return dubs
    .filter((d) => Boolean(d?.subjectId && d?.detailPath))
    .map((d) => ({
      subjectId: String(d.subjectId),
      detailPath: String(d.detailPath),
      language: String(d.language || d.lanCode || '').trim(),
      lanCode: String(d.lanCode || d.language || '').trim(),
      original: d.original,
      active: false,
    }));
}

const KNOWN_LANGUAGE_CODES: Record<string, { code: string; label: string }> = {
  hi: { code: 'hi', label: 'Hindi' },
  hin: { code: 'hi', label: 'Hindi' },
  hindi: { code: 'hi', label: 'Hindi' },
  en: { code: 'en', label: 'English' },
  eng: { code: 'en', label: 'English' },
  english: { code: 'en', label: 'English' },
  ja: { code: 'ja', label: 'Japanese' },
  jpn: { code: 'ja', label: 'Japanese' },
  jap: { code: 'ja', label: 'Japanese' },
  japanese: { code: 'ja', label: 'Japanese' },
  ta: { code: 'ta', label: 'Tamil' },
  tam: { code: 'ta', label: 'Tamil' },
  tamil: { code: 'ta', label: 'Tamil' },
  te: { code: 'te', label: 'Telugu' },
  tel: { code: 'te', label: 'Telugu' },
  telugu: { code: 'te', label: 'Telugu' },
  ml: { code: 'ml', label: 'Malayalam' },
  mal: { code: 'ml', label: 'Malayalam' },
  malayalam: { code: 'ml', label: 'Malayalam' },
  kn: { code: 'kn', label: 'Kannada' },
  kan: { code: 'kn', label: 'Kannada' },
  kannada: { code: 'kn', label: 'Kannada' },
  bn: { code: 'bn', label: 'Bengali' },
  ben: { code: 'bn', label: 'Bengali' },
  bengali: { code: 'bn', label: 'Bengali' },
  ko: { code: 'ko', label: 'Korean' },
  kor: { code: 'ko', label: 'Korean' },
  korean: { code: 'ko', label: 'Korean' },
  mr: { code: 'mr', label: 'Marathi' },
  mar: { code: 'mr', label: 'Marathi' },
  marathi: { code: 'mr', label: 'Marathi' },
  pa: { code: 'pa', label: 'Punjabi' },
  pan: { code: 'pa', label: 'Punjabi' },
  punjabi: { code: 'pa', label: 'Punjabi' },
  gu: { code: 'gu', label: 'Gujarati' },
  guj: { code: 'gu', label: 'Gujarati' },
  gujarati: { code: 'gu', label: 'Gujarati' },
  ur: { code: 'ur', label: 'Urdu' },
  urd: { code: 'ur', label: 'Urdu' },
  urdu: { code: 'ur', label: 'Urdu' },
  es: { code: 'es', label: 'Spanish' },
  spa: { code: 'es', label: 'Spanish' },
  spanish: { code: 'es', label: 'Spanish' },
  esla: { code: 'esla', label: 'Spanish' },
  fr: { code: 'fr', label: 'French' },
  fre: { code: 'fr', label: 'French' },
  fra: { code: 'fr', label: 'French' },
  french: { code: 'fr', label: 'French' },
  de: { code: 'de', label: 'German' },
  ger: { code: 'de', label: 'German' },
  deu: { code: 'de', label: 'German' },
  german: { code: 'de', label: 'German' },
  pt: { code: 'pt', label: 'Portuguese' },
  por: { code: 'pt', label: 'Portuguese' },
  portuguese: { code: 'pt', label: 'Portuguese' },
  ptbr: { code: 'ptbr', label: 'Portuguese' },
  ru: { code: 'ru', label: 'Russian' },
  rus: { code: 'ru', label: 'Russian' },
  russian: { code: 'ru', label: 'Russian' },
  zh: { code: 'zh', label: 'Chinese' },
  chi: { code: 'zh', label: 'Chinese' },
  zho: { code: 'zh', label: 'Chinese' },
  chinese: { code: 'zh', label: 'Chinese' },
  ar: { code: 'ar', label: 'Arabic' },
  ara: { code: 'ar', label: 'Arabic' },
  arabic: { code: 'ar', label: 'Arabic' },
  id: { code: 'id', label: 'Indonesian' },
  ind: { code: 'id', label: 'Indonesian' },
  indonesian: { code: 'id', label: 'Indonesian' },
  th: { code: 'th', label: 'Thai' },
  tha: { code: 'th', label: 'Thai' },
  thai: { code: 'th', label: 'Thai' },
  vi: { code: 'vi', label: 'Vietnamese' },
  vie: { code: 'vi', label: 'Vietnamese' },
  vietnamese: { code: 'vi', label: 'Vietnamese' },
};

function isUnknownLangCode(code?: string | null): boolean {
  const clean = String(code || '').trim().toLowerCase();
  return !clean || clean === 'und' || clean === 'unknown' || clean === 'original';
}

function languagesEquivalent(aRaw: string, bRaw: string): boolean {
  const a = normalizeMovieboxLanguage(aRaw);
  const b = normalizeMovieboxLanguage(bRaw);
  if (!a || !b) return false;
  if (a === b) return true;
  // Support regional variants such as es <-> esla, pt <-> ptbr
  if (a.length === 2 && b.startsWith(a)) return true;
  if (b.length === 2 && a.startsWith(b)) return true;
  return false;
}

/**
 * Infers the active default stream's language from real metadata already present
 * in the response / /api/info without calling the Dub API.
 * MovieBox /api/stream omits the currently playing stream from data.audioOptions,
 * so preserving an entry for the original stream prevents it from disappearing on switch.
 */
export function inferDefaultMovieboxLanguage(args: {
  activeAudio?: MovieboxStreamAudioOption | null;
  audioOptions: MovieboxStreamAudioOption[];
  availableLanguageHints?: string[];
  titleHint?: string;
  detailPath?: string;
}): { lanCode: string; language: string; isOriginal: boolean } {
  const activeCode = String(args.activeAudio?.lanCode || '').trim();
  const activeLang = String(args.activeAudio?.language || '').trim();
  if (!isUnknownLangCode(activeCode) || !isUnknownLangCode(activeLang)) {
    const resolvedCode = normalizeMovieboxLanguage(activeCode || activeLang);
    return {
      lanCode: resolvedCode || activeCode || 'und',
      language: activeLang || KNOWN_LANGUAGE_CODES[resolvedCode]?.label || resolvedCode || 'Original',
      isOriginal: Boolean(args.activeAudio?.original),
    };
  }

  // 1. Compare /api/info languages list against stream.data.audioOptions (the missing one is the active stream).
  if (Array.isArray(args.availableLanguageHints) && args.availableLanguageHints.length > 0) {
    const otherHasOriginal = args.audioOptions.some(
      (o) => Boolean(o.original) || /original/i.test(String(o.language || ''))
    );

    const missingHints = args.availableLanguageHints
      .map((raw) => String(raw || '').trim())
      .filter(Boolean)
      .filter((hint) => {
        if (/original/i.test(hint)) {
          return !otherHasOriginal;
        }
        return !args.audioOptions.some(
          (o) =>
            languagesEquivalent(o.lanCode, hint) ||
            languagesEquivalent(o.language, hint)
        );
      });

    if (missingHints.length === 1) {
      const hint = missingHints[0];
      if (/original/i.test(hint)) {
        return { lanCode: 'und', language: 'Original Audio', isOriginal: true };
      }
      const norm = normalizeMovieboxLanguage(hint);
      const known = KNOWN_LANGUAGE_CODES[norm] || KNOWN_LANGUAGE_CODES[hint.toLowerCase()];
      if (known) {
        return { lanCode: known.code, language: known.label, isOriginal: false };
      }
      return { lanCode: norm || 'und', language: hint, isOriginal: false };
    }
  }

  // 2. Check bracketed language tag in title (e.g. "Love in Disguise [Hindi]").
  const title = String(args.titleHint || '').trim();
  const bracketMatches = title.match(/\[([^\]]+)\]/g) || [];
  for (const rawBracket of bracketMatches) {
    const inner = rawBracket
      .slice(1, -1)
      .trim()
      .toLowerCase()
      .replace(/\s*dub$/i, '')
      .trim();
    const known = KNOWN_LANGUAGE_CODES[inner];
    if (known) {
      return { lanCode: known.code, language: known.label, isOriginal: false };
    }
  }

  // 3. Check explicit language slug token in detailPath (e.g. "love-in-disguise-hindi-ww61uWUBJx1").
  const slugTokens = String(args.detailPath || '')
    .toLowerCase()
    .split(/[^a-z]+/)
    .filter(Boolean);
  for (let i = slugTokens.length - 1; i >= 0; i--) {
    const token = slugTokens[i];
    // Only match full language names in URL slugs to avoid false positives on 2-letter words like "in", "en", "de"
    if (token.length >= 4 && KNOWN_LANGUAGE_CODES[token]) {
      const known = KNOWN_LANGUAGE_CODES[token];
      return { lanCode: known.code, language: known.label, isOriginal: false };
    }
  }

  return { lanCode: 'und', language: 'Original Audio', isOriginal: true };
}

export function findMatchingDubOption(
  options: MovieboxStreamAudioOption[],
  query: { lanCode?: string; language?: string; subjectId?: string; detailPath?: string }
): MovieboxStreamAudioOption | null {
  if (!Array.isArray(options) || options.length === 0) return null;

  if (query.subjectId && query.detailPath) {
    const exact = options.find(
      (o) =>
        String(o.subjectId) === String(query.subjectId) &&
        String(o.detailPath) === String(query.detailPath)
    );
    if (exact) return exact;
  }

  if (query.subjectId) {
    const bySubject = options.find(
      (o) => String(o.subjectId) === String(query.subjectId)
    );
    if (bySubject) return bySubject;
  }

  const wantedRaw = query.lanCode || query.language || '';
  const wanted = normalizeMovieboxLanguage(wantedRaw);
  if (!wanted) return null;

  // Prefer exact canonical match first, then regional variant fallback (e.g. es <-> esla, pt <-> ptbr).
  return (
    options.find((o) => normalizeMovieboxLanguage(o.lanCode) === wanted) ||
    options.find((o) => normalizeMovieboxLanguage(o.language) === wanted) ||
    options.find((o) => languagesEquivalent(o.lanCode, wanted)) ||
    options.find((o) => languagesEquivalent(o.language, wanted)) ||
    null
  );
}

function makeStreamCacheKey(
  subjectId: string,
  season: number,
  episode: number,
  fallbackUrl: string
): string {
  if (subjectId) {
    return `${subjectId}:${season}:${episode}`;
  }
  return fallbackUrl;
}

function cloneOptionsWithActive(
  options: MovieboxStreamAudioOption[],
  active: MovieboxStreamAudioOption | null
): MovieboxStreamAudioOption[] {
  return options.map((opt) => ({
    ...opt,
    active: Boolean(
      active &&
        opt.subjectId === active.subjectId &&
        opt.detailPath === active.detailPath
    ),
  }));
}

/**
 * In-memory MovieBox playback session controller.
 *
 * Guarantees:
 * - Flow A (URL has language param): calls Dub API once, caches full response & dub options,
 *   calls Stream endpoint once for the requested language.
 * - Flow B (URL has no language param): calls Dub API 0 times, calls Stream endpoint once directly.
 * - Language switching: reuses cached dub options (0 Dub API calls), fetches stream once per
 *   uncached language, and serves previously selected languages from session memory (0 Stream calls).
 * - Never persists session state to localStorage, sessionStorage, IndexedDB, or DB.
 * - Deduplicates concurrent initialization calls and drops stale async responses on rapid switches.
 * - Clears/replaces cache when a genuinely different MovieBox title is opened.
 */
export class MovieboxSessionController {
  private deps: MovieboxSessionDeps;
  private session: MovieboxPlaybackSession | null = null;
  private initInFlightKey: string | null = null;
  private initInFlightPromise: Promise<MovieboxSessionSnapshot> | null = null;
  private dubsInFlight: Map<string, Promise<MovieboxDubsResponse>> = new Map();
  private streamInFlight: Map<string, Promise<MovieboxStreamResponse>> = new Map();

  constructor(deps?: Partial<MovieboxSessionDeps>) {
    this.deps = {
      fetchDubs: deps?.fetchDubs ?? fetchMovieboxDubs,
      fetchStream: deps?.fetchStream ?? fetchMovieboxStream,
      onClearTitleCache: deps?.onClearTitleCache ?? clearMovieboxStreamDubCache,
    };
  }

  getActiveSession(): MovieboxPlaybackSession | null {
    return this.session;
  }

  resetSession(): void {
    this.session = null;
    this.initInFlightKey = null;
    this.initInFlightPromise = null;
    this.dubsInFlight.clear();
    this.streamInFlight.clear();
    this.deps.onClearTitleCache?.();
  }

  private async fetchDubsOnce(detailPath: string): Promise<MovieboxDubsResponse> {
    const existing = this.dubsInFlight.get(detailPath);
    if (existing) return existing;

    const promise = this.deps.fetchDubs(detailPath).finally(() => {
      this.dubsInFlight.delete(detailPath);
    });
    this.dubsInFlight.set(detailPath, promise);
    return promise;
  }

  private async fetchStreamOnce(
    cacheKey: string,
    streamUrl: string
  ): Promise<MovieboxStreamResponse> {
    const existing = this.streamInFlight.get(cacheKey);
    if (existing) return existing;

    const promise = this.deps.fetchStream(streamUrl).finally(() => {
      this.streamInFlight.delete(cacheKey);
    });
    this.streamInFlight.set(cacheKey, promise);
    return promise;
  }

  private buildSnapshot(
    session: MovieboxPlaybackSession,
    streamResponse: MovieboxStreamResponse,
    fromStreamCache: boolean
  ): MovieboxSessionSnapshot {
    const playbackUrl = streamResponse.data?.streams?.[0]?.url || '';
    return {
      contentId: session.contentId,
      flow: session.flow,
      requestedLanguage: session.requestedLanguage,
      dubsResponse: session.dubsResponse,
      cachedDubOptions: cloneOptionsWithActive(
        session.cachedDubOptions,
        session.selectedDub
      ),
      selectedLanguage: session.selectedLanguage,
      selectedDub: session.selectedDub ? { ...session.selectedDub, active: true } : null,
      streamUrl: session.currentStreamUrl,
      streamResponse,
      playbackUrl,
      fromStreamCache,
    };
  }

  async initializeSession(
    args: InitializeMovieboxSessionArgs
  ): Promise<MovieboxSessionSnapshot> {
    const contentId = String(args.contentId || '').trim();
    const parsedBase = parseMovieboxStreamUrl(args.baseStreamUrl);
    const season = args.season !== undefined ? args.season : parsedBase.season;
    const episode = args.episode !== undefined ? args.episode : parsedBase.episode;
    const detailPath = parsedBase.detailPath || String(args.fallbackDetailPath || '').trim();
    const subjectId = parsedBase.subjectId;
    const rawRequestedLanguage = String(args.requestedLanguage || '').trim();
    const flow: MovieboxFlowType = rawRequestedLanguage ? 'with-lang' : 'without-lang';
    const normalizedRequestedLang = rawRequestedLanguage
      ? normalizeMovieboxLanguage(rawRequestedLanguage)
      : '';

    // Switching to a genuinely different MovieBox title clears the entire previous session cache.
    if (this.session && this.session.contentId !== contentId) {
      this.resetSession();
    }

    const initKey = `${contentId}::${season}::${episode}::${parsedBase.normalizedUrl}::${flow}::${normalizedRequestedLang}`;

    // Re-render / redundant effect guard: if the exact session is already active and loaded,
    // return it immediately with 0 Dub API calls and 0 Stream API calls.
    if (
      this.session &&
      this.session.contentId === contentId &&
      this.session.season === season &&
      this.session.episode === episode &&
      this.session.baseStreamUrl === parsedBase.normalizedUrl &&
      this.session.currentStreamResponse
    ) {
      return this.buildSnapshot(this.session, this.session.currentStreamResponse, true);
    }

    // Deduplicate concurrent initialization calls for the same session context.
    if (this.initInFlightKey === initKey && this.initInFlightPromise) {
      return this.initInFlightPromise;
    }

    const runInit = async (): Promise<MovieboxSessionSnapshot> => {
      // Reuse existing title-level Dub API cache when switching episodes within the SAME series
      // in Flow A so the Dub API is never called redundantly within the same title session.
      const existingSameTitleSession =
        this.session && this.session.contentId === contentId ? this.session : null;

      let dubsResponse: MovieboxDubsResponse | null =
        existingSameTitleSession?.dubsResponse ?? null;
      let cachedDubOptions: MovieboxStreamAudioOption[] =
        existingSameTitleSession?.cachedDubOptions
          ? [...existingSameTitleSession.cachedDubOptions]
          : [];

      let targetStreamUrl = parsedBase.normalizedUrl;
      let selectedDub: MovieboxStreamAudioOption | null = null;
      let selectedLanguage = normalizedRequestedLang;

      // ── FLOW A: MovieBox opened WITH a language parameter ──
      if (flow === 'with-lang') {
        const alreadyHasMatch =
          cachedDubOptions.length > 0 &&
          Boolean(
            findMatchingDubOption(cachedDubOptions, {
              lanCode: rawRequestedLanguage,
              language: rawRequestedLanguage,
            })
          );

        if (!dubsResponse && !alreadyHasMatch && detailPath) {
          try {
            const fetchedDubs = await this.fetchDubsOnce(detailPath);
            if (fetchedDubs?.success && Array.isArray(fetchedDubs.data)) {
              dubsResponse = fetchedDubs;
              cachedDubOptions = mapDubsToAudioOptions(fetchedDubs.data);
            }
          } catch (err) {
            console.warn(
              '[Moviebox] Dubs lookup failed during Flow A; falling back to default stream:',
              err
            );
            dubsResponse = null;
            cachedDubOptions = [];
          }
        }

        if (cachedDubOptions.length > 0) {
          const matched = findMatchingDubOption(cachedDubOptions, {
            lanCode: rawRequestedLanguage,
            language: rawRequestedLanguage,
          });
          if (matched) {
            selectedDub = matched;
            selectedLanguage = normalizeMovieboxLanguage(
              matched.lanCode || matched.language || rawRequestedLanguage
            );
            targetStreamUrl = buildMovieboxStreamUrl(
              matched.subjectId,
              matched.detailPath,
              season,
              episode
            );
          } else {
            // Requested language not found: preserve existing fallback to default stream URL
            // without inventing a language, while keeping real cachedDubOptions intact.
            selectedDub =
              findMatchingDubOption(cachedDubOptions, {
                subjectId,
                detailPath,
              }) || null;
            selectedLanguage = selectedDub
              ? normalizeMovieboxLanguage(selectedDub.lanCode || selectedDub.language)
              : '';
          }
        }
      }
      // ── FLOW B: MovieBox opened WITHOUT a language parameter ──
      // Never call the Dub API at all. Call the stream endpoint directly using default URL.

      const parsedTarget = parseMovieboxStreamUrl(targetStreamUrl);
      const streamCache = existingSameTitleSession?.streamCache ?? new Map<string, MovieboxStreamResponse>();
      const streamCacheKey = makeStreamCacheKey(
        parsedTarget.subjectId,
        season,
        episode,
        targetStreamUrl
      );

      let streamResponse = streamCache.get(streamCacheKey) || null;
      let fromStreamCache = Boolean(streamResponse);

      if (!streamResponse) {
        streamResponse = await this.fetchStreamOnce(streamCacheKey, targetStreamUrl);
        if (!streamResponse?.success || !streamResponse.data?.streams?.[0]?.url) {
          throw new Error('No stream URL');
        }
        streamCache.set(streamCacheKey, streamResponse);
      }

      // In Flow B (or Flow A if Dub API failed), capture any outer options returned by the
      // initial default stream response WITHOUT calling the Dub API.
      // MovieBox /api/stream omits the currently playing stream from data.audioOptions,
      // so we prepend an explicit entry for the current default stream so it is NEVER lost on switch.
      if (cachedDubOptions.length === 0 && Array.isArray(streamResponse.data?.audioOptions)) {
        const streamAudioOpts = streamResponse.data.audioOptions
          .filter((o) => Boolean(o?.subjectId && o?.detailPath))
          .map((o) => ({ ...o }));

        const activeSubjectId =
          parsedTarget.subjectId || String(streamResponse.data?.subjectId || '').trim();
        const activeDetailPath =
          parsedTarget.detailPath ||
          String(streamResponse.data?.detailPath || '').trim() ||
          detailPath;

        const alreadyContainsCurrent =
          Boolean(activeSubjectId) &&
          streamAudioOpts.some((o) => String(o.subjectId) === String(activeSubjectId));

        if (activeSubjectId && activeDetailPath && !alreadyContainsCurrent) {
          const inferred = inferDefaultMovieboxLanguage({
            activeAudio: streamResponse.data?.activeAudio,
            audioOptions: streamAudioOpts,
            availableLanguageHints: args.availableLanguageHints,
            titleHint: args.titleHint,
            detailPath: activeDetailPath,
          });
          const defaultEntry: MovieboxStreamAudioOption = {
            subjectId: activeSubjectId,
            detailPath: activeDetailPath,
            language: inferred.language,
            lanCode: inferred.lanCode,
            original: inferred.isOriginal,
            active: true,
          };
          cachedDubOptions = [defaultEntry, ...streamAudioOpts];
        } else {
          cachedDubOptions = streamAudioOpts;
        }
      }

      if (!selectedDub && cachedDubOptions.length > 0) {
        const streamActive =
          streamResponse.data?.activeAudio ||
          streamResponse.data?.audioOptions?.find((o) => o.active) ||
          null;
        selectedDub =
          (streamActive &&
            findMatchingDubOption(cachedDubOptions, {
              subjectId: streamActive.subjectId,
              detailPath: streamActive.detailPath,
              lanCode: streamActive.lanCode,
            })) ||
          findMatchingDubOption(cachedDubOptions, {
            subjectId: parsedTarget.subjectId,
            detailPath: parsedTarget.detailPath,
          }) ||
          null;
      }

      if (!selectedLanguage && selectedDub && !isUnknownLangCode(selectedDub.lanCode)) {
        selectedLanguage = normalizeMovieboxLanguage(
          selectedDub.lanCode || selectedDub.language
        );
      }

      const playbackUrl = streamResponse.data.streams[0].url;
      const nextSeq = (existingSameTitleSession?.requestSeq ?? 0) + 1;

      this.session = {
        contentId,
        originalDetailPath: detailPath,
        originalSubjectId: subjectId,
        originalUrl: args.originalUrl,
        baseStreamUrl: parsedBase.normalizedUrl,
        requestedLanguage: normalizedRequestedLang,
        season,
        episode,
        flow,
        dubsResponse,
        cachedDubOptions,
        selectedLanguage,
        selectedDub,
        currentStreamUrl: targetStreamUrl,
        currentStreamResponse: streamResponse,
        currentPlaybackUrl: playbackUrl,
        streamCache,
        requestSeq: nextSeq,
      };

      return this.buildSnapshot(this.session, streamResponse, fromStreamCache);
    };

    this.initInFlightKey = initKey;
    this.initInFlightPromise = runInit().finally(() => {
      if (this.initInFlightKey === initKey) {
        this.initInFlightKey = null;
        this.initInFlightPromise = null;
      }
    });

    return this.initInFlightPromise;
  }

  /**
   * Switches playback to another language/dub within the active session:
   * - Never calls the Dub API.
   * - Reuses cached dub metadata and preserves original cachedDubOptions & ordering.
   * - Serves previously fetched languages directly from session.streamCache (0 network calls).
   * - Drops stale async responses when rapid language switching occurs.
   * - Preserves previous working playback state if the stream request fails.
   */
  async switchLanguage(
    args: SwitchMovieboxLanguageArgs
  ): Promise<MovieboxSessionSnapshot> {
    const session = this.session;
    if (!session) {
      throw new Error('No active MovieBox playback session');
    }

    const season = args.season !== undefined ? args.season : session.season;
    const episode = args.episode !== undefined ? args.episode : session.episode;

    // Look up selected language in the already cached dub options (0 Dub API calls).
    const cachedMatch = findMatchingDubOption(session.cachedDubOptions, {
      subjectId: args.subjectId,
      detailPath: args.detailPath,
      lanCode: args.lanCode,
      language: args.language || args.label,
    });

    const targetSubjectId = cachedMatch?.subjectId || String(args.subjectId || '').trim();
    const targetDetailPath = cachedMatch?.detailPath || String(args.detailPath || '').trim();

    if (!targetSubjectId || !targetDetailPath) {
      throw new Error('Requested MovieBox language is not available in session cache');
    }

    const targetDub: MovieboxStreamAudioOption = cachedMatch ?? {
      subjectId: targetSubjectId,
      detailPath: targetDetailPath,
      language: String(args.language || args.label || args.lanCode || '').trim(),
      lanCode: String(args.lanCode || args.language || '').trim(),
    };

    const targetStreamUrl = buildMovieboxStreamUrl(
      targetSubjectId,
      targetDetailPath,
      season,
      episode
    );
    const streamCacheKey = makeStreamCacheKey(
      targetSubjectId,
      season,
      episode,
      targetStreamUrl
    );
    const targetLang = normalizeMovieboxLanguage(
      targetDub.lanCode || targetDub.language || args.lanCode || ''
    );

    const reqSeq = ++session.requestSeq;

    // Fast path: previously selected language is already cached in session memory -> 0 API calls!
    const cachedStream = session.streamCache.get(streamCacheKey);
    if (cachedStream?.success && cachedStream.data?.streams?.[0]?.url) {
      session.season = season;
      session.episode = episode;
      session.selectedDub = targetDub;
      session.selectedLanguage = targetLang;
      session.currentStreamUrl = targetStreamUrl;
      session.currentStreamResponse = cachedStream;
      session.currentPlaybackUrl = cachedStream.data.streams[0].url;

      return this.buildSnapshot(session, cachedStream, true);
    }

    // Fetch ONLY the stream endpoint for the newly selected language (0 Dub API calls).
    // Do NOT mutate active playback state until the stream succeeds AND matches latest reqSeq!
    const streamResponse = await this.fetchStreamOnce(streamCacheKey, targetStreamUrl);
    if (!streamResponse?.success || !streamResponse.data?.streams?.[0]?.url) {
      throw new Error('No stream URL for selected language');
    }

    // Store valid response in session memory even if superseded, so switching back later is instant.
    if (this.session === session) {
      session.streamCache.set(streamCacheKey, streamResponse);
    }

    // Race-condition guard: if a newer switch occurred or title changed, do NOT overwrite active state.
    if (this.session !== session || reqSeq !== session.requestSeq) {
      const currentRes = this.session?.currentStreamResponse ?? streamResponse;
      return {
        ...this.buildSnapshot(this.session ?? session, currentRes, true),
        stale: true,
      };
    }

    // If any cached option originally had an unknown lanCode ('und'), enrich its label/code
    // in place from this stream's audioOptions without adding, removing, or reordering entries.
    if (Array.isArray(streamResponse.data?.audioOptions)) {
      for (const cachedOpt of session.cachedDubOptions) {
        if (!isUnknownLangCode(cachedOpt.lanCode)) continue;
        const incoming = streamResponse.data.audioOptions.find(
          (o) => String(o.subjectId) === String(cachedOpt.subjectId)
        );
        if (incoming && !isUnknownLangCode(incoming.lanCode)) {
          cachedOpt.lanCode = incoming.lanCode;
          cachedOpt.language = incoming.language || cachedOpt.language;
        }
      }
    }

    // Commit new active stream while preserving original session.cachedDubOptions unchanged!
    session.season = season;
    session.episode = episode;
    session.selectedDub = targetDub;
    session.selectedLanguage = targetLang;
    session.currentStreamUrl = targetStreamUrl;
    session.currentStreamResponse = streamResponse;
    session.currentPlaybackUrl = streamResponse.data.streams[0].url;

    return this.buildSnapshot(session, streamResponse, false);
  }

  /**
   * Enriches an unknown ('und') active default dub's language code once Shaka's manifest
   * exposes the real audio track language, without making any API call or reordering options.
   */
  enrichActiveLanguageFromManifest(lanCode: string): MovieboxSessionSnapshot | null {
    const session = this.session;
    if (!session || !session.currentStreamResponse) return null;

    const clean = normalizeMovieboxLanguage(lanCode);
    if (isUnknownLangCode(clean)) return null;

    let changed = false;
    const active = session.selectedDub;
    if (active && isUnknownLangCode(active.lanCode)) {
      const known = KNOWN_LANGUAGE_CODES[clean];
      active.lanCode = known?.code || clean;
      active.language = known?.label || clean;
      const inCache = session.cachedDubOptions.find(
        (o) =>
          String(o.subjectId) === String(active.subjectId) &&
          String(o.detailPath) === String(active.detailPath)
      );
      if (inCache && isUnknownLangCode(inCache.lanCode)) {
        inCache.lanCode = active.lanCode;
        inCache.language = active.language;
      }
      if (!session.selectedLanguage) {
        session.selectedLanguage = active.lanCode;
      }
      changed = true;
    }

    if (!changed) return null;
    return this.buildSnapshot(session, session.currentStreamResponse, true);
  }
}

export const movieboxSession = new MovieboxSessionController();
