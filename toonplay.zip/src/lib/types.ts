export interface User {
  id: number;
  username: string;
  display_name: string | null;
  email: string;
  avatar_url: string | null;
  profile_banner_url?: string | null;
  profile_frame_url?: string | null;
  bio: string | null;
  level: number;
  xp: number;
  minutes_watched: number;
  total_episodes_watched: number;
  total_anime_watched: number;
  completed_anime: number;
  current_streak_days: number;
  best_streak_days: number;
  last_active_date: string | null;
  joined_at: string;
  created_at: string;
  updated_at: string;
  show_watchlist: number;
  show_history: number;
  show_stats: number;
  auto_play: number;
  auto_next: number;
  auto_skip: number;
}

export interface AnimeStat {
  id: number;
  user_id: number;
  cartoon_id: string;
  cartoon_title: string;
  cartoon_image: string | null;
  total_episodes_available: number;
  episodes_watched: number;
  completed: number;
  first_watched: string;
  last_watched: string;
  genres: string | null;
}

export interface MostWatchedItem {
  cartoon_id: string;
  cartoon_title: string;
  cartoon_image: string;
  episodes_watched: number;
  episodes_completed_30d: number;
  episodes_completed_total?: number;
  total_episodes_available: number;
  progress_percentage?: number | null;
  completed: number;
  last_completed_at: string | null;
  period_days: number;
}

export interface GenreStat {
  id: number;
  user_id: number;
  genre: string;
  episodes_watched: number;
}

export interface DailyActivity {
  id: number;
  user_id: number;
  activity_date: string;
  episodes_watched: number;
  xp_earned: number;
}

export interface WatchlistItem {
  id: number;
  user_id: number;
  cartoon_id: string;
  cartoon_title: string;
  cartoon_image: string | null;
  cartoon_type: 'movie' | 'series';
  added_at: string;
}

export interface WatchHistoryItem {
  id: number;
  user_id: number;
  cartoon_id: string;
  cartoon_title: string;
  cartoon_image: string | null;
  cartoon_type: 'movie' | 'series';
  episode_id: string | null;
  episode_number: number | null;
  season_number: number | null;
  episode_title: string | null;
  episode_image: string | null;
  progress_seconds: number;
  duration_seconds: number;
  server_type: 'server1' | 'server2' | 'server3' | null;
  last_watched: string;
}

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
  [key: string]: any;
}

export interface StatsSummary {
  userId: number;
  username: string;
  displayName: string;
  avatarUrl: string;
  level: number;
  xp: number;
  minutesWatched: number;
  totalEpisodesWatched: number;
  totalAnimeWatched: number;
  completedAnime: number;
  currentStreakDays: number;
  bestStreakDays: number;
  lastActiveDate: string | null;
  watchlistCount: number;
  historyCount: number;
  topGenres: GenreStat[];
  recentActivity: DailyActivity[];
}

export interface WatchProgressPayload {
  cartoon_id: string;
  cartoon_title: string;
  cartoon_image?: string;
  cartoon_type: 'movie' | 'series';
  episode_id?: string | number;
  episode_number?: number;
  season_number?: number;
  episode_title?: string;
  episode_image?: string;
  progress_seconds: number;
  duration_seconds: number;
  server_type?: 'server1' | 'server2' | 'server3';
  added_seconds?: number;
  genres?: string[];
  total_episodes_available?: number;
}