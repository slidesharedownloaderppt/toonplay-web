function safeParse(dateStr?: string | Date | null): number {
  if (!dateStr) return NaN;
  if (dateStr instanceof Date) return dateStr.getTime();

  const s = String(dateStr).trim();

  const sqlDate = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})(?:\.(\d+))?$/.exec(s);
  if (sqlDate) {
    const [, y, mo, d, h, mi, se, ms] = sqlDate;
    const msStr = ms ? (ms + '000').slice(0, 3) : '0';
    const date = new Date(0);
    date.setUTCFullYear(+y, +mo - 1, +d);
    date.setUTCHours(+h, +mi, +se, +msStr);
    return date.getTime();
  }

  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) {
    const [y, mo, d] = s.split('-').map(Number);
    const date = new Date(0);
    date.setFullYear(y, mo - 1, d);
    date.setHours(0, 0, 0, 0);
    return date.getTime();
  }

  const t = new Date(s).getTime();
  return Number.isFinite(t) ? t : NaN;
}

export function timeAgo(dateStr?: string | null): string {
  if (!dateStr) return '';
  const then = safeParse(dateStr);
  if (!Number.isFinite(then)) return '';

  const seconds = Math.floor((Date.now() - then) / 1000);

  if (seconds < 0) return 'just now';
  if (seconds < 5) return 'just now';
  if (seconds < 60) return `${seconds} seconds ago`;

  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return minutes === 1 ? '1 minute ago' : `${minutes} minutes ago`;

  const hours = Math.floor(minutes / 60);
  if (hours < 24) return hours === 1 ? '1 hour ago' : `${hours} hours ago`;

  const days = Math.floor(hours / 24);
  if (days === 1) return '1 day ago';
  if (days < 30) return `${days} days ago`;

  const months = Math.floor(days / 30);
  if (months === 1) return '1 month ago';
  if (months < 12) return `${months} months ago`;

  const years = Math.floor(months / 12);
  return years === 1 ? '1 year ago' : `${years} years ago`;
}

export function joinedAgo(dateStr?: string | null): string {
  const rel = timeAgo(dateStr);
  return rel ? `Joined ${rel}` : '';
}

export function formatDate(dateStr?: string | null): string {
  if (!dateStr) return '';
  const t = safeParse(dateStr);
  if (!Number.isFinite(t)) return '';
  return new Date(t).toLocaleDateString(undefined, { year: 'numeric', month: 'short' });
}

export function formatDayShort(dateStr?: string | null): string {
  if (!dateStr) return '';
  const t = safeParse(dateStr);
  if (!Number.isFinite(t)) return '';
  return new Date(t).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}