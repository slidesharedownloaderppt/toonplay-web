const TOKEN_KEY = 'toonplay_token';
const API_BASE = '';

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string | null): void {
  if (token) localStorage.setItem(TOKEN_KEY, token);
  else localStorage.removeItem(TOKEN_KEY);
}

export class ApiError extends Error {
  status: number;
  code?: string;
  constructor(status: number, message: string, code?: string) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

interface RequestOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  body?: any;
  auth?: boolean;
  signal?: AbortSignal;
  beacon?: boolean;
}

export async function api<T = any>(path: string, opts: RequestOptions = {}): Promise<T> {
  const { method = 'GET', body, auth = true, signal, beacon = false } = opts;
  const headers: Record<string, string> = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';

  const token = getToken();
  if (auth && token) headers['Authorization'] = `Bearer ${token}`;

  const url = `${API_BASE}${path}`;

  if (beacon) {
    navigator.sendBeacon(url, new Blob([JSON.stringify(body || {})], { type: 'application/json' }));
    return undefined as T;
  }

  const res = await fetch(url, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
    signal,
  });

  let json: any = null;
  try {
    json = await res.json();
  } catch {
    json = null;
  }

  if (res.status === 401 && auth) {
    setToken(null);
    window.dispatchEvent(new CustomEvent('toonplay:unauthorized'));
  }

  if (!res.ok || (json && json.success === false)) {
    const msg = json?.error || `HTTP ${res.status}`;
    throw new ApiError(res.status, msg, json?.error);
  }

  return (json ?? {}) as T;
}

export const authApi = {
  register: (body: { username: string; email: string; password: string; display_name?: string }) =>
    api<{ success: boolean; token: string; user: any; message?: string }>('/api/auth/register', {
      method: 'POST', body, auth: false,
    }),

  login: (body: { usernameOrEmail: string; password: string }) =>
    api<{ success: boolean; token: string; user: any; message?: string }>('/api/auth/login', {
      method: 'POST', body, auth: false,
    }),

  google: (body: { idToken?: string; accessToken?: string }) =>
    api<{ success: boolean; token: string; user: any }>('/api/auth/google', {
      method: 'POST', body, auth: false,
    }),

  logout: () => api<{ success: boolean }>('/api/auth/logout', { method: 'POST' }),

  me: () => api<{ success: boolean; user: any }>('/api/auth/me'),

  forgotPassword: (email: string) =>
    api<{ success: boolean; message: string }>('/api/auth/forgot-password', {
      method: 'POST', body: { email }, auth: false,
    }),

  verifyOtp: (email: string, otp: string) =>
    api<{ success: boolean; resetToken: string }>('/api/auth/verify-otp', {
      method: 'POST', body: { email, otp }, auth: false,
    }),

  resetPassword: (email: string, resetToken: string, newPassword: string) =>
    api<{ success: boolean; token: string; message: string }>('/api/auth/reset-password', {
      method: 'POST', body: { email, resetToken, newPassword }, auth: false,
    }),

  changePassword: (currentPassword: string, newPassword: string) =>
    api<{ success: boolean; message: string }>('/api/users/password', {
      method: 'PUT', body: { currentPassword, newPassword },
    }),

  deleteAccount: (opts: { password?: string; confirm?: string }) =>
    api<{ success: boolean; message: string }>('/api/auth/delete-account', {
      method: 'DELETE',
      body: opts,
    }),
};

export const userApi = {
  profile: () => api<{ success: boolean; user: any }>('/api/users/profile'),
  updateProfile: (body: {
    display_name?: string;
    avatar_url?: string | null;
    profile_banner_url?: string | null;
    profile_frame_url?: string | null;
    bio?: string;
    username?: string;
  }) =>
    api<{ success: boolean; user: any }>('/api/users/profile', { method: 'PUT', body }),
  updatePreferences: (body: Partial<{
    show_watchlist: boolean; show_history: boolean; show_stats: boolean;
    auto_play: boolean; auto_next: boolean; auto_skip: boolean;
  }>) => api<{ success: boolean; user: any; preferences: any }>('/api/users/preferences', { method: 'PUT', body }),
  publicProfile: (username: string) =>
    api<{ success: boolean; profile: any }>(`/api/users/${encodeURIComponent(username)}`),
  activity: (username: string, days = 30) =>
    api<{ success: boolean; days: number; activities: any[]; hidden?: boolean }>(
      `/api/users/${encodeURIComponent(username)}/activity?days=${days}`
    ),
  list: (page = 1, limit = 20) =>
    api<{ success: boolean; users: any[]; total: number; totalPages: number }>(
      `/api/users?page=${page}&limit=${limit}`, { auth: false }
    ),
  leaderboard: (limit = 10) =>
    api<{ success: boolean; entries: any[]; count: number }>(
      `/api/leaderboard?limit=${limit}`, { auth: false }
    ),
};

export const watchlistApi = {
  list: (page = 1, limit = 50, type?: string) => {
    const q = new URLSearchParams({ page: String(page), limit: String(limit) });
    if (type) q.set('type', type);
    return api<{ success: boolean; items: any[]; total: number }>(`/api/watchlist?${q}`);
  },
  check: (cartoonId: string) =>
    api<{ success: boolean; inWatchlist: boolean; item: any }>(`/api/watchlist/check/${encodeURIComponent(cartoonId)}`),
  add: (body: {
    cartoon_id: string;
    cartoon_title: string;
    cartoon_image?: string;
    cartoon_type: string;
anilist_id?: number | null;
tmdb_id?: number | null;
subject_id?: string | null;
  }) =>
    api<{ success: boolean; item: any }>('/api/watchlist', { method: 'POST', body }),
  remove: (cartoonId: string) =>
    api<{ success: boolean; affectedRows: number }>(`/api/watchlist/${encodeURIComponent(cartoonId)}`, { method: 'DELETE' }),
  clear: () => api<{ success: boolean }>('/api/watchlist', { method: 'DELETE' }),
};

export const historyApi = {
  list: (page = 1, limit = 50) =>
    api<{ success: boolean; items: any[]; total: number }>(`/api/history?page=${page}&limit=${limit}`),
  forCartoon: (cartoonId: string) =>
    api<{ success: boolean; latest: any; history: any[] }>(`/api/history/${encodeURIComponent(cartoonId)}`),
  save: (payload: any) => api<{ success: boolean; record: any }>('/api/history', { method: 'POST', body: payload }),
  deleteOne: (id: number) => api<{ success: boolean }>(`/api/history/${id}`, { method: 'DELETE' }),
  deleteCartoon: (cartoonId: string) =>
    api<{ success: boolean }>(`/api/history/cartoon/${encodeURIComponent(cartoonId)}`, { method: 'DELETE' }),
  clear: () => api<{ success: boolean }>('/api/history', { method: 'DELETE' }),
};

export const statsApi = {
  summary: () => api<{ success: boolean; summary: any }>('/api/stats/summary'),
  anime: () => api<{ success: boolean; stats: any[]; count: number }>('/api/stats/anime'),
  animeFor: (cartoonId: string) =>
    api<{ success: boolean; stat: any }>(`/api/stats/anime/${encodeURIComponent(cartoonId)}`),
  genres: () => api<{ success: boolean; genres: any[] }>('/api/stats/genres'),
  dailyActivity: (days = 30) => api<{ success: boolean; activities: any[] }>(`/api/stats/daily-activity?days=${days}`),
};

export const watchApi = {
  progress: (payload: any, beacon = false) =>
    api<{ success: boolean; user: any }>('/api/watch/progress', { method: 'POST', body: payload, beacon }),
  complete: (payload: any) =>
    api<{ success: boolean; firstCompletion: boolean; user: any }>('/api/watch/complete', {
      method: 'POST',
      body: payload,
    }),
};

export const friendsApi = {
  status: (targetUsername: string) =>
    api<{
      success: boolean;
      status: 'self' | 'friends' | 'pending_sent' | 'pending_received' | 'none';
      friendsCount: number;
      requestId?: string;
    }>(`/api/friends/status/${encodeURIComponent(targetUsername)}`, { auth: true }),
  sendRequest: (targetUsername: string) =>
    api<{ success: boolean; message: string; status: string }>('/api/friends/request', {
      method: 'POST',
      body: { targetUsername },
      auth: true,
    }),
  respondRequest: (requestId: string, action: 'accept' | 'decline' | 'cancel') =>
    api<{ success: boolean; message: string }>(`/api/friends/request/${requestId}`, {
      method: 'POST',
      body: { action },
      auth: true,
    }),
  removeFriend: (targetUsername: string) =>
    api<{ success: boolean; message: string }>(`/api/friends/${encodeURIComponent(targetUsername)}`, {
      method: 'DELETE',
      auth: true,
    }),
  list: () =>
    api<{
      success: boolean;
      friends: any[];
      incomingRequests: any[];
      outgoingRequests: any[];
      totalFriends: number;
    }>('/api/friends', { auth: true }),
  searchUsers: (query: string) =>
    api<{ success: boolean; users: any[] }>(`/api/friends/search?q=${encodeURIComponent(query)}`, {
      auth: true,
    }),
};