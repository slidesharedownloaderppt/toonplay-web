export type XpTierName =
  | 'Bronze'
  | 'Silver'
  | 'Gold'
  | 'Platinum'
  | 'Diamond'
  | 'Mythic'
  | 'Legend'
  | 'Champion'
  | 'Hero'
  | 'Immortal'
  | 'Celestial'
  | 'Cosmic'
  | 'Divine'
  | 'God';

export interface XpTier {
  name: XpTierName;
  minLevel: number;
  maxLevel: number | null;
  color: string;
  dark: string;
  light: string;
  crestGradient: [string, string, string];
  progressGradient: string;
  glow: string;
  icon: string;
}


const TIERS: XpTier[] = [
  {
    name: 'Bronze',
    minLevel: 1,
    maxLevel: 9,
    color: '#cd7f32',
    dark: '#a8621f',
    light: '#e8a05b',
    crestGradient: ['#2a1c10', '#1a1008', '#0d0804'],
    progressGradient: 'linear-gradient(90deg, #8a5220 0%, #cd7f32 50%, #e8a05b 100%)',
    glow: 'rgba(205, 127, 50, 0.45)',
    icon: '🛡️',
  },
  {
    name: 'Silver',
    minLevel: 10,
    maxLevel: 19,
    color: '#c0c0c0',
    dark: '#8b8b8b',
    light: '#e5e5e5',
    crestGradient: ['#232428', '#15161a', '#0a0b0d'],
    progressGradient: 'linear-gradient(90deg, #7a7a7a 0%, #c0c0c0 50%, #e5e5e5 100%)',
    glow: 'rgba(192, 192, 192, 0.4)',
    icon: '⚔️',
  },
  {
    name: 'Gold',
    minLevel: 20,
    maxLevel: 29,
    color: '#eab308',
    dark: '#b88806',
    light: '#fcd34d',
    crestGradient: ['#1c1f2e', '#0f111a', '#07080d'],
    progressGradient: 'linear-gradient(90deg, #a16207 0%, #eab308 50%, #fcd34d 100%)',
    glow: 'rgba(234, 179, 8, 0.45)',
    icon: '🏅',
  },
  {
    name: 'Platinum',
    minLevel: 30,
    maxLevel: 49,
    color: '#67e8f9',
    dark: '#22b8cf',
    light: '#a5f3fc',
    crestGradient: ['#0f1e24', '#081216', '#04090c'],
    progressGradient: 'linear-gradient(90deg, #0891b2 0%, #67e8f9 50%, #a5f3fc 100%)',
    glow: 'rgba(103, 232, 249, 0.45)',
    icon: '💠',
  },
  {
    name: 'Diamond',
    minLevel: 50,
    maxLevel: 74,
    color: '#a78bfa',
    dark: '#7c5ce0',
    light: '#c4b5fd',
    crestGradient: ['#16132a', '#0c0a1a', '#050410'],
    progressGradient: 'linear-gradient(90deg, #6d28d9 0%, #a78bfa 50%, #c4b5fd 100%)',
    glow: 'rgba(167, 139, 250, 0.5)',
    icon: '💎',
  },
  {
    name: 'Mythic',
    minLevel: 75,
    maxLevel: 99,
    color: '#f472b6',
    dark: '#db2777',
    light: '#f9a8d4',
    crestGradient: ['#2a0f1e', '#18080f', '#0a0407'],
    progressGradient: 'linear-gradient(90deg, #be185d 0%, #f472b6 50%, #f9a8d4 100%)',
    glow: 'rgba(244, 114, 182, 0.5)',
    icon: '🔮',
  },
  {
    name: 'Legend',
    minLevel: 100,
    maxLevel: 124,
    color: '#fbbf24',
    dark: '#d97706',
    light: '#fde68a',
    crestGradient: ['#2a1f05', '#1a1203', '#0a0701'],
    progressGradient: 'linear-gradient(90deg, #b45309 0%, #fbbf24 50%, #fde68a 100%)',
    glow: 'rgba(251, 191, 36, 0.65)',
    icon: '👑',
  },
  {
    name: 'Champion',
    minLevel: 125,
    maxLevel: 149,
    color: '#fb923c',
    dark: '#ea580c',
    light: '#fdba74',
    crestGradient: ['#2a1408', '#180a04', '#0a0502'],
    progressGradient: 'linear-gradient(90deg, #c2410c 0%, #fb923c 50%, #fdba74 100%)',
    glow: 'rgba(251, 146, 60, 0.55)',
    icon: '🏆',
  },
  {
    name: 'Hero',
    minLevel: 150,
    maxLevel: 174,
    color: '#34d399',
    dark: '#059669',
    light: '#6ee7b7',
    crestGradient: ['#0a2a1e', '#04180f', '#020a07'],
    progressGradient: 'linear-gradient(90deg, #047857 0%, #34d399 50%, #6ee7b7 100%)',
    glow: 'rgba(52, 211, 153, 0.55)',
    icon: '🦁',
  },
  {
    name: 'Immortal',
    minLevel: 175,
    maxLevel: 199,
    color: '#f87171',
    dark: '#dc2626',
    light: '#fca5a5',
    crestGradient: ['#2a0f0f', '#180808', '#0a0404'],
    progressGradient: 'linear-gradient(90deg, #b91c1c 0%, #f87171 50%, #fca5a5 100%)',
    glow: 'rgba(248, 113, 113, 0.55)',
    icon: '☠️',
  },
  {
    name: 'Celestial',
    minLevel: 200,
    maxLevel: 224,
    color: '#818cf8',
    dark: '#4f46e5',
    light: '#c7d2fe',
    crestGradient: ['#141432', '#0a0a1e', '#040410'],
    progressGradient: 'linear-gradient(90deg, #4338ca 0%, #818cf8 50%, #c7d2fe 100%)',
    glow: 'rgba(129, 140, 248, 0.6)',
    icon: '🌟',
  },
  {
    name: 'Cosmic',
    minLevel: 225,
    maxLevel: 249,
    color: '#c084fc',
    dark: '#9333ea',
    light: '#e9d5ff',
    crestGradient: ['#1e0a2a', '#100418', '#05020a'],
    progressGradient: 'linear-gradient(90deg, #7e22ce 0%, #c084fc 50%, #e9d5ff 100%)',
    glow: 'rgba(192, 132, 252, 0.65)',
    icon: '🌌',
  },
  {
    name: 'Divine',
    minLevel: 250,
    maxLevel: 274,
    color: '#fde047',
    dark: '#eab308',
    light: '#fef9c3',
    crestGradient: ['#2a2405', '#1a1603', '#0a0801'],
    progressGradient: 'linear-gradient(90deg, #ca8a04 0%, #fde047 50%, #fef9c3 100%)',
    glow: 'rgba(253, 224, 71, 0.7)',
    icon: '🕊️',
  },
  {
    name: 'God',
    minLevel: 275,
    maxLevel: null,
    color: '#DCEBFF',
    dark: '#123A8C',
    light: '#DCEBFF',
    crestGradient: ['#183B79', '#0B1D40', '#050D20'],
    progressGradient: 'linear-gradient(90deg, #123A8C 0%, #3978E8 35%, #DCEBFF 72%, #FFFFFF 100%)',
    glow: 'rgba(141, 187, 255, 0.8)',
    icon: '⚜️',
  },
];

export function getXpTier(level: number): XpTier {
  const safeLevel = Math.max(1, Math.floor(level || 1));
  for (let i = TIERS.length - 1; i >= 0; i--) {
    if (safeLevel >= TIERS[i].minLevel) return TIERS[i];
  }
  return TIERS[0];
}

export function getAllXpTiers(): XpTier[] {
  return TIERS.slice();
}

export function getNextXpTier(level: number): XpTier | null {
  const current = getXpTier(level);
  const idx = TIERS.findIndex((t) => t.name === current.name);
  if (idx === -1 || idx >= TIERS.length - 1) return null;
  return TIERS[idx + 1];
}

export function getLevelProgress(xp: number) {
  const safeXp = Math.max(0, Math.floor(xp || 0));
  const level = Math.floor(Math.sqrt(safeXp / 100)) + 1;

  const currentLevelThreshold = Math.floor(Math.pow(level - 1, 2) * 100);
  const nextLevelThreshold = Math.floor(Math.pow(level, 2) * 100);

  const currentLevelXp = Math.max(0, safeXp - currentLevelThreshold);
  const xpForNextLevel = nextLevelThreshold - currentLevelThreshold;
  const progressPercent =
    xpForNextLevel > 0
      ? Math.max(0, Math.min(100, (currentLevelXp / xpForNextLevel) * 100))
      : 100;

  return {
    level,
    currentLevelXp,
    xpForNextLevel,
    nextLevelThreshold,
    currentLevelThreshold,
    progressPercent,
  };
}

export function getTotalXpProgress(xp: number) {
  const safeXp = Math.max(0, Math.floor(xp || 0));
  const level = Math.floor(Math.sqrt(safeXp / 100)) + 1;
  const nextLevelThreshold = Math.floor(Math.pow(level, 2) * 100);
  const progressPercent =
    nextLevelThreshold > 0
      ? Math.max(0, Math.min(100, (safeXp / nextLevelThreshold) * 100))
      : 100;

  return {
    level,
    totalXp: safeXp,
    nextLevelThreshold,
    progressPercent,
  };
}

export function formatXp(xp: number): string {
  return Math.max(0, Math.floor(xp || 0)).toLocaleString('en-US');
}