export interface RawGenreStat {
  genre: string;
  episodes_watched: number;
}

export interface ComputedGenreShare {
  genre: string;
  episodes_watched: number;
  percentage: number;
  barWidth: number;
}

/**
 * Computes each top genre's percentage of the user's total episodes watched.
 *
 * Example: if a user watched 142 total episodes and 108 of them had the "Action"
 * genre tag, Action = Math.round((108 / 142) * 100) = 76%.
 * Because a single anime episode can belong to multiple genres, each genre's
 * percentage represents the share of total watched episodes containing that genre
 * (clamped to 0–100%).
 */
export function computeTopGenreShares(
  genres: RawGenreStat[] | null | undefined,
  totalEpisodes?: number | null,
  limit = 8
): { items: ComputedGenreShare[]; denominator: number } {
  if (!Array.isArray(genres) || genres.length === 0) {
    return { items: [], denominator: 0 };
  }

  // Normalize, filter non-positive entries, and merge case-insensitive duplicates
  const merged = new Map<string, { genre: string; episodes_watched: number }>();
  for (const row of genres) {
    const label = String(row?.genre ?? '').trim();
    const eps = Math.max(0, Number(row?.episodes_watched || 0));
    if (!label || !Number.isFinite(eps) || eps <= 0) continue;

    const key = label.toLowerCase();
    const existing = merged.get(key);
    if (existing) {
      existing.episodes_watched += eps;
    } else {
      merged.set(key, { genre: label, episodes_watched: eps });
    }
  }

  const all = Array.from(merged.values()).sort((a, b) => {
    if (b.episodes_watched !== a.episodes_watched) {
      return b.episodes_watched - a.episodes_watched;
    }
    return a.genre.localeCompare(b.genre);
  });

  if (all.length === 0) {
    return { items: [], denominator: 0 };
  }

  const cleanTotalEpisodes = Number(totalEpisodes || 0);
  const fallbackTotal = all.reduce((sum, g) => sum + g.episodes_watched, 0);
  const denominator =
    Number.isFinite(cleanTotalEpisodes) && cleanTotalEpisodes > 0
      ? cleanTotalEpisodes
      : fallbackTotal;

  if (denominator <= 0) {
    return { items: [], denominator: 0 };
  }

  const safeLimit = Math.max(1, Math.floor(limit));
  const visible = all.slice(0, safeLimit);

  const items: ComputedGenreShare[] = visible.map((g) => {
    const rawPct = Math.min(100, (g.episodes_watched / denominator) * 100);
    return {
      genre: g.genre,
      episodes_watched: g.episodes_watched,
      percentage: Math.min(100, Math.round(rawPct)),
      barWidth: rawPct,
    };
  });

  return {
    items,
    denominator,
  };
}
