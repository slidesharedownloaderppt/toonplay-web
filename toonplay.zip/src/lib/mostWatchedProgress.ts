import type { AnimeInfoData } from '../types';

export interface MostWatchedLike {
  cartoon_id?: string;
  episodes_watched?: number | null;
  episodes_completed_30d?: number | null;
  episodes_completed_total?: number | null;
  total_episodes_available?: number | null;
}

export interface ShowProgressMetrics {
  /** Unique completed episodes for this show (clamped to totalEpisodes when total is known). */
  watchedEpisodes: number;
  /** Actual total available episodes for this show (0 if unavailable). */
  totalEpisodes: number;
  /** Whether a valid positive total episode count is available. */
  hasTotalEpisodes: boolean;
  /**
   * Completion percentage in [0, 100] rounded to 2 decimal places when totalEpisodes > 0,
   * or null when totalEpisodes is unavailable (never NaN or Infinity).
   * Guaranteed to be < 100 unless watchedEpisodes === totalEpisodes.
   */
  progressPercentage: number | null;
  /** Progress bar fill width percentage in [0, 100] (0 when totalEpisodes is unavailable). */
  barWidth: number;
  /** Formatted percentage string (e.g. "41.67%", "33.33%", "100%"), or null when unavailable. */
  percentageLabel: string | null;
  /** Formatted watched/total episode text using the exact same values as the progress bar. */
  episodeLabel: string;
  /** True strictly when totalEpisodes > 0 and all available episodes are completed. */
  isCompleted: boolean;
}

function toNonNegativeInt(value: unknown): number {
  const num = Number(value);
  if (!Number.isFinite(num) || num <= 0) return 0;
  return Math.floor(num);
}

/**
 * Computes show completion progress strictly from:
 *   progressPercentage = (watchedEpisodes / totalEpisodes) * 100
 *
 * Safeguards:
 * - Never returns NaN or Infinity when totalEpisodes is 0, missing, or invalid.
 * - Never invents a percentage when totalEpisodes is unavailable.
 * - Clamps unique completed episodes to [0, totalEpisodes] when totalEpisodes > 0.
 * - Clamps progress to [0, 100] and only reaches 100% when all available episodes are completed.
 */
export function computeShowProgress(
  watchedEpisodes: unknown,
  totalEpisodes: unknown
): ShowProgressMetrics {
  const rawWatched = toNonNegativeInt(watchedEpisodes);
  const safeTotal = toNonNegativeInt(totalEpisodes);

  if (safeTotal <= 0) {
    return {
      watchedEpisodes: rawWatched,
      totalEpisodes: 0,
      hasTotalEpisodes: false,
      progressPercentage: null,
      barWidth: 0,
      percentageLabel: null,
      episodeLabel: `${rawWatched} ${rawWatched === 1 ? 'episode' : 'episodes'}`,
      isCompleted: false,
    };
  }

  const clampedWatched = Math.min(safeTotal, rawWatched);
  const isCompleted = clampedWatched >= safeTotal;

  let progressPercentage: number;
  if (isCompleted) {
    progressPercentage = 100;
  } else if (clampedWatched <= 0) {
    progressPercentage = 0;
  } else {
    const rawPct = (clampedWatched / safeTotal) * 100;
    const rounded = Math.round(rawPct * 100) / 100;
    // Never display 100% unless every available episode is completed.
    progressPercentage = Math.min(99.99, Math.max(0, rounded));
  }

  const percentageLabel = `${Number(progressPercentage.toFixed(2))}%`;
  const episodeLabel = `${clampedWatched} of ${safeTotal} ${
    safeTotal === 1 ? 'episode' : 'episodes'
  }`;

  return {
    watchedEpisodes: clampedWatched,
    totalEpisodes: safeTotal,
    hasTotalEpisodes: true,
    progressPercentage,
    barWidth: progressPercentage,
    percentageLabel,
    episodeLabel,
    isCompleted,
  };
}

/**
 * Returns the show's authoritative unique completed episode count for progress calculation.
 * Prefers all-time unique completions (`episodes_completed_total`) from `user_episode_completions`,
 * falling back cleanly to 30-day unique completions if an older payload omits it.
 */
export function resolveShowWatchedCount(item: MostWatchedLike | null | undefined): number {
  if (!item) return 0;
  if (item.episodes_completed_total != null) {
    return toNonNegativeInt(item.episodes_completed_total);
  }
  return toNonNegativeInt(item.episodes_completed_30d ?? item.episodes_watched ?? 0);
}

/**
 * Resolves the best known positive total episode count from stored metadata and
 * optional freshly fetched show metadata.
 */
export function resolveShowTotalEpisodes(
  item: MostWatchedLike | null | undefined,
  hydratedTotal?: number | null
): number {
  const stored = toNonNegativeInt(item?.total_episodes_available);
  const fresh = toNonNegativeInt(hydratedTotal);
  if (fresh > 0) return Math.max(stored, fresh);
  return stored;
}

/**
 * Extracts total available episode count from the app's existing `AnimeInfoData` response
 * (mirrors WatchPage's seasonsList aggregation + movie fallback).
 */
export function extractTotalEpisodesFromAnimeInfo(
  anime: Partial<AnimeInfoData> | null | undefined
): number {
  if (!anime) return 0;

  if (Array.isArray(anime.seasonsList) && anime.seasonsList.length > 0) {
    const sum = anime.seasonsList.reduce((acc, season) => {
      if (Array.isArray(season?.episodes) && season.episodes.length > 0) {
        return acc + season.episodes.length;
      }
      return acc + toNonNegativeInt(season?.episodeCount);
    }, 0);
    if (sum > 0) return sum;
  }

  if (typeof anime.episodes === 'string') {
    const match = anime.episodes.trim().match(/^(\d+)/);
    if (match) {
      const parsed = toNonNegativeInt(match[1]);
      if (parsed > 0) return parsed;
    }
  } else if (typeof anime.episodes === 'number') {
    const parsed = toNonNegativeInt(anime.episodes);
    if (parsed > 0) return parsed;
  }

  if (String(anime.type || '').trim().toLowerCase() === 'movie') {
    return 1;
  }

  return 0;
}
