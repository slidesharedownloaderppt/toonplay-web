export interface PageMetadataConfig {
  title: string;
  description: string;
  ogTitle?: string;
  ogDescription?: string;
  ogType?: 'website' | 'video.movie' | 'video.tv_show' | 'video.other' | 'article';
  image?: string;
  imageAlt?: string;
}

const DEFAULT_IMAGE = '/images/og-image.jpg';
const BASE_TITLE = 'ToonPlay - Watch Anime & Cartoons Online Free';
const BASE_DESCRIPTION =
  'Discover and watch cartoons online with ToonPlay. Browse classic and modern animated series, enjoy fast secure streaming, and access a clean catalog experience without intrusive ads.';

const LANGUAGE_LABELS: Record<string, string> = {
  hindi: 'Hindi (हिन्दी)',
  telugu: 'Telugu (తెలుగు)',
  tamil: 'Tamil (தமிழ்)',
  malayalam: 'Malayalam (മലയാളം)',
  kannada: 'Kannada (ಕನ್ನಡ)',
  bengali: 'Bengali (বাংলা)',
  english: 'English',
  japanese: 'Japanese (日本語)',
  korean: 'Korean (한국어)',
};

export function getRouteMetadata(
  route: string,
  params?: {
    query?: string;
    lang?: string;
    category?: string;
    animeTitle?: string;
    animeType?: string;
    animeImage?: string;
    subType?: string;
    page?: number;
    username?: string;
    section?: string;
    sectionLabel?: string;
  }
): PageMetadataConfig {
  const normalizedRoute = route.toLowerCase().replace(/\/+$/, '') || '/';
  const pageSuffix = params?.page && params.page > 1 ? ` - Page ${params.page}` : '';

  if (params?.animeTitle) {
    const isMovie = params.animeType === 'movie';
    const title = params.animeTitle.trim();
    const buildDescription = (prefix: string, suffix: string): string => {
      const full = `${prefix} ${title} ${suffix}`;
      return full.length > 158 ? full.slice(0, 155).trimEnd() + '…' : full;
    };

    const description = isMovie
      ? buildDescription(
          'Watch the anime film',
          'online in HD on ToonPlay — full synopsis, multi-audio dubs, and instant streaming.'
        )
      : buildDescription(
          'Watch',
          'online in HD on ToonPlay — episode lists, multi-server mirrors, audio dubs, and full synopsis.'
        );

    const ogDescription = isMovie
      ? `Stream the anime film ${title} in high definition on ToonPlay.`
      : `Stream ${title} in high definition with multi-server mirrors and multi-audio on ToonPlay.`;

    return {
      title: isMovie ? `${title} (Film) - ToonPlay` : `${title} - ToonPlay`,
      description,
      ogTitle: `${title} - ToonPlay`,
      ogDescription,
      ogType: isMovie ? 'video.movie' : 'video.tv_show',
      image: params.animeImage || DEFAULT_IMAGE,
      imageAlt: `${title} - ToonPlay`,
    };
  }

  if (normalizedRoute.startsWith('/watch/')) {
    return {
      title: 'Watch Anime & Cartoons Online in HD | ToonPlay',
      description: 'Stream anime series and cartoon movies online in high definition with multi-server mirrors, multiple audio dubs, and instant HD playback on ToonPlay.',
      ogTitle: 'Watch Online in HD - ToonPlay',
      ogDescription: 'Stream anime and cartoon titles in HD with multi-server and multi-audio options on ToonPlay.',
      ogType: 'video.other',
      image: DEFAULT_IMAGE,
      imageAlt: 'Watch Anime & Cartoons Online - ToonPlay',
    };
  }

  if (normalizedRoute.startsWith('/info/')) {
    return {
      title: 'Anime & Cartoon Details | ToonPlay',
      description: 'Explore anime and cartoon title details on ToonPlay — full synopsis, episode guides, season metrics, audio dub languages, and recommended related titles.',
      ogTitle: 'Anime & Cartoon Details - ToonPlay',
      ogDescription: 'View full title details, episode guides, and audio dub options on ToonPlay.',
      ogType: 'video.other',
      image: DEFAULT_IMAGE,
      imageAlt: 'Anime & Cartoon Details - ToonPlay',
    };
  }

  if (normalizedRoute === '/' || normalizedRoute === '/home') {
    return {
      title: BASE_TITLE,
      description: BASE_DESCRIPTION,
      ogTitle: BASE_TITLE,
      ogDescription: BASE_DESCRIPTION,
      ogType: 'website',
      image: DEFAULT_IMAGE,
      imageAlt: BASE_TITLE,
    };
  }

  if (normalizedRoute.startsWith('/search')) {
    const q = params?.query?.trim();
    if (q) {
      const safeQ = q.length > 60 ? q.slice(0, 57).trimEnd() + '…' : q;

      const baseDesc = `Search results for "${safeQ}" on ToonPlay. Stream matching anime series, cartoon shows, and movies in HD with multi-language audio dubs across our catalog.`;
      const description =
        baseDesc.length > 158 ? baseDesc.slice(0, 155).trimEnd() + '…' : baseDesc;

      return {
        title: `Search: "${safeQ}"${pageSuffix} | ToonPlay`,
        description,
        ogTitle: `Search results for "${safeQ}" - ToonPlay`,
        ogDescription: `Find anime series, cartoon shows, and movies matching "${safeQ}" on ToonPlay.`,
        ogType: 'website',
        image: DEFAULT_IMAGE,
        imageAlt: `Search results for "${safeQ}" on ToonPlay`,
      };
    }
    return {
      title: `Search Anime & Cartoons${pageSuffix} | ToonPlay`,
      description: 'Search thousands of anime series, cartoon shows, feature animation movies, and multi-language dubbed releases across ToonPlay’s full HD catalog.',
      ogTitle: 'Search Anime & Cartoons - ToonPlay',
      ogDescription: 'Instant title search across ToonPlay’s anime and cartoon library.',
      ogType: 'website',
      image: DEFAULT_IMAGE,
      imageAlt: 'Search Anime & Cartoons - ToonPlay',
    };
  }

  if (normalizedRoute === '/category/anime' || normalizedRoute === '/anime') {
    const typeLabel = params?.subType === 'series' ? 'Series' : params?.subType === 'movies' ? 'Movies' : 'All Catalog';

    const animeDescriptions: Record<string, string> = {
      Series:
        'Stream popular anime series online in HD on ToonPlay. Browse seasonal anime, fan-favorite shows, and complete episode lists with multi-language audio dubs.',
      Movies:
        'Watch blockbuster anime movies online in HD on ToonPlay. Explore top-rated feature films, classic cinematic releases, and modern anime films with multi-audio dubs.',
      'All Catalog':
        'Browse ToonPlay’s full anime catalog — popular series, seasonal anime, and blockbuster anime films, all streamable in HD with multi-language audio dubs.',
    };

const animeOgDescriptions: Record<string, string> = {
  Series:
    'Top rated anime series, fresh weekly episodes, and complete episode guides — streamable in HD on ToonPlay.',
  Movies:
    'Blockbuster anime feature films, classic releases, and modern cinematic titles — streamable in HD on ToonPlay.',
  'All Catalog':
    'The complete ToonPlay anime library — series, movies, and weekly releases, all in high definition.',
};

    return {
      title: `Anime ${typeLabel}${pageSuffix} | ToonPlay`,
      description: animeDescriptions[typeLabel] || animeDescriptions['All Catalog'],
      ogTitle: `Anime ${typeLabel} - ToonPlay`,
      ogDescription: animeOgDescriptions[typeLabel] || animeOgDescriptions['All Catalog'],
      ogType: 'website',
      image: DEFAULT_IMAGE,
      imageAlt: `Anime ${typeLabel} - ToonPlay`,
    };
  }

  if (normalizedRoute === '/category/cartoon' || normalizedRoute === '/cartoon') {
    const typeLabel = params?.subType === 'series' ? 'Series' : params?.subType === 'movies' ? 'Movies' : 'All Catalog';

    const cartoonDescriptions: Record<string, string> = {
      Series:
        'Stream popular cartoon series online in HD on ToonPlay. Browse nostalgic classics, modern animated shows, and full episode collections across all ages.',
      Movies:
        'Watch animated cartoon movies online in HD on ToonPlay. Explore family features, animated classics, and modern cartoon films for all ages.',
      'All Catalog':
        'Browse ToonPlay’s complete cartoon and animation catalog — classic series, family features, nostalgic films, and modern animations, all in high definition.',
    };

    const cartoonOgDescriptions: Record<string, string> = {
      Series:
        'Beloved cartoon series, modern animated shows, and complete episode collections — streamable in HD on ToonPlay.',
      Movies:
        'Family animation features, animated classics, and modern cartoon films — streamable in HD on ToonPlay.',
      'All Catalog':
        'The complete ToonPlay cartoon & animation library — series, movies, and family features in HD.',
    };

    return {
      title: `Cartoons & Animation ${typeLabel}${pageSuffix} | ToonPlay`,
      description: cartoonDescriptions[typeLabel] || cartoonDescriptions['All Catalog'],
      ogTitle: `Cartoons & Animation ${typeLabel} - ToonPlay`,
      ogDescription: cartoonOgDescriptions[typeLabel] || cartoonOgDescriptions['All Catalog'],
      ogType: 'website',
      image: DEFAULT_IMAGE,
      imageAlt: `Cartoons & Animation ${typeLabel} - ToonPlay`,
    };
  }

  if (normalizedRoute === '/languages') {
    return {
      title: 'Browse Anime & Cartoons by Audio Language | ToonPlay',
      description: 'Stream anime and cartoons in your preferred audio language — Hindi, Telugu, Tamil, Malayalam, Kannada, Bengali, English, Japanese, and Korean dubs in HD on ToonPlay.',
      ogTitle: 'Languages & Audio Dubs - ToonPlay',
      ogDescription: 'Pick your audio language and stream anime and cartoon titles dubbed in Hindi, Telugu, Tamil, English, and more on ToonPlay.',
      ogType: 'website',
      image: DEFAULT_IMAGE,
      imageAlt: 'Browse Anime & Cartoons by Audio Language - ToonPlay',
    };
  }

  if (normalizedRoute.startsWith('/language/')) {
    const langCode = params?.lang || normalizedRoute.replace('/language/', '').split('/')[0];
    const langName = LANGUAGE_LABELS[langCode?.toLowerCase() || ''] || (langCode ? langCode.toUpperCase() : 'Dubbed');
    const typeLabel = params?.subType === 'series' ? 'Series' : params?.subType === 'movies' ? 'Movies' : 'Catalog';

    const descVariants: Record<string, string> = {
      Series: `Stream anime and cartoon series dubbed in ${langName} on ToonPlay. Full episode lists, multi-server mirrors, and HD playback with ${langName} audio and subtitles.`,
      Movies: `Watch anime and cartoon movies dubbed in ${langName} on ToonPlay. Feature films in HD with ${langName} audio dubs and subtitles across our full catalog.`,
      Catalog: `Watch anime and cartoon titles dubbed in ${langName} on ToonPlay. Series, movies, and weekly releases in crystal-clear HD with ${langName} audio and subtitles.`,
    };

    const ogDescVariants: Record<string, string> = {
      Series: `Stream ${langName}-dubbed anime and cartoon series with multi-server HD playback on ToonPlay.`,
      Movies: `Watch ${langName}-dubbed anime and cartoon films in HD on ToonPlay.`,
      Catalog: `Stream ${langName}-dubbed anime and cartoon titles — series, movies, and weekly releases — in HD on ToonPlay.`,
    };

    return {
      title: `${langName} Dubbed Anime & Cartoons ${typeLabel}${pageSuffix} | ToonPlay`,
      description: descVariants[typeLabel] || descVariants['Catalog'],
      ogTitle: `${langName} Dubbed Anime & Cartoons - ToonPlay`,
      ogDescription: ogDescVariants[typeLabel] || ogDescVariants['Catalog'],
      ogType: 'website',
      image: DEFAULT_IMAGE,
      imageAlt: `${langName} Dubbed Anime & Cartoons - ToonPlay`,
    };
  }

  if (normalizedRoute === '/watchlist') {
    return {
      title: `My Watchlist — Saved Anime & Cartoons${pageSuffix} | ToonPlay`,
      description: 'Access your personalized watchlist of saved anime series and cartoon movies on ToonPlay. Resume streaming, manage your queue, and pick up any title instantly in HD.',
      ogTitle: 'My Watchlist — Saved Anime & Cartoons - ToonPlay',
      ogDescription: 'Your personal anime and cartoon watchlist on ToonPlay — resume, manage, and stream saved titles anytime.',
      ogType: 'website',
      image: DEFAULT_IMAGE,
      imageAlt: 'My Watchlist — Saved Anime & Cartoons - ToonPlay',
    };
  }

  if (normalizedRoute === '/history') {
    return {
      title: `Watch History — Recently Streamed Anime & Cartoons${pageSuffix} | ToonPlay`,
      description: 'View your chronological watch history on ToonPlay — recent anime series, cartoon shows, and movies you streamed. Easily resume from the exact episode and audio language you left off.',
      ogTitle: 'Watch History — Recently Streamed Anime & Cartoons - ToonPlay',
      ogDescription: 'Your streaming history on ToonPlay — resume any anime or cartoon title from where you left off.',
      ogType: 'website',
      image: DEFAULT_IMAGE,
      imageAlt: 'Watch History — Recently Streamed Anime & Cartoons - ToonPlay',
    };
  }

  if (normalizedRoute === '/about') {
    return {
      title: 'About ToonPlay — Anime & Cartoon Streaming Platform',
      description: 'Learn about ToonPlay: a fast, ad-light anime and cartoon streaming platform with multi-language audio dubs, HD playback, and a clean catalog experience for fans worldwide.',
      ogTitle: 'About ToonPlay — Anime & Cartoon Streaming Platform',
      ogDescription: 'Discover the mission, streaming technology, and community behind ToonPlay — your home for anime and cartoons in HD.',
      ogType: 'article',
      image: DEFAULT_IMAGE,
      imageAlt: 'About ToonPlay — Anime & Cartoon Streaming Platform',
    };
  }

  if (normalizedRoute === '/contact') {
    return {
      title: 'Contact ToonPlay — Support, DMCA & Business Inquiries',
      description: 'Reach ToonPlay support for playback issues, broken links, DMCA requests, media partnerships, or general questions. Get in touch with our team and we’ll respond promptly.',
      ogTitle: 'Contact ToonPlay — Support & Inquiries',
      ogDescription: 'Contact ToonPlay for support, DMCA requests, business inquiries, and feedback. We’re here to help.',
      ogType: 'article',
      image: DEFAULT_IMAGE,
      imageAlt: 'Contact ToonPlay — Support & Inquiries',
    };
  }

  if (normalizedRoute === '/terms') {
    return {
      title: 'Terms of Service — Usage Guidelines & Disclaimers | ToonPlay',
      description: 'Read the full ToonPlay Terms of Service, including acceptable usage guidelines, streaming rules, third-party content disclaimers, and user responsibilities when accessing our platform.',
      ogTitle: 'Terms of Service — ToonPlay',
      ogDescription: 'Review the ToonPlay Terms of Service, acceptable usage rules, and disclaimers governing our streaming platform.',
      ogType: 'article',
      image: DEFAULT_IMAGE,
      imageAlt: 'ToonPlay Terms of Service',
    };
  }

  if (normalizedRoute === '/dmca') {
    return {
      title: 'DMCA & Copyright Notice — Compliance Policy | ToonPlay',
      description: 'ToonPlay DMCA policy, copyright compliance, non-hosting disclaimer, and statutory notice filing procedures. Submit copyright takedown requests with full statutory information.',
      ogTitle: 'DMCA & Copyright Compliance — ToonPlay',
      ogDescription: 'Review ToonPlay’s DMCA compliance policy, non-hosting disclaimer, and copyright notice filing process.',
      ogType: 'article',
      image: DEFAULT_IMAGE,
      imageAlt: 'ToonPlay DMCA & Copyright Compliance Policy',
    };
  }

  if (normalizedRoute === '/profile') {
    const user = params?.username?.trim();
    return {
      title: user
        ? `@${user} — Account Settings | ToonPlay`
        : 'Account Settings | ToonPlay',
      description: user
        ? `Manage your ToonPlay account @${user} — update profile details, avatar, playback preferences, and security settings.`
        : 'Manage your ToonPlay account — update profile details, avatar, playback preferences, and security settings from one dashboard.',
      ogTitle: user ? `@${user} — Account Settings` : 'Account Settings - ToonPlay',
      ogDescription: user
        ? `Personalize your ToonPlay profile @${user} and manage account preferences.`
        : 'Update your ToonPlay account and streaming preferences.',
      ogType: 'website',
      image: DEFAULT_IMAGE,
      imageAlt: 'ToonPlay Account Settings',
    };
  }

  if (normalizedRoute.startsWith('/u/') && normalizedRoute.endsWith('/activity')) {
    const raw = normalizedRoute.replace(/^\/u\//, '').replace(/\/activity\/?$/, '');
    const uname = params?.username?.trim() || raw || 'User';
    return {
      title: `@${uname}'s Activity — Watchlist & Streaming History | ToonPlay`,
      description: `Explore @${uname}'s full watchlist activity on ToonPlay — currently watching, completed titles, and streaming history across anime series and cartoon movies.`,
      ogTitle: `@${uname}'s Activity - ToonPlay`,
      ogDescription: `See what @${uname} is watching and has completed on ToonPlay.`,
      ogType: 'website',
      image: DEFAULT_IMAGE,
      imageAlt: `@${uname}'s Activity on ToonPlay`,
    };
  }

  if (normalizedRoute.startsWith('/u/')) {
    const raw = normalizedRoute.replace(/^\/u\//, '').split('/')[0];
    const uname = params?.username?.trim() || raw || 'User';
    return {
      title: `@${uname} — Profile, Stats & Watchlist | ToonPlay`,
      description: `View @${uname}'s ToonPlay profile — level progress, XP tier, watchlist, completed anime, and streaming statistics across anime and cartoon titles.`,
      ogTitle: `@${uname} — Profile - ToonPlay`,
      ogDescription: `Check out @${uname}'s watchlist, stats, and level progression on ToonPlay.`,
      ogType: 'website',
      image: DEFAULT_IMAGE,
      imageAlt: `@${uname}'s Profile on ToonPlay`,
    };
  }

  if (normalizedRoute === '/leaderboard' || normalizedRoute === '/leaderboards') {
    return {
      title: 'Global Leaderboard — Top Anime & Cartoon Fans by XP | ToonPlay',
      description:
        'Explore ToonPlay’s global leaderboard — the top anime and cartoon fans ranked by total XP, level progress, and watch streaks. See the hall of fame and track your climb.',
      ogTitle: 'Global Leaderboard — Top Fans by XP - ToonPlay',
      ogDescription:
        'The highest-XP anime and cartoon fans on ToonPlay — hall of fame, top 10 ranking, and XP leaderboard.',
      ogType: 'website',
      image: DEFAULT_IMAGE,
      imageAlt: 'ToonPlay Global Leaderboard — Hall of Fame',
    };
  }

  if (normalizedRoute === '/downloads') {
    return {
      title: 'Download Center — Anime & Cartoon Episodes | ToonPlay',
      description: 'Download anime and cartoon episodes in 480p, 720p, 1080p — multiple quality options and direct links from HCloud, GDF, MEGA, and more.',
      ogTitle: 'Download Center - ToonPlay',
      ogDescription: 'Download anime and cartoon episodes in multiple qualities.',
      ogType: 'website',
      image: DEFAULT_IMAGE,
      imageAlt: 'ToonPlay Download Center',
    };
  }
  
    if (
    normalizedRoute === '/movies' ||
    normalizedRoute === '/category/movies'
  ) {
    return {
      title: `Movies & Shows — Stream in HD${pageSuffix} | ToonPlay`,
      description:
        'Browse the full ToonPlay movies catalog — blockbuster films, K-dramas, C-dramas, anime, documentaries, and international shows streaming in HD with multi-language audio dubs.',
      ogTitle: 'Movies & Shows — Streaming in HD - ToonPlay',
      ogDescription:
        'Blockbuster films, K-dramas, anime, and international shows — all streaming in HD on ToonPlay.',
      ogType: 'website',
      image: DEFAULT_IMAGE,
      imageAlt: 'ToonPlay Movies & Shows Catalog',
    };
  }

  if (normalizedRoute.startsWith('/movies/section/')) {
    const rawId = normalizedRoute
      .replace(/^\/movies\/section\//, '')
      .split('/')[0];

    const slug = rawId || '';

    const prettySlug =
      params?.sectionLabel?.trim() ||
      (slug
        ? slug
            .replace(/[-_]+/g, ' ')
            .replace(/\b\w/g, (c) => c.toUpperCase())
        : 'Movies Collection');

    return {
      title: `${prettySlug}${pageSuffix} | ToonPlay`,
      description: `Browse ${prettySlug} on ToonPlay — blockbuster films, K-dramas, C-dramas, anime, and international shows streaming in HD with multi-language audio dubs.`,
      ogTitle: `${prettySlug} - ToonPlay`,
      ogDescription: `Stream ${prettySlug} in HD on ToonPlay.`,
      ogType: 'website',
      image: DEFAULT_IMAGE,
      imageAlt: `${prettySlug} on ToonPlay`,
    };
  }
  if (normalizedRoute.startsWith('/downloads/')) {
    const slug = normalizedRoute.replace('/downloads/', '').split('/')[0];
    const pretty = slug
      .split('-')
      .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
      .join(' ');
    return {
      title: `${pretty} — Episode Downloads | ToonPlay`,
      description: `Download ${pretty} episodes in multiple resolutions and qualities from ToonPlay.`,
      ogTitle: `${pretty} — Downloads - ToonPlay`,
      ogDescription: `Download ${pretty} episodes in HD.`,
      ogType: 'website',
      image: DEFAULT_IMAGE,
      imageAlt: `${pretty} — Downloads on ToonPlay`,
    };
  }

  if (normalizedRoute === '/friends') {
    return {
      title: `Friends — Manage Your Anime & Cartoon Squad${pageSuffix} | ToonPlay`,
      description:
        'Manage your ToonPlay friends — send and accept friend requests, browse your friends list, and discover other anime and cartoon fans. Connect, compare stats, and grow your squad.',
      ogTitle: 'Friends — Your Anime & Cartoon Squad - ToonPlay',
      ogDescription:
        'Send friend requests, accept incoming invites, and manage your ToonPlay friends — connect with anime and cartoon fans worldwide.',
      ogType: 'website',
      image: DEFAULT_IMAGE,
      imageAlt: 'ToonPlay Friends — Manage Your Squad',
    };
  }

  if (normalizedRoute.startsWith('/section/')) {
    const slug =
      params?.section ||
      normalizedRoute.replace(/^\/section\//, '').split('/')[0] ||
      '';

    const SECTION_META: Record<
      string,
      { title: string; description: string; ogTitle: string; ogDescription: string }
    > = {
      'childhood-shows': {
        title: `Childhood Shows${pageSuffix} | ToonPlay`,
        description:
          'Relive your childhood on ToonPlay — nostalgic classic cartoons, retro anime shows, and beloved animated favorites from the golden era of television, streaming in HD.',
        ogTitle: 'Childhood Shows - ToonPlay',
        ogDescription:
          'Nostalgic classics, retro cartoons, and childhood favorite shows streaming in HD on ToonPlay.',
      },
      'latest-episodes': {
        title: `Latest Episodes & Releases${pageSuffix} | ToonPlay`,
        description:
          'Stream the latest anime episodes and fresh cartoon releases on ToonPlay — newly added titles, weekly episodes, and recent movie drops in HD.',
        ogTitle: 'Latest Episodes & Releases - ToonPlay',
        ogDescription:
          'Fresh anime episodes and new cartoon releases streaming in HD on ToonPlay.',
      },
      'popular-series': {
        title: `Most Popular TV Series${pageSuffix} | ToonPlay`,
        description:
          'Discover the most popular anime and cartoon TV series on ToonPlay — top-rated shows, fan favorites, and binge-worthy episode collections in HD.',
        ogTitle: 'Most Popular TV Series - ToonPlay',
        ogDescription:
          'Top-rated anime and cartoon series streaming in HD on ToonPlay.',
      },
      'blockbuster-movies': {
        title: `Blockbuster Anime Movies${pageSuffix} | ToonPlay`,
        description:
          'Watch blockbuster anime and animated movies on ToonPlay — cinematic feature films, classic releases, and modern hits in HD with multi-language dubs.',
        ogTitle: 'Blockbuster Anime Movies - ToonPlay',
        ogDescription:
          'Feature-length anime and animated films streaming in HD on ToonPlay.',
      },
    };

    const meta = SECTION_META[slug];
    if (meta) {
      return {
        title: meta.title,
        description: meta.description,
        ogTitle: meta.ogTitle,
        ogDescription: meta.ogDescription,
        ogType: 'website',
        image: DEFAULT_IMAGE,
        imageAlt: meta.ogTitle,
      };
    }

    return {
      title: `Catalog Section${pageSuffix} | ToonPlay`,
      description:
        'Browse curated anime and cartoon catalog sections on ToonPlay — trending, latest, popular series, and blockbuster movies, all in HD.',
      ogTitle: 'Catalog Section - ToonPlay',
      ogDescription: 'Curated anime and cartoon catalog sections on ToonPlay.',
      ogType: 'website',
      image: DEFAULT_IMAGE,
      imageAlt: 'Catalog Section - ToonPlay',
    };
  }

  return {
    title: BASE_TITLE,
    description: BASE_DESCRIPTION,
    ogTitle: BASE_TITLE,
    ogDescription: BASE_DESCRIPTION,
    ogType: 'website',
    image: DEFAULT_IMAGE,
    imageAlt: BASE_TITLE,
  };
}

export function applyPageMetadata(meta: PageMetadataConfig): void {
  if (typeof document === 'undefined') return;

  document.title = meta.title;

  const setMeta = (nameOrProperty: string, content: string, isProperty = false) => {
    const attribute = isProperty ? 'property' : 'name';
    let el = document.querySelector(`meta[${attribute}="${nameOrProperty}"]`);
    if (!el) {
      el = document.createElement('meta');
      el.setAttribute(attribute, nameOrProperty);
      document.head.appendChild(el);
    }
    el.setAttribute('content', content);
  };

  const currentImage = meta.image || DEFAULT_IMAGE;
  const currentAlt = meta.imageAlt || meta.ogTitle || meta.title;

  setMeta('description', meta.description);

  setMeta('og:title', meta.ogTitle || meta.title, true);
  setMeta('og:description', meta.ogDescription || meta.description, true);
  setMeta('og:type', meta.ogType || 'website', true);
  setMeta('og:site_name', 'ToonPlay', true);
  setMeta('og:image', currentImage, true);
  setMeta('og:image:secure_url', currentImage, true);
  setMeta('og:image:type', 'image/jpeg', true);
  setMeta('og:image:width', '1200', true);
  setMeta('og:image:height', '630', true);
  setMeta('og:image:alt', currentAlt, true);

  setMeta('twitter:card', 'summary_large_image');
  setMeta('twitter:title', meta.ogTitle || meta.title);
  setMeta('twitter:description', meta.ogDescription || meta.description);
  setMeta('twitter:image', currentImage);
  setMeta('twitter:image:alt', currentAlt);
}

export function updateMetadataForRoute(
  route: string,
  params?: {
    query?: string;
    lang?: string;
    category?: string;
    animeTitle?: string;
    animeType?: string;
    animeImage?: string;
    subType?: string;
    page?: number;
    username?: string;
    section?: string;
    sectionLabel?: string;
  }
): void {
  const meta = getRouteMetadata(route, params);
  applyPageMetadata(meta);
}

export default {
  getRouteMetadata,
  applyPageMetadata,
  updateMetadataForRoute,
};
