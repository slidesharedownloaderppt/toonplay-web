import React, { useState, useEffect, useCallback, useMemo, useRef, lazy, Suspense } from 'react';
import { Navbar } from './components/Navbar.tsx';
import { HeroBanner } from './components/HeroBanner.tsx';
import { LanguageGridSection } from './components/LanguageGridSection.tsx';
import { Share } from './components/Share.tsx';
import { CatalogTabsSection } from './components/CatalogTabsSection.tsx';
import { ContinueWatchingSection } from './components/ContinueWatchingSection.tsx';
import { AnimeSection } from './components/AnimeSection.tsx';
import { LoadingSkeleton } from './components/LoadingSkeleton.tsx';
import { BootScreen } from './components/BootScreen.tsx';
import type { HomeSectionSlug } from './pages/HomeSectionPage.tsx';
import { LanguageSkeleton } from './components/LanguageSkeleton.tsx';
import { CategorySkeleton } from './components/CategorySkeleton.tsx';
import { HomeSectionSkeleton } from './components/HomeSectionSkeleton.tsx';
import { WatchlistSkeleton } from './components/WatchlistSkeleton.tsx';
import { HistorySkeleton } from './components/HistorySkeleton.tsx';
import { WatchSkeleton } from './components/WatchSkeleton.tsx';
import { SearchSkeleton } from './components/SearchSkeleton.tsx';
import { InfoSkeleton } from './components/InfoSkeleton.tsx';
import { ErrorState } from './components/ErrorState.tsx';
import { Footer } from './components/Footer.tsx';
import { ProfileSettingsSkeleton } from './components/ProfileSettingsSkeleton.tsx';
import { PublicProfileSkeleton } from './components/PublicProfileSkeleton.tsx';
import { LeaderboardSkeleton } from './components/LeaderboardSkeleton.tsx';
import { FriendsSkeleton } from './components/FriendsSkeleton.tsx';
import { UserActivitySkeleton } from './components/UserActivitySkeleton.tsx';
import type { AuthStep } from './components/auth/AuthModal.tsx';
import { MoviesSkeleton } from './components/MoviesSkeleton.tsx';
import { useAuth } from './context/AuthContext.tsx';
import { watchlistApi, historyApi, watchApi, statsApi, getToken } from './lib/api.ts';
import { HomeApiData, HomeApiResponse, UnifiedAnime, TrendingAnime } from './types.ts';
import {
  getStoredWatchlist,
  saveStoredWatchlist,
  getStoredHistory,
  saveStoredHistory,
  normalizeApiData,
} from './utils/animeHelper.ts';
import { Check } from 'lucide-react';
import { fetchHomeContent, getCachedHomeContent } from './api.ts';
import { updateMetadataForRoute } from './metadata.ts';

const HomeSectionPage = lazy(() =>
  import('./pages/HomeSectionPage.tsx').then((m) => ({ default: m.HomeSectionPage }))
);
const SearchPage = lazy(() =>
  import('./pages/SearchPage.tsx').then((m) => ({ default: m.SearchPage }))
);
const CategoryPage = lazy(() =>
  import('./pages/CategoryPage.tsx').then((m) => ({ default: m.CategoryPage }))
);
const LanguagePage = lazy(() =>
  import('./pages/LanguagePage.tsx').then((m) => ({ default: m.LanguagePage }))
);
const WatchlistPage = lazy(() =>
  import('./pages/WatchlistPage.tsx').then((m) => ({ default: m.WatchlistPage }))
);
const HistoryPage = lazy(() =>
  import('./pages/HistoryPage.tsx').then((m) => ({ default: m.HistoryPage }))
);
const FriendsPage = lazy(() =>
  import('./pages/FriendsPage.tsx').then((m) => ({ default: m.FriendsPage }))
);
const DownloadsPage = lazy(() =>
  import('./pages/DownloadsPage.tsx').then((m) => ({ default: m.DownloadsPage }))
);
const DownloadDetailPage = lazy(() =>
  import('./pages/DownloadDetailPage.tsx').then((m) => ({ default: m.DownloadDetailPage }))
);
const LanguagesDirectoryPage = lazy(() =>
  import('./pages/LanguagesDirectoryPage.tsx').then((m) => ({ default: m.LanguagesDirectoryPage }))
);
const InfoPage = lazy(() =>
  import('./pages/InfoPage.tsx').then((m) => ({ default: m.InfoPage }))
);
const WatchPage = lazy(() =>
  import('./pages/WatchPage.tsx').then((m) => ({ default: m.WatchPage }))
);
const AboutPage = lazy(() =>
  import('./pages/StaticPages.tsx').then((m) => ({ default: m.AboutPage }))
);
const ContactPage = lazy(() =>
  import('./pages/StaticPages.tsx').then((m) => ({ default: m.ContactPage }))
);
const TermsPage = lazy(() =>
  import('./pages/StaticPages.tsx').then((m) => ({ default: m.TermsPage }))
);
const DmcaPage = lazy(() =>
  import('./pages/StaticPages.tsx').then((m) => ({ default: m.DmcaPage }))
);
const LoginPage = lazy(() =>
  import('./components/auth/LoginPage.tsx').then((m) => ({ default: m.LoginPage }))
);
const RegisterPage = lazy(() =>
  import('./components/auth/RegisterPage.tsx').then((m) => ({ default: m.RegisterPage }))
);
const ForgotPasswordPage = lazy(() =>
  import('./components/auth/ForgotPasswordPage.tsx').then((m) => ({ default: m.ForgotPasswordPage }))
);
const ProfilePage = lazy(() =>
  import('./components/profile/ProfilePage.tsx').then((m) => ({ default: m.ProfilePage }))
);
const UserActivityPage = lazy(() =>
  import('./pages/UserActivityPage.tsx').then((m) => ({ default: m.UserActivityPage }))
);
const LeaderboardPage = lazy(() =>
  import('./pages/LeaderboardPage.tsx').then((m) => ({ default: m.LeaderboardPage }))
);
const MoviesPage = lazy(() => import('./pages/MoviesPage.tsx'));
const MoviesSectionPage = lazy(() => import('./pages/MoviesSectionPage.tsx'));
const SearchModal = lazy(() =>
  import('./components/SearchModal.tsx').then((m) => ({ default: m.SearchModal }))
);
const AuthModal = lazy(() =>
  import('./components/auth/AuthModal.tsx').then((m) => ({ default: m.AuthModal }))
);
const TelegramJoinModal = lazy(() =>
  import('./components/TelegramJoinModal.tsx').then((m) => ({ default: m.TelegramJoinModal }))
);

type AppView =
  | 'home'
  | 'anime'
  | 'cartoon'
  | 'movies' 
  | 'languages'
  | 'language'
  | 'search'
  | 'watchlist'
  | 'history'
  | 'info'
  | 'watch'
  | 'about'
  | 'contact'
  | 'terms'
  | 'dmca'
  | 'login'
  | 'register'
  | 'forgot-password'
  | 'profile'
  | 'user-activity'
  | 'leaderboard'
  | 'friends'
  | 'downloads'
  | 'download-detail'
  | 'home-section'
  | 'movies-section';

function dbWatchlistRowToUnified(row: any): UnifiedAnime {
  const rawId =
    row?.cartoon_id ??
    row?.cartoonId ??
    row?.anime_id ??
    row?.animeId ??
    row?.id ??
    '';
  const title =
    row?.cartoon_title ??
    row?.cartoonTitle ??
    row?.anime_title ??
    row?.animeTitle ??
    row?.title ??
    '';
  const image =
    row?.cartoon_image ??
    row?.cartoonImage ??
    row?.anime_image ??
    row?.animeImage ??
    row?.image ??
    '';
  const rawType =
    row?.cartoon_type ??
    row?.cartoonType ??
    row?.anime_type ??
    row?.animeType ??
    row?.type ??
    'series';

  const rawTypeStr = String(rawType || 'SERIES').trim().toUpperCase();
  const isMovie = rawTypeStr === 'MOVIE';

  const rawAnilist = row?.anilist_id ?? row?.anilistId ?? null;
  const anilistId =
    rawAnilist != null && Number(rawAnilist) > 0 ? Number(rawAnilist) : undefined;
  const rawTmdb = row?.tmdb_id ?? row?.tmdbId ?? null;
  const tmdbId =
    rawTmdb != null && Number(rawTmdb) > 0 ? Number(rawTmdb) : undefined;

const rawSubjectId = row?.subject_id ?? row?.subjectId ?? null;
const subjectId =
  rawSubjectId != null && String(rawSubjectId).trim()
    ? String(rawSubjectId).trim()
    : undefined;

return {
  id: String(rawId || ''),
  title: String(title || ''),
  image: String(image || ''),
  type: isMovie ? 'movie' : 'series',
  displayType: rawTypeStr,
  anilistId,
  tmdbId,
  subjectId,
  category: isMovie ? 'movie' : 'series',
};
}

function dbHistoryRowToUnified(row: any): UnifiedAnime {
  const rawId = row?.cartoon_id ?? row?.cartoonId ?? row?.anime_id ?? row?.animeId ?? row?.id ?? '';
  const title = row?.cartoon_title ?? row?.cartoonTitle ?? row?.anime_title ?? row?.animeTitle ?? row?.title ?? '';
  const image = row?.cartoon_image ?? row?.cartoonImage ?? row?.anime_image ?? row?.animeImage ?? row?.image ?? '';
  const rawType = row?.cartoon_type ?? row?.cartoonType ?? row?.anime_type ?? row?.animeType ?? row?.type ?? 'series';

  const rawTypeStr = String(rawType || 'SERIES').trim().toUpperCase();
  const isMovie = rawTypeStr === 'MOVIE';

const rawAnilist = row?.anilist_id ?? row?.anilistId ?? null;
const anilistId = rawAnilist != null && Number(rawAnilist) > 0 ? Number(rawAnilist) : undefined;
const rawTmdb = row?.tmdb_id ?? row?.tmdbId ?? null;
const tmdbId = rawTmdb != null && Number(rawTmdb) > 0 ? Number(rawTmdb) : undefined;

const rawSubjectId = row?.subject_id ?? row?.subjectId ?? null;
const subjectId =
  rawSubjectId != null && String(rawSubjectId).trim()
    ? String(rawSubjectId).trim()
    : undefined;

  // server_type is stored like "options1-tel" — split into server + lang
  const rawServerType = String(row?.server_type ?? row?.serverType ?? '').trim();
  const dashIdx = rawServerType.lastIndexOf('-');
  const serverBase = dashIdx > 0 ? rawServerType.slice(0, dashIdx) : rawServerType || undefined;
  const langFromServer = dashIdx > 0 ? rawServerType.slice(dashIdx + 1) : undefined;

  const resolvedId = String(rawId || '');
  const isReanime = resolvedId && !/^(anime|movies?|series)[-_]/i.test(resolvedId);

  return {
    id: resolvedId,
    title: String(title || ''),
    image: String(image || ''),
    type: isMovie ? 'movie' : 'series',
    displayType: rawTypeStr,
    anilistId,
    tmdbId,
    subjectId,
    category: isMovie ? 'movie' : 'series',
    seasonNumber: isReanime
      ? undefined
      : row?.season_number ?? row?.seasonNumber ?? undefined,
    episodeNumber: row?.episode_number ?? row?.episodeNumber ?? undefined,
    server: serverBase,
    lang: row?.lang ?? langFromServer ?? undefined,
    playedAt: row?.last_watched
      ? new Date(row.last_watched).getTime()
      : row?.lastWatched
      ? new Date(row.lastWatched).getTime()
      : undefined,
  };
}

function sanitizeStoredList(list: UnifiedAnime[]): UnifiedAnime[] {
  if (!Array.isArray(list)) return [];
  return list
    .filter(
      (item) =>
        item &&
        typeof item.id === 'string' &&
        item.id !== '' &&
        item.id !== 'undefined' &&
        item.id !== 'null' &&
        typeof item.title === 'string' &&
        item.title !== ''
    )
    .map((item) => {
      const isReanime = !/^(anime|movies?|series)[-_]/i.test(item.id);
      if (!isReanime) return item;
      if (item.seasonNumber == null) return item;
      return { ...item, seasonNumber: undefined };
    });
}

export default function App() {
  // Global direct-link ad: opens only after a genuine user click.
  useEffect(() => {
    const AD_URL = import.meta.env.VITE_DIRECT_LINK_AD_URL;
    const STORAGE_KEY = 'toonplay_watch_direct_link_last_attempt';
    const COOLDOWN = 24 * 60 * 60 * 1000;

    if (!AD_URL) return;

const handleGlobalClick = (event: MouseEvent) => {
  if (!event.isTrusted) return;

  // Do not trigger ads from clicks inside the Telegram join modal.
  if (
    event.target instanceof Element &&
    event.target.closest('[data-no-direct-link-ad="true"]')
  ) {
    return;
  }

      try {
        const lastAttempt = Number(localStorage.getItem(STORAGE_KEY) || 0);

        if (lastAttempt > 0 && Date.now() - lastAttempt < COOLDOWN) {
          return;
        }
      } catch {
        // Continue if localStorage is unavailable.
      }

      const adWindow = window.open(AD_URL, '_blank');

      if (adWindow) {
        adWindow.opener = null;

        try {
          localStorage.setItem(STORAGE_KEY, String(Date.now()));
        } catch {
          // Ignore storage errors.
        }
      }
    };

    document.addEventListener('click', handleGlobalClick, true);

    return () => {
      document.removeEventListener('click', handleGlobalClick, true);
    };
  }, []);

  const initialCachedHome = useMemo(() => getCachedHomeContent(), []);
  const [apiData, setApiData] = useState<HomeApiData | null>(() =>
    initialCachedHome?.success && initialCachedHome.data ? initialCachedHome.data : null
  );
  const [isLoading, setIsLoading] = useState<boolean>(
    () => !(initialCachedHome?.success && initialCachedHome.data)
  );
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const [activeMainTab, setActiveMainTab] = useState<'all' | 'anime' | 'cartoon' | 'watchlist' | 'history'>('all');

  const [currentView, setCurrentView] = useState<AppView>(() => {
    if (typeof window === 'undefined') return 'home';
    const p = window.location.pathname.toLowerCase();
    if (p.startsWith('/watch/')) return 'watch';
    if (p.startsWith('/section/')) return 'home-section';
    if (p.startsWith('/info/')) return 'info';
    if (p === '/search') return 'search';
    if (p === '/friends') return 'friends';
    if (p === '/downloads') return 'downloads';
    if (p.startsWith('/downloads/')) return 'download-detail';
if (p === '/category/anime' || p === '/anime') return 'anime';
if (p === '/category/cartoon' || p === '/cartoon') return 'cartoon';
if (p === '/movies' || p === '/category/movies') return 'movies';
if (p.startsWith('/movies/section/')) return 'movies-section';
    if (p === '/languages') return 'languages';
    if (p.startsWith('/language/')) return 'language';
    if (p === '/watchlist') return 'watchlist';
    if (p === '/history') return 'history';
    if (p === '/about') return 'about';
    if (p === '/contact') return 'contact';
    if (p === '/terms') return 'terms';
    if (p === '/dmca') return 'dmca';
    if (p === '/login') return 'login';
    if (p === '/register') return 'register';
    if (p === '/forgot-password') return 'forgot-password';
    if (p === '/profile') return 'profile';
    if (p === '/leaderboard' || p === '/leaderboards') return 'leaderboard';
    if (p.startsWith('/u/')) {
      const parts = p.replace(/^\/u\//, '').split('/').filter(Boolean);
      if (parts[1] === 'activity') return 'user-activity';
      return 'profile';
    }
    return 'home';
  });
  const [currentPath, setCurrentPath] = useState<string>(() =>
    typeof window !== 'undefined'
      ? window.location.pathname.replace(/\/+$/, '') || '/'
      : '/'
  );
  const [infoAnimeId, setInfoAnimeId] = useState<string>('');
  const [infoSubjectId, setInfoSubjectId] = useState<string>('');
const [watchAnimeId, setWatchAnimeId] = useState<string>('');
const [watchSubjectId, setWatchSubjectId] = useState<string>('');
  const [searchParamQuery, setSearchParamQuery] = useState<string>('');
  const [languagePageLang, setLanguagePageLang] = useState<string>('hindi');
  const [profileUsername, setProfileUsername] = useState<string>('');
  const [userActivityUsername, setUserActivityUsername] = useState<string>('');
  const [downloadSlug, setDownloadSlug] = useState<string>('');
const [moviesSectionId, setMoviesSectionId] = useState<string>(() => {
  if (typeof window === 'undefined') return '';
  const p = window.location.pathname.toLowerCase();
  if (p.startsWith('/movies/section/')) {
    return decodeURIComponent(
      window.location.pathname
        .replace(/^\/movies\/section\//i, '')
        .split(/[?#]/)[0]
    );
  }
  return '';
});
  const [homeSection, setHomeSection] = useState<string>(() => {
    if (typeof window === 'undefined') return '';
    const p = window.location.pathname.toLowerCase();

    if (p.startsWith('/section/')) {
      const slug = window.location.pathname
        .replace(/^\/section\//i, '')
        .split(/[?#]/)[0];

      return slug === 'trending' ? 'childhood-shows' : slug;
    }

    return '';
  });
  const [authModal, setAuthModal] = useState<{ open: boolean; step: AuthStep }>({
    open: false,
    step: 'login',
  });

  const { isAuthenticated, loading: authLoading, user: authUser } = useAuth();

const [selectedLanguage, setSelectedLanguage] = useState<string | null>(null);
const [latestLangTab, setLatestLangTab] = useState<'JAP/ENG' | 'HIN/TAM/TEL'>('HIN/TAM/TEL');

const [isUnder480, setIsUnder480] = useState(() => {
  return typeof window !== 'undefined' &&
    window.matchMedia('(max-width: 479px)').matches;
});

useEffect(() => {
  const mediaQuery = window.matchMedia('(max-width: 479px)');

  const handleScreenChange = () => {
    setIsUnder480(mediaQuery.matches);
  };

  handleScreenChange();
  mediaQuery.addEventListener('change', handleScreenChange);

  return () => {
    mediaQuery.removeEventListener('change', handleScreenChange);
  };
}, []);

const [showTelegramModal, setShowTelegramModal] = useState(false);

const handleCloseTelegramModal = useCallback(() => {
  localStorage.setItem('toonplay_telegram_dismissed', String(Date.now()));
  setShowTelegramModal(false);
}, []);

  const watchSessionRef = useRef<{
    cartoonId: string;
    cartoonTitle: string;
    cartoonImage: string;
    cartoonType: string;
    serverType?: string;
    episodeId?: string;
    episodeNumber?: number;
    seasonNumber?: number;
    episodeTitle?: string;
    episodeImage?: string;
    genres?: string[];
    totalEpisodesAvailable?: number;
    startedAt: number;
    lastFlushedSeconds: number;
  } | null>(null);

  const [watchlist, setWatchlist] = useState<UnifiedAnime[]>(() => {
    if (getToken()) return [];
    return sanitizeStoredList(getStoredWatchlist());
  });
  const [history, setHistory] = useState<UnifiedAnime[]>(() => {
    if (getToken()) return [];
    return sanitizeStoredList(getStoredHistory());
  });

  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const [searchInitialQuery, setSearchInitialQuery] = useState<string>('');

const [booting, setBooting] = useState<boolean>(true);
const [bootProgress, setBootProgress] = useState(false);
const bootStartRef = useRef<number>(performance.now());
const handleBootComplete = useCallback(() => setBootProgress(true), []);

useEffect(() => {
  if (booting) return;

  const STORAGE_KEY = 'toonplay_telegram_dismissed';
  const COOLDOWN = 24 * 60 * 60 * 1000;

  const lastDismissed = Number(localStorage.getItem(STORAGE_KEY));

  if (lastDismissed && Date.now() - lastDismissed < COOLDOWN) {
    return;
  }

  const timer = window.setTimeout(() => {
    setShowTelegramModal(true);
  }, 1200);

  return () => window.clearTimeout(timer);
}, [booting]);
  const [languagePageLoading, setLanguagePageLoading] = useState<boolean>(true);
  const [categoryPageLoading, setCategoryPageLoading] = useState<boolean>(true);
  const [watchPageLoading, setWatchPageLoading] = useState<boolean>(true);
  const [searchPageLoading, setSearchPageLoading] = useState<boolean>(true);
  const [infoPageLoading, setInfoPageLoading] = useState<boolean>(true);
  const [watchlistPageLoading, setWatchlistPageLoading] = useState<boolean>(true);
  const [historyPageLoading, setHistoryPageLoading] = useState<boolean>(true);
  const [userActivityPageLoading, setUserActivityPageLoading] = useState<boolean>(true);
  const [profilePageLoading, setProfilePageLoading] = useState<boolean>(true);
  const [leaderboardPageLoading, setLeaderboardPageLoading] = useState<boolean>(true);
  const [friendsPageLoading, setFriendsPageLoading] = useState<boolean>(true);
  const [homeSectionPageLoading, setHomeSectionPageLoading] = useState<boolean>(true);
  const [moviesPageLoading, setMoviesPageLoading] = useState<boolean>(true);
  const [moviesSectionPageLoading, setMoviesSectionPageLoading] = useState<boolean>(true);

  const currentViewRef = useRef<AppView>(currentView);
  useEffect(() => {
    currentViewRef.current = currentView;
  }, [currentView]);

  const currentLanguageRef = useRef<string>(languagePageLang);
  useEffect(() => {
    currentLanguageRef.current = languagePageLang;
  }, [languagePageLang]);
  
const currentHomeSectionRef = useRef<string>('');
useEffect(() => {
  currentHomeSectionRef.current = homeSection;
}, [homeSection]);

const currentMoviesSectionRef = useRef<string>('');
useEffect(() => {
  currentMoviesSectionRef.current = moviesSectionId;
}, [moviesSectionId]);

const infoAnimeIdRef = useRef<string>(infoAnimeId);
useEffect(() => {
  infoAnimeIdRef.current = infoAnimeId;
}, [infoAnimeId]);

  const lastProfileTargetRef = useRef<string>('');
  
  useEffect(() => {
  const handleOpenAuth = (event: Event) => {
    const detail = (event as CustomEvent<{ step?: AuthStep }>).detail;
    setAuthModal({
      open: true,
      step: detail?.step || 'login',
    });
  };

  window.addEventListener('toonplay:open-auth', handleOpenAuth);
  return () => window.removeEventListener('toonplay:open-auth', handleOpenAuth);
}, []);

useEffect(() => {
  if (!booting) return;
  if (bootProgress && !isLoading) {
    setBooting(false);
    return;
  }
  const t = window.setTimeout(() => setBooting(false), 4500);
  return () => window.clearTimeout(t);
}, [booting, bootProgress, isLoading]);

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((current) => (current === msg ? null : current));
    }, 2800);
  }, []);

  const parseCurrentLocation = useCallback(() => {

    if (window.location.hash) {
      const cleanHash = window.location.hash.replace(/^#\/?/, '');
      const targetPath = cleanHash ? `/${cleanHash}` : '/';
      window.history.replaceState(null, '', targetPath);
    }

    const rawPath = window.location.pathname.replace(/\/+$/, '') || '/';
    const pathname = rawPath.toLowerCase();
    setCurrentPath(rawPath);
    const searchParams = new URLSearchParams(window.location.search);
    const historyState = window.history.state as {
  subjectId?: string;
} | null;

const routeSubjectId = String(historyState?.subjectId || '').trim();

    if (!pathname.startsWith('/u/') && pathname !== '/profile') {
      lastProfileTargetRef.current = '';
    }

if (pathname.startsWith('/watch/')) {
  const watchId = rawPath.replace(/^\/watch\/?/i, '').split('?')[0];

  setCurrentView('watch');
  setWatchAnimeId(watchId);
  setWatchSubjectId(routeSubjectId);
  setWatchPageLoading(true);
} else if (pathname.startsWith('/info/')) {
  const infoId = rawPath.replace(/^\/info\/?/i, '').split('?')[0];
  const changedId = infoId !== infoAnimeIdRef.current;

  setCurrentView('info');
  setInfoAnimeId(infoId);
  setInfoSubjectId(routeSubjectId);

  if (changedId) setInfoPageLoading(true);
} else if (pathname === '/movies' || pathname === '/category/movies') {
      const wasNotOnMovies = currentViewRef.current !== 'movies';
      setCurrentView('movies');
      if (wasNotOnMovies) setMoviesPageLoading(true);
    } else if (pathname.startsWith('/movies/section/')) {
      const secId = decodeURIComponent(
        rawPath.replace(/^\/movies\/section\//, '').split(/[?#]/)[0]
      );
      const wasNotOnSameSection =
        currentViewRef.current !== 'movies-section' ||
        currentMoviesSectionRef.current !== secId;
      setCurrentView('movies-section');
      setMoviesSectionId(secId);
      if (wasNotOnSameSection) setMoviesSectionPageLoading(true);
    } else if (pathname === '/' || pathname === '/home') {
      setCurrentView('home');
      setActiveMainTab('all');
    } else if (pathname === '/search') {
      const wasNotOnSearch = currentViewRef.current !== 'search';
      setCurrentView('search');
      setSearchParamQuery(searchParams.get('q') || '');
      if (wasNotOnSearch) setSearchPageLoading(true);
    } else if (pathname === '/category/anime' || pathname === '/anime') {
      const wasNotOnAnime = currentViewRef.current !== 'anime';
      setCurrentView('anime');
      if (wasNotOnAnime) setCategoryPageLoading(true);
    } else if (pathname === '/category/cartoon' || pathname === '/cartoon') {
      const wasNotOnCartoon = currentViewRef.current !== 'cartoon';
      setCurrentView('cartoon');
      if (wasNotOnCartoon) setCategoryPageLoading(true);
    } else if (pathname === '/languages') {
      setCurrentView('languages');
    } else if (pathname.startsWith('/language/')) {
      const lang = pathname.replace('/language/', '').split('/')[0] || 'hindi';
      const wasNotOnSameLanguage =
        currentViewRef.current !== 'language' || currentLanguageRef.current !== lang;
      setCurrentView('language');
      setLanguagePageLang(lang);
      if (wasNotOnSameLanguage) setLanguagePageLoading(true);
    } else if (pathname === '/watchlist') {
      setCurrentView('watchlist');
    } else if (pathname === '/history') {
      setCurrentView('history');
    } else if (pathname === '/about') {
      setCurrentView('about');
    } else if (pathname === '/contact') {
      setCurrentView('contact');
    } else if (pathname === '/terms') {
      setCurrentView('terms');
    } else if (pathname === '/dmca') {
      setCurrentView('dmca');
    } else if (pathname === '/login') {
      setCurrentView('login');
    } else if (pathname === '/register') {
      setCurrentView('register');
    } else if (pathname === '/forgot-password') {
      setCurrentView('forgot-password');
    } else if (pathname === '/profile') {
      setCurrentView('profile');
      setProfileUsername('');
      lastProfileTargetRef.current = '__own__';
    } else if (pathname === '/friends') {
      const wasNotOnFriends = currentViewRef.current !== 'friends';
      setCurrentView('friends');
      if (wasNotOnFriends) setFriendsPageLoading(true);
    } else if (pathname === '/downloads') {
      setCurrentView('downloads');
    } else if (pathname.startsWith('/downloads/')) {
      const slug = rawPath.replace(/^\/downloads\//, '').split(/[?#]/)[0];
      setCurrentView('download-detail');
      setDownloadSlug(slug);
    } else if (pathname.startsWith('/section/')) {
      const rawSlug = rawPath.replace(/^\/section\//, '').split(/[?#]/)[0];
      const slug = rawSlug === 'trending' ? 'childhood-shows' : rawSlug;

      const wasNotOnSameSection =
        currentViewRef.current !== 'home-section' ||
        currentHomeSectionRef.current !== slug;

      setCurrentView('home-section');
      setHomeSection(slug);

      if (wasNotOnSameSection) setHomeSectionPageLoading(true);
    } else if (pathname === '/leaderboard' || pathname === '/leaderboards') {
      const wasNotOnLeaderboard = currentViewRef.current !== 'leaderboard';
      setCurrentView('leaderboard');
      if (wasNotOnLeaderboard) setLeaderboardPageLoading(true);
    } else if (pathname.startsWith('/u/')) {
      const afterU = rawPath.replace(/^\/u\//, '').split(/[?#]/)[0];
      const segments = afterU.split('/').filter(Boolean);
      const uname = segments[0] || '';
      const subPage = segments[1] || '';

      if (uname && subPage === 'activity') {
        setCurrentView('user-activity');
        setUserActivityUsername(decodeURIComponent(uname));
        setUserActivityPageLoading(true);
      } else if (uname) {
        const decoded = decodeURIComponent(uname);
        const target = `u:${decoded}`;
        setCurrentView('profile');
        setProfileUsername(decoded);
        if (lastProfileTargetRef.current !== target) {
          lastProfileTargetRef.current = target;
          setProfilePageLoading(true);
        }
      } else {
        setCurrentView('home');
      }
    } else {

      setCurrentView('home');
      setActiveMainTab('all');
    }

    let usernameParam: string | undefined;
    if (pathname.startsWith('/u/')) {
      const afterU = rawPath.replace(/^\/u\//, '').split(/[?#]/)[0];
      const segments = afterU.split('/').filter(Boolean);
      if (segments[0]) usernameParam = decodeURIComponent(segments[0]);
    }

    updateMetadataForRoute(pathname, {
      query: searchParams.get('q') || undefined,
      lang: pathname.startsWith('/language/') ? pathname.replace('/language/', '').split('/')[0] : undefined,
      subType: (searchParams.get('type') as any) || undefined,
      page: searchParams.get('page') ? parseInt(searchParams.get('page')!, 10) : undefined,
      username: usernameParam,
      section: pathname.startsWith('/section/')
        ? pathname.replace('/section/', '').split('/')[0]
        : undefined,
    });
  }, []);

  useEffect(() => {
    parseCurrentLocation();
    window.addEventListener('popstate', parseCurrentLocation);
    return () => window.removeEventListener('popstate', parseCurrentLocation);
  }, [parseCurrentLocation]);

const navigate = useCallback(
  (
    path: string,
    state?: { subjectId?: string }
  ) => {
    const cleanPath = path.startsWith('/') ? path : `/${path}`;
    const targetUrl = new URL(cleanPath, window.location.origin);
    const targetPath = targetUrl.pathname + targetUrl.search + targetUrl.hash;

    const currentUrl =
      window.location.pathname + window.location.search + window.location.hash;

    if (currentUrl !== targetPath || state !== undefined) {
      window.history.pushState(state || null, '', targetPath);
    }

    parseCurrentLocation();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  },
  [parseCurrentLocation]
);

  const fetchAnimeData = useCallback(async (silent = false) => {
    if (!silent) {
      setIsLoading(true);
      setErrorMessage(null);
    }

    try {
      const json = await fetchHomeContent();

      if (json && json.success && json.data) {
        setApiData(json.data);
        setErrorMessage(null);
      } else {
        throw new Error('Unsuccessful streaming response structure.');
      }
    } catch (err: any) {
      if (!silent) {
        console.error('Failed to load streaming catalog:', err);
        setErrorMessage(
          err.message || 'Unable to connect to live streaming servers. Please check your connection.'
        );
      }
    } finally {
      if (!silent) {
        setIsLoading(false);
      }
    }
  }, []);

  const hasTriggeredHomeFetchRef = useRef<boolean>(false);

  useEffect(() => {
    const hasInitialCache = Boolean(initialCachedHome?.success && initialCachedHome.data);
if (currentView !== 'home' && !isSearchOpen) return;
if (hasTriggeredHomeFetchRef.current) return;
hasTriggeredHomeFetchRef.current = true;
fetchAnimeData(Boolean(initialCachedHome?.success && initialCachedHome.data));
  }, [currentView, isSearchOpen, fetchAnimeData, initialCachedHome]);

  const prevAuthRef = useRef<boolean>(isAuthenticated);
  const hydratedRef = useRef<boolean>(false);

  useEffect(() => {
    if (authLoading) return;

    const wasAuthenticated = prevAuthRef.current;
    prevAuthRef.current = isAuthenticated;

    if (wasAuthenticated && !isAuthenticated) {
      const guestWatchlist = getStoredWatchlist();
      const guestHistory = getStoredHistory();
      setWatchlist(guestWatchlist);
      setHistory(guestHistory);
      setProfilePageLoading(false);
      setWatchlistPageLoading(false);
      setHistoryPageLoading(false);
      hydratedRef.current = true; 
      return;
    }
    if (isAuthenticated) {
      return;
    }
    if (!hydratedRef.current) {
      hydratedRef.current = true;
      return;
    }
    saveStoredWatchlist(watchlist);
    saveStoredHistory(history);
  }, [watchlist, history, isAuthenticated, authLoading]);

  useEffect(() => {
    if (authLoading) return;
    if (!isAuthenticated) {
      setWatchlistPageLoading(false);
      return;
    }
    let cancelled = false;
    setWatchlistPageLoading(true);
    watchlistApi
      .list(1, 100)
      .then((res) => {
        if (cancelled) return;
        setWatchlist(
          sanitizeStoredList(
            (res.items || []).map(dbWatchlistRowToUnified)
          )
        );
      })
      .catch(() => {
        /* silent */
      })
      .finally(() => {
        if (!cancelled) setWatchlistPageLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [isAuthenticated, authLoading]);

  useEffect(() => {
    if (authLoading) return;
    if (!isAuthenticated) {
      setHistoryPageLoading(false);
      return;
    }
    let cancelled = false;
    setHistoryPageLoading(true);
    historyApi
      .list(1, 100)
      .then((res) => {
        if (cancelled) return;
        setHistory(
          sanitizeStoredList(
            (res.items || []).map(dbHistoryRowToUnified)
          )
        );
      })
      .catch(() => {
      })
      .finally(() => {
        if (!cancelled) setHistoryPageLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [isAuthenticated, authLoading]);

  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen(true);
      }
    };
    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, []);

  const fullCatalog = useMemo(() => {
    if (!apiData) return [];
    return normalizeApiData(apiData);
  }, [apiData]);

  const topTrendingTitles = useMemo(() => {
    if (fullCatalog.length === 0) return [];
    return fullCatalog.slice(0, 5);
  }, [fullCatalog]);

  const latestReleases: UnifiedAnime[] = useMemo(() => {
    if (!apiData?.latest_releases) return [];
    return apiData.latest_releases.map((item) => {
      const raw = String(item.type || '').trim().toUpperCase();
      const isMovie = raw === 'MOVIE';
      return {
        id: item.id,
        title: item.title,
        image: item.image,
        type: isMovie ? 'movie' : 'series',
        displayType: raw || (isMovie ? 'MOVIE' : 'SERIES'),
        season: item.season,
        episodes: item.episodes,
        anilistId: item.anilist_id,
        category: 'latest' as const,
      };
    });
  }, [apiData]);
  
  const globalLatestReleases: UnifiedAnime[] = useMemo(() => {
    if (!apiData?.global_latest_releases) return [];
    return apiData.global_latest_releases.map((item) => {
      const raw = String(item.type || '').trim().toUpperCase();
      const isMovie = raw === 'MOVIE';
      return {
        id: item.id,
        title: item.title,
        image: item.image_url,
        type: isMovie ? 'movie' : 'series',
        displayType: raw || (isMovie ? 'MOVIE' : 'SERIES'),
        season: item.season ? `Season ${item.season}` : null,
        episodes: item.latest_episode != null ? `EP:${item.latest_episode}` : null,
        anilistId: item.anilist_id,
        category: 'latest' as const,
      };
    });
  }, [apiData]);

  const popularSeries: UnifiedAnime[] = useMemo(() => {
    if (!apiData?.popular_series) return [];
    return apiData.popular_series.map((item) => ({
      id: item.id,
      title: item.title,
      image: item.image,
      type: 'series' as const,
      displayType: 'SERIES' as const,
      anilistId: item.anilist_id,
      category: 'series' as const,
    }));
  }, [apiData]);

  const popularMovies: UnifiedAnime[] = useMemo(() => {
    if (!apiData?.popular_movies) return [];
    return apiData.popular_movies.map((item) => ({
      id: item.id,
      title: item.title,
      image: item.image,
      type: 'movie' as const,
      displayType: 'MOVIE' as const,
      anilistId: item.anilist_id,
      category: 'movie' as const,
    }));
  }, [apiData]);

  const trendingAnime: UnifiedAnime[] = useMemo(() => {
    if (!apiData?.trending) return [];
    return apiData.trending.map((item: TrendingAnime) => {
      const raw = String(item.type || '').trim().toUpperCase();
      const isMovie = raw === 'MOVIE';
      return {
        id: item.id,
        title: item.title,
        image: item.image || item.poster_image || '',
        type: isMovie ? 'movie' : 'series',
        displayType: raw || (isMovie ? 'MOVIE' : 'SERIES'),
        anilistId: item.anilist_id,
        category: isMovie ? ('movie' as const) : ('series' as const),
      };
    });
  }, [apiData]);

  const watchlistRef = useRef<UnifiedAnime[]>(watchlist);
  useEffect(() => {
    watchlistRef.current = watchlist;
  }, [watchlist]);

  const watchlistIdSet = useMemo(
    () => new Set(watchlist.map((w) => w.id)),
    [watchlist]
  );
  const watchlistIdSetRef = useRef<Set<string>>(watchlistIdSet);
  useEffect(() => {
    watchlistIdSetRef.current = watchlistIdSet;
  }, [watchlistIdSet]);

  const historyRef = useRef<UnifiedAnime[]>(history);
  useEffect(() => {
    historyRef.current = history;
  }, [history]);

  const handleToggleWatchlist = useCallback(
    async (anime: UnifiedAnime) => {
      // Defensive guard — never persist an item without a usable id/title.
      if (
        !anime ||
        !anime.id ||
        anime.id === 'undefined' ||
        anime.id === 'null' ||
        !anime.title
      ) {
        showToast('Cannot save to watchlist: missing anime id or title');
        return;
      }

      const exists = watchlistIdSetRef.current.has(anime.id);

      if (exists) {
        setWatchlist((prev) => prev.filter((item) => item.id !== anime.id));
        showToast(`Removed "${anime.title}" from Watchlist`);
      } else {
        setWatchlist((prev) => [anime, ...prev]);
        showToast(`Added "${anime.title}" to Watchlist`);
      }
      if (isAuthenticated) {
        try {
          if (exists) {
            await watchlistApi.remove(anime.id);
          } else {
        await watchlistApi.add({
          cartoon_id: anime.id,
          cartoon_title: anime.title,
          cartoon_image: anime.image,
          cartoon_type:
            (anime.displayType && String(anime.displayType).toUpperCase()) ||
            (String(anime.type || '').toLowerCase() === 'movie'
              ? 'MOVIE'
              : 'SERIES'),
          anilist_id:
            anime.anilistId != null && Number(anime.anilistId) > 0
              ? Number(anime.anilistId)
              : null,
          tmdb_id:
            anime.tmdbId != null && Number(anime.tmdbId) > 0
              ? Number(anime.tmdbId)
              : null,
              subject_id: anime.subjectId
  ? String(anime.subjectId).trim()
  : null,
        });
          }
        } catch (err: any) {
          if (exists) {
            setWatchlist((prev) => [anime, ...prev]);
          } else {
            setWatchlist((prev) => prev.filter((item) => item.id !== anime.id));
          }
          showToast(`Failed: ${err?.message || 'Try again'}`);
        }
      }
    },
    [isAuthenticated, showToast]
  );

  const handleClearWatchlist = useCallback(async () => {
    const previous = watchlistRef.current;
    setWatchlist([]);
    showToast('Watchlist cleared');
    if (isAuthenticated) {
      try {
        await watchlistApi.clear();
      } catch {
        setWatchlist(previous);
        showToast('Failed to clear watchlist');
      }
    }
  }, [isAuthenticated, showToast]);

  const handleClearHistory = useCallback(async () => {
    const previous = historyRef.current;
    setHistory([]);
    showToast('Watch history cleared');

    if (isAuthenticated) {
      try {
        await historyApi.clear();
      } catch {
        setHistory(previous);
        showToast('Failed to clear history');
      }
    }
  }, [isAuthenticated, showToast]);

  const handleRemoveHistoryItem = useCallback(
    async (anime: UnifiedAnime) => {
      const previous = historyRef.current;
      setHistory((prev) => prev.filter((x) => x.id !== anime.id));
      showToast(`Removed "${anime.title}" from history`);

      if (isAuthenticated) {
        try {
          await historyApi.deleteCartoon(anime.id);
        } catch {
          setHistory(previous);
          showToast('Failed to remove history item');
        }
      }
    },
    [isAuthenticated, showToast]
  );

  const recordToHistory = useCallback(
    async (
      anime: UnifiedAnime,
      context?: {
        seasonNumber?: number;
        episodeNumber?: number;
        episodeId?: string;
        episodeTitle?: string;
        episodeImage?: string;
        lang?: string;
        server?: string;
        genres?: string[];
        totalEpisodesAvailable?: number;
      }
    ) => {

      setHistory((prev) => {
        const isSameEntry = (x: UnifiedAnime) => {
          if (x.id === anime.id) return true;
          const xIsReanime =
            x.id && !/^(anime|movies?|series)[-_]/i.test(x.id);
          const aIsReanime =
            anime.id && !/^(anime|movies?|series)[-_]/i.test(anime.id);
          if (!xIsReanime || !aIsReanime) return false;
          return (
            !!x.title &&
            !!anime.title &&
            x.title.toLowerCase() === anime.title.toLowerCase()
          );
        };

        const filtered = prev.filter((x) => !isSameEntry(x));
        const existing = prev.find((x) => isSameEntry(x));

        let serverBase: string | undefined = existing?.server;
        let langVal: string | undefined = existing?.lang;

        const ctxServer = String(context?.server || '').trim();
        const ctxLang = String(context?.lang || '').trim();

        if (ctxServer && ctxLang) {
          const suffix = `-${ctxLang}`;
          serverBase = ctxServer.toLowerCase().endsWith(suffix.toLowerCase())
            ? ctxServer.slice(0, ctxServer.length - suffix.length)
            : ctxServer;
          langVal = ctxLang;
        } else if (ctxServer) {
          const dashIdx = ctxServer.lastIndexOf('-');
          if (dashIdx > 0) {
            serverBase = ctxServer.slice(0, dashIdx);
            langVal = ctxServer.slice(dashIdx + 1);
          } else {
            serverBase = ctxServer;
          }
        } else if (ctxLang) {
          langVal = ctxLang;
        }

const merged: UnifiedAnime = {
  ...anime,
  id: anime.id,
  seasonNumber: context?.seasonNumber,
  episodeNumber: context?.episodeNumber,
  lang: langVal,
  server: serverBase,
  playedAt: Date.now(),
};

        return [merged, ...filtered].slice(0, 50);
      });

      if (isAuthenticated) {
        const serverBase = String(context?.server || anime.server || '').trim();
        const langCode = String(context?.lang || anime.lang || '').trim();

        let composite: string | null = null;
        if (serverBase && langCode) {
          const suffix = `-${langCode}`;
          composite = serverBase.toLowerCase().endsWith(suffix.toLowerCase())
            ? serverBase
            : `${serverBase}-${langCode}`;
        } else if (serverBase) {
          composite = serverBase;
        }

        try {
          await historyApi.save({
            cartoon_id: anime.id,
            cartoon_title: anime.title,
            cartoon_image: anime.image,
            cartoon_type:
              (anime.displayType && String(anime.displayType).toUpperCase()) ||
              (String(anime.type || '').toLowerCase() === 'movie'
                ? 'MOVIE'
                : 'SERIES'),
            anilist_id:
              anime.anilistId != null && Number(anime.anilistId) > 0
                ? Number(anime.anilistId)
                : null,
            tmdb_id:
              anime.tmdbId != null && Number(anime.tmdbId) > 0
                ? Number(anime.tmdbId)
                : null,
                subject_id: anime.subjectId
  ? String(anime.subjectId).trim()
  : null,
episode_id: context?.episodeId
  ? String(context.episodeId)
  : context?.episodeNumber != null
  ? String(context.episodeNumber)
  : null,

episode_number:
  Number.isFinite(context?.episodeNumber as number) &&
  (context?.episodeNumber as number) > 0
    ? context?.episodeNumber
    : null,

season_number:
  Number.isFinite(context?.seasonNumber as number) &&
  (context?.seasonNumber as number) > 0
    ? context?.seasonNumber
    : null,
            episode_title: context?.episodeTitle,
            episode_image: context?.episodeImage,
            progress_seconds: 0,
            duration_seconds: 0,
            server_type: composite,
          });
        } catch {
        }
      }
    },
    [isAuthenticated]
  );

  useEffect(() => {
    if (!isAuthenticated) {
      watchSessionRef.current = null;
      return;
    }

    const flush = (final = false) => {
      const sess = watchSessionRef.current;
      if (!sess) return;

      const now = Date.now();
      const elapsedSeconds = Math.floor((now - sess.startedAt) / 1000);
      const delta = Math.max(0, elapsedSeconds - sess.lastFlushedSeconds);
      if (delta < 5 && !final) return;

      sess.lastFlushedSeconds = elapsedSeconds;

      const payload = {
        cartoon_id: sess.cartoonId,
        cartoon_title: sess.cartoonTitle,
        cartoon_image: sess.cartoonImage,
        cartoon_type: sess.cartoonType,
        episode_id: sess.episodeId,
        episode_number:
          Number.isFinite(sess.episodeNumber as number) &&
          (sess.episodeNumber as number) > 0
            ? sess.episodeNumber
            : null,
        season_number:
          Number.isFinite(sess.seasonNumber as number) &&
          (sess.seasonNumber as number) > 0
            ? sess.seasonNumber
            : null,
        episode_title: sess.episodeTitle,
        episode_image: sess.episodeImage,
        progress_seconds: 0,
        duration_seconds: 0,
        server_type: (sess as any).serverType || null,
        added_seconds: delta,
        genres: sess.genres,
        total_episodes_available: sess.totalEpisodesAvailable,
      };

      watchApi.progress(payload, final).catch(() => {});
    };

    const interval = window.setInterval(() => flush(false), 30000);

    const onVisibility = () => {
      if (document.visibilityState === 'hidden') flush(false);
    };
    const onBeforeUnload = () => flush(true);

    document.addEventListener('visibilitychange', onVisibility);
    window.addEventListener('beforeunload', onBeforeUnload);

    return () => {
      window.clearInterval(interval);
      document.removeEventListener('visibilitychange', onVisibility);
      window.removeEventListener('beforeunload', onBeforeUnload);
      flush(true);
    };
  }, [isAuthenticated]);

  const handleWatchSessionStart = useCallback(
    (sess: {
      cartoonId: string;
      cartoonTitle: string;
      cartoonImage: string;
      cartoonType: string;  
      serverType?: string;
      episodeId?: string;
      episodeNumber?: number;
      seasonNumber?: number;
      episodeTitle?: string;
      episodeImage?: string;
      genres?: string[];
      totalEpisodesAvailable?: number;
    }) => {
      const prev = watchSessionRef.current;
      if (prev && isAuthenticated) {
        const elapsedSeconds = Math.floor((Date.now() - prev.startedAt) / 1000);
        const delta = Math.max(0, elapsedSeconds - prev.lastFlushedSeconds);
        if (delta >= 1) {
          watchApi.progress({
            cartoon_id: prev.cartoonId,
            cartoon_title: prev.cartoonTitle,
            cartoon_image: prev.cartoonImage,
            cartoon_type: prev.cartoonType,
            episode_id: prev.episodeId,
            episode_number:
              Number.isFinite(prev.episodeNumber as number) &&
              (prev.episodeNumber as number) > 0
                ? prev.episodeNumber
                : null,
            season_number:
              Number.isFinite(prev.seasonNumber as number) &&
              (prev.seasonNumber as number) > 0
                ? prev.seasonNumber
                : null,
            episode_title: prev.episodeTitle,
            episode_image: prev.episodeImage,
            progress_seconds: 0,
            duration_seconds: 0,
            server_type: (prev as any).serverType || null,
            added_seconds: delta,
            genres: prev.genres,
            total_episodes_available: prev.totalEpisodesAvailable,
          }).catch(() => {});
        }
      }

      watchSessionRef.current = {
        ...sess,
        startedAt: Date.now(),
        lastFlushedSeconds: 0,
      };
    },
    [isAuthenticated]
  );

  const handleEpisodeComplete = useCallback(
    async (payload: {
      cartoonId: string;
      cartoonTitle: string;
      cartoonImage: string;
      cartoonType: string;   
      episodeId?: string;
      episodeNumber?: number;
      seasonNumber?: number;
      episodeTitle?: string;
      episodeImage?: string;
      server?: string;
      genres?: string[];
      totalEpisodesAvailable?: number;
      durationSeconds?: number;
      progressSeconds?: number;
    }) => {
      if (!isAuthenticated) return;

      const srv = payload.server
        ? String(payload.server).trim().toLowerCase().slice(0, 64)
        : null;

      try {
        await watchApi.complete({
          cartoon_id: payload.cartoonId,
          cartoon_title: payload.cartoonTitle,
          cartoon_image: payload.cartoonImage,
          cartoon_type: payload.cartoonType,
          episode_id: payload.episodeId,
          episode_number:
            Number.isFinite(payload.episodeNumber as number) &&
            (payload.episodeNumber as number) > 0
              ? payload.episodeNumber
              : null,
          season_number:
            Number.isFinite(payload.seasonNumber as number) &&
            (payload.seasonNumber as number) > 0
              ? payload.seasonNumber
              : null,
          episode_title: payload.episodeTitle,
          episode_image: payload.episodeImage,
          server_type: srv,
          genres: payload.genres,
          total_episodes_available: payload.totalEpisodesAvailable,
          duration_seconds: payload.durationSeconds || 0,
          progress_seconds: payload.progressSeconds || payload.durationSeconds || 0,
        });
        showToast(`Episode marked as watched ✓`);
      } catch (err: any) {
        console.warn('[watch complete]', err?.message);
      }
    },
    [isAuthenticated, showToast]
  );

const handleSelectAnime = useCallback(
  (anime: UnifiedAnime) => {
    const id = String(anime?.id || '').trim();

    if (!id || id === 'undefined' || id === 'null') {
      showToast('Cannot open this title: missing id');
      return;
    }

    const sid = String((anime as any).subjectId || '').trim();

    navigate(`/info/${id}`, {
      subjectId: sid || undefined,
    });
  },
  [navigate, showToast]
);

const handleResumeHistoryEntry = useCallback(
  (anime: UnifiedAnime) => {
  const resolvedId = String(anime?.id || '').trim();

if (
  !resolvedId ||
  resolvedId === 'undefined' ||
  resolvedId === 'null'
) {
  showToast('Cannot resume this title: missing anime ID');
  return;
}
    const params = new URLSearchParams();
    if (anime.anilistId != null && String(anime.anilistId).trim() !== '') {
      params.set('anilistid', String(anime.anilistId));
    }

    const serverBase = String(anime.server || '').trim();
    const langCode = String(anime.lang || '').trim();

    // Rebuild composite verbatim, same rule as recordToHistory.
    let composite = '';
    if (serverBase && langCode) {
      const suffix = `-${langCode}`;
      composite = serverBase.toLowerCase().endsWith(suffix.toLowerCase())
        ? serverBase
        : `${serverBase}-${langCode}`;
    } else if (serverBase) {
      composite = serverBase;
    }

    if (composite) params.set('server', composite);
    if (langCode) params.set('lang', langCode);

    const isReanime = !/^(anime|movies?|series)[-_]/i.test(resolvedId);

    if (String(anime.type || '').toLowerCase() !== 'movie') {
      // Season: only legacy series/movie IDs.
      if (
        !isReanime &&
        Number.isFinite(anime.seasonNumber as number) &&
        (anime.seasonNumber as number) > 0
      ) {
        params.set('season', String(anime.seasonNumber));
      }
      // Episode: any non-movie title, reanime included.
      if (
        Number.isFinite(anime.episodeNumber as number) &&
        (anime.episodeNumber as number) > 0
      ) {
        params.set('ep', String(anime.episodeNumber));
      }
    }

const resumeSubjectId = String((anime as any).subjectId || '').trim();
const query = params.toString();

navigate(
  `/watch/${resolvedId}${query ? `?${query}` : ''}`,
  resumeSubjectId ? { subjectId: resumeSubjectId } : undefined
);
  },
  [navigate]
);

  const handlePlayAnime = useCallback(
    (
      anime: UnifiedAnime,
      preferredLang?: string,
      seasonOverride?: number,
      episodeOverride?: number
    ) => {
      const resolvedId = String(anime?.id || '');
      if (!resolvedId || resolvedId === 'undefined' || resolvedId === 'null') {
        showToast('Cannot play this title: missing id');
        return;
      }

      const params = new URLSearchParams();
      if (anime.anilistId != null && String(anime.anilistId).trim() !== '') {
        params.set('anilistid', String(anime.anilistId));
      }
const playSubjectId = String((anime as any).subjectId || '').trim();
const serverBase = String(anime.server || '').trim();
const langCode = String(preferredLang || anime.lang || '').trim();

// Verbatim composite, same rule as recordToHistory / resume.
let composite = '';
if (serverBase && langCode) {
  const suffix = `-${langCode}`;
  composite = serverBase.toLowerCase().endsWith(suffix.toLowerCase())
    ? serverBase
    : `${serverBase}-${langCode}`;
} else if (serverBase) {
  composite = serverBase;
}

params.set('server', composite);
if (langCode) params.set('lang', langCode);
      const isReanime = !/^(anime|movies?|series)[-_]/i.test(resolvedId);

      const seasonNum =
        seasonOverride ??
        (Number.isFinite(anime.seasonNumber as number)
          ? (anime.seasonNumber as number)
          : isReanime
          ? NaN
          : anime.season != null
          ? parseInt(String(anime.season).replace(/\D/g, ''), 10)
          : NaN);

      const episodeNum =
        episodeOverride ??
        (Number.isFinite(anime.episodeNumber as number)
          ? (anime.episodeNumber as number)
          : anime.episodes != null
          ? parseInt(String(anime.episodes).replace(/\D/g, ''), 10)
          : NaN);

      if (!isReanime && Number.isFinite(seasonNum) && seasonNum > 0) {
        params.set('season', String(seasonNum));
      }
      if (Number.isFinite(episodeNum) && episodeNum > 0) {
        params.set('ep', String(episodeNum));
      }
      const cleanBase = composite.includes('-')
        ? composite.slice(0, composite.lastIndexOf('-'))
        : composite;
      const cleanLang = composite.includes('-')
        ? composite.slice(composite.lastIndexOf('-') + 1)
        : '';

      recordToHistory(
        {
          ...anime,
          id: anime.id,
        },
        {
          seasonNumber:
            !isReanime && Number.isFinite(seasonNum) && seasonNum > 0
              ? seasonNum
              : undefined,
          episodeNumber:
            Number.isFinite(episodeNum) && episodeNum > 0
              ? episodeNum
              : undefined,
          lang: cleanLang || undefined,
          server: cleanBase,
        }
      );

const query = params.toString();

navigate(
  `/watch/${resolvedId}${query ? `?${query}` : ''}`,
  playSubjectId ? { subjectId: playSubjectId } : undefined
);
    },
    [navigate, recordToHistory, showToast]
  );

  const handleOpenSearch = useCallback((query?: string) => {
    setSearchInitialQuery(query || '');
    setIsSearchOpen(true);
  }, []);

  const handleSelectLanguage = useCallback(
    (langCode: string | null) => {
      setSelectedLanguage(langCode);
      if (langCode) {
        showToast(`Selected audio language: ${langCode.toUpperCase()}`);
      } else {
        showToast('Cleared language filter');
      }
    },
    [showToast]
  );

  if (currentView === 'home' && isLoading && !apiData) {
    return (
      <>
<BootScreen
  visible={booting}
  onComplete={handleBootComplete}
/>
        <LoadingSkeleton />

        {!booting && (
          <Suspense fallback={null}>
            <TelegramJoinModal
              isOpen={showTelegramModal}
              onClose={handleCloseTelegramModal}
            />
          </Suspense>
        )}
      </>
    );
  }

  if (currentView === 'home' && errorMessage && !apiData) {
    return (
      <>
<BootScreen
  visible={booting}
  onComplete={handleBootComplete}
/>
        <ErrorState
          errorMessage={errorMessage}
          onRetry={() => fetchAnimeData(false)}
          isRetrying={isLoading}
        />

        {!booting && (
          <Suspense fallback={null}>
            <TelegramJoinModal
              isOpen={showTelegramModal}
              onClose={handleCloseTelegramModal}
            />
          </Suspense>
        )}
      </>
    );
  }

  return (
    <>
{currentView === 'home' && (
  <BootScreen
    visible={booting}
    onComplete={handleBootComplete}
  />
)}
      <div className="min-h-screen bg-[#0b0c16] text-slate-100 flex flex-col font-sans selection:bg-indigo-600 selection:text-white">

      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#14172b] border border-[#2e3252] text-white px-3.5 py-2 rounded-xl shadow-2xl shadow-black/80 flex items-center gap-2 text-xs font-normal animate-in fade-in slide-in-from-bottom-2 duration-200">
          <Check className="w-3.5 h-3.5 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      <Navbar
        watchlistCount={watchlist.length}
        historyCount={history.length}
        onOpenSearch={handleOpenSearch}
        onNavigate={navigate}
        currentView={currentView}
        activeMainTab={activeMainTab}
        onOpenAuth={(step) => setAuthModal({ open: true, step })}
      />

      <main className="flex-1 w-full">

        {currentView === 'search' && (
          <div className="relative">
            {searchPageLoading && (
              <div className="fixed inset-x-0 top-16 bottom-0 z-30 bg-[#0b0c16] overflow-y-auto">
                <SearchSkeleton />
              </div>
            )}
            <Suspense fallback={<SearchSkeleton />}>
              <SearchPage
                initialQuery={searchParamQuery}
                onSearchPageLoadingChange={setSearchPageLoading}
                onSelectAnime={handleSelectAnime}
                onPlayAnime={handlePlayAnime}
                watchlist={watchlist}
                onToggleWatchlist={handleToggleWatchlist}
                onBackToHome={() => navigate('/')}
              />
            </Suspense>
          </div>
        )}
        
        {currentView === 'home-section' && (
          <div className="relative">
            {homeSectionPageLoading && (
              <div className="fixed inset-x-0 top-16 bottom-0 z-30 bg-[#0b0c16] overflow-y-auto">
                <HomeSectionSkeleton />
              </div>
            )}
            <Suspense fallback={<HomeSectionSkeleton />}>
              <HomeSectionPage
                section={homeSection as HomeSectionSlug}
                onSelectAnime={handleSelectAnime}
                onPlayAnime={handlePlayAnime}
                watchlist={watchlist}
                onToggleWatchlist={handleToggleWatchlist}
                onBackToHome={() => navigate('/')}
                onHomeSectionPageLoadingChange={setHomeSectionPageLoading}
              />
            </Suspense>
          </div>
        )}
        
        {currentView === 'friends' && (
          <div className="relative">
            {friendsPageLoading && (
              <div className="fixed inset-x-0 top-16 bottom-0 z-30 bg-[#0b0c16] overflow-y-auto">
                <FriendsSkeleton />
              </div>
            )}
            <Suspense fallback={<FriendsSkeleton />}>
              <FriendsPage
                onNavigate={navigate}
                onFriendsPageLoadingChange={setFriendsPageLoading}
              />
            </Suspense>
          </div>
        )}
        
{currentView === 'movies' && (
  <div className="relative">
    {moviesPageLoading && (
      <div className="fixed inset-x-0 top-16 bottom-0 z-30 bg-[#0b0c16] overflow-y-auto">
        <MoviesSkeleton />
      </div>
    )}
    <Suspense fallback={<MoviesSkeleton />}>
      <MoviesPage
        onSelectAnime={handleSelectAnime}
        onPlayAnime={handlePlayAnime}
        watchlist={watchlist}
        onToggleWatchlist={handleToggleWatchlist}
        onBackToHome={() => navigate('/')}
        onNavigate={navigate}
        onMoviesPageLoadingChange={setMoviesPageLoading}
      />
    </Suspense>
  </div>
)}

{currentView === 'movies-section' && (
  <div className="relative">
    {moviesSectionPageLoading && (
      <div className="fixed inset-x-0 top-16 bottom-0 z-30 bg-[#0b0c16] overflow-y-auto">
        <HomeSectionSkeleton />
      </div>
    )}
    <Suspense fallback={<HomeSectionSkeleton />}>
      <MoviesSectionPage
        sectionId={moviesSectionId}
        onSelectAnime={handleSelectAnime}
        onPlayAnime={handlePlayAnime}
        watchlist={watchlist}
        onToggleWatchlist={handleToggleWatchlist}
        onBackToHome={() => navigate('/')}
        onMoviesSectionPageLoadingChange={setMoviesSectionPageLoading}
      />
    </Suspense>
  </div>
)}

        {currentView === 'downloads' && (
          <Suspense fallback={<div className="min-h-[60vh] bg-[#0b0c16]" />}>
            <DownloadsPage
              onNavigate={navigate}
              onBackToHome={() => navigate('/')}
            />
          </Suspense>
        )}

        {currentView === 'download-detail' && (
          <Suspense fallback={<div className="min-h-[60vh] bg-[#0b0c16]" />}>
            <DownloadDetailPage
              slug={downloadSlug}
              onNavigate={navigate}
              onBackToHome={() => navigate('/')}
            />
          </Suspense>
        )}

        {currentView === 'anime' && (
          <div className="relative">
            {categoryPageLoading && (
              <div className="fixed inset-x-0 top-16 bottom-0 z-30 bg-[#0b0c16] overflow-y-auto">
                <CategorySkeleton />
              </div>
            )}
            <Suspense fallback={<CategorySkeleton />}>
              <CategoryPage
                category="anime"
                onCategoryPageLoadingChange={setCategoryPageLoading}
                onSelectAnime={handleSelectAnime}
                onPlayAnime={handlePlayAnime}
                watchlist={watchlist}
                onToggleWatchlist={handleToggleWatchlist}
                onBackToHome={() => navigate('/')}
              />
            </Suspense>
          </div>
        )}

        {currentView === 'cartoon' && (
          <div className="relative">
            {categoryPageLoading && (
              <div className="fixed inset-x-0 top-16 bottom-0 z-30 bg-[#0b0c16] overflow-y-auto">
                <CategorySkeleton />
              </div>
            )}
            <Suspense fallback={<CategorySkeleton />}>
              <CategoryPage
                category="cartoon"
                onCategoryPageLoadingChange={setCategoryPageLoading}
                onSelectAnime={handleSelectAnime}
                onPlayAnime={handlePlayAnime}
                watchlist={watchlist}
                onToggleWatchlist={handleToggleWatchlist}
                onBackToHome={() => navigate('/')}
              />
            </Suspense>
          </div>
        )}

        {currentView === 'languages' && (
          <Suspense fallback={<div className="min-h-[60vh] bg-[#0b0c16]" />}>
            <LanguagesDirectoryPage
              onSelectLanguage={(lang) => {
                setLanguagePageLang(lang);
                navigate(`/language/${lang}`);
              }}
              onBackToHome={() => navigate('/')}
              onNavigate={navigate}
            />
          </Suspense>
        )}

        {currentView === 'language' && (
          <div className="relative">
            {languagePageLoading && (
              <div className="fixed inset-x-0 top-16 bottom-0 z-30 bg-[#0b0c16] overflow-y-auto">
                <LanguageSkeleton />
              </div>
            )}
            <Suspense fallback={<LanguageSkeleton />}>
              <LanguagePage
                language={languagePageLang}
                onLanguagePageLoadingChange={setLanguagePageLoading}
                onSelectLanguage={(lang) => {
                  setLanguagePageLang(lang);
                  navigate(`/language/${lang}`);
                }}
                onSelectAnime={handleSelectAnime}
                onPlayAnime={handlePlayAnime}
                watchlist={watchlist}
                onToggleWatchlist={handleToggleWatchlist}
                onBackToHome={() => navigate('/')}
              />
            </Suspense>
          </div>
        )}

        {currentView === 'watchlist' && (
          <div className="relative">
            {watchlistPageLoading && (
              <div className="fixed inset-x-0 top-16 bottom-0 z-30 bg-[#0b0c16] overflow-y-auto">
                <WatchlistSkeleton />
              </div>
            )}
            <Suspense fallback={<WatchlistSkeleton />}>
              <WatchlistPage
                watchlist={watchlist}
                onToggleWatchlist={handleToggleWatchlist}
                onSelectAnime={handleSelectAnime}
                onPlayAnime={handlePlayAnime}
                onClearWatchlist={handleClearWatchlist}
                onBackToHome={() => navigate('/')}
                onNavigate={navigate}
              />
            </Suspense>
          </div>
        )}

        {currentView === 'history' && (
          <div className="relative">
            {historyPageLoading && (
              <div className="fixed inset-x-0 top-16 bottom-0 z-30 bg-[#0b0c16] overflow-y-auto">
                <HistorySkeleton />
              </div>
            )}
            <Suspense fallback={<HistorySkeleton />}>
              <HistoryPage
                history={history}
                watchlist={watchlist}
                onToggleWatchlist={handleToggleWatchlist}
                onSelectAnime={handleSelectAnime}
                onPlayAnime={handlePlayAnime}
                onResumeHistoryEntry={handleResumeHistoryEntry}
                onClearHistory={handleClearHistory}
                onRemoveHistoryItem={handleRemoveHistoryItem}
                onBackToHome={() => navigate('/')}
                onNavigate={navigate}
              />
            </Suspense>
          </div>
        )}

        {currentView === 'about' && (
          <Suspense fallback={<div className="min-h-[60vh] bg-[#0b0c16]" />}>
            <AboutPage onBackToHome={() => navigate('/')} onNavigate={navigate} />
          </Suspense>
        )}

        {currentView === 'contact' && (
          <Suspense fallback={<div className="min-h-[60vh] bg-[#0b0c16]" />}>
            <ContactPage onBackToHome={() => navigate('/')} onNavigate={navigate} />
          </Suspense>
        )}

        {currentView === 'terms' && (
          <Suspense fallback={<div className="min-h-[60vh] bg-[#0b0c16]" />}>
            <TermsPage onBackToHome={() => navigate('/')} onNavigate={navigate} />
          </Suspense>
        )}

        {currentView === 'dmca' && (
          <Suspense fallback={<div className="min-h-[60vh] bg-[#0b0c16]" />}>
            <DmcaPage onBackToHome={() => navigate('/')} onNavigate={navigate} />
          </Suspense>
        )}

        {currentView === 'login' && (
          <Suspense fallback={<div className="min-h-[60vh] bg-[#0b0c16]" />}>
            <LoginPage onNavigate={navigate} />
          </Suspense>
        )}

        {currentView === 'register' && (
          <Suspense fallback={<div className="min-h-[60vh] bg-[#0b0c16]" />}>
            <RegisterPage onNavigate={navigate} />
          </Suspense>
        )}

        {currentView === 'forgot-password' && (
          <Suspense fallback={<div className="min-h-[60vh] bg-[#0b0c16]" />}>
            <ForgotPasswordPage onNavigate={navigate} />
          </Suspense>
        )}

        {currentView === 'profile' && (
          <div className="relative">
            {profilePageLoading && (
              <div
                className={`fixed inset-x-0 top-16 bottom-0 z-30 overflow-y-auto ${
                  profileUsername ? 'bg-[#070811]' : 'bg-[#0b0c16]'
                }`}
              >
                {profileUsername ? <PublicProfileSkeleton /> : <ProfileSettingsSkeleton />}
              </div>
            )}
            <Suspense fallback={profileUsername ? <PublicProfileSkeleton /> : <ProfileSettingsSkeleton />}>
              <ProfilePage
                username={profileUsername}
                onNavigate={navigate}
                watchlist={watchlist}
                onToggleWatchlist={handleToggleWatchlist}
                onPlayAnime={handlePlayAnime}
                onProfilePageLoadingChange={setProfilePageLoading}
              />
            </Suspense>
          </div>
        )}

        {currentView === 'user-activity' && (
          <div className="relative">
            {userActivityPageLoading && (
              <div className="fixed inset-x-0 top-16 bottom-0 z-30 bg-[#070811] overflow-y-auto">
                <UserActivitySkeleton />
              </div>
            )}
            <Suspense fallback={<UserActivitySkeleton />}>
              <UserActivityPage
                username={userActivityUsername}
                onNavigate={navigate}
                onUserActivityPageLoadingChange={setUserActivityPageLoading}
              />
            </Suspense>
          </div>
        )}

        {currentView === 'leaderboard' && (
          <div className="relative">
            {leaderboardPageLoading && (
              <div className="fixed inset-x-0 top-16 bottom-0 z-30 bg-black overflow-y-auto">
                <LeaderboardSkeleton />
              </div>
            )}
            <Suspense fallback={<LeaderboardSkeleton />}>
              <LeaderboardPage
                onNavigate={navigate}
                onBackToHome={() => navigate('/')}
                onLeaderboardPageLoadingChange={setLeaderboardPageLoading}
              />
            </Suspense>
          </div>
        )}

        {currentView === 'info' && (
          <div className="relative">
            {infoPageLoading && (
              <div className="fixed inset-x-0 top-16 bottom-0 z-30 bg-[#0b0c16] overflow-y-auto">
                <InfoSkeleton />
              </div>
            )}
            <Suspense fallback={<InfoSkeleton />}>
              <InfoPage
                id={infoAnimeId}
                subjectId={infoSubjectId}
                onInfoPageLoadingChange={setInfoPageLoading}
                onPlayAnime={handlePlayAnime}
                onNavigate={navigate}
                watchlist={watchlist}
                onToggleWatchlist={handleToggleWatchlist}
                onBackToHome={() => navigate('/')}
              />
            </Suspense>
          </div>
        )}

        {currentView === 'watch' && (
          <div className="relative">
            {watchPageLoading && (
              <div className="fixed inset-x-0 top-16 bottom-0 z-30 bg-[#070811] overflow-y-auto">
                <WatchSkeleton />
              </div>
            )}
            <Suspense fallback={<WatchSkeleton />}>
              <WatchPage
                id={watchAnimeId}
                subjectId={watchSubjectId}
                onWatchPageLoadingChange={setWatchPageLoading}
                onNavigate={navigate}
                watchlist={watchlist}
                onToggleWatchlist={handleToggleWatchlist}
                onBackToHome={() => navigate('/')}
                onRecordHistory={recordToHistory}
                onWatchSessionStart={handleWatchSessionStart}
                onEpisodeComplete={handleEpisodeComplete}
                isAuthenticated={isAuthenticated}
                serverPrefs={
                  isAuthenticated && authUser
                    ? {
                        autoPlay: Boolean(authUser.auto_play),
                        autoNext: Boolean(authUser.auto_next),
                        autoSkip: Boolean(authUser.auto_skip),
                      }
                    : undefined
                }
              />
            </Suspense>
          </div>
        )}

        {currentView === 'home' && (
          <>

            {apiData?.hero && apiData.hero.length > 0 && (
              <div className="-mt-16 sm:-mt-17">
                <HeroBanner
                  heroes={apiData.hero}
                  onSelectAnime={handleSelectAnime}
                  onPlayAnime={handlePlayAnime}
                  watchlist={watchlist}
                  onToggleWatchlist={handleToggleWatchlist}
                />
              </div>
            )}

            {/* Downloads Banner */}
<div className="mx-auto w-full max-w-7xl px-4 pt-4 pb-6 sm:px-6 lg:px-8">

  {/* Desktop */}
  <button
    type="button"
    onClick={() => navigate('/downloads')}
    aria-label="Explore downloads"
    className="group hidden w-full cursor-pointer overflow-hidden rounded-xl lg:block"
  >
    <img
      src="/images/downloads-banner.webp"
      alt="Download your favorite Anime and Cartoons"
      className="block h-auto w-full rounded-xl object-cover transition-transform duration-300 group-hover:scale-[1.01]"
      loading="lazy"
    />
  </button>

  {/* Tablet */}
  <button
    type="button"
    onClick={() => navigate('/downloads')}
    aria-label="Explore downloads"
    className="group hidden w-full cursor-pointer overflow-hidden rounded-xl sm:block lg:hidden"
  >
    <img
      src="/images/download-banner-tablet.webp"
      alt="Download your favorite Anime and Cartoons"
      className="block h-auto w-full rounded-xl object-cover"
      loading="lazy"
    />
  </button>

  {/* Mobile */}
  <button
    type="button"
    onClick={() => navigate('/downloads')}
    aria-label="Explore downloads"
    className="group block w-full cursor-pointer overflow-hidden rounded-xl sm:hidden"
  >
    <img
      src="/images/download-banner-mobile.webp"
      alt="Download your favorite Anime and Cartoons"
      className="block h-auto w-full rounded-xl object-cover"
      loading="lazy"
    />
  </button>

</div>

<Share />

<LanguageGridSection
  selectedLanguage={selectedLanguage}
  onSelectLanguage={handleSelectLanguage}
  onNavigateLanguage={(lang) => navigate(`/language/${lang}`)}
/>
            
            <ContinueWatchingSection
              history={history}
              onResume={handleResumeHistoryEntry}
              onRemove={handleRemoveHistoryItem}
              onNavigate={navigate}
            />

            <CatalogTabsSection
              onSelectAnime={handleSelectAnime}
              onPlayAnime={handlePlayAnime}
              watchlist={watchlist}
              history={history}
              onToggleWatchlist={handleToggleWatchlist}
              onClearHistory={handleClearHistory}
              onRemoveHistoryItem={handleRemoveHistoryItem}
              activeMainTab={activeMainTab}
              onChangeMainTab={(tab) => setActiveMainTab(tab)}
              onNavigate={navigate}
              onResumeHistoryEntry={handleResumeHistoryEntry}
            />

            {activeMainTab === 'all' && (
              <>
<AnimeSection
  key={`latest-${isUnder480 ? 'mobile' : 'desktop'}`}
  id="latest"
  title="Latest Episodes & Releases"
  subtitle="Fresh Releases"
  items={latestLangTab === 'JAP/ENG' ? globalLatestReleases : latestReleases}
  onSelectAnime={handleSelectAnime}
  onPlayAnime={(anime) => {
    const s =
      anime.season != null
        ? parseInt(String(anime.season).replace(/\D/g, ''), 10)
        : undefined;
    const e =
      anime.episodes != null
        ? parseInt(String(anime.episodes).replace(/\D/g, ''), 10)
        : undefined;
    handlePlayAnime(anime, undefined, s, e);
  }}
  watchlist={watchlist}
  onToggleWatchlist={handleToggleWatchlist}
  defaultView={isUnder480 ? 'carousel' : 'grid'}
  seeAllHref="/section/latest-episodes"
  onSeeAll={navigate}
  langTabs={['JAP/ENG', 'HIN/TAM/TEL']}
  activeLangTab={latestLangTab}
  onChangeLangTab={(tab) => setLatestLangTab(tab as 'JAP/ENG' | 'HIN/TAM/TEL')}
/>

                {trendingAnime.length > 0 && (
                  <AnimeSection
                  key={`trending-${isUnder480 ? 'mobile' : 'desktop'}`}
                    id="trending"
                    title="Childhood Shows"
                    subtitle="Nostalgic Classics"
                    items={trendingAnime}
                    onSelectAnime={handleSelectAnime}
                    onPlayAnime={handlePlayAnime}
                    watchlist={watchlist}
                    onToggleWatchlist={handleToggleWatchlist}
                    defaultView={isUnder480 ? 'carousel' : 'grid'}
                      seeAllHref="/section/childhood-shows"
  onSeeAll={navigate}
                  />
                )}

                <AnimeSection
                key={`series-${isUnder480 ? 'mobile' : 'desktop'}`}
                  id="series"
                  title="Most Popular TV Series"
                  subtitle="Top Rated Shows"
                  items={popularSeries}
                  onSelectAnime={handleSelectAnime}
                  onPlayAnime={handlePlayAnime}
                  watchlist={watchlist}
                  onToggleWatchlist={handleToggleWatchlist}
                  defaultView={isUnder480 ? 'carousel' : 'grid'}
                    seeAllHref="/section/popular-series"
  onSeeAll={navigate}
                />

                <AnimeSection
                key={`movies-${isUnder480 ? 'mobile' : 'desktop'}`}
                  id="movies"
                  title="Blockbuster Anime Movies"
                  subtitle="Feature Films"
                  items={popularMovies}
                  onSelectAnime={handleSelectAnime}
                  onPlayAnime={handlePlayAnime}
                  watchlist={watchlist}
                  onToggleWatchlist={handleToggleWatchlist}
                  defaultView={isUnder480 ? 'carousel' : 'grid'}
                    seeAllHref="/section/blockbuster-movies"
  onSeeAll={navigate}
                />
              </>
            )}
          </>
        )}
      </main>

      <Footer onNavigate={navigate} currentPath={currentPath} />

      {isSearchOpen && (
        <Suspense fallback={null}>
          <SearchModal
            isOpen={isSearchOpen}
            onClose={() => setIsSearchOpen(false)}
            topTrending={topTrendingTitles}
            initialQuery={searchInitialQuery}
            onSelectAnime={handleSelectAnime}
            onPlayAnime={handlePlayAnime}
            onNavigateToSearchPage={(q) =>
              navigate(q ? `/search?q=${encodeURIComponent(q)}` : '/search')
            }
            watchlist={watchlist}
            onToggleWatchlist={handleToggleWatchlist}
          />
        </Suspense>
      )}

      {authModal.open && (
        <Suspense fallback={null}>
          <AuthModal
            isOpen={authModal.open}
            initialStep={authModal.step}
            onClose={() => setAuthModal((prev) => ({ ...prev, open: false }))}
            onSuccess={() => setAuthModal((prev) => ({ ...prev, open: false }))}
            onNavigate={navigate}
          />
        </Suspense>
      )}

      {!booting && (
        <Suspense fallback={null}>
          <TelegramJoinModal
            isOpen={showTelegramModal}
            onClose={handleCloseTelegramModal}
          />
        </Suspense>
      )}
      </div>
    </>
  );
}
