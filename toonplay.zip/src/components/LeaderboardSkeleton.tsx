import React from 'react';

export const LeaderboardSkeleton: React.FC = () => {
  return (
    <div className="text-slate-100 pt-6 sm:pt-10 md:pt-20 pb-32 font-sans overflow-x-hidden relative">
      {/* Background layers — same as real page */}
      <div className="fixed inset-0 pointer-events-none -z-10">
        <div className="absolute inset-0 bg-[radial-gradient(120%_75%_at_50%_0%,#16182c_0%,#0f1122_45%,#0b0c16_100%)]" />
        <div
          className="absolute inset-0 opacity-[0.07] mix-blend-screen"
          style={{
            backgroundImage:
              "url('https://www.transparenttextures.com/patterns/stardust.png')",
          }}
        />
      </div>

      {/* HALL OF FAME watermark */}
      <div className="fixed inset-0 flex items-center justify-center pointer-events-none z-0 opacity-[0.03] overflow-hidden">
        <h1 className="text-[5.5rem] sm:text-[10rem] md:text-[15rem] font-black italic tracking-tighter uppercase whitespace-normal md:whitespace-nowrap leading-[0.85] md:leading-none text-center -skew-x-[15deg] px-4 md:px-0">
          HALL OF FAME
        </h1>
      </div>

      <div className="w-full max-w-[1800px] mx-auto px-4 xl:px-8 relative z-10 flex flex-col items-center gap-4 sm:gap-6 md:gap-8">
        <div className="flex flex-1 flex-col items-center w-full max-w-[1000px]">
          {/* Heading — matches live page: mb-6 sm:mb-10 md:mb-16 */}
          <div className="mb-6 sm:mb-10 md:mb-16 text-center">
            <div className="w-48 sm:w-64 md:w-96 h-7 sm:h-10 md:h-14 bg-[#16182c] rounded mx-auto animate-pulse" />
            <div className="w-32 sm:w-40 h-3 sm:h-4 bg-[#16182c]/60 rounded mx-auto mt-2 animate-pulse" />
          </div>

          {/* Podium — 3 cards, same dims + order/scale as live page */}
          <div className="grid grid-cols-3 gap-2 sm:gap-3 md:gap-6 w-full max-w-3xl mx-auto mb-8 sm:mb-10 md:mb-16 px-2 sm:px-3 md:px-0">
            {/* #2 — silver (order-1, scale-90) */}
            <div className="flex flex-col justify-end h-full transform origin-bottom order-1 scale-[0.90] md:scale-[0.95] z-20">
              <div className="relative rounded-xl md:rounded-2xl overflow-hidden flex flex-col items-center justify-start py-2 sm:py-3 md:py-4 px-1.5 sm:px-2 md:px-6 h-fit min-h-0 bg-gradient-to-b from-[#14172b] to-slate-700/20 border-[1.5px] md:border-[2px] border-slate-300/40 shadow-[0_0_10px_rgba(148,163,184,0.15)] md:shadow-[0_0_30px_rgba(148,163,184,0.15)] animate-pulse">
                <div className="relative z-10 w-full flex flex-col items-center justify-start md:pt-2">
                  {/* Frame container — same w/h chain as live page */}
                  <div className="relative w-14 h-20 sm:w-20 md:w-28 md:h-40 shrink-0 mt-1 md:mt-0">
                    <div className="absolute top-3 md:top-6 left-1/2 -translate-x-1/2 size-14 md:size-28 rounded-full bg-[#0b0c16] border border-[#2e3252]" />
                  </div>
                  <div className="flex flex-col items-center w-full min-w-0 mt-2 gap-2">
                    <div className="w-full h-2.5 sm:h-3 md:h-5 bg-white/10 rounded mb-1" />
                    <div className="w-full h-10 md:h-14 bg-[#0f1122]/80 rounded md:rounded-xl border border-[#222540]" />
                  </div>
                </div>
              </div>
            </div>

            {/* #1 — gold (order-2, scale-105) */}
            <div className="flex flex-col justify-end h-full transform origin-bottom order-2 scale-105 md:scale-110 z-30">
              <div className="relative rounded-xl md:rounded-2xl overflow-hidden flex flex-col items-center justify-start py-2 sm:py-3 md:py-4 px-1.5 sm:px-2 md:px-6 h-fit min-h-0 bg-gradient-to-b from-[#14172b] to-yellow-900/20 border-[1.5px] md:border-[3px] border-yellow-500/40 shadow-[0_0_20px_rgba(234,179,8,0.15)] md:shadow-[0_0_50px_rgba(234,179,8,0.15)] animate-pulse">
                <div className="relative z-10 w-full flex flex-col items-center justify-start md:pt-2">
                  <div className="relative w-14 h-20 sm:w-20 md:w-28 md:h-40 shrink-0 mt-1 md:mt-0">
                    <div className="absolute top-3 md:top-6 left-1/2 -translate-x-1/2 size-14 md:size-28 rounded-full bg-[#0b0c16] border border-[#2e3252]" />
                  </div>
                  <div className="flex flex-col items-center w-full min-w-0 mt-2 gap-2">
                    <div className="w-full h-2.5 sm:h-3 md:h-5 bg-white/10 rounded mb-1" />
                    <div className="w-full h-10 md:h-14 bg-[#0f1122]/80 rounded md:rounded-xl border border-[#222540]" />
                  </div>
                </div>
              </div>
            </div>

            {/* #3 — bronze (order-3, scale-75) */}
            <div className="flex flex-col justify-end h-full transform origin-bottom order-3 scale-[0.75] md:scale-[0.80] z-10">
              <div className="relative rounded-xl md:rounded-2xl overflow-hidden flex flex-col items-center justify-start py-2 sm:py-3 md:py-4 px-1.5 sm:px-2 md:px-6 h-fit min-h-0 bg-gradient-to-b from-[#14172b] to-amber-900/20 border-[1.5px] md:border-[2px] border-amber-700/40 shadow-[0_0_10px_rgba(180,83,9,0.15)] md:shadow-[0_0_30px_rgba(180,83,9,0.15)] animate-pulse">
                <div className="relative z-10 w-full flex flex-col items-center justify-start md:pt-2">
                  <div className="relative w-14 h-20 sm:w-20 md:w-28 md:h-40 shrink-0 mt-1 md:mt-0">
                    <div className="absolute top-3 md:top-6 left-1/2 -translate-x-1/2 size-14 md:size-28 rounded-full bg-[#0b0c16] border border-[#2e3252]" />
                  </div>
                  <div className="flex flex-col items-center w-full min-w-0 mt-2 gap-2">
                    <div className="w-full h-2.5 sm:h-3 md:h-5 bg-white/10 rounded mb-1" />
                    <div className="w-full h-10 md:h-14 bg-[#0f1122]/80 rounded md:rounded-xl border border-[#222540]" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Contenders — 7 rows, colors + structure match live page */}
          <div className="flex-1 flex flex-col w-full max-w-4xl mx-auto pt-8 border-t border-[#23263f] relative">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#0b0c16] px-4 text-xs font-mono tracking-[0.3em] uppercase text-slate-500">
              THE CONTENDERS
            </div>

            {/* Column headers */}
            <div className="flex items-center gap-1 w-full h-8 md:h-10 mb-2 pr-1 md:pr-2">
              <div className="w-8 md:w-16" />
              <div className="flex-1" />
              <div className="w-24 md:w-36 text-center">
                <span className="font-black text-sm md:text-2xl text-white drop-shadow-md italic">
                  XP
                </span>
              </div>
              <div className="w-12 md:w-20 text-center">
                <span className="font-black text-sm md:text-2xl text-slate-400 drop-shadow-md italic">
                  LVL
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1.5 md:gap-2">
              {Array.from({ length: 7 }).map((_, i) => (
                <div
                  key={i}
                  className="flex items-stretch gap-1 w-full h-12 md:h-14 animate-pulse"
                >
                  <div className="w-8 md:w-16 flex items-center justify-center">
                    <div className="w-5 md:w-10 h-6 md:h-9 bg-[#16182c]/70 rounded" />
                  </div>

                  <div className="flex-1 min-w-0 overflow-hidden bg-[#14172b] flex items-center -skew-x-[15deg] px-3 md:px-6 shadow-lg border-l-2 md:border-l-[6px] border-[#23263f]">
                    <div className="flex items-center gap-2 md:gap-4 skew-x-[15deg] w-full min-w-0 overflow-hidden">
                      <div className="size-6 md:size-10 shrink-0 rounded-full bg-[#1c2038] border border-[#2e3252]" />
                      <div className="flex-1 h-2.5 md:h-5 bg-[#1c2038] rounded" />
                    </div>
                  </div>

                  <div className="w-24 md:w-36 flex items-center justify-center -skew-x-[15deg] shrink-0 grow-0 basis-[6rem] md:basis-[9rem] bg-slate-100 px-1">
                    <div className="w-14 md:w-24 h-2.5 md:h-5 skew-x-[15deg] bg-[#0b0c16]/30 rounded" />
                  </div>

                  <div className="w-12 md:w-20 bg-[#16182c] flex items-center justify-center -skew-x-[15deg] shrink-0 grow-0 basis-[3rem] md:basis-[5rem] border-r-2 md:border-r-[6px] border-[#23263f]">
                    <div className="w-5 md:w-8 h-2.5 md:h-5 skew-x-[15deg] bg-[#0b0c16]/30 rounded" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};