import React from 'react';

const Pulse: React.FC<{ className?: string }> = ({ className = '' }) => (
  <div className={`bg-[#171a2b] animate-pulse rounded-lg ${className}`} />
);

const HeroSkeleton: React.FC = () => (
  <section className="relative w-full min-h-[580px] md:min-h-[660px] lg:min-h-[720px] flex items-end overflow-hidden bg-[#0b0c16]">
    <div className="absolute inset-0">
      <Pulse className="w-full h-full !rounded-none" />
      <div className="absolute inset-0 bg-gradient-to-t from-[#0b0c16] via-[#0b0c16]/85 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-r from-[#0b0c16] via-[#0b0c16]/80 to-transparent max-w-4xl" />
      <div className="absolute bottom-0 inset-x-0 h-32 sm:h-36 z-[5] pointer-events-none select-none bg-gradient-to-b from-transparent via-[#0b0c16]/80 to-[#0b0c16]" />
    </div>

    <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pt-28 sm:pt-32 lg:pt-36 pb-4 md:pb-5">
      <div className="max-w-2xl space-y-3.5">
        <Pulse className="h-8 sm:h-10 lg:h-12 w-3/4" />
        <div className="flex items-center gap-2">
          <Pulse className="h-3 w-12" />
          <Pulse className="h-3 w-10" />
          <Pulse className="h-3 w-14" />
        </div>
        <div className="space-y-2">
          <Pulse className="h-3 w-full" />
          <Pulse className="h-3 w-5/6" />
          <Pulse className="h-3 w-2/3" />
        </div>
        <div className="flex items-center gap-3 pt-2">
          <Pulse className="h-10 w-32 !rounded-xl" />
          <Pulse className="h-10 w-40 !rounded-xl" />
        </div>
      </div>

      <div className="mt-7 pt-4 border-t border-[#1e2136] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2.5 overflow-hidden">
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <Pulse key={i} className="h-12 w-24 sm:w-28 shrink-0 !rounded-lg" />
          ))}
        </div>
        <div className="flex items-center gap-2">
          <Pulse className="h-8 w-8 !rounded-lg" />
          <Pulse className="h-3 w-12" />
          <Pulse className="h-8 w-8 !rounded-lg" />
        </div>
      </div>
    </div>
  </section>
);

const RowSkeleton: React.FC<{ columns?: number }> = ({ columns = 12 }) => (
  <section className="py-7 border-b border-[#1b1e33]">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex items-center justify-between mb-5">
        <div className="space-y-2">
          <Pulse className="h-3 w-24" />
          <Pulse className="h-5 w-48" />
        </div>
        <Pulse className="h-8 w-20 !rounded-lg" />
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5 sm:gap-4.5">
        {Array.from({ length: columns }).map((_, i) => (
          <div key={i} className="space-y-2">
            <Pulse className="aspect-[2/3] w-full !rounded-xl" />
            <Pulse className="h-3 w-3/4" />
            <Pulse className="h-2.5 w-1/2" />
          </div>
        ))}
      </div>
    </div>
  </section>
);

export const MoviesSkeleton: React.FC = () => (
  <div className="min-h-screen bg-[#0b0c16]">
    <HeroSkeleton />
    <RowSkeleton />
    <RowSkeleton />
    <RowSkeleton />
  </div>
);

export default MoviesSkeleton;