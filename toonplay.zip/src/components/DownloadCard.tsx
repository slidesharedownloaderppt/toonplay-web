import React, { useState } from 'react';
import { Film, Tv, Download, ChevronRight } from 'lucide-react';
import { DownloadSeriesMeta } from '../types';

interface Props {
  slug: string;
  meta: DownloadSeriesMeta;
  onOpen: (slug: string) => void;
}

export const DownloadCard: React.FC<Props> = React.memo(({ slug, meta, onOpen }) => {
  const [imageFailed, setImageFailed] = useState(false);

  return (
    <div
      onClick={() => onOpen(slug)}
      className="group relative flex flex-col aspect-[2/3] bg-[#121424] border border-[#22253c] hover:border-indigo-500/50 rounded-xl overflow-hidden transition-[border-color,box-shadow] duration-200 hover:shadow-md hover:shadow-black/40 cursor-pointer select-none"
    >
      <div className="absolute inset-0 bg-[#0d0e1b] overflow-hidden">
        {!imageFailed && meta.image ? (
          <img
            src={meta.image}
            alt={meta.title}
            loading="lazy"
            decoding="async"
            draggable="false"
            onDragStart={(e) => e.preventDefault()}
            referrerPolicy="no-referrer"
            onError={() => setImageFailed(true)}
            className="w-full h-full object-cover object-center group-hover:scale-104 transition-transform duration-300 ease-out pointer-events-none select-none"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-[#121428] via-[#161932] to-[#0d0e1d] flex flex-col items-center justify-center p-4 text-center">
            {meta.type === 'movie' ? (
              <Film className="w-7 h-7 text-indigo-400/50 mb-2" />
            ) : (
              <Tv className="w-7 h-7 text-indigo-400/50 mb-2" />
            )}
            <span className="text-xs text-indigo-200 line-clamp-2">{meta.title}</span>
          </div>
        )}

        <div className="absolute inset-x-0 bottom-0 h-3/5 bg-gradient-to-t from-[#0a0b16] via-[#0a0b16]/85 to-transparent pointer-events-none" />

        <div className="absolute top-2 right-2 flex items-center gap-1.5">
          <div className="flex items-center gap-1 text-[10px] text-slate-300 bg-[#0c0e1a]/92 px-1.5 py-0.5 rounded border border-[#23263d]">
            {meta.type === 'movie' ? <Film className="w-2.5 h-2.5 text-indigo-400" /> : <Tv className="w-2.5 h-2.5 text-indigo-400" />}
            <span>{meta.type === 'movie' ? 'Movie' : 'Series'}</span>
          </div>
        </div>

        <div className="absolute inset-x-0 bottom-0 p-2.5 sm:p-3 flex flex-col gap-1.5">
          <div className="text-[10px] font-mono text-emerald-300 truncate flex items-center gap-1">
            <span className="w-1 h-1 rounded-full bg-emerald-400 shrink-0" />
            <span className="truncate">
              {meta.type === 'movie' ? 'Movie' : `${meta.episodeCount} ${meta.episodeCount === 1 ? 'episode' : 'episodes'}`}
              {' · '}{meta.lastUploadDate}
            </span>
          </div>

          <h3
            title={meta.title}
            className="text-xs sm:text-[13px] font-medium text-slate-100 group-hover:text-indigo-300 transition-colors line-clamp-2 leading-snug"
          >
            {meta.title}
          </h3>

          <div className="pt-1.5 mt-0.5 border-t border-white/10 flex items-center justify-between gap-2">
            <button
              onClick={(e) => { e.stopPropagation(); onOpen(slug); }}
              className="flex-1 py-1 px-2 rounded-md bg-[#181a2e]/95 hover:bg-indigo-600 text-slate-200 hover:text-white border border-[#282b45] hover:border-indigo-500 transition-colors flex items-center justify-center gap-1.5 text-[11px] cursor-pointer"
            >
              <Download className="w-3 h-3" />
              <span>Download</span>
            </button>
            <div className="p-1.5 rounded-md border bg-[#181a2e]/95 border-[#282b45] text-slate-400">
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
});
DownloadCard.displayName = 'DownloadCard';