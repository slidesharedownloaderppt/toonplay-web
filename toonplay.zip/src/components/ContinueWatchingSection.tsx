import React, { useEffect, useState, useCallback } from 'react';
import { History, ChevronLeft, ChevronRight, Trash2, Play, ArrowRight } from 'lucide-react';
import { UnifiedAnime } from '../types';
import { useDragScroll } from '../utils/useDragScroll.ts';

interface Props {
  history: UnifiedAnime[];
  onResume: (anime: UnifiedAnime) => void;
  onRemove: (anime: UnifiedAnime) => void;
  onNavigate: (path: string) => void;
}

export const ContinueWatchingSection = React.memo(function ContinueWatchingSection({
  history,
  onResume,
  onRemove,
  onNavigate,
}: Props) {
  const dragScroll = useDragScroll<HTMLDivElement>();
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);

  const items = React.useMemo(() => {
    const seen = new Set<string>();
    const sorted = [...history].sort(
      (a, b) => (b.playedAt || 0) - (a.playedAt || 0)
    );
    const unique: UnifiedAnime[] = [];
    for (const item of sorted) {
      if (!seen.has(item.id)) {
        seen.add(item.id);
        unique.push(item);
      }
      if (unique.length >= 10) break;
    }
    return unique;
  }, [history]);

  useEffect(() => {
    const el = dragScroll.ref.current;
    if (!el) return;

    let rafId: number | null = null;
    const updateScrollButtons = () => {
      rafId = null;
      const node = dragScroll.ref.current;
      if (!node) return;
      const nextLeft = node.scrollLeft > 4;
      const nextRight = node.scrollLeft + node.clientWidth < node.scrollWidth - 4;
      setCanScrollLeft((prev) => (prev === nextLeft ? prev : nextLeft));
      setCanScrollRight((prev) => (prev === nextRight ? prev : nextRight));
    };

    const scheduleUpdate = () => {
      if (rafId === null) {
        rafId = requestAnimationFrame(updateScrollButtons);
      }
    };

    updateScrollButtons();
    el.addEventListener('scroll', scheduleUpdate, { passive: true });

    let ro: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined') {
      ro = new ResizeObserver(scheduleUpdate);
      ro.observe(el);
    } else {
      window.addEventListener('resize', scheduleUpdate, { passive: true });
    }

    return () => {
      el.removeEventListener('scroll', scheduleUpdate);
      if (ro) {
        ro.disconnect();
      } else {
        window.removeEventListener('resize', scheduleUpdate);
      }
      if (rafId !== null) cancelAnimationFrame(rafId);
    };
  }, [items.length, dragScroll.ref]);

  const scrollByAmount = useCallback((dir: 'left' | 'right') => {
    const el = dragScroll.ref.current;
    if (!el) return;
    const amount = Math.max(220, Math.floor(el.clientWidth * 0.75));
    const reducedMotion =
      typeof window !== 'undefined' &&
      window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    el.scrollBy({
      left: dir === 'left' ? -amount : amount,
      behavior: reducedMotion ? 'auto' : 'smooth',
    });
  }, [dragScroll.ref]);

  if (items.length === 0) return null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="flex flex-col gap-5">
        {/* Header row */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 flex rounded-xl bg-indigo-500/10 items-center justify-center">
              <History className="w-4 h-4 text-indigo-400" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-semibold text-white tracking-tight">
                Continue Watching
              </h2>
              <p className="text-[10px] font-mono text-slate-500">
                Pick up where you left off
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => scrollByAmount('left')}
              disabled={!canScrollLeft}
              className={`hidden md:flex items-center justify-center w-6 h-6 rounded-full bg-[#14172b] border border-[#23263f] text-slate-400 hover:text-white hover:border-indigo-500/50 transition-all cursor-pointer ${
                !canScrollLeft
                  ? 'opacity-40 cursor-not-allowed hover:text-slate-400 hover:border-[#23263f]'
                  : ''
              }`}
              title="Scroll left"
              aria-label="Scroll left"
            >
              <ChevronLeft className="w-3 h-3" />
            </button>
            <button
              onClick={() => scrollByAmount('right')}
              disabled={!canScrollRight}
              className={`hidden md:flex items-center justify-center w-6 h-6 rounded-full bg-[#14172b] border border-[#23263f] text-slate-400 hover:text-white hover:border-indigo-500/50 transition-all cursor-pointer ${
                !canScrollRight
                  ? 'opacity-40 cursor-not-allowed hover:text-slate-400 hover:border-[#23263f]'
                  : ''
              }`}
              title="Scroll right"
              aria-label="Scroll right"
            >
              <ChevronRight className="w-3 h-3" />
            </button>

            <button
              onClick={() => onNavigate('/history')}
              className="text-[10px] font-mono font-bold text-slate-400 hover:text-indigo-300 border border-[#23263f] hover:border-indigo-500/40 px-3 py-1.5 bg-[#14172b]/50 hover:bg-indigo-950/20 rounded-full transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              title="View full watch history"
            >
              See All
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Horizontal scroll container */}
        <div
          ref={dragScroll.ref}
          {...dragScroll.dragProps}
          className="tp-drag-scroll overflow-x-auto overscroll-x-contain scrollbar-hide select-none"
        >
          <div className="flex gap-4 min-w-max pb-1 items-start">
            {items.map((item) => {
              const isMovie = item.type === 'movie';

              const ep = item.episodeNumber;
              const season = item.seasonNumber;

              const image = item.image || item.backdrop || '';

              return (
                <div
                  key={item.id}
                  className="group relative flex-shrink-0 w-[150px] h-[112px] sm:w-[170px] sm:h-[128px] md:w-[190px] md:h-[143px] lg:w-[210px] lg:h-[158px] bg-[#121424] border border-[#22253c] hover:border-indigo-500/50 rounded-xl overflow-hidden transition-[border-color,box-shadow] duration-200 hover:shadow-md hover:shadow-black/40 cursor-pointer select-none"
                  onClick={() => {
                    if (!dragScroll.hasDraggedRef.current) onResume(item);
                  }}
                >
                  <div className="absolute inset-0 bg-[#0d0e1b] overflow-hidden">
                    {image ? (
                      <img
                        src={image}
                        alt={item.title}
                        loading="lazy"
                        decoding="async"
                        draggable={false}
                        onDragStart={(e) => e.preventDefault()}
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          (e.currentTarget as HTMLImageElement).style.opacity = '0';
                        }}
                        className="w-full h-full object-cover object-center group-hover:scale-104 transition-transform duration-300 ease-out pointer-events-none select-none"
                      />
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-[#121428] via-[#161932] to-[#0d0e1d] flex items-center justify-center">
                        <Play className="w-6 h-6 text-indigo-400/50" />
                      </div>
                    )}

                    {/* Gradient overlay */}
                    <div className="absolute inset-x-0 bottom-0 h-3/5 bg-gradient-to-t from-[#0a0b16] via-[#0a0b16]/85 to-transparent pointer-events-none" />

                    {/* Top-right: remove only (no badges) */}
                    <div className="absolute top-1.5 right-1.5 flex items-center gap-1">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onRemove(item);
                        }}
                        className="w-4.5 h-4.5 rounded bg-[#0c0e1a]/92 hover:bg-rose-600 border border-[#23263d] hover:border-rose-500 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
                        title="Remove from continue watching"
                        aria-label="Remove from continue watching"
                      >
                        <Trash2 className="w-2.5 h-2.5" />
                      </button>
                    </div>

                    {/* Bottom overlay info — more visible data */}
                    <div className="absolute inset-x-0 bottom-0 p-2 flex flex-col gap-1">
                      {/* Type + Season + Episode visible line */}
                      <div className="text-[9px] font-mono font-bold text-emerald-300 truncate flex items-center gap-1">
                        <span className="w-1 h-1 rounded-full bg-emerald-400 shrink-0" aria-hidden="true" />
                        <span className="truncate">
                          {isMovie
                            ? 'MOVIE'
                            : `SERIES${season != null ? ` · S${season}` : ''}${ep != null ? ` · E${ep}` : ''}`}
                        </span>
                      </div>

                      {/* Episode title if series */}
                      {!isMovie && (item as any).episodeTitle && (
                        <div className="text-[9px] font-mono text-indigo-300 truncate">
                          {(item as any).episodeTitle}
                        </div>
                      )}

                      <h3
                        title={item.title}
                        className="text-[11px] font-medium text-slate-100 group-hover:text-indigo-300 transition-colors line-clamp-1 leading-snug"
                      >
                        {item.title}
                      </h3>

                      <div className="pt-1 mt-0.5 border-t border-white/10 flex items-center justify-between gap-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onResume(item);
                          }}
                          className="flex-1 py-0.5 px-2 rounded-md bg-[#181a2e]/95 hover:bg-indigo-600 text-slate-200 hover:text-white border border-[#282b45] hover:border-indigo-500 transition-colors flex items-center justify-center gap-1 text-[10px] font-normal cursor-pointer"
                        >
                          <Play className="w-2.5 h-2.5 fill-current" />
                          <span>Resume</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
});