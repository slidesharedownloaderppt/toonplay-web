import React from 'react';

export const PublicProfileSkeleton: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#070811] text-white">
      {/* ================= BANNER ================= */}
      <div className="relative -mt-16 h-52 sm:h-64 md:h-80 lg:h-96 w-full overflow-hidden bg-[#070811] pt-16">
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute inset-0 bg-[#0d0f1e]/60" />
          <div className="absolute inset-0 bg-gradient-to-b from-[#0d0f1e]/40 via-transparent to-[#070811]/60" />
          {/* Grid shimmer to match the real header's grid overlay */}
          <div
            className="absolute inset-0 opacity-30 animate-pulse"
            style={{
              backgroundImage:
                'linear-gradient(rgba(255,255,255,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.06) 1px, transparent 1px)',
              backgroundSize: '24px 24px',
              maskImage:
                'radial-gradient(ellipse 90% 80% at 50% 45%, black 45%, transparent 100%)',
              WebkitMaskImage:
                'radial-gradient(ellipse 90% 80% at 50% 45%, black 45%, transparent 100%)',
            }}
          />
        </div>
        {/* Glass fades */}
        <div className="absolute inset-x-0 top-0 h-24 sm:h-32 bg-gradient-to-b from-[#070811] via-[#070811]/40 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 h-32 sm:h-40 bg-gradient-to-t from-[#070811] via-[#070811]/60 to-transparent" />
      </div>

      {/* ================= AVATAR + NAME ================= */}
      <div className="relative z-10 mx-auto max-w-7xl -mt-12 sm:-mt-14 lg:-mt-24 px-4 sm:px-6 md:px-8 pb-4 sm:pb-6">
        <div className="flex w-full flex-col items-center gap-4 lg:flex-row lg:items-end lg:justify-between lg:gap-8">
          {/* Left: avatar + name */}
          <div className="flex flex-col items-center gap-4 lg:flex-row lg:items-end lg:gap-6">
            {/* Avatar + crest */}
            <div className="relative shrink-0 h-24 w-24 sm:h-28 sm:w-28 lg:h-36 lg:w-36">
              <div className="h-full w-full rounded-full border-4 border-[#070811] bg-[#14172b] animate-pulse" />
              {/* Crest placeholder */}
              <div className="absolute -bottom-3 sm:-bottom-3.5 lg:-bottom-4 left-1/2 -translate-x-1/2 w-11 h-11 rounded-full bg-[#14172b] border border-[#23263f] animate-pulse" />
            </div>

            {/* Name + meta */}
            <div className="flex flex-col items-center gap-2 lg:items-start lg:pb-2 lg:mt-3">
              {/* Name + tick + info + activity row */}
              <div className="flex items-center gap-2 mb-1">
                <div className="w-40 sm:w-52 h-7 sm:h-8 bg-[#16182c] rounded animate-pulse" />
                <div className="w-[22px] h-[22px] rounded-full bg-[#16182c] animate-pulse" />
                <div className="w-7 h-7 rounded-full bg-[#16182c] animate-pulse" />
                <div className="w-7 h-7 rounded-full bg-[#16182c] animate-pulse" />
              </div>

              {/* @username (hidden on mobile) */}
              <div className="hidden lg:block w-32 h-3.5 bg-[#16182c]/70 rounded animate-pulse mb-2" />

              {/* Joined + anime count row */}
              <div className="flex items-center gap-3">
                <div className="w-24 h-3 bg-[#16182c]/70 rounded animate-pulse" />
                <div className="w-20 h-3 bg-[#16182c]/70 rounded animate-pulse" />
              </div>

              {/* XP bar */}
              <div className="w-[170px] lg:w-[240px] h-3.5 bg-[#16182c]/70 rounded-full animate-pulse mt-2" />
            </div>
          </div>

          {/* Right: stats duo */}
          <div className="flex shrink-0 gap-6 pb-2 sm:gap-8 lg:gap-12 lg:pb-0">
            <div className="text-center space-y-2">
              <div className="w-14 h-7 bg-[#16182c] rounded animate-pulse" />
              <div className="w-16 h-2.5 bg-[#16182c]/70 rounded animate-pulse" />
            </div>
            <div className="text-center space-y-2">
              <div className="w-14 h-7 bg-[#16182c] rounded animate-pulse" />
              <div className="w-16 h-2.5 bg-[#16182c]/70 rounded animate-pulse" />
            </div>
          </div>
        </div>
      </div>

      {/* ================= WATCHLIST SECTION ================= */}
      <div className="mx-auto min-h-[60vh] max-w-7xl pb-12">
        {/* Section header + tabs */}
        <div className="relative border-b border-white/5 bg-[#0a0b16]/30 px-4 py-4 sm:px-6 md:px-8">
          <div className="flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 rounded bg-[#1a1d33] animate-pulse" />
                <div className="w-24 h-5 bg-[#1a1d33] rounded animate-pulse" />
              </div>
              <div className="w-16 h-3.5 bg-[#1a1d33]/70 rounded animate-pulse" />
            </div>

            <div className="flex gap-2">
              {Array.from({ length: 3 }).map((_, i) => (
                <div
                  key={i}
                  className="w-24 h-7 bg-[#141414] rounded-md animate-pulse"
                />
              ))}
            </div>
          </div>
        </div>

        {/* Grid */}
        <div className="px-4 pt-6 pb-8 sm:px-6 md:px-8">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
            {Array.from({ length: 12 }).map((_, i) => (
              <div
                key={i}
                className="relative rounded-xl bg-[#121424] border border-[#22253c] overflow-hidden aspect-[2/3] animate-pulse"
              >
                <div className="absolute inset-0 bg-[#0d0e1b]" />
                <div className="absolute top-2 right-2 w-14 h-5 rounded bg-[#181a30]/90 border border-[#22253c]" />
                <div className="absolute inset-x-0 bottom-0 p-2.5 sm:p-3 flex flex-col gap-1.5">
                  <div className="w-16 h-2.5 bg-[#181a30] rounded" />
                  <div className="w-full h-3.5 bg-[#181a30] rounded" />
                  <div className="pt-1.5 mt-0.5 border-t border-white/10 flex items-center gap-2">
                    <div className="flex-1 h-6 bg-[#181a30] rounded-md" />
                    <div className="w-7 h-6 bg-[#181a30] rounded-md" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};