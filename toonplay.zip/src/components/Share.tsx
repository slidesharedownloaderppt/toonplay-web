
import { useEffect, useRef } from 'react';
import { Share2 } from 'lucide-react';

declare global {
  interface Window {
    __sharethis__?: {
      initialize: () => void;
    };
  }
}

let shareThisPromise: Promise<void> | null = null;

function loadShareThis(): Promise<void> {
  if (window.__sharethis__?.initialize) {
    return Promise.resolve();
  }

  if (shareThisPromise) return shareThisPromise;

  shareThisPromise = new Promise((resolve, reject) => {
    const script = document.createElement('script');

    script.id = 'sharethis-sdk';
    script.async = true;
    script.src =
      'https://platform-api.sharethis.com/js/sharethis.js#property=6a27902e62e6095ba1246c92&product=sop';

    script.onload = () => {
      let attempts = 0;

      const check = () => {
        if (window.__sharethis__?.initialize) {
          resolve();
        } else if (attempts++ < 30) {
          window.setTimeout(check, 300);
        } else {
          shareThisPromise = null;
          reject(new Error('ShareThis SDK initialization timed out'));
        }
      };

      check();
    };

    script.onerror = () => {
      shareThisPromise = null;
      reject(new Error('ShareThis SDK failed to load'));
    };

    document.head.appendChild(script);
  });

  return shareThisPromise;
}

export function Share({ embedded = false }: { embedded?: boolean }) {
  const sectionRef = useRef<HTMLElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let cancelled = false;
    let initialized = false;
    let timer: number | undefined;

    const initialize = async () => {
      if (initialized || cancelled) return;
      initialized = true;
      try {
        await loadShareThis();

        if (cancelled || !containerRef.current) return;

        containerRef.current.setAttribute(
          'data-url',
          window.location.href
        );

        containerRef.current.setAttribute(
          'data-title',
          document.title
        );

        window.__sharethis__?.initialize();
      } catch (error) {
        console.warn('[ShareThis]', error);
      }
    };

    const target = sectionRef.current;
    if (typeof IntersectionObserver !== 'undefined' && target) {
      const observer = new IntersectionObserver(
        (entries) => {
          if (entries.some((entry) => entry.isIntersecting)) {
            observer.disconnect();
            timer = window.setTimeout(initialize, 60);
          }
        },
        { rootMargin: '250px 0px' }
      );
      observer.observe(target);

      return () => {
        cancelled = true;
        observer.disconnect();
        if (timer !== undefined) window.clearTimeout(timer);
      };
    }

    timer = window.setTimeout(initialize, 150);

    return () => {
      cancelled = true;
      if (timer !== undefined) window.clearTimeout(timer);
    };
  }, []);

  return (
<section ref={sectionRef} className={`relative z-10 isolate ${embedded ? '' : 'mb-3'}`}>
  <div className={embedded ? '' : 'max-w-7xl mx-auto px-4 sm:px-6 lg:px-8'}>
        <div className="relative overflow-hidden rounded-2xl border border-indigo-500/20 bg-gradient-to-r from-[#15172c] via-[#17152e] to-[#111629] px-4 py-3 sm:px-6 sm:py-3.5">

          <div
            className="absolute -right-10 -top-16 w-48 h-48 rounded-full pointer-events-none"
            style={{ background: 'radial-gradient(circle, rgba(99, 102, 241, 0.14) 0%, transparent 70%)' }}
          />

          <div className="relative flex flex-col sm:flex-row items-center justify-between gap-2.5 sm:gap-4">

            <div className="flex items-center gap-3 min-w-0">
              <div className="w-9 h-9 shrink-0 rounded-xl bg-indigo-500/15 border border-indigo-400/20 flex items-center justify-center">
                <Share2 className="w-4 h-4 text-indigo-300" />
              </div>

              <div className="min-w-0">
                <h3 className="text-sm font-bold text-white leading-tight">
                  Enjoying ToonPlay?
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Share the fun with your friends!
                </p>
              </div>
            </div>

            <div
              ref={containerRef}
              className="sharethis-inline-share-buttons relative z-10 min-w-0"
            />

          </div>
        </div>
      </div>
    </section>
  );
}
