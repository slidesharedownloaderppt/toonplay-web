import React from 'react';

export const CategorySkeleton: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">

      {/* Header row: back button + title block + type filter pills */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1c1f36]">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-[#121424] border border-[#23263d] animate-pulse" />
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <div className="w-3.5 h-3.5 rounded bg-[#16182c] animate-pulse" />
              <div className="w-28 h-3 bg-[#16182c] rounded animate-pulse" />
            </div>
            <div className="w-64 sm:w-80 h-6 sm:h-7 bg-[#16182c] rounded animate-pulse" />
            <div className="w-56 h-3 bg-[#16182c]/70 rounded animate-pulse" />
          </div>
        </div>

        <div className="flex items-center gap-1.5 p-1 bg-[#121424] border border-[#23263d] rounded-xl self-start sm:self-auto">
          <div className="w-12 h-7 bg-[#16182c] rounded-lg animate-pulse" />
          <div className="w-16 h-7 bg-[#16182c] rounded-lg animate-pulse" />
          <div className="w-18 h-7 bg-[#16182c] rounded-lg animate-pulse" />
        </div>
      </div>

      {/* Share row */}
      <div className="h-12 w-full rounded-xl bg-[#121424] border border-[#23263d] animate-pulse" />

      {/* Count + pagination row */}
      <div className="flex items-center justify-between">
        <div className="w-40 h-3 bg-[#16182c]/70 rounded animate-pulse" />
        <div className="flex items-center gap-2">
          <div className="w-16 h-7 bg-[#121424] border border-[#23263d] rounded-lg animate-pulse" />
          <div className="w-20 h-3 bg-[#16182c]/70 rounded animate-pulse" />
          <div className="w-16 h-7 bg-[#121424] border border-[#23263d] rounded-lg animate-pulse" />
        </div>
      </div>

      {/* Card grid — same classes as CategoryPage */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5 sm:gap-4.5">
        {Array.from({ length: 12 }).map((_, i) => (
          <div
            key={i}
            className="relative rounded-xl bg-[#121424] border border-[#22253c] overflow-hidden aspect-[2/3] animate-pulse"
          >
            <div className="absolute inset-0 bg-[#0d0e1b]" />
            <div className="absolute top-2 right-2 w-14 h-5 rounded bg-[#181a30]/90 border border-[#23263d]" />
            <div className="absolute inset-x-0 bottom-0 p-2.5 sm:p-3 flex flex-col gap-1.5">
              <div className="w-16 h-2.5 bg-[#181a30] rounded" />
              <div className="w-full h-3.5 bg-[#181a30] rounded" />
              <div className="pt-1.5 mt-0.5 border-t border-white/10 flex items-center gap-2">
                <div className="flex-1 h-6 bg-[#181a30] rounded-md" />
                <div className="w-7 h-6 bg-[#181a30] rounded-md" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Bottom pagination */}
      <div className="pt-6 border-t border-[#1c1f36] flex items-center justify-center gap-3">
        <div className="w-28 h-8 bg-[#121424] border border-[#23263d] rounded-lg animate-pulse" />
        <div className="w-24 h-3 bg-[#16182c]/70 rounded animate-pulse" />
        <div className="w-24 h-8 bg-[#121424] border border-[#23263d] rounded-lg animate-pulse" />
      </div>
    </div>
  );
};