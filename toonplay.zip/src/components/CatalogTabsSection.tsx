import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Sparkles,
  Film,
  Tv,
  ChevronLeft,
  ChevronRight,
  Loader2,
  AlertCircle,
  RefreshCw,
  Library,
  Flame,
  Bookmark,
  Clock,
} from 'lucide-react';
import { AnimeCard } from './AnimeCard.tsx';
import { PaginatedApiResponse, UnifiedAnime } from '../types.ts';
import { fetchCategorySeries, fetchCategoryMovies } from '../api.ts';

interface CatalogTabsSectionProps {
  onSelectAnime: (anime: UnifiedAnime) => void;
  onPlayAnime: (anime: UnifiedAnime) => void;
  watchlist: UnifiedAnime[];
  history: UnifiedAnime[];
  onToggleWatchlist: (anime: UnifiedAnime) => void;
  onClearHistory: () => void;
  onRemoveHistoryItem: (anime: UnifiedAnime) => void;
  activeMainTab: 'all' | 'anime' | 'cartoon' | 'watchlist' | 'history';
  onChangeMainTab: (tab: 'all' | 'anime' | 'cartoon' | 'watchlist' | 'history') => void;
  onNavigate?: (path: string) => void;
  onResumeHistoryEntry?: (anime: UnifiedAnime) => void;
}

export const CatalogTabsSection: React.FC<CatalogTabsSectionProps> = ({
  onSelectAnime,
  onPlayAnime,
  watchlist,
  history,
  onToggleWatchlist,
  onClearHistory,
  onRemoveHistoryItem,
  activeMainTab,
  onChangeMainTab,
  onNavigate,
  onResumeHistoryEntry,
}) => {
  const [subType, setSubType] = useState<'all' | 'series' | 'movies'>('all');

  const [seriesPage, setSeriesPage] = useState<number>(1);
  const [moviesPage, setMoviesPage] = useState<number>(1);

  const watchlistIdSet = useMemo(
    () => new Set(watchlist.map((w) => w.id)),
    [watchlist]
  );

  const [seriesData, setSeriesData] = useState<UnifiedAnime[]>([]);
  const [moviesData, setMoviesData] = useState<UnifiedAnime[]>([]);
  const [seriesTotalPages, setSeriesTotalPages] = useState<number>(1);
  const [moviesTotalPages, setMoviesTotalPages] = useState<number>(1);

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [fetchError, setFetchError] = useState<string | null>(null);

  const fetchCategoryData = useCallback(async () => {
    if (activeMainTab !== 'anime' && activeMainTab !== 'cartoon') return;

    setIsLoading(true);
    setFetchError(null);

    const category = activeMainTab;

    try {
      const shouldFetchSeries = subType === 'all' || subType === 'series';
      const shouldFetchMovies = subType === 'all' || subType === 'movies';

      const [seriesRes, moviesRes] = await Promise.all([
        shouldFetchSeries ? fetchCategorySeries(category, seriesPage) : Promise.resolve(null),
        shouldFetchMovies ? fetchCategoryMovies(category, moviesPage) : Promise.resolve(null),
      ]);

      if (seriesRes && seriesRes.success && Array.isArray(seriesRes.data)) {
const normalizedSeries: UnifiedAnime[] = seriesRes.data.map((item) => ({
  id: item.id,
  subjectId: item.subjectId,
  title: item.title,
  image: item.image,
  type: 'series',
  category: category === 'cartoon' ? 'cartoon' : 'series',
}));
        setSeriesData(normalizedSeries);
        setSeriesTotalPages(seriesRes.pagination?.totalPages || 1);
      }

      if (moviesRes && moviesRes.success && Array.isArray(moviesRes.data)) {
const normalizedMovies: UnifiedAnime[] = moviesRes.data.map((item) => ({
  id: item.id,
  subjectId: item.subjectId,
  title: item.title,
  image: item.image,
  type: 'movie',
  category: category === 'cartoon' ? 'cartoon' : 'movie',
}));
        setMoviesData(normalizedMovies);
        setMoviesTotalPages(moviesRes.pagination?.totalPages || 1);
      }
    } catch (err: any) {
      console.error('Error fetching category data:', err);
      setFetchError(err.message || 'Failed to load content from streaming server.');
    } finally {
      setIsLoading(false);
    }
  }, [activeMainTab, subType, seriesPage, moviesPage]);

  useEffect(() => {
    if (activeMainTab === 'anime' || activeMainTab === 'cartoon') {
      fetchCategoryData();
    }
  }, [activeMainTab, fetchCategoryData]);

  const handleTabChange = (tab: 'all' | 'anime' | 'cartoon' | 'watchlist' | 'history') => {
    onChangeMainTab(tab);
    setSeriesPage(1);
    setMoviesPage(1);
    setSubType('all');
  };

  return (
    <section id="catalog-tabs" className="bg-[#0e101f] border-y border-[#1c1f36] py-4">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3.5">

          <div className="flex items-center gap-1.5 p-1 bg-[#121424] border border-[#23263d] rounded-xl overflow-x-auto scrollbar-none">
            <button
              onClick={() => handleTabChange('all')}
              className={`px-3 sm:px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                activeMainTab === 'all'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-[#1a1c32]'
              }`}
            >
              <Library className="w-3.5 h-3.5" />
              <span>All Library</span>
            </button>

            <button
              onClick={() => handleTabChange('anime')}
              className={`px-3 sm:px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                activeMainTab === 'anime'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-[#1a1c32]'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Anime</span>
            </button>

            <button
              onClick={() => handleTabChange('cartoon')}
              className={`px-3 sm:px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                activeMainTab === 'cartoon'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-[#1a1c32]'
              }`}
            >
              <Flame className="w-3.5 h-3.5" />
              <span>Cartoon</span>
            </button>
          </div>

          <div className="flex items-center gap-1.5 p-1 bg-[#121424] border border-[#23263d] rounded-xl self-start md:self-auto overflow-x-auto scrollbar-none">
            <button
              onClick={() => handleTabChange('watchlist')}
              className={`px-3 sm:px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                activeMainTab === 'watchlist'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-[#1a1c32]'
              }`}
            >
              <Bookmark className="w-3.5 h-3.5 text-indigo-400" />
              <span>Watchlist</span>
              {watchlist.length > 0 && (
                <span className="text-[10px] font-mono tabular-nums px-1.5 py-0.2 bg-[#0d0e1c] text-indigo-300 rounded border border-[#2a2d46]">
                  {watchlist.length}
                </span>
              )}
            </button>

            <button
              onClick={() => handleTabChange('history')}
              className={`px-3 sm:px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                activeMainTab === 'history'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-[#1a1c32]'
              }`}
            >
              <Clock className="w-3.5 h-3.5 text-indigo-400" />
              <span>History</span>
              {history.length > 0 && (
                <span className="text-[10px] font-mono tabular-nums px-1.5 py-0.2 bg-[#0d0e1c] text-indigo-300 rounded border border-[#2a2d46]">
                  {history.length}
                </span>
              )}
            </button>
          </div>
        </div>

        {(activeMainTab === 'anime' || activeMainTab === 'cartoon') && (
          <div className="flex items-center justify-between gap-3 mt-4 pt-3 border-t border-[#1a1d33] text-xs">
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500 font-mono text-[11px] mr-1">Filter:</span>
              <button
                onClick={() => setSubType('all')}
                className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                  subType === 'all'
                    ? 'bg-[#1b1e35] text-indigo-300 font-medium border border-[#2d3150]'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setSubType('series')}
                className={`px-2.5 py-1 rounded-md transition-colors flex items-center gap-1 cursor-pointer ${
                  subType === 'series'
                    ? 'bg-[#1b1e35] text-indigo-300 font-medium border border-[#2d3150]'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Tv className="w-3 h-3" />
                <span>Series</span>
              </button>
              <button
                onClick={() => setSubType('movies')}
                className={`px-2.5 py-1 rounded-md transition-colors flex items-center gap-1 cursor-pointer ${
                  subType === 'movies'
                    ? 'bg-[#1b1e35] text-indigo-300 font-medium border border-[#2d3150]'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Film className="w-3 h-3" />
                <span>Movies</span>
              </button>
            </div>
          </div>
        )}

        {activeMainTab === 'watchlist' && (
          <div className="mt-6 pt-4 border-t border-[#1a1d33] space-y-4">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Bookmark className="w-4 h-4 text-indigo-400" />
                <h3 className="text-base font-semibold text-white">Your Saved Watchlist</h3>
              </div>

              {onNavigate && (
                <button
                  onClick={() => onNavigate('/watchlist')}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium text-indigo-300 hover:text-white bg-[#15182e] hover:bg-indigo-600 border border-[#2b3052] hover:border-indigo-500 transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
                  title="Open full Watchlist page"
                >
                  <span>See All</span>
                  {watchlist.length > 0 && (
                    <span className="font-mono tabular-nums text-[11px] opacity-80">({watchlist.length})</span>
                  )}
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {watchlist.length > 0 ? (
              <>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5 sm:gap-4.5">
                  {watchlist.slice(0, 12).map((item) => (
                    <AnimeCard
                      key={item.id}
                      anime={item}
                      onSelect={onSelectAnime}
                      onPlay={onPlayAnime}
                      isBookmarked={true}
                      onToggleWatchlist={onToggleWatchlist}
                    />
                  ))}
                </div>

                {watchlist.length > 12 && onNavigate && (
                  <div className="flex justify-center pt-3 pb-1">
                    <button
                      onClick={() => onNavigate('/watchlist')}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-500 shadow-md shadow-indigo-600/25 transition-all cursor-pointer"
                    >
                      <span>See All {watchlist.length} Watchlist Titles</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </>
            ) : (
              <div className="text-center py-16 text-slate-400 space-y-2">
                <Bookmark className="w-8 h-8 text-indigo-500/40 mx-auto" />
                <p className="text-sm font-medium text-slate-300">Your watchlist is currently empty</p>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Click the bookmark button on any anime or cartoon title to add it to your watchlist.
                </p>
              </div>
            )}
          </div>
        )}

        {activeMainTab === 'history' && (
          <div className="mt-6 pt-4 border-t border-[#1a1d33] space-y-4">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-indigo-400" />
                <h3 className="text-base font-semibold text-white">Recently Watched Titles</h3>
              </div>

              <div className="flex items-center gap-2">
                {onNavigate && (
                  <button
                    onClick={() => onNavigate('/history')}
                    className="px-3 py-1.5 rounded-lg text-xs font-medium text-indigo-300 hover:text-white bg-[#15182e] hover:bg-indigo-600 border border-[#2b3052] hover:border-indigo-500 transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
                    title="Open full History page"
                  >
                    <span>See All</span>
                    {history.length > 0 && (
                      <span className="font-mono tabular-nums text-[11px] opacity-80">({history.length})</span>
                    )}
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            {history.length > 0 ? (
              <>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5 sm:gap-4.5">
                  {history.slice(0, 12).map((item) => (
                    <AnimeCard
                      key={item.id}
                      anime={item}
                      onSelect={onResumeHistoryEntry || onSelectAnime}
                      onPlay={onResumeHistoryEntry || onPlayAnime}
                      isBookmarked={watchlistIdSet.has(item.id)}
                      onToggleWatchlist={onToggleWatchlist}
                      onRemove={onRemoveHistoryItem}
                    />
                  ))}
                </div>

                {history.length > 12 && onNavigate && (
                  <div className="flex justify-center pt-3 pb-1">
                    <button
                      onClick={() => onNavigate('/history')}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-500 shadow-md shadow-indigo-600/25 transition-all cursor-pointer"
                    >
                      <span>See All {history.length} Watched Titles</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </>
            ) : (
              <div className="text-center py-16 text-slate-400 space-y-2">
                <Clock className="w-8 h-8 text-indigo-500/40 mx-auto" />
                <p className="text-sm font-medium text-slate-300">No watch history yet</p>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Titles you stream will automatically appear here so you can quickly resume where you left off.
                </p>
              </div>
            )}
          </div>
        )}

        {(activeMainTab === 'anime' || activeMainTab === 'cartoon') && (
          <div className="mt-6 pt-4 border-t border-[#1a1d33] space-y-8">

            {isLoading && (
              <div className="py-16 text-center space-y-3">
                <Loader2 className="w-6 h-6 text-indigo-400 animate-spin mx-auto" />
                <p className="text-xs font-mono text-indigo-300">
                  Loading {activeMainTab} streaming catalog...
                </p>
              </div>
            )}

            {fetchError && !isLoading && (
              <div className="p-5 rounded-xl bg-rose-950/20 border border-rose-900/40 text-center space-y-2">
                <AlertCircle className="w-6 h-6 text-rose-400 mx-auto" />
                <p className="text-xs text-rose-300">{fetchError}</p>
                <button
                  onClick={fetchCategoryData}
                  className="px-3 py-1.5 text-xs bg-[#17192e] hover:bg-[#1e223f] text-slate-200 rounded-lg inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>Retry</span>
                </button>
              </div>
            )}

            {!isLoading && !fetchError && (subType === 'all' || subType === 'series') && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Tv className="w-4 h-4 text-indigo-400" />
                    <h3 className="text-base font-semibold text-white capitalize">
                      {activeMainTab} Series
                    </h3>
                  </div>

                  <div className="flex items-center gap-2 text-xs">
                    {onNavigate && (
                      <button
                        onClick={() => onNavigate(`/category/${activeMainTab}?type=series`)}
                        className="hidden sm:flex items-center gap-1 px-2.5 py-1 rounded bg-[#131526] hover:bg-[#1a1d33] border border-[#23263d] text-indigo-300 hover:text-white cursor-pointer font-medium"
                      >
                        <span>See All</span>
                        <ChevronRight className="w-3 h-3" />
                      </button>
                    )}
                    <button
                      onClick={() => setSeriesPage((p) => Math.max(1, p - 1))}
                      disabled={seriesPage <= 1}
                      className="p-1 rounded bg-[#131526] hover:bg-[#1a1d33] border border-[#23263d] disabled:opacity-40 disabled:pointer-events-none text-slate-300 cursor-pointer"
                    >
                      <ChevronLeft className="w-3.5 h-3.5" />
                    </button>
                    <span className="px-2 font-mono text-slate-300 tabular-nums text-[11px]">
                      {seriesPage} / {seriesTotalPages}
                    </span>
                    <button
                      onClick={() => setSeriesPage((p) => Math.min(seriesTotalPages, p + 1))}
                      disabled={seriesPage >= seriesTotalPages}
                      className="p-1 rounded bg-[#131526] hover:bg-[#1a1d33] border border-[#23263d] disabled:opacity-40 disabled:pointer-events-none text-slate-300 cursor-pointer"
                    >
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5 sm:gap-4.5">
                  {seriesData.slice(0, 12).map((item) => (
                    <AnimeCard
                      key={item.id}
                      anime={item}
                      onSelect={onSelectAnime}
                      onPlay={onPlayAnime}
                      isBookmarked={watchlistIdSet.has(item.id)}
                      onToggleWatchlist={onToggleWatchlist}
                    />
                  ))}
                </div>
              </div>
            )}

            {!isLoading && !fetchError && (subType === 'all' || subType === 'movies') && (
              <div className="space-y-4 pt-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Film className="w-4 h-4 text-indigo-400" />
                    <h3 className="text-base font-semibold text-white capitalize">
                      {activeMainTab} Movies
                    </h3>
                  </div>

                  <div className="flex items-center gap-2 text-xs">
                    {onNavigate && (
                      <button
                        onClick={() => onNavigate(`/category/${activeMainTab}?type=movies`)}
                        className="hidden sm:flex items-center gap-1 px-2.5 py-1 rounded bg-[#131526] hover:bg-[#1a1d33] border border-[#23263d] text-indigo-300 hover:text-white cursor-pointer font-medium"
                      >
                        <span>See All</span>
                        <ChevronRight className="w-3 h-3" />
                      </button>
                    )}
                    <button
                      onClick={() => setMoviesPage((p) => Math.max(1, p - 1))}
                      disabled={moviesPage <= 1}
                      className="p-1 rounded bg-[#131526] hover:bg-[#1a1d33] border border-[#23263d] disabled:opacity-40 disabled:pointer-events-none text-slate-300 cursor-pointer"
                    >
                      <ChevronLeft className="w-3.5 h-3.5" />
                    </button>
                    <span className="px-2 font-mono text-slate-300 tabular-nums text-[11px]">
                      {moviesPage} / {moviesTotalPages}
                    </span>
                    <button
                      onClick={() => setMoviesPage((p) => Math.min(moviesTotalPages, p + 1))}
                      disabled={moviesPage >= moviesTotalPages}
                      className="p-1 rounded bg-[#131526] hover:bg-[#1a1d33] border border-[#23263d] disabled:opacity-40 disabled:pointer-events-none text-slate-300 cursor-pointer"
                    >
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5 sm:gap-4.5">
                  {moviesData.slice(0, 12).map((item) => (
                    <AnimeCard
                      key={item.id}
                      anime={item}
                      onSelect={onSelectAnime}
                      onPlay={onPlayAnime}
                      isBookmarked={watchlistIdSet.has(item.id)}
                      onToggleWatchlist={onToggleWatchlist}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
};
