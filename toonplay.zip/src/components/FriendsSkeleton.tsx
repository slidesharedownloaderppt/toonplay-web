import React from 'react';

export const FriendsSkeleton: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#0b0c16] text-slate-100 pt-24 pb-16 px-4 md:px-8 max-w-6xl mx-auto">
      {/* Header */}
      <div className="pb-6 border-b border-[#23263f]">
        <div className="flex items-center gap-3">
          <div className="w-7 h-7 rounded bg-[#16182c] animate-pulse" />
          <div className="w-32 h-7 bg-[#16182c] rounded animate-pulse" />
        </div>
        <div className="w-64 h-4 bg-[#16182c]/60 rounded mt-2 animate-pulse" />
      </div>

      {/* Tabs */}
      <div className="flex border-b border-[#23263f] mt-6 gap-2">
        <div className="px-4 py-2.5 flex items-center gap-2">
          <div className="w-4 h-4 bg-[#16182c] rounded animate-pulse" />
          <div className="w-20 h-4 bg-[#16182c] rounded animate-pulse" />
        </div>
        <div className="px-4 py-2.5 flex items-center gap-2">
          <div className="w-4 h-4 bg-[#16182c] rounded animate-pulse" />
          <div className="w-20 h-4 bg-[#16182c] rounded animate-pulse" />
        </div>
        <div className="px-4 py-2.5 flex items-center gap-2">
          <div className="w-4 h-4 bg-[#16182c] rounded animate-pulse" />
          <div className="w-24 h-4 bg-[#16182c] rounded animate-pulse" />
        </div>
      </div>

      {/* Cards grid */}
      <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {Array.from({ length: 6 }).map((_, i) => (
          <div
            key={i}
            className="bg-[#14172b] border border-[#23263f] p-4 rounded-xl flex items-center justify-between animate-pulse"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-full bg-[#1c2038] border border-[#2e3252] shrink-0" />
              <div className="min-w-0 space-y-2">
                <div className="w-24 h-3 bg-[#1c2038] rounded" />
                <div className="w-16 h-2 bg-[#1c2038]/60 rounded" />
              </div>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <div className="w-8 h-8 rounded-lg bg-[#1c2038]" />
              <div className="w-8 h-8 rounded-lg bg-[#1c2038]" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};