import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { ChevronLeft, ChevronRight, LayoutGrid, Rows } from 'lucide-react';
import { AnimeCard } from './AnimeCard.tsx';
import { UnifiedAnime } from '../types.ts';
import { useDragScroll } from '../utils/useDragScroll.ts';

interface AnimeSectionProps {
  id: string;
  title: string;
  subtitle?: string;
  items: UnifiedAnime[];
  onSelectAnime: (anime: UnifiedAnime) => void;
  onPlayAnime: (anime: UnifiedAnime) => void;
  watchlist: UnifiedAnime[];
  onToggleWatchlist: (anime: UnifiedAnime) => void;
  defaultView?: 'carousel' | 'grid';
  seeAllHref?: string;
  onSeeAll?: (href: string) => void;
  maxItems?: number;
  /** Optional language tabs rendered in the header (e.g. JAP/ENG · HIN/TAM/TEL). */
  langTabs?: string[];
  /** Currently active lang tab. Must be one of `langTabs`. */
  activeLangTab?: string;
  /** Fires when the user picks a different lang tab. */
  onChangeLangTab?: (tab: string) => void;
}

export const AnimeSection: React.FC<AnimeSectionProps> = React.memo(({
  id,
  title,
  subtitle,
  items,
  onSelectAnime,
  onPlayAnime,
  watchlist,
  onToggleWatchlist,
  defaultView = 'grid',
  seeAllHref,
  onSeeAll,
  maxItems = 12,
  langTabs,
  activeLangTab,
  onChangeLangTab,
}) => {
  const [viewMode, setViewMode] = useState<'carousel' | 'grid'>(defaultView);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);
  const dragScroll = useDragScroll<HTMLDivElement>();

  const displayItems = useMemo(() => items.slice(0, maxItems), [items, maxItems]);
  const watchlistIdSet = useMemo(
    () => new Set(watchlist.map((w) => w.id)),
    [watchlist]
  );

  const hasLangTabs =
    Array.isArray(langTabs) && langTabs.length > 0 && !!onChangeLangTab;

  const handleCarouselSelect = useCallback(
    (selected: UnifiedAnime) => {
      if (!dragScroll.hasDraggedRef.current) onSelectAnime(selected);
    },
    [dragScroll.hasDraggedRef, onSelectAnime]
  );

  const handleCarouselPlay = useCallback(
    (played: UnifiedAnime) => {
      if (!dragScroll.hasDraggedRef.current) onPlayAnime(played);
    },
    [dragScroll.hasDraggedRef, onPlayAnime]
  );

  useEffect(() => {
    if (viewMode !== 'carousel') return;
    const el = dragScroll.ref.current;
    if (!el) return;

    let rafId: number | null = null;
    const updateBounds = () => {
      rafId = null;
      const node = dragScroll.ref.current;
      if (!node) return;
      const nextLeft = node.scrollLeft > 4;
      const nextRight = node.scrollLeft + node.clientWidth < node.scrollWidth - 4;
      setCanScrollLeft((prev) => (prev === nextLeft ? prev : nextLeft));
      setCanScrollRight((prev) => (prev === nextRight ? prev : nextRight));
    };

    const scheduleUpdate = () => {
      if (rafId === null) {
        rafId = requestAnimationFrame(updateBounds);
      }
    };

    updateBounds();
    el.addEventListener('scroll', scheduleUpdate, { passive: true });

    let ro: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined') {
      ro = new ResizeObserver(scheduleUpdate);
      ro.observe(el);
    } else {
      window.addEventListener('resize', scheduleUpdate, { passive: true });
    }

    return () => {
      el.removeEventListener('scroll', scheduleUpdate);
      if (ro) {
        ro.disconnect();
      } else {
        window.removeEventListener('resize', scheduleUpdate);
      }
      if (rafId !== null) cancelAnimationFrame(rafId);
    };
  }, [viewMode, displayItems.length, activeLangTab, dragScroll.ref]);

  const scrollByDirection = useCallback(
    (dir: -1 | 1) => {
      const el = dragScroll.ref.current;
      if (!el) return;
      const step = Math.max(240, Math.floor(el.clientWidth * 0.8));
      const reducedMotion =
        typeof window !== 'undefined' &&
        window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
      el.scrollBy({
        left: dir * step,
        behavior: reducedMotion ? 'auto' : 'smooth',
      });
    },
    [dragScroll.ref]
  );

  if (!items || items.length === 0) return null;

  return (
    <section id={id} className="tp-cv-section py-7 border-b border-[#1b1e33]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-5">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-indigo-400 mb-0.5">
              <span>{subtitle || 'ToonPlay Catalog'}</span>
              <span aria-hidden="true">·</span>
              <span className="tabular-nums">{displayItems.length} titles</span>
            </div>
            <h2 className="text-lg sm:text-xl font-semibold text-white tracking-tight">
              {title}
            </h2>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">

            {hasLangTabs && (
              <div className="flex items-center bg-[#121424] border border-[#24273e] p-0.5 rounded-lg text-[11px] font-mono">
                {langTabs!.map((tab) => {
                  const isActive = tab === activeLangTab;
                  return (
                    <button
                      key={tab}
                      type="button"
                      onClick={() => {
                        if (!isActive) onChangeLangTab?.(tab);
                      }}
                      aria-pressed={isActive}
                      className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                        isActive
                          ? 'bg-indigo-600 text-white shadow-sm'
                          : 'text-slate-400 hover:text-white hover:bg-[#1a1d33]'
                      }`}
                    >
                      {tab}
                    </button>
                  );
                })}
              </div>
            )}

            {seeAllHref && items.length >= 12 && (
              <button
                onClick={() => onSeeAll?.(seeAllHref)}
                className="px-3 py-1.5 rounded-lg bg-[#121424] hover:bg-[#1a1d33] border border-[#24273e] text-slate-300 hover:text-white text-xs font-medium transition-colors cursor-pointer flex items-center gap-1"
              >
                See All
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            )}

            <div className="flex items-center bg-[#121424] border border-[#24273e] p-0.5 rounded-lg text-xs">
              <button
                onClick={() => setViewMode('grid')}
                title="Grid View (Active Default)"
                className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                  viewMode === 'grid'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('carousel')}
                title="Scroll View"
                className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                  viewMode === 'carousel'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Rows className="w-4 h-4" />
              </button>
            </div>

            {viewMode === 'carousel' && (
              <div className="flex items-center gap-1 ml-1">
                <button
                  type="button"
                  onClick={() => scrollByDirection(-1)}
                  disabled={!canScrollLeft}
                  aria-label={`Scroll ${title} left`}
                  className={`p-1.5 rounded-lg bg-[#121424] border border-[#24273e] transition-colors ${
                    canScrollLeft
                      ? 'hover:bg-[#1a1d33] text-slate-300 hover:text-white cursor-pointer'
                      : 'text-slate-600 opacity-45 cursor-not-allowed'
                  }`}
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => scrollByDirection(1)}
                  disabled={!canScrollRight}
                  aria-label={`Scroll ${title} right`}
                  className={`p-1.5 rounded-lg bg-[#121424] border border-[#24273e] transition-colors ${
                    canScrollRight
                      ? 'hover:bg-[#1a1d33] text-slate-300 hover:text-white cursor-pointer'
                      : 'text-slate-600 opacity-45 cursor-not-allowed'
                  }`}
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>

        <div
          key={activeLangTab || 'default'}
          className="animate-in fade-in slide-in-from-top-1 duration-300"
        >
          {viewMode === 'grid' ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5 sm:gap-4.5">
              {displayItems.map((item) => (
                <AnimeCard
                  key={item.id}
                  anime={item}
                  onSelect={onSelectAnime}
                  onPlay={onPlayAnime}
                  isBookmarked={watchlistIdSet.has(item.id)}
                  onToggleWatchlist={onToggleWatchlist}
                />
              ))}
            </div>
          ) : (
            <div
              ref={dragScroll.ref}
              {...dragScroll.dragProps}
              className="tp-drag-scroll grid grid-rows-1 grid-flow-col gap-3.5 sm:gap-4.5 auto-cols-[calc((100%-14px)/2)] sm:auto-cols-[calc((100%-36px)/3)] md:auto-cols-[calc((100%-54px)/4)] lg:auto-cols-[calc((100%-72px)/5)] xl:auto-cols-[calc((100%-90px)/6)] overflow-x-auto overscroll-x-contain pb-4 scrollbar-hide"
            >
              {displayItems.map((item) => (
                <div key={item.id} className="select-none">
                  <AnimeCard
                    anime={item}
                    onSelect={handleCarouselSelect}
                    onPlay={handleCarouselPlay}
                    isBookmarked={watchlistIdSet.has(item.id)}
                    onToggleWatchlist={onToggleWatchlist}
                  />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
});
AnimeSection.displayName = 'AnimeSection';