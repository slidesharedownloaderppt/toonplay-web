import React from 'react';
import { Globe, Check } from 'lucide-react';

interface LanguageGridSectionProps {
  selectedLanguage: string | null;
  onSelectLanguage: (langCode: string | null) => void;
  onNavigateLanguage?: (langCode: string) => void;
}

export const LANGUAGES_LIST = [
  { name: 'Hindi', native: 'हिन्दी', code: 'hindi', count: 'Dubbed' },
  { name: 'Telugu', native: 'తెలుగు', code: 'telugu', count: 'Dubbed' },
  { name: 'Tamil', native: 'தமிழ்', code: 'tamil', count: 'Dubbed' },
  { name: 'Malayalam', native: 'മലയാളം', code: 'malayalam', count: 'Dubbed' },
  { name: 'Kannada', native: 'ಕನ್ನಡ', code: 'kannada', count: 'Dubbed' },
  { name: 'Bengali', native: 'বাংলা', code: 'bengali', count: 'Dubbed' },
  { name: 'English', native: 'English', code: 'english', count: 'Sub / Dub' },
  { name: 'Japanese', native: '日本語', code: 'japanese', count: 'Original' },
  { name: 'Korean', native: '한국어', code: 'korean', count: 'Sub / Dub' },
];

export const LanguageGridSection: React.FC<LanguageGridSectionProps> = ({
  selectedLanguage,
  onSelectLanguage,
  onNavigateLanguage,
}) => {
  return (
    <section id="languages-grid" className="bg-[#0b0c16] py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        <div className="flex items-center justify-between gap-4 mb-4">
          <div className="flex items-center gap-2">
            <Globe className="w-4 h-4 text-indigo-400" />
            <h3 className="text-sm sm:text-base font-semibold text-white tracking-tight">
              Browse by Audio & Dubbed Language
            </h3>
          </div>

          {selectedLanguage && (
            <button
              onClick={() => onSelectLanguage(null)}
              className="text-xs text-indigo-400 hover:text-indigo-300 font-mono underline cursor-pointer"
            >
              Reset Filter
            </button>
          )}
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-9 gap-2.5">
          {LANGUAGES_LIST.map((lang) => {
            const isSelected = selectedLanguage === lang.code;

            return (
              <button
                key={lang.code}
                onClick={() => {
                  if (onNavigateLanguage) {
                    onNavigateLanguage(lang.code);
                  } else {
                    onSelectLanguage(isSelected ? null : lang.code);
                  }
                }}
                className={`group relative text-left p-2.5 rounded-xl border transition-all duration-200 cursor-pointer flex flex-col justify-between gap-1 select-none ${
                  isSelected
                    ? 'bg-indigo-950/80 border-indigo-500 shadow-md shadow-indigo-950/50 scale-[1.02]'
                    : 'bg-[#121424] hover:bg-[#181a30] border-[#22253d] hover:border-indigo-500/40'
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <span className="text-[11px] font-mono text-slate-400 group-hover:text-indigo-300 transition-colors">
                    {lang.native}
                  </span>
                  {isSelected && <Check className="w-3.5 h-3.5 text-indigo-400 shrink-0" />}
                </div>

                <div className="pt-0.5">
                  <span className="text-xs sm:text-sm font-medium text-white block group-hover:text-indigo-200 truncate">
                    {lang.name}
                  </span>
                  <span className="text-[10px] text-slate-500 font-mono block">
                    {lang.count}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
};
