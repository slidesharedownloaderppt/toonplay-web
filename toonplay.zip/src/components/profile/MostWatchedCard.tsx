import { useEffect, useMemo, useState } from 'react';
import { fetchAnimeInfo } from '../../api';
import {
  computeShowProgress,
  extractTotalEpisodesFromAnimeInfo,
  resolveShowTotalEpisodes,
  resolveShowWatchedCount,
} from '../../lib/mostWatchedProgress';

interface Props {
  items: any[];
  onNavigate?: (path: string) => void;
}

export function MostWatchedCard({ items, onNavigate }: Props) {
  const [hydratedTotals, setHydratedTotals] = useState<Record<string, number>>({});

  const top5 = useMemo(() => {
    const eligible = Array.isArray(items)
      ? items.filter((a) => Number(a?.episodes_completed_30d ?? a?.episodes_watched ?? 0) > 0)
      : [];
    return eligible.slice(0, 5);
  }, [items]);

  // If any visible show is missing a stored total episode count (or its stored total is stale
  // relative to unique completed episodes), hydrate the real available total from the existing
  // cached show metadata API without altering ranking or blocking initial render.
  useEffect(() => {
    const idsNeedingTotal = top5
      .filter((a) => {
        const id = String(a?.cartoon_id || '').trim();
        if (!id || hydratedTotals[id] !== undefined) return false;
        const storedTotal = Number(a?.total_episodes_available || 0);
        const watched = resolveShowWatchedCount(a);
        return storedTotal <= 0 || watched > storedTotal;
      })
      .map((a) => String(a.cartoon_id).trim());

    if (idsNeedingTotal.length === 0) return;

    let cancelled = false;
    Promise.allSettled(
      idsNeedingTotal.map(async (id) => {
        const res = await fetchAnimeInfo(id);
        return {
          id,
          total: extractTotalEpisodesFromAnimeInfo(res?.anime),
        };
      })
    ).then((results) => {
      if (cancelled) return;
      const updates: Record<string, number> = {};
      for (const r of results) {
        if (r.status === 'fulfilled' && r.value.id) {
          updates[r.value.id] = r.value.total;
        }
      }
      if (Object.keys(updates).length > 0) {
        setHydratedTotals((prev) => ({ ...prev, ...updates }));
      }
    });

    return () => {
      cancelled = true;
    };
  }, [top5, hydratedTotals]);

  if (top5.length === 0) {
    return (
      <div className="bg-[#14172b] border border-[#2e3252] rounded-2xl p-5">
        <div className="mb-3">
          <h3 className="text-sm font-semibold text-white">Most watched</h3>
          <p className="text-[11px] text-slate-500 mt-0.5">Last 30 days</p>
        </div>
        <p className="text-xs text-slate-500">Nothing watched yet.</p>
      </div>
    );
  }

  return (
    <div className="bg-[#14172b] border border-[#2e3252] rounded-2xl p-5">
      <div className="mb-3">
        <h3 className="text-sm font-semibold text-white">Most watched</h3>
        <p className="text-[11px] text-slate-500 mt-0.5">Last 30 days</p>
      </div>

      <ol className="space-y-2">
        {top5.map((a) => {
          const id = String(a.cartoon_id);
          const watchedRaw = resolveShowWatchedCount(a);
          const totalAvailable = resolveShowTotalEpisodes(a, hydratedTotals[id]);
          const progress = computeShowProgress(watchedRaw, totalAvailable);

          return (
            <li key={id}>
              <button
                type="button"
                onClick={() => onNavigate?.(`/info/${id}`)}
                className="w-full flex items-center gap-3 hover:bg-[#1c2038] rounded-lg p-1.5 -m-1.5 transition text-left cursor-pointer"
              >
                {a.cartoon_image ? (
                  <img
                    src={a.cartoon_image}
                    alt={a.cartoon_title}
                    className="w-11 h-14 rounded object-cover shrink-0"
                    loading="lazy"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-11 h-14 rounded bg-[#0b0c16] shrink-0" />
                )}

                <div className="flex-1 min-w-0">
                  <p className="text-xs text-white truncate leading-snug">
                    {a.cartoon_title}
                  </p>
                  <div className="flex items-baseline justify-between gap-2 mt-0.5">
                    <p className="text-[10px] text-slate-500 truncate">
                      {progress.episodeLabel}
                    </p>
                    {progress.percentageLabel && (
                      <span className="text-[10px] text-slate-400 tabular-nums shrink-0">
                        {progress.percentageLabel}
                      </span>
                    )}
                  </div>
                  <div
                    role="progressbar"
                    aria-label={`${a.cartoon_title} completion progress`}
                    aria-valuemin={0}
                    aria-valuemax={100}
                    aria-valuenow={progress.progressPercentage ?? undefined}
                    className="h-[3px] bg-[#0b0c16] rounded-full overflow-hidden mt-1.5"
                  >
                    <div
                      className="h-full bg-indigo-500 rounded-full transition-[width] duration-500"
                      style={{ width: `${progress.barWidth}%` }}
                    />
                  </div>
                </div>
              </button>
            </li>
          );
        })}
      </ol>
    </div>
  );
}