interface Props {
  items: any[];
  onNavigate?: (path: string) => void;
}

export function MostWatchedCard({ items, onNavigate }: Props) {
  if (!items || items.length === 0) {
    return (
      <div className="bg-[#14172b] border border-[#2e3252] rounded-2xl p-5">
        <div className="mb-3">
          <h3 className="text-sm font-semibold text-white">Most watched</h3>
          <p className="text-[11px] text-slate-500 mt-0.5">Last 30 days</p>
        </div>
        <p className="text-xs text-slate-500">Nothing watched yet.</p>
      </div>
    );
  }

  const top5 = items.slice(0, 5);
  const maxWatched = Math.max(
    1,
    ...top5.map((a) => Number(a.episodes_watched || 0))
  );

  return (
    <div className="bg-[#14172b] border border-[#2e3252] rounded-2xl p-5">
      <div className="mb-3">
        <h3 className="text-sm font-semibold text-white">Most watched</h3>
        <p className="text-[11px] text-slate-500 mt-0.5">Last 30 days</p>
      </div>

      <ol className="space-y-2">
        {top5.map((a) => {
          const watched = Number(a.episodes_watched || 0);
          const total = Number(a.total_episodes_available || 0);
          const barWidth = (watched / maxWatched) * 100;
          const epLabel =
            total > 0
              ? `${watched} of ${total} episodes`
              : `${watched} episode${watched === 1 ? '' : 's'}`;

          return (
            <li key={a.cartoon_id}>
              <button
                type="button"
                onClick={() => onNavigate?.(`/info/${a.cartoon_id}`)}
                className="w-full flex items-center gap-3 hover:bg-[#1c2038] rounded-lg p-1.5 -m-1.5 transition text-left cursor-pointer"
              >
                {a.cartoon_image ? (
                  <img
                    src={a.cartoon_image}
                    alt={a.cartoon_title}
                    className="w-11 h-14 rounded object-cover shrink-0"
                    loading="lazy"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-11 h-14 rounded bg-[#0b0c16] shrink-0" />
                )}

                <div className="flex-1 min-w-0">
                  <p className="text-xs text-white truncate leading-snug">
                    {a.cartoon_title}
                  </p>
                  <p className="text-[10px] text-slate-500 mt-0.5">{epLabel}</p>
                  <div className="h-[3px] bg-[#0b0c16] rounded-full overflow-hidden mt-1.5">
                    <div
                      className="h-full bg-indigo-500 rounded-full transition-[width] duration-500"
                      style={{ width: `${Math.max(2, barWidth)}%` }}
                    />
                  </div>
                </div>
              </button>
            </li>
          );
        })}
      </ol>
    </div>
  );
}