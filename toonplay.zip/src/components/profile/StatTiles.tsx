interface StatTileProps {
  label: string;
  value: string | number;
  unit?: string;
  sub?: string;
  delta?: {
    value: string;
    direction: 'up' | 'down';
    title?: string;
  };
}

function StatTile({ label, value, unit, sub, delta }: StatTileProps) {
  return (
    <li className="flex flex-col gap-1.5 rounded-xl border border-[#2e3252] bg-[#14172b] p-3.5 min-w-0">
      {/* Head row: label + optional delta badge */}
      <span className="flex items-start justify-between gap-2 min-w-0">
        <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 truncate">
          {label}
        </span>
        {delta && (
          <b
            title={delta.title}
            className={`shrink-0 text-[10px] font-bold tabular-nums px-1.5 py-0.5 rounded ${
              delta.direction === 'up'
                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
            }`}
          >
            {delta.direction === 'up' ? '↑' : '↓'} {delta.value}
          </b>
        )}
      </span>

      {/* Value row */}
      <span className="text-lg font-bold text-white tabular-nums leading-tight truncate">
        {value}
        {unit && (
          <span className="text-xs font-medium text-slate-500 ml-0.5">
            {unit}
          </span>
        )}
      </span>

      {/* Sub line (optional) */}
      {sub && (
        <span className="text-[10px] text-slate-500 truncate">{sub}</span>
      )}
    </li>
  );
}

export interface StatTilesData {
  episodesWatched: number;
  episodesDelta?: string;
  totalAnimeWatched: number;
  completedAnime: number;
  activeDays: number;
  activeDaysTotal?: number;
  activeDaysDelta?: string;
}

interface Props {
  data: StatTilesData;
  rangeLabel?: string;
}

export function StatTiles({ data, rangeLabel = 'Compared with the 30 days before' }: Props) {
  const {
    episodesWatched,
    episodesDelta,
    totalAnimeWatched,
    completedAnime,
    activeDays,
    activeDaysTotal = 30,
    activeDaysDelta,
  } = data;

  const episodesPerShow =
    totalAnimeWatched > 0
      ? Math.round((episodesWatched / totalAnimeWatched) * 10) / 10
      : 0;

  return (
    <ul className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
      <StatTile
        label="Episodes"
        value={episodesWatched.toLocaleString()}
        delta={
          episodesDelta
            ? { value: episodesDelta, direction: 'up', title: rangeLabel }
            : undefined
        }
      />

      <StatTile
        label="Shows"
        value={totalAnimeWatched}
        sub={totalAnimeWatched > 0 ? `${episodesPerShow} episodes each` : undefined}
      />

      <StatTile label="Completed" value={completedAnime} />

      <StatTile
        label="Active days"
        value={activeDays}
        unit={`/ ${activeDaysTotal}`}
        delta={
          activeDaysDelta
            ? { value: activeDaysDelta, direction: 'up', title: rangeLabel }
            : undefined
        }
      />
    </ul>
  );
}