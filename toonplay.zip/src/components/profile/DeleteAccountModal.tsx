import React, { useEffect, useState } from 'react';
import { AlertTriangle, Trash2, X, Loader2, Lock } from 'lucide-react';
import { authApi } from '../../lib/api';
import { useAuth } from '../../context/AuthContext';
import { toast } from 'sonner';

interface Props {
  open: boolean;
  onClose: () => void;
  onDeleted: () => void;
}

export const DeleteAccountModal: React.FC<Props> = ({ open, onClose, onDeleted }) => {
  const { user, logout } = useAuth();
  const isGoogleUser = Boolean((user as any)?.google_id);

  const [password, setPassword] = useState('');
  const [confirmText, setConfirmText] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) {
      setPassword('');
      setConfirmText('');
      setError(null);
      setBusy(false);
    }
  }, [open]);

  // Close on Escape (only when not busy)
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !busy) onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, busy, onClose]);

  if (!open) return null;

  const handleDelete = async () => {
    if (busy) return;
    if (isGoogleUser) {
      if (confirmText.trim().toUpperCase() !== 'DELETE') {
        setError('Type DELETE (all caps) to confirm.');
        return;
      }
    } else {
      if (!password) {
        setError('Enter your password to confirm.');
        return;
      }
    }
    setError(null);
    setBusy(true);
    try {
      if (isGoogleUser) {
        await authApi.deleteAccount({ confirm: confirmText.trim().toUpperCase() });
      } else {
        await authApi.deleteAccount({ password });
      }
      // Clear local session so nothing stale remains
      try {
        await logout();
      } catch {
        /* ignore — session is deleted server-side */
      }
      toast.success('Account deleted permanently');
      onDeleted();
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to delete account');
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#111322] border border-[#272b47] rounded-2xl p-6 max-w-md w-full shadow-2xl text-left space-y-4 animate-in zoom-in-95 duration-200">
        <div className="flex items-start justify-between gap-3">
          <div className="w-10 h-10 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400 shrink-0">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <button
            type="button"
            onClick={onClose}
            disabled={busy}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-[#1a1c30] transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-1.5">
          <h3 className="text-lg font-semibold text-white">Delete account permanently?</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            This will <span className="text-rose-300">permanently erase</span> your account, watchlist,
            watch history, stats, and all associated data. <span className="text-slate-200">This action
            cannot be undone.</span>
          </p>
        </div>

        {error && (
          <div className="px-3.5 py-2.5 rounded-lg bg-rose-950/50 border border-rose-900/60 text-rose-300 text-xs">
            {error}
          </div>
        )}

        {isGoogleUser ? (
          <div className="space-y-1.5">
            <label className="block text-[11px] font-medium text-slate-400">
              Type <span className="font-mono font-bold text-rose-300">DELETE</span> to confirm
            </label>
            <input
              type="text"
              value={confirmText}
              onChange={(e) => setConfirmText(e.target.value)}
              placeholder="DELETE"
              autoComplete="off"
              autoCapitalize="characters"
              spellCheck={false}
              disabled={busy}
              className="w-full bg-[#0b0c16] border border-[#2e3252] rounded-lg px-3 py-2.5 text-sm text-white placeholder:text-slate-500 outline-none focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 transition disabled:opacity-60 font-mono tracking-widest"
            />
            <p className="text-[10px] text-slate-500">
              Your account is linked to Google — no password needed, type DELETE above.
            </p>
          </div>
        ) : (
          <div className="space-y-1.5">
            <label className="block text-[11px] font-medium text-slate-400">
              Confirm with your password
            </label>
            <div className="relative">
              <Lock className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter password"
                autoComplete="current-password"
                disabled={busy}
                className="w-full bg-[#0b0c16] border border-[#2e3252] rounded-lg pl-9 pr-3 py-2.5 text-sm text-white placeholder:text-slate-500 outline-none focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 transition disabled:opacity-60"
              />
            </div>
          </div>
        )}

        <div className="flex items-center justify-end gap-3 pt-2 border-t border-[#1a1d33]">
          <button
            type="button"
            onClick={onClose}
            disabled={busy}
            className="px-4 py-2 text-xs font-mono rounded-xl bg-[#181a2e] hover:bg-[#22253f] border border-[#262a4a] text-slate-300 transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Cancel
          </button>
<button
  type="button"
  onClick={handleDelete}
  disabled={busy || (isGoogleUser ? !confirmText.trim() : !password)}
  className="flex items-center gap-1.5 px-4 py-2 text-xs font-mono rounded-xl bg-rose-800 hover:bg-rose-700 text-white font-medium border border-rose-700/60 transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-rose-800"
>
  {busy ? (
    <Loader2 className="w-3.5 h-3.5 animate-spin" />
  ) : (
    <Trash2 className="w-3.5 h-3.5" />
  )}
  <span>{busy ? 'Deleting…' : 'Delete my account'}</span>
</button>
        </div>
      </div>
    </div>
  );
};