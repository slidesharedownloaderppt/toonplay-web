import { useState } from 'react';
import { Eye, EyeOff, Shield, Loader2 } from 'lucide-react';
import { authApi } from '../../lib/api';
import { toast } from 'sonner';

interface Props {
  onSaved?: () => void;
}

export function SecuritySection({ onSaved }: Props) {
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [confirm, setConfirm] = useState('');
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);

  const canSubmit =
    current.length > 0 && next.length >= 6 && next === confirm && !busy;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canSubmit) return;
    setBusy(true);
    try {
      await authApi.changePassword(current, next);
      toast.success('Password changed successfully');
      setCurrent('');
      setNext('');
      setConfirm('');
      onSaved?.();
    } catch (err: any) {
      toast.error(err?.message || 'Failed to change password');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-white tracking-tight">Security</h2>

      <form onSubmit={handleSubmit} className="p-5 rounded-2xl bg-[#14172b] border border-[#23263f] space-y-4">
        <div>
          <label className="block text-xs font-medium text-slate-400 mb-1.5">
            Current Password
          </label>
          <div className="relative">
            <input
              type={show ? 'text' : 'password'}
              value={current}
              onChange={(e) => setCurrent(e.target.value)}
              placeholder="••••••••"
              autoComplete="current-password"
              className="w-full bg-[#06070d] border border-[#23263f] rounded-lg px-3 py-2.5 pr-10 text-white text-sm focus:outline-none focus:border-indigo-500/60"
            />
            <button
              type="button"
              onClick={() => setShow((v) => !v)}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-slate-500 hover:text-slate-300"
            >
              {show ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-400 mb-1.5">
            New Password
          </label>
          <input
            type={show ? 'text' : 'password'}
            value={next}
            onChange={(e) => setNext(e.target.value)}
            placeholder="At least 6 characters"
            autoComplete="new-password"
            className="w-full bg-[#06070d] border border-[#23263f] rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-indigo-500/60"
          />
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-400 mb-1.5">
            Confirm New Password
          </label>
          <input
            type={show ? 'text' : 'password'}
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            placeholder="Re-enter new password"
            autoComplete="new-password"
            className="w-full bg-[#06070d] border border-[#23263f] rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-indigo-500/60"
          />
          {confirm.length > 0 && next !== confirm && (
            <p className="text-[10px] text-rose-400 mt-1">Passwords do not match.</p>
          )}
        </div>

        <div className="flex justify-end pt-2 border-t border-[#23263f]">
          <button
            type="submit"
            disabled={!canSubmit}
            className="cursor-pointer inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-colors disabled:opacity-50"
          >
            {busy ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Shield className="w-3.5 h-3.5" />
            )}
            <span>{busy ? 'Updating…' : 'Change password'}</span>
          </button>
        </div>
      </form>
    </div>
  );
}