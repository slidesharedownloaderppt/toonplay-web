import { useEffect, useMemo, useRef, useState } from 'react';
import { X, Loader2, Check, Search, Ban } from 'lucide-react';
import {
  fetchFrameCatalog,
  isAuthoritativeProfileFrameUrl,
  type FrameCatalogCategory,
} from '../../api';
import { userApi } from '../../lib/api';
import { AvatarWithFrame } from './AvatarWithFrame';
import { toast } from 'sonner';

interface Props {
  open: boolean;
  currentAvatarUrl: string | null;
  currentFrameUrl: string | null;
  username?: string;
  onClose: () => void;
  onSaved: (newFrameUrl: string | null) => void;
}

export function FramePickerModal({
  open,
  currentAvatarUrl,
  currentFrameUrl,
  username,
  onClose,
  onSaved,
}: Props) {
  const sanitizedCurrentFrame = isAuthoritativeProfileFrameUrl(currentFrameUrl)
    ? String(currentFrameUrl).trim()
    : null;

  const [categories, setCategories] = useState<FrameCatalogCategory[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<string | null>(sanitizedCurrentFrame);
  const [visible, setVisible] = useState(false);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const closeTimerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (closeTimerRef.current !== null) window.clearTimeout(closeTimerRef.current);
    };
  }, []);

  useEffect(() => {
    if (!open) {
      setVisible(false);
      return;
    }
    if (closeTimerRef.current !== null) {
      window.clearTimeout(closeTimerRef.current);
      closeTimerRef.current = null;
    }
    setSelected(sanitizedCurrentFrame);
    setSearch('');
    setActiveCategory('All');
    const raf = requestAnimationFrame(() => setVisible(true));
    return () => cancelAnimationFrame(raf);
  }, [open, sanitizedCurrentFrame]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = 0;
    }
  }, [activeCategory, search]);

  useEffect(() => {
    if (!open || categories.length > 0) return;
    let cancelled = false;
    setLoading(true);
    fetchFrameCatalog()
      .then((res) => {
        if (!cancelled) setCategories(res.categories);
      })
      .catch((err) => {
        if (cancelled) return;
        console.error('[frame catalog]', err);
        toast.error('Could not load avatar frames');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [open, categories.length]);

  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') handleClose();
    };
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener('keydown', onKey);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, saving]);

  const totalCount = useMemo(
    () => categories.reduce((sum, c) => sum + c.frames.length, 0),
    [categories]
  );

  const filteredCategories = useMemo(() => {
    const q = search.trim().toLowerCase();
    const scoped =
      activeCategory === 'All'
        ? categories
        : categories.filter((c) => c.label === activeCategory);

    if (!q) return scoped;
    return scoped
      .map((cat) => {
        const catMatches = cat.label.toLowerCase().includes(q);
        return {
          ...cat,
          frames: catMatches
            ? cat.frames
            : cat.frames.filter(
                (f) =>
                  f.name.toLowerCase().includes(q) ||
                  f.filename.toLowerCase().includes(q)
              ),
        };
      })
      .filter((cat) => cat.frames.length > 0);
  }, [categories, activeCategory, search]);

  const selectedMeta = useMemo(() => {
    for (const cat of categories) {
      for (const f of cat.frames) {
        if (f.url === selected) return f;
      }
    }
    return null;
  }, [categories, selected]);

  const normalizedCurrent = sanitizedCurrentFrame;
  const normalizedSelected = selected || null;
  const canSave = !saving && normalizedSelected !== normalizedCurrent;

  const scheduleClose = () => {
    setVisible(false);
    if (closeTimerRef.current !== null) window.clearTimeout(closeTimerRef.current);
    closeTimerRef.current = window.setTimeout(() => {
      closeTimerRef.current = null;
      onClose();
    }, 200);
  };

  const handleClose = () => {
    if (saving) return;
    scheduleClose();
  };

  const handleSave = async () => {
    if (!canSave) return;
    setSaving(true);
    try {
      await userApi.updateProfile({ profile_frame_url: normalizedSelected });
      toast.success(
        normalizedSelected ? 'Profile frame updated' : 'Profile frame removed'
      );
      onSaved(normalizedSelected);
      scheduleClose();
    } catch (err: any) {
      toast.error(err?.message || 'Failed to update profile frame');
    } finally {
      setSaving(false);
    }
  };

  const handleRemoveFrame = async () => {
    if (saving) return;
    setSaving(true);
    try {
      await userApi.updateProfile({ profile_frame_url: null });
      toast.success('Profile frame removed');
      onSaved(null);
      scheduleClose();
    } catch (err: any) {
      toast.error(err?.message || 'Failed to remove frame');
    } finally {
      setSaving(false);
    }
  };

  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Profile frame picker"
      onClick={handleClose}
      className="fixed inset-0 z-[220] flex items-start sm:items-center justify-center p-2 sm:p-6 overflow-y-auto bg-black/80 backdrop-blur-sm transition-opacity duration-200 ease-out"
      style={{ opacity: visible ? 1 : 0 }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-2xl bg-[#0b0d16] border border-[#2e3252] rounded-2xl shadow-2xl shadow-black/80 my-4 sm:my-6 overflow-hidden"
        style={{
          transform: visible
            ? 'translateY(0) scale(1)'
            : 'translateY(12px) scale(0.96)',
          opacity: visible ? 1 : 0,
          transition:
            'transform 220ms cubic-bezier(0.22, 1, 0.36, 1), opacity 180ms ease',
        }}
      >
        {/* Header */}
        <div className="px-4 sm:px-6 pt-4 pb-3 border-b border-[#23263f] flex items-start justify-between gap-3">
          <div>
            <h2 className="text-base font-semibold text-white tracking-tight">
              Avatar Frame
            </h2>

<p className="text-[11px] text-slate-500 mt-0.5">
  Customize your avatar with animated frames visible across your profile.
  {totalCount > 0 ? ` · ${totalCount} frames available` : ''}
</p>

          </div>
          <button
            type="button"
            onClick={handleClose}
            aria-label="Close"
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#1c2038] transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Live Preview + Search + Category Filter */}
        <div className="px-4 sm:px-6 py-3.5 border-b border-[#23263f] bg-[#0d1019] space-y-3">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3 shrink-0 p-1">
              <AvatarWithFrame
                avatarUrl={currentAvatarUrl}
                frameUrl={selected}
                username={username}
                alt="Large frame preview"
                className="w-16 h-16"
                avatarClassName="border-2 border-[#070811]"
                loading="eager"
              />
              <AvatarWithFrame
                avatarUrl={currentAvatarUrl}
                frameUrl={selected}
                username={username}
                alt="Small frame preview"
                className="w-9 h-9 hidden sm:inline-flex"
                avatarClassName="border border-[#2e3252]"
                loading="eager"
              />
            </div>

            <div className="min-w-0 flex-1">
              <p className="text-xs font-semibold text-white truncate">
                {selectedMeta?.name || (selected ? 'Selected frame' : 'No frame')}
              </p>
              <p className="text-[10px] text-slate-500 truncate mt-0.5">
                {selectedMeta?.category ||
                  (selected
                    ? 'Active decorative avatar frame'
                    : 'Your normal avatar without a frame')}
              </p>
            </div>
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search frames or collections..."
              className="w-full bg-[#06070d] border border-[#23263f] rounded-lg pl-8 pr-2.5 py-1.5 text-[11px] text-white placeholder:text-slate-600 focus:outline-none focus:border-indigo-500/60"
            />
          </div>

          {categories.length > 1 && (
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 thin-scrollbar">
              <button
                type="button"
                onClick={() => setActiveCategory('All')}
                className={`shrink-0 px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors cursor-pointer border ${
                  activeCategory === 'All'
                    ? 'bg-indigo-600 text-white border-indigo-500'
                    : 'bg-[#06070d] text-slate-400 hover:text-white border-[#23263f]'
                }`}
              >
                All ({totalCount})
              </button>
              {categories.map((cat) => (
                <button
                  key={cat.label}
                  type="button"
                  onClick={() => setActiveCategory(cat.label)}
                  className={`shrink-0 px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors cursor-pointer border ${
                    activeCategory === cat.label
                      ? 'bg-indigo-600 text-white border-indigo-500'
                      : 'bg-[#06070d] text-slate-400 hover:text-white border-[#23263f]'
                  }`}
                >
                  {cat.label}{' '}
                  <span className="opacity-65">({cat.frames.length})</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Body */}
        {loading ? (
          <div className="h-64 flex items-center justify-center">
            <Loader2 className="w-5 h-5 animate-spin text-indigo-400" />
          </div>
        ) : filteredCategories.length === 0 ? (
          <div className="h-64 flex items-center justify-center text-xs text-slate-500 px-4 text-center">
            No frames match &quot;{search}&quot;.
          </div>
        ) : (
          <div
            ref={scrollRef}
            className="max-h-[50vh] sm:max-h-[380px] overflow-y-auto thin-scrollbar"
          >
            {/* None option */}
            {!search.trim() && activeCategory === 'All' && (
              <div className="px-4 sm:px-6 pt-3.5 pb-2 border-b border-[#23263f]">
                <button
                  type="button"
                  onClick={() => setSelected(null)}
                  aria-pressed={!selected}
                  className={`inline-flex items-center gap-2 px-3 py-2 rounded-xl border text-xs font-medium transition-colors cursor-pointer ${
                    !selected
                      ? 'bg-indigo-600/20 border-indigo-500 text-white'
                      : 'bg-[#14172b] border-[#23263f] text-slate-300 hover:border-[#3a3f66]'
                  }`}
                >
                  <Ban className="w-3.5 h-3.5 text-slate-400" />
                  <span>No Frame (Normal Avatar)</span>
                  {!selected && <Check className="w-3.5 h-3.5 text-indigo-400" />}
                </button>
              </div>
            )}

            {filteredCategories.map((cat) => (
              <div
                key={cat.label}
                className="border-b border-[#23263f] last:border-b-0"
              >
                <div className="px-4 sm:px-6 pt-3.5 pb-2 flex items-baseline gap-2">
                  <span className="text-xs font-semibold text-white">
                    {cat.label}
                  </span>
                  <span className="text-[10px] text-slate-500">
                    {cat.frames.length}{' '}
                    {cat.frames.length === 1 ? 'frame' : 'frames'}
                  </span>
                </div>

                <div className="px-4 sm:px-6 pb-4 grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2.5">
                  {cat.frames.map((frame) => {
                    const isSelected = selected === frame.url;
                    return (
                      <button
                        key={frame.url}
                        type="button"
                        onClick={() => setSelected(frame.url)}
                        aria-pressed={isSelected}
                        title={frame.name}
                        className={`relative flex flex-col items-center gap-2 p-3 rounded-xl border transition-colors cursor-pointer ${
                          isSelected
                            ? 'bg-indigo-600/15 border-indigo-500 ring-1 ring-indigo-500/40'
                            : 'bg-[#14172b] border-[#23263f] hover:border-[#3a3f66]'
                        }`}
                      >
                        <div className="py-1">
                          <AvatarWithFrame
                            avatarUrl={currentAvatarUrl}
                            frameUrl={frame.url}
                            username={username}
                            alt={frame.name}
                            className="w-12 h-12"
                            avatarClassName="border border-[#2e3252]"
                            loading="lazy"
                          />
                        </div>
                        <span className="text-[10px] font-medium text-slate-300 truncate w-full text-center">
                          {frame.name}
                        </span>
                        {isSelected && (
                          <span className="absolute top-1.5 right-1.5 w-4 h-4 rounded-full bg-indigo-600 flex items-center justify-center">
                            <Check className="w-2.5 h-2.5 text-white" />
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Footer */}
        <div className="px-4 sm:px-6 py-3 border-t border-[#23263f] flex flex-wrap items-center gap-2 bg-[#0d1019]">
          <button
            type="button"
            onClick={handleRemoveFrame}
            disabled={saving || (!sanitizedCurrentFrame && !currentFrameUrl)}
            className="px-3 py-1.5 rounded-lg bg-transparent hover:bg-rose-500/10 border border-[#23263f] hover:border-rose-500/40 text-rose-400 hover:text-rose-300 text-[11px] font-medium disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors"
          >
            Remove frame
          </button>

          <div className="flex-1" />

          <button
            type="button"
            onClick={handleClose}
            disabled={saving}
            className="px-3 py-1.5 rounded-lg bg-[#14172b] hover:bg-[#1c2038] border border-[#23263f] text-slate-300 text-[11px] font-medium disabled:opacity-50 cursor-pointer transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={!canSave}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-semibold disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer transition-colors"
          >
            {saving ? (
              <Loader2 className="w-3 h-3 animate-spin" />
            ) : (
              <Check className="w-3 h-3" />
            )}
            <span>{saving ? 'Saving…' : 'Save frame'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
