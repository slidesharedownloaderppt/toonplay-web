import React, { useEffect, useMemo, useState } from 'react';
import { Bookmark, Play, Check, Lock, ChevronLeft, ChevronRight } from 'lucide-react';
import { ProfileHeader } from './ProfileHeader';
import { AnimeCard } from '../AnimeCard';
import { UnifiedAnime } from '../../types';
import { useAuth } from '../../context/AuthContext';

interface Props {
  profile: any;
  onNavigate: (path: string) => void;
  watchlist?: UnifiedAnime[];
  onToggleWatchlist?: (anime: UnifiedAnime) => void;
  onPlayAnime?: (
    anime: UnifiedAnime,
    lang?: string,
    season?: number,
    ep?: number
  ) => void;
}

type TabId = 'all' | 'watching' | 'completed';

interface TabDef {
  id: TabId;
  label: string;
  icon: React.ReactNode;
}

/**
 * Public profile page body.
 *
 * Visibility rules:
 *   - Owner: ALWAYS sees their watchlist (show_watchlist has no effect on owner).
 *   - Non-owner + show_watchlist = 1 → watchlist grid (or "empty" text).
 *   - Non-owner + show_watchlist = 0 → "Private Watchlist" lock card.
 *   - Owner + empty → "Your watchlist is empty."
 *   - Non-owner + empty → "@username's watchlist is empty."
 */
export const PublicProfileView: React.FC<Props> = ({
  profile,
  onNavigate,
  watchlist = [],
  onToggleWatchlist,
  onPlayAnime,
}) => {
  const [activeTab, setActiveTab] = useState<TabId>('all');
  const [page, setPage] = useState(1);
  const { user: authUser } = useAuth();
  const watchlistIdSet = useMemo(
    () => new Set(watchlist.map((w) => w.id)),
    [watchlist]
  );

  const user = profile || {};
  const username = user.username || '';

  // Owner detection (case-insensitive to be safe)
  const isOwner =
    !!authUser &&
    (authUser.username || '').toLowerCase() === username.toLowerCase();

  // Owner always sees their watchlist. Non-owner only if show_watchlist !== 0.
  const watchlistHidden = !isOwner && Number(user.show_watchlist) === 0;
  const showWatchlist = !watchlistHidden;

  // Owner uses the live global watchlist; visitors use the profile's public watchlist.
  const watchlistItems = useMemo<UnifiedAnime[]>(() => {
    if (isOwner) {
      return watchlist;
    }

    const raw = Array.isArray(user.watchlist) ? user.watchlist : [];

    return raw.map((row: any): UnifiedAnime => ({
      id: String(row.cartoon_id ?? row.id),
      subjectId: row.subject_id != null
        ? String(row.subject_id)
        : row.subjectId != null
          ? String(row.subjectId)
          : undefined,
      title: String(row.cartoon_title ?? row.title ?? 'Unknown'),
      image: row.cartoon_image ?? row.image ?? '',
      type: (row.cartoon_type === 'movie' ? 'movie' : 'series') as 'movie' | 'series',
      category: (row.cartoon_type === 'movie' ? 'movie' : 'series') as 'movie' | 'series',
    }));
  }, [isOwner, watchlist, user.watchlist]);

  // Completed IDs from stats.recentAnime
  const completedIds = useMemo(() => {
    const stats = user.stats?.recentAnime;
    if (!Array.isArray(stats)) return new Set<string>();
    return new Set<string>(
      stats
        .filter((s: any) => Number(s.completed) === 1)
        .map((s: any) => String(s.cartoon_id))
    );
  }, [user.stats]);

  const watchingItems = useMemo(
    () => watchlistItems.filter((i) => !completedIds.has(i.id)),
    [watchlistItems, completedIds]
  );
  const completedItems = useMemo(
    () => watchlistItems.filter((i) => completedIds.has(i.id)),
    [watchlistItems, completedIds]
  );

  const tabs: TabDef[] = [
    { id: 'all', label: 'All', icon: <Bookmark className="h-3 w-3" /> },
    { id: 'watching', label: 'Watching', icon: <Play className="h-3 w-3" /> },
    { id: 'completed', label: 'Completed', icon: <Check className="h-3 w-3" /> },
  ];
  
  const ITEMS_PER_PAGE = 12;
  
  const counts: Record<TabId, number> = {
    all: watchlistItems.length,
    watching: watchingItems.length,
    completed: completedItems.length,
  };

const visibleItems =
  activeTab === 'all'
    ? watchlistItems
    : activeTab === 'watching'
    ? watchingItems
    : completedItems;

const totalPages = Math.max(
  1,
  Math.ceil(visibleItems.length / ITEMS_PER_PAGE)
);

const currentPage = Math.min(page, totalPages);

const paginatedItems = useMemo(() => {
  const start = (currentPage - 1) * ITEMS_PER_PAGE;
  return visibleItems.slice(start, start + ITEMS_PER_PAGE);
}, [visibleItems, currentPage]);

useEffect(() => {
  if (page > totalPages) {
    setPage(totalPages);
  }
}, [page, totalPages]);

  const handleActivityClick = () => {
    onNavigate(`/u/${username}/activity`);
  };

  return (
    <div className="min-h-screen bg-[#070811] text-white">
      {/* Hero header */}
      <ProfileHeader
        user={user}
        isOwn={isOwner}
        onActivityClick={handleActivityClick}
        onNavigate={onNavigate}
      />

      {/* Watchlist section */}
      <div className="mx-auto min-h-[60vh] max-w-7xl pb-12">
        {!showWatchlist ? (
          /* ============ Private state (non-owner only) ============ */
          <div className="px-4 pt-6 pb-8 sm:px-6 md:px-8">
            <div className="flex flex-col items-center justify-center py-24 sm:py-32">
              <div className="animate-fade-in-up flex flex-col items-center text-center">
                <div className="relative mb-6 h-20 w-20">
                  <div className="absolute inset-0 rotate-6 rounded-md bg-gradient-to-tr from-indigo-500/20 to-indigo-500/5" />
                  <div className="absolute inset-0 flex -rotate-3 items-center justify-center rounded-md border border-white/10 bg-[#141414] shadow-lg">
                    <Lock className="h-8 w-8 text-indigo-400" />
                  </div>
                </div>
                <h3 className="mb-2 text-xl font-black tracking-tight text-white">
                  Private Watchlist
                </h3>
                <p className="max-w-[280px] text-sm leading-relaxed font-medium text-zinc-400">
                  This user has set their watchlist to private.
                </p>
              </div>
            </div>
          </div>
        ) : (
          /* ============ Watchlist visible (owner always, non-owner if show=1) ============ */
          <>
            {/* Section header + tabs */}
            <div className="animate-fade-in relative border-b border-white/5 bg-[#0a0b16]/30 px-4 py-4 sm:px-6 md:px-8">
              <div className="flex flex-col gap-4">
                <div className="flex items-center justify-between">
                  <h2 className="flex items-center gap-2 text-lg font-bold tracking-tight text-white">
                    <Bookmark className="h-5 w-5 text-indigo-400" />
                    Watchlist
                  </h2>
                  <span className="text-sm text-zinc-400">
                    <span className="font-bold text-white tabular-nums">
                      {watchlistItems.length}
                    </span>{' '}
                    shows
                  </span>
                </div>

                {/* Folder tabs */}
                <div className="overflow-hidden">
                  <div
                    className="flex gap-2 overflow-x-auto scrollbar-hide pb-1"
                    style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
                  >
                    {tabs.map((t) => {
                      const active = activeTab === t.id;
                      return (
                        <button
                          key={t.id}
                          type="button"
                          onClick={() => {
  setActiveTab(t.id);
  setPage(1);
}}
                          className={`flex shrink-0 items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors cursor-pointer ${
                            active
                              ? 'bg-indigo-500 text-white'
                              : 'bg-[#141414] text-zinc-400 hover:bg-[#1a1a1a] hover:text-white'
                          }`}
                        >
                          {t.icon}
                          <span>{t.label}</span>
                          <span className={active ? 'text-white/80' : 'opacity-70'}>
                            ({counts[t.id]})
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>

            {/* Grid or empty state */}
            <div className="px-4 pt-6 pb-8 sm:px-6 md:px-8">
              {visibleItems.length === 0 ? (
                <EmptyState
                  title={
                    activeTab === 'all'
                      ? 'No Show Found'
                      : activeTab === 'watching'
                      ? 'Nothing in progress'
                      : 'Nothing completed'
                  }
                  message={
                    activeTab === 'all'
                      ? isOwner
                        ? 'Your watchlist is empty.'
                        : `@${username}'s watchlist is empty.`
                      : activeTab === 'watching'
                      ? isOwner
                        ? 'You are not currently watching anything.'
                        : `@${username} is not currently watching anything.`
                      : isOwner
                      ? "You haven't completed any show yet."
                      : `@${username} hasn't completed any show yet.`
                  }
                />
              ) : (
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
                  {paginatedItems.map((item) => {
                    const unified = item as UnifiedAnime;
                    const isBookmarked = watchlistIdSet.has(item.id);
                    return (
                      <AnimeCard
                        key={item.id}
                        anime={unified}
onSelect={(a) =>
  onNavigate(
    `/info/${encodeURIComponent(a.id)}${
      a.subjectId ? `?subjectId=${encodeURIComponent(a.subjectId)}` : ''
    }`
  )
}
                        onPlay={(a) =>
                          onPlayAnime
                            ? onPlayAnime(a)
                            : onNavigate(`/watch/${encodeURIComponent(a.id)}`)
                        }
                        isBookmarked={isBookmarked}
                        onToggleWatchlist={onToggleWatchlist ?? (() => {})}
                      />
                    );
                  })}
                </div>
              )}

              {totalPages > 1 && (
                <div className="flex items-center justify-center gap-3 pt-8 pb-4">
                  <button
                    type="button"
                    onClick={() => {
                      setPage((p) => Math.max(1, p - 1));
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    disabled={currentPage <= 1}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-mono bg-[#14172b] border border-[#232742] text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-indigo-600 hover:text-white transition-colors cursor-pointer"
                  >
                    <ChevronLeft className="w-3.5 h-3.5" />
                    <span>Previous</span>
                  </button>

                  <div className="flex items-center gap-1">
                    {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                      <button
                        key={p}
                        type="button"
                        onClick={() => {
                          setPage(p);
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }}
                        className={`w-7 h-7 rounded-lg text-xs font-mono flex items-center justify-center transition-colors cursor-pointer ${
                          currentPage === p
                            ? 'bg-indigo-600 text-white font-semibold'
                            : 'bg-[#14172b] text-slate-400 hover:text-white border border-[#232742]'
                        }`}
                      >
                        {p}
                      </button>
                    ))}
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setPage((p) => Math.min(totalPages, p + 1));
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    disabled={currentPage >= totalPages}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-mono bg-[#14172b] border border-[#232742] text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-indigo-600 hover:text-white transition-colors cursor-pointer"
                  >
                    <span>Next</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

/* ============================================================
 * Inner components
 * ============================================================ */

const EmptyState: React.FC<{ title: string; message: string }> = ({
  title,
  message,
}) => (
  <div className="flex flex-col items-center justify-center py-24 sm:py-32">
    <div className="animate-fade-in-up flex flex-col items-center text-center">
      <div className="relative mb-6 h-20 w-20">
        <div className="absolute inset-0 rotate-6 rounded-md bg-gradient-to-tr from-indigo-500/20 to-indigo-500/5" />
        <div className="absolute inset-0 flex -rotate-3 items-center justify-center rounded-md border border-white/10 bg-[#141414] shadow-lg transition-transform duration-300 hover:rotate-0">
          <Bookmark className="h-8 w-8 text-indigo-400" strokeWidth={2.5} />
        </div>
      </div>
      <h3 className="mb-2 text-xl font-black tracking-tight text-white">{title}</h3>
      <p className="max-w-[280px] text-sm leading-relaxed font-medium text-zinc-400">
        {message}
      </p>
    </div>
  </div>
);