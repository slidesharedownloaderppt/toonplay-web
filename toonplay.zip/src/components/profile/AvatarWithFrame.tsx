import React, { useEffect, useMemo, useState } from 'react';
import { getProfileFrameCandidateUrls } from '../../api';

export interface AvatarWithFrameProps {
  avatarUrl?: string | null;
  frameUrl?: string | null;
  username?: string | null;
  alt?: string;
  /** Size & positioning classes on the outer square wrapper (e.g. "w-10 h-10", "h-24 w-24 lg:h-36 lg:w-36"). */
  className?: string;
  /** Extra classes for the circular inner avatar container (e.g. border-2 border-[#070811]). */
  avatarClassName?: string;
  /** Shape class for the avatar image container (defaults to "rounded-full"). */
  roundedClassName?: string;
  /** If true and no avatarUrl is set, renders a centered initial badge instead of a DiceBear image. */
  showInitialFallback?: boolean;
  initialClassName?: string;
  /** Frame scale relative to avatar diameter (default 1.24 so decoration wraps cleanly around circular edge). */
  frameScaleClassName?: string;
  loading?: 'lazy' | 'eager';
}

export function getFallbackAvatarUrl(seed?: string | null): string {
  return `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(
    String(seed || 'user')
  )}`;
}

/**
 * Shared avatar-with-frame renderer used across Public Profile, User Activity,
 * Settings (/profile), Global Header (UserMenu), Leaderboard, and Friends lists.
 *
 * - Renders a standard avatar with zero extra chrome when `frameUrl` is empty
 *   or comes from a retired legacy frame source.
 * - Automatically retries alternate mirrors (fastly.jsdelivr.net -> raw.githubusercontent.com)
 *   for the exact same pinned commit if cdn.jsdelivr.net transiently fails or is throttled.
 * - Overlays the selected authoritative frame centered around the avatar using
 *   `object-contain` so it scales proportionally at every avatar size without
 *   stretching, cropping, or obscuring the avatar image.
 */
export const AvatarWithFrame: React.FC<AvatarWithFrameProps> = ({
  avatarUrl,
  frameUrl,
  username,
  alt,
  className = 'w-10 h-10',
  avatarClassName = 'border border-[#2e3252]',
  roundedClassName = 'rounded-full',
  showInitialFallback = false,
  initialClassName = 'bg-indigo-600 text-white text-xs font-semibold',
  frameScaleClassName = 'w-[124%] h-[124%]',
  loading = 'lazy',
}) => {
  const cleanAvatar = String(avatarUrl || '').trim();
  const rawFrame = String(frameUrl || '').trim();
  const frameCandidates = useMemo(
    () => getProfileFrameCandidateUrls(rawFrame),
    [rawFrame]
  );
  const fallbackSrc = getFallbackAvatarUrl(username || alt || 'user');

  const [avatarFailed, setAvatarFailed] = useState(false);
  const [frameAttempt, setFrameAttempt] = useState(0);

  useEffect(() => {
    setAvatarFailed(false);
  }, [cleanAvatar]);

  useEffect(() => {
    setFrameAttempt(0);
  }, [rawFrame]);

  const activeFrameSrc = frameCandidates[frameAttempt] || '';
  const initial = (alt || username || '?').trim().charAt(0).toUpperCase() || '?';
  const showInitial = showInitialFallback && (!cleanAvatar || avatarFailed);
  const resolvedAvatarSrc = !avatarFailed && cleanAvatar ? cleanAvatar : fallbackSrc;

  return (
    <span className={`relative inline-flex shrink-0 items-center justify-center ${className}`}>
      <span
        className={`relative z-10 flex h-full w-full items-center justify-center overflow-hidden bg-[#0b0c16] ${roundedClassName} ${avatarClassName}`}
      >
        {showInitial ? (
          <span className={`flex h-full w-full items-center justify-center ${initialClassName}`}>
            {initial}
          </span>
        ) : (
          <img
            src={resolvedAvatarSrc}
            alt={alt || username || 'Avatar'}
            loading={loading}
            decoding="async"
            referrerPolicy="no-referrer"
            className="h-full w-full object-cover"
            onError={() => {
              if (!avatarFailed) setAvatarFailed(true);
            }}
          />
        )}
      </span>

      {activeFrameSrc && (
        <img
          src={activeFrameSrc}
          alt=""
          aria-hidden="true"
          loading={loading}
          decoding="async"
          referrerPolicy="no-referrer"
          className={`pointer-events-none select-none absolute left-1/2 top-1/2 z-20 -translate-x-1/2 -translate-y-1/2 ${frameScaleClassName} max-w-none object-contain`}
          onError={() => {
            if (frameAttempt + 1 < frameCandidates.length) {
              setFrameAttempt((prev) => prev + 1);
            } else {
              setFrameAttempt(frameCandidates.length);
            }
          }}
        />
      )}
    </span>
  );
};
