import { useEffect, useMemo, useState } from 'react';
import {
  X,
  Loader2,
  Check,
  Search,
  Link as LinkIcon,
} from 'lucide-react';
import { fetchAvatarCatalog, type AvatarCatalogCategory } from '../../api';
import { userApi } from '../../lib/api';
import { toast } from 'sonner';

const CDN_BASE = 'https://animerulz.watch';
const FALLBACK_AVATAR = 'https://api.dicebear.com/7.x/bottts/svg?seed=fallback';

interface Props {
  open: boolean;
  currentAvatarUrl: string | null;
  onClose: () => void;
  onSaved: (newUrl: string) => void;
}

type Mode = 'gallery' | 'url';

export function AvatarPickerModal({
  open,
  currentAvatarUrl,
  onClose,
  onSaved,
}: Props) {
  const [mode, setMode] = useState<Mode>('gallery');
  const [categories, setCategories] = useState<AvatarCatalogCategory[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<string | null>(currentAvatarUrl);
  const [customUrl, setCustomUrl] = useState('');
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (!open) {
      setVisible(false);
      return;
    }
    setSelected(currentAvatarUrl);
    setCustomUrl('');
    setSearch('');
    setMode('gallery');
    const raf = requestAnimationFrame(() => setVisible(true));
    return () => cancelAnimationFrame(raf);
  }, [open, currentAvatarUrl]);

  // Fetch catalog once when opened
  useEffect(() => {
    if (!open) return;
    if (categories.length > 0) return;
    let cancelled = false;
    setLoading(true);
    fetchAvatarCatalog()
      .then((cats) => {
        if (!cancelled) setCategories(cats);
      })
      .catch((err) => {
        if (cancelled) return;
        console.error('[avatar catalog]', err);
        toast.error('Could not load avatars — check your connection');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [open, categories.length]);

  // Body scroll lock + Escape
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') handleClose();
    };
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener('keydown', onKey);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const resolveUrl = (src: string): string => {
    if (/^https?:\/\//i.test(src)) return src;
    return `${CDN_BASE}${src.startsWith('/') ? '' : '/'}${src}`;
  };

  // Filter every category by the search query (all at once, like the reference)
  const filteredCategories = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return categories;
    return categories
      .map((cat) => ({
        ...cat,
        avatars: cat.avatars.filter((a) =>
          a.alt.toLowerCase().includes(q)
        ),
      }))
      .filter((cat) => cat.avatars.length > 0);
  }, [categories, search]);

  // The currently selected avatar (for the preview label)
  const selectedMeta = useMemo(() => {
    for (const cat of categories) {
      for (const a of cat.avatars) {
        const url = resolveUrl(a.src);
        if (a.src === selected || url === selected) {
          return { ...a, category: cat.label };
        }
      }
    }
    return null;
  }, [categories, selected]);

  const previewSrc =
    mode === 'url'
      ? customUrl.trim() || currentAvatarUrl || FALLBACK_AVATAR
      : selected
      ? resolveUrl(selected)
      : currentAvatarUrl || FALLBACK_AVATAR;

  const previewName =
    mode === 'url'
      ? customUrl.trim()
        ? 'Custom image'
        : 'Paste an image URL'
      : selectedMeta?.alt || (selected ? 'Selected avatar' : 'No avatar selected');

  const previewDesc =
    mode === 'url'
      ? 'Any direct image URL — JPEG, PNG, GIF or WEBP.'
      : selectedMeta?.category
      ? selectedMeta.category
      : 'Click a tile below or paste your own URL.';

  const canSave =
    !saving &&
    (mode === 'url'
      ? customUrl.trim().length > 0
      : !!selected && selected !== currentAvatarUrl);

  const handleSave = async () => {
    if (!canSave) return;
    const finalUrl =
      mode === 'url'
        ? customUrl.trim()
        : selected
        ? resolveUrl(selected)
        : '';
    if (!finalUrl) return;
    setSaving(true);
    try {
      await userApi.updateProfile({ avatar_url: finalUrl });
      toast.success('Avatar updated');
      onSaved(finalUrl);
      handleClose();
    } catch (err: any) {
      toast.error(err?.message || 'Failed to update avatar');
    } finally {
      setSaving(false);
    }
  };

  const handleClose = () => {
    setVisible(false);
    setTimeout(() => onClose(), 200);
  };

  const handleRemove = async () => {
    setSaving(true);
    try {
      const fallback = 'https://api.dicebear.com/7.x/bottts/svg?seed=user';
      await userApi.updateProfile({ avatar_url: fallback });
      toast.success('Avatar reset');
      onSaved(fallback);
      handleClose();
    } catch (err: any) {
      toast.error(err?.message || 'Failed to remove avatar');
    } finally {
      setSaving(false);
    }
  };

  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Avatar picker"
      onClick={handleClose}
      className="fixed inset-0 z-[220] flex items-start sm:items-center justify-center p-2 sm:p-6 overflow-y-auto"
      style={{
        backgroundColor: visible ? 'rgba(0,0,0,0.8)' : 'rgba(0,0,0,0)',
        backdropFilter: visible ? 'blur(8px)' : 'blur(0px)',
        transition: 'background-color 200ms ease, backdrop-filter 200ms ease',
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-2xl bg-[#0b0d16] border border-[#2e3252] rounded-2xl shadow-2xl shadow-black/80 my-4 sm:my-6 overflow-hidden"
        style={{
          transform: visible
            ? 'translateY(0) scale(1)'
            : 'translateY(12px) scale(0.96)',
          opacity: visible ? 1 : 0,
          transition:
            'transform 220ms cubic-bezier(0.22, 1, 0.36, 1), opacity 180ms ease',
        }}
      >
        {/* Header */}
        <div className="px-5 sm:px-6 pt-4 pb-3 border-b border-[#23263f] flex items-start justify-between gap-3">
          <div>
            <h2 className="text-base font-semibold text-white tracking-tight">
              Avatar
            </h2>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Pick a picture for your profile.
            </p>
          </div>
          <button
            type="button"
            onClick={handleClose}
            aria-label="Close"
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#1c2038] transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Toolbar: preview + mode toggle + search */}
        <div className="px-5 sm:px-6 py-3 border-b border-[#23263f] bg-[#0d1019] space-y-3">
          <div className="flex items-center gap-3">
            <img
              src={previewSrc}
              alt="Preview"
              className="w-12 h-12 rounded-full object-cover border-2 border-indigo-500/50 bg-[#06070d] shrink-0"
              onError={(e) => {
                (e.target as HTMLImageElement).src = FALLBACK_AVATAR;
              }}
            />
            <div className="min-w-0 flex-1">
              <p className="text-xs font-medium text-white truncate">
                {previewName}
              </p>
              <p className="text-[10px] text-slate-500 truncate">
                {previewDesc}
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-2">
            <div className="flex gap-1 p-1 rounded-lg bg-[#06070d] border border-[#23263f] shrink-0">
              <button
                type="button"
                onClick={() => setMode('gallery')}
                className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors cursor-pointer ${
                  mode === 'gallery'
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Gallery
              </button>
              <button
                type="button"
                onClick={() => setMode('url')}
                className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors cursor-pointer ${
                  mode === 'url'
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Custom URL
              </button>
            </div>

            {mode === 'gallery' && (
              <div className="relative flex-1">
                <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search avatars..."
                  className="w-full bg-[#06070d] border border-[#23263f] rounded-lg pl-8 pr-2.5 py-1.5 text-[11px] text-white placeholder:text-slate-600 focus:outline-none focus:border-indigo-500/60"
                />
              </div>
            )}
          </div>
        </div>

        {/* Body */}
        {mode === 'url' ? (
          <div className="p-5 sm:p-6 space-y-3">
            <label className="block text-[11px] font-medium text-slate-400">
              Image URL
            </label>
            <div className="relative">
              <LinkIcon className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="url"
                value={customUrl}
                onChange={(e) => setCustomUrl(e.target.value)}
                placeholder="https://example.com/avatar.jpg"
                autoFocus
                className="w-full bg-[#06070d] border border-[#23263f] rounded-lg pl-8 pr-2.5 py-2 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:border-indigo-500/60"
              />
            </div>
            <p className="text-[10px] text-slate-600">
              Any direct image URL — JPEG, PNG, GIF or WEBP.
            </p>
            {customUrl.trim() && (
              <div className="flex items-center gap-2.5 p-2.5 rounded-lg bg-[#06070d] border border-[#23263f]">
                <img
                  src={customUrl}
                  alt="Custom preview"
                  className="w-10 h-10 rounded-full object-cover border border-[#2e3252] bg-[#14172b]"
                  onError={(e) => {
                    (e.target as HTMLImageElement).style.opacity = '0.3';
                  }}
                  onLoad={(e) => {
                    (e.target as HTMLImageElement).style.opacity = '1';
                  }}
                />
                <p className="text-[10px] text-slate-400 truncate flex-1">
                  {customUrl}
                </p>
              </div>
            )}
          </div>
        ) : loading ? (
          <div className="h-64 flex items-center justify-center">
            <Loader2 className="w-5 h-5 animate-spin text-indigo-400" />
          </div>
        ) : categories.length === 0 ? (
          <div className="h-64 flex flex-col items-center justify-center gap-2 text-xs text-slate-500 px-6 text-center">
            <p>Could not load avatars.</p>
            <button
              type="button"
              onClick={() => {
                setCategories([]);
                setLoading(true);
                fetchAvatarCatalog()
                  .then((cats) => setCategories(cats))
                  .catch(() => toast.error('Still failing — check your network'))
                  .finally(() => setLoading(false));
              }}
              className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-semibold cursor-pointer transition-colors"
            >
              Retry
            </button>
            <p className="text-[10px] text-slate-600">
              Or switch to &quot;Custom URL&quot;.
            </p>
          </div>
        ) : filteredCategories.length === 0 ? (
          <div className="h-64 flex items-center justify-center text-xs text-slate-500">
            No avatars match &quot;{search}&quot;.
          </div>
        ) : (
          // Scrollable body — all categories stacked vertically
          <div className="max-h-[55vh] sm:max-h-[440px] overflow-y-auto thin-scrollbar">
            {filteredCategories.map((cat) => (
              <div
                key={cat.label}
                className="border-b border-[#23263f] last:border-b-0"
              >
                {/* Category header */}
                <div className="px-5 sm:px-6 pt-3.5 pb-2 flex flex-wrap items-baseline gap-x-2.5 gap-y-0.5">
                  <span className="text-xs font-semibold text-white">
                    {cat.label}
                  </span>
                  <span className="text-[10px] text-slate-500">
                    {cat.avatars.length} avatars
                  </span>
                </div>

                {/* Grid */}
                <div className="px-5 sm:px-6 pb-4">
                  <div className="grid grid-cols-5 sm:grid-cols-7 md:grid-cols-8 gap-2">
                    {cat.avatars.map((a) => {
                      const url = resolveUrl(a.src);
                      const isSelected =
                        selected === a.src || selected === url;
                      return (
                        <button
                          key={a.src}
                          type="button"
                          onClick={() => setSelected(a.src)}
                          title={a.alt}
                          aria-pressed={isSelected}
                          className={`relative aspect-square rounded-full overflow-hidden border-2 transition-all hover:scale-105 cursor-pointer group ${
                            isSelected
                              ? 'border-indigo-500 ring-2 ring-indigo-500/40'
                              : 'border-[#23263f] hover:border-[#3a3f66]'
                          }`}
                        >
                          <img
                            src={url}
                            alt={a.alt}
                            className="w-full h-full object-cover"
                            loading="lazy"
                            referrerPolicy="no-referrer"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src =
                                FALLBACK_AVATAR;
                            }}
                          />
                          {isSelected ? (
                            <span className="absolute inset-0 bg-indigo-600/30 flex items-center justify-center">
                              <Check className="w-4 h-4 text-white drop-shadow" />
                            </span>
                          ) : (
                            <span className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Footer */}
        <div className="px-5 sm:px-6 py-3 border-t border-[#23263f] flex items-center gap-2 bg-[#0d1019]">
          <button
            type="button"
            onClick={handleRemove}
            disabled={saving}
            className="px-3 py-1.5 rounded-lg bg-transparent hover:bg-rose-500/10 border border-[#23263f] hover:border-rose-500/40 text-rose-400 hover:text-rose-300 text-[11px] font-medium disabled:opacity-50 cursor-pointer transition-colors"
          >
            Remove avatar
          </button>

          <div className="flex-1" />

          <button
            type="button"
            onClick={onClose}
            disabled={saving}
            className="px-3 py-1.5 rounded-lg bg-[#14172b] hover:bg-[#1c2038] border border-[#23263f] text-slate-300 text-[11px] font-medium disabled:opacity-50 cursor-pointer transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={!canSave}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-semibold disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer transition-colors"
          >
            {saving ? (
              <Loader2 className="w-3 h-3 animate-spin" />
            ) : (
              <Check className="w-3 h-3" />
            )}
            <span>{saving ? 'Saving…' : 'Save'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}