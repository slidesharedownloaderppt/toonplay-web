import { useEffect, useMemo, useRef, useState } from 'react';
import {
  X,
  Loader2,
  Check,
  Search,
  Link as LinkIcon,
} from 'lucide-react';
import {
  ANIMERULZ_CDN_BASE,
  fetchAvatarCatalog,
  type AvatarCatalogCategory,
} from '../../api';
import { userApi } from '../../lib/api';
import { AvatarWithFrame } from './AvatarWithFrame';
import { toast } from 'sonner';

const FALLBACK_AVATAR = 'https://api.dicebear.com/7.x/bottts/svg?seed=fallback';

interface Props {
  open: boolean;
  currentAvatarUrl: string | null;
  currentFrameUrl?: string | null;
  username?: string;
  onClose: () => void;
  onSaved: (newUrl: string) => void;
}

type Mode = 'gallery' | 'url';

export function AvatarPickerModal({
  open,
  currentAvatarUrl,
  currentFrameUrl,
  username,
  onClose,
  onSaved,
}: Props) {
  const [mode, setMode] = useState<Mode>('gallery');
  const [categories, setCategories] = useState<AvatarCatalogCategory[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<string | null>(currentAvatarUrl);
  const [customUrl, setCustomUrl] = useState('');
  const [visible, setVisible] = useState(false);
  const closeTimerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (closeTimerRef.current !== null) window.clearTimeout(closeTimerRef.current);
    };
  }, []);

  useEffect(() => {
    if (!open) {
      setVisible(false);
      return;
    }
    if (closeTimerRef.current !== null) {
      window.clearTimeout(closeTimerRef.current);
      closeTimerRef.current = null;
    }
    setSelected(currentAvatarUrl);
    setCustomUrl('');
    setSearch('');
    setActiveCategory('All');
    setMode('gallery');
    const raf = requestAnimationFrame(() => setVisible(true));
    return () => cancelAnimationFrame(raf);
  }, [open, currentAvatarUrl]);

  // Fetch merged avatar catalog (built-in icons.json + external avatars.json)
  useEffect(() => {
    if (!open) return;
    if (categories.length > 0) return;
    let cancelled = false;
    setLoading(true);
    fetchAvatarCatalog()
      .then((cats) => {
        if (!cancelled) setCategories(cats);
      })
      .catch((err) => {
        if (cancelled) return;
        console.error('[avatar catalog]', err);
        toast.error('Could not load avatars — check your connection');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [open, categories.length]);

  // Body scroll lock + Escape
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') handleClose();
    };
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener('keydown', onKey);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const resolveUrl = (src: string): string => {
    if (/^https?:\/\//i.test(src)) return src;
    return `${ANIMERULZ_CDN_BASE}${src.startsWith('/') ? '' : '/'}${src}`;
  };

  const totalAvatarsCount = useMemo(() => {
    const unique = new Set<string>();
    for (const cat of categories) {
      for (const a of cat.avatars) unique.add(a.src);
    }
    return unique.size;
  }, [categories]);

  // Filter categories by active category tag + search query
  const filteredCategories = useMemo(() => {
    const q = search.trim().toLowerCase();
    const scoped =
      activeCategory === 'All'
        ? categories
        : categories.filter((cat) => cat.label === activeCategory);

    if (!q) return scoped;
    return scoped
      .map((cat) => {
        const catMatches = cat.label.toLowerCase().includes(q);
        return {
          ...cat,
          avatars: catMatches
            ? cat.avatars
            : cat.avatars.filter(
                (a) =>
                  a.alt.toLowerCase().includes(q) ||
                  (a.tags || []).some((t) => t.toLowerCase().includes(q))
              ),
        };
      })
      .filter((cat) => cat.avatars.length > 0);
  }, [categories, activeCategory, search]);

  const selectedMeta = useMemo(() => {
    for (const cat of categories) {
      for (const a of cat.avatars) {
        const url = resolveUrl(a.src);
        if (a.src === selected || url === selected) {
          return { ...a, category: cat.label };
        }
      }
    }
    return null;
  }, [categories, selected]);

  const previewSrc =
    mode === 'url'
      ? customUrl.trim() || currentAvatarUrl || FALLBACK_AVATAR
      : selected
      ? resolveUrl(selected)
      : currentAvatarUrl || FALLBACK_AVATAR;

  const previewName =
    mode === 'url'
      ? customUrl.trim()
        ? 'Custom image'
        : 'Paste an image URL'
      : selectedMeta?.alt || (selected ? 'Selected avatar' : 'No avatar selected');

  const previewDesc =
    mode === 'url'
      ? 'Any direct image URL — JPEG, PNG, GIF or WEBP.'
      : selectedMeta?.category
      ? selectedMeta.category
      : 'Pick a tile below or paste your own URL.';

  const canSave =
    !saving &&
    (mode === 'url'
      ? customUrl.trim().length > 0
      : !!selected && resolveUrl(selected) !== currentAvatarUrl);

  const handleSave = async () => {
    if (!canSave) return;
    const finalUrl =
      mode === 'url'
        ? customUrl.trim()
        : selected
        ? resolveUrl(selected)
        : '';
    if (!finalUrl) return;
    setSaving(true);
    try {
      await userApi.updateProfile({ avatar_url: finalUrl });
      toast.success('Avatar updated');
      onSaved(finalUrl);
      handleClose();
    } catch (err: any) {
      toast.error(err?.message || 'Failed to update avatar');
    } finally {
      setSaving(false);
    }
  };

  const handleClose = () => {
    if (saving) return;
    setVisible(false);
    if (closeTimerRef.current !== null) window.clearTimeout(closeTimerRef.current);
    closeTimerRef.current = window.setTimeout(() => {
      closeTimerRef.current = null;
      onClose();
    }, 200);
  };

  const handleRemove = async () => {
    if (saving) return;
    setSaving(true);
    try {
      const fallback = `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(
        username || 'user'
      )}`;
      await userApi.updateProfile({ avatar_url: fallback });
      toast.success('Avatar reset');
      onSaved(fallback);
      handleClose();
    } catch (err: any) {
      toast.error(err?.message || 'Failed to remove avatar');
    } finally {
      setSaving(false);
    }
  };

  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Avatar picker"
      onClick={handleClose}
      className="fixed inset-0 z-[220] flex items-start sm:items-center justify-center p-2 sm:p-6 overflow-y-auto bg-black/80 backdrop-blur-sm transition-opacity duration-200 ease-out"
      style={{ opacity: visible ? 1 : 0 }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-2xl bg-[#0b0d16] border border-[#2e3252] rounded-2xl shadow-2xl shadow-black/80 my-4 sm:my-6 overflow-hidden"
        style={{
          transform: visible
            ? 'translateY(0) scale(1)'
            : 'translateY(12px) scale(0.96)',
          opacity: visible ? 1 : 0,
          transition:
            'transform 220ms cubic-bezier(0.22, 1, 0.36, 1), opacity 180ms ease',
        }}
      >
        {/* Header */}
        <div className="px-4 sm:px-6 pt-4 pb-3 border-b border-[#23263f] flex items-start justify-between gap-3">
          <div>
            <h2 className="text-base font-semibold text-white tracking-tight">
              Avatar
            </h2>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Pick a picture for your profile
              {totalAvatarsCount > 0 ? ` · ${totalAvatarsCount} available` : ''}.
            </p>
          </div>
          <button
            type="button"
            onClick={handleClose}
            aria-label="Close"
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#1c2038] transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Toolbar: preview + mode toggle + search + category tags */}
        <div className="px-4 sm:px-6 py-3 border-b border-[#23263f] bg-[#0d1019] space-y-3">
          <div className="flex items-center gap-3.5">
            <AvatarWithFrame
              avatarUrl={previewSrc}
              frameUrl={currentFrameUrl}
              username={username}
              alt="Preview"
              className="w-12 h-12"
              avatarClassName="border-2 border-indigo-500/50"
              loading="eager"
            />
            <div className="min-w-0 flex-1">
              <p className="text-xs font-medium text-white truncate">
                {previewName}
              </p>
              <p className="text-[10px] text-slate-500 truncate">
                {previewDesc}
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-2">
            <div className="flex gap-1 p-1 rounded-lg bg-[#06070d] border border-[#23263f] shrink-0">
              <button
                type="button"
                onClick={() => setMode('gallery')}
                className={`flex-1 sm:flex-initial px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors cursor-pointer ${
                  mode === 'gallery'
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Gallery
              </button>
              <button
                type="button"
                onClick={() => setMode('url')}
                className={`flex-1 sm:flex-initial px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors cursor-pointer ${
                  mode === 'url'
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Custom URL
              </button>
            </div>

            {mode === 'gallery' && (
              <div className="relative flex-1">
                <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search avatars or anime tags..."
                  className="w-full bg-[#06070d] border border-[#23263f] rounded-lg pl-8 pr-2.5 py-1.5 text-[11px] text-white placeholder:text-slate-600 focus:outline-none focus:border-indigo-500/60"
                />
              </div>
            )}
          </div>

          {/* Tag / category filter bar */}
          {mode === 'gallery' && categories.length > 0 && (
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 thin-scrollbar">
              <button
                type="button"
                onClick={() => setActiveCategory('All')}
                className={`shrink-0 px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors cursor-pointer border ${
                  activeCategory === 'All'
                    ? 'bg-indigo-600 text-white border-indigo-500'
                    : 'bg-[#06070d] text-slate-400 hover:text-white border-[#23263f]'
                }`}
              >
                All ({totalAvatarsCount})
              </button>
              {categories.map((cat) => (
                <button
                  key={cat.label}
                  type="button"
                  onClick={() => setActiveCategory(cat.label)}
                  className={`shrink-0 px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors cursor-pointer border ${
                    activeCategory === cat.label
                      ? 'bg-indigo-600 text-white border-indigo-500'
                      : 'bg-[#06070d] text-slate-400 hover:text-white border-[#23263f]'
                  }`}
                >
                  {cat.label}{' '}
                  <span className="opacity-65">({cat.avatars.length})</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Body */}
        {mode === 'url' ? (
          <div className="p-4 sm:p-6 space-y-3">
            <label className="block text-[11px] font-medium text-slate-400">
              Image URL
            </label>
            <div className="relative">
              <LinkIcon className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="url"
                value={customUrl}
                onChange={(e) => setCustomUrl(e.target.value)}
                placeholder="https://example.com/avatar.jpg"
                autoFocus
                className="w-full bg-[#06070d] border border-[#23263f] rounded-lg pl-8 pr-2.5 py-2 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:border-indigo-500/60"
              />
            </div>
            <p className="text-[10px] text-slate-600">
              Any direct image URL — JPEG, PNG, GIF or WEBP.
            </p>
            {customUrl.trim() && (
              <div className="flex items-center gap-3 p-2.5 rounded-lg bg-[#06070d] border border-[#23263f]">
                <AvatarWithFrame
                  avatarUrl={customUrl.trim()}
                  frameUrl={currentFrameUrl}
                  username={username}
                  alt="Custom preview"
                  className="w-10 h-10"
                  loading="eager"
                />
                <p className="text-[10px] text-slate-400 truncate flex-1">
                  {customUrl}
                </p>
              </div>
            )}
          </div>
        ) : loading ? (
          <div className="h-64 flex items-center justify-center">
            <Loader2 className="w-5 h-5 animate-spin text-indigo-400" />
          </div>
        ) : categories.length === 0 ? (
          <div className="h-64 flex flex-col items-center justify-center gap-2 text-xs text-slate-500 px-6 text-center">
            <p>Could not load avatars.</p>
            <button
              type="button"
              onClick={() => {
                setCategories([]);
                setLoading(true);
                fetchAvatarCatalog()
                  .then((cats) => setCategories(cats))
                  .catch(() => toast.error('Still failing — check your network'))
                  .finally(() => setLoading(false));
              }}
              className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-semibold cursor-pointer transition-colors"
            >
              Retry
            </button>
            <p className="text-[10px] text-slate-600">
              Or switch to &quot;Custom URL&quot;.
            </p>
          </div>
        ) : filteredCategories.length === 0 ? (
          <div className="h-64 flex items-center justify-center text-xs text-slate-500 px-4 text-center">
            No avatars match &quot;{search}&quot;.
          </div>
        ) : (
          <div className="max-h-[52vh] sm:max-h-[420px] overflow-y-auto thin-scrollbar">
            {filteredCategories.map((cat) => (
              <div
                key={cat.label}
                className="border-b border-[#23263f] last:border-b-0"
              >
                <div className="px-4 sm:px-6 pt-3.5 pb-2 flex flex-wrap items-baseline gap-x-2.5 gap-y-0.5">
                  <span className="text-xs font-semibold text-white">
                    {cat.label}
                  </span>
                  <span className="text-[10px] text-slate-500">
                    {cat.avatars.length} avatars
                  </span>
                </div>

                <div className="px-4 sm:px-6 pb-4">
                  <div className="grid grid-cols-4 xs:grid-cols-5 sm:grid-cols-7 md:grid-cols-8 gap-2">
                    {cat.avatars.map((a) => {
                      const url = resolveUrl(a.src);
                      const isSelected =
                        selected === a.src || selected === url;
                      return (
                        <button
                          key={`${cat.label}:${a.src}`}
                          type="button"
                          onClick={() => setSelected(url)}
                          title={a.alt}
                          aria-pressed={isSelected}
                          className={`relative aspect-square rounded-full overflow-hidden border-2 transition-[transform,border-color] hover:scale-105 cursor-pointer group ${
                            isSelected
                              ? 'border-indigo-500 ring-2 ring-indigo-500/40'
                              : 'border-[#23263f] hover:border-[#3a3f66]'
                          }`}
                        >
                          <img
                            src={url}
                            alt={a.alt}
                            className="w-full h-full object-cover"
                            loading="lazy"
                            decoding="async"
                            referrerPolicy="no-referrer"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src =
                                FALLBACK_AVATAR;
                            }}
                          />
                          {isSelected ? (
                            <span className="absolute inset-0 bg-indigo-600/30 flex items-center justify-center">
                              <Check className="w-4 h-4 text-white drop-shadow" />
                            </span>
                          ) : (
                            <span className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Footer */}
        <div className="px-4 sm:px-6 py-3 border-t border-[#23263f] flex flex-wrap items-center gap-2 bg-[#0d1019]">
          <button
            type="button"
            onClick={handleRemove}
            disabled={saving}
            className="px-3 py-1.5 rounded-lg bg-transparent hover:bg-rose-500/10 border border-[#23263f] hover:border-rose-500/40 text-rose-400 hover:text-rose-300 text-[11px] font-medium disabled:opacity-50 cursor-pointer transition-colors"
          >
            Reset avatar
          </button>

          <div className="flex-1" />

          <button
            type="button"
            onClick={handleClose}
            disabled={saving}
            className="px-3 py-1.5 rounded-lg bg-[#14172b] hover:bg-[#1c2038] border border-[#23263f] text-slate-300 text-[11px] font-medium disabled:opacity-50 cursor-pointer transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={!canSave}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-semibold disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer transition-colors"
          >
            {saving ? (
              <Loader2 className="w-3 h-3 animate-spin" />
            ) : (
              <Check className="w-3 h-3" />
            )}
            <span>{saving ? 'Saving…' : 'Save'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}