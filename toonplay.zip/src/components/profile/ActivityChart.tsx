import { useEffect, useState } from 'react';
import { statsApi, userApi } from '../../lib/api';
import { formatDayShort } from '../../lib/time';

interface Props {
  initialRange?: 30 | 90 | 365;
  readOnly?: boolean;
  /** If provided, fetches PUBLIC activity for that user (works for /u/:username).
   *  If omitted, fetches the logged-in user's activity (works for /profile only). */
  username?: string;
}

type Range = 30 | 90 | 365;

const RANGE_LABEL: Record<Range, string> = {
  30: '30 days',
  90: '90 days',
  365: '1 year',
};

export function ActivityChart({ initialRange = 30, readOnly, username }: Props) {
  const [range, setRange] = useState<Range>(initialRange);
  const [activities, setActivities] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);

    const fetchPromise = username
      ? userApi.activity(username, range)
      : statsApi.dailyActivity(range);

    fetchPromise
      .then((res: any) => {
        if (!cancelled) setActivities(res.activities || []);
      })
      .catch(() => {
        if (!cancelled) setActivities([]);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [range, username]);

  const maxEpisodes = Math.max(1, ...activities.map((a) => Number(a.episodes_watched || 0)));
  const totalEpisodes = activities.reduce((s, a) => s + Number(a.episodes_watched || 0), 0);
  const activeDays = activities.filter((a) => Number(a.episodes_watched || 0) > 0).length;
  const peakDay = activities.reduce(
    (best, a) => (Number(a.episodes_watched || 0) > Number(best?.episodes_watched || 0) ? a : best),
    activities[0]
  );

  // Y-axis tick labels — episodes
  const yTicks = (() => {
    const max = maxEpisodes;
    if (max <= 1) return [0, 1];
    const step = Math.max(1, Math.ceil(max / 3));
    const ticks: number[] = [];
    for (let v = 0; v <= max; v += step) ticks.push(v);
    if (ticks[ticks.length - 1] < max) ticks.push(max);
    return ticks;
  })();

  return (
    <div className="bg-[#14172b] border border-[#2e3252] rounded-2xl p-5">
      {/* Header row */}
      <div className="flex items-start justify-between mb-4 gap-3 flex-wrap">
        <div>
          <h3 className="text-sm font-semibold text-white">Episodes</h3>
          <p className="text-[11px] text-slate-500 mt-0.5">
            Per day, active on {activeDays} of {range} days
          </p>
        </div>
        {!readOnly && (
          <div className="flex gap-1 bg-[#0b0c16] border border-[#2e3252] rounded-lg p-0.5">
            {([30, 90, 365] as Range[]).map((r) => (
              <button
                key={r}
                onClick={() => setRange(r)}
                className={`px-2.5 py-1 text-[11px] rounded-md transition cursor-pointer ${
                  range === r
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {RANGE_LABEL[r]}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Body */}
      {loading ? (
        <div className="h-40 flex items-center justify-center text-xs text-slate-500">
          Loading…
        </div>
      ) : activities.length === 0 ? (
        <div className="h-40 flex items-center justify-center text-xs text-slate-500">
          No activity yet.
        </div>
      ) : (
        <div className="flex gap-3">
          {/* Y axis */}
          <div className="relative h-40 flex flex-col justify-between text-[9px] font-mono text-slate-500 tabular-nums shrink-0 w-6 text-right">
            {yTicks
              .slice()
              .reverse()
              .map((v) => (
                <span key={v}>{v}</span>
              ))}
          </div>

          {/* Plot area */}
          <div className="relative flex-1 h-40">
            {/* Grid lines */}
            <div className="absolute inset-0 flex flex-col justify-between pointer-events-none">
              {yTicks.map((v) => (
                <div
                  key={v}
                  className="border-t border-dashed border-[#1f2240] w-full"
                />
              ))}
            </div>

            {/* Bars */}
            <div className="absolute inset-0 flex items-end gap-[2px]">
              {activities.map((a, i) => {
                const eps = Number(a.episodes_watched || 0);
                const heightPct = eps === 0 ? 2 : 4 + (eps / maxEpisodes) * 96;
                const isActive = eps > 0;
                const isPeak =
                  peakDay &&
                  a.activity_date === peakDay.activity_date &&
                  eps === Number(peakDay.episodes_watched || 0) &&
                  eps > 0;
                return (
                  <div
                    key={i}
                    className="flex-1 min-w-[3px] max-w-[20px] group relative flex flex-col justify-end"
                    style={{ height: '100%' }}
                  >
                    {/* Peak label */}
                    {isPeak && (
                      <span
                        className="absolute left-1/2 -translate-x-1/2 -top-1 text-[9px] font-mono text-indigo-300 whitespace-nowrap"
                        style={{ bottom: `${heightPct}%`, top: 'auto' }}
                      >
                        {eps} ep
                      </span>
                    )}

                    {/* Bar */}
                    <div
                      className={`w-full rounded-t transition ${
                        isActive
                          ? 'bg-indigo-500 hover:bg-indigo-400'
                          : 'bg-[#1c2038]'
                      }`}
                      style={{ height: `${heightPct}%` }}
                    />

                    {/* Hover tooltip */}
                    <div className="hidden group-hover:block absolute bottom-full mb-1 left-1/2 -translate-x-1/2 px-2 py-1 bg-black text-white text-[10px] whitespace-nowrap rounded shadow-lg z-20 pointer-events-none">
                      {formatDayShort(a.activity_date)} · {eps} ep
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* X axis labels — every 5th day */}
      {!loading && activities.length > 0 && (
        <div className="flex gap-3 mt-2">
          <div className="w-6 shrink-0" />
          <div className="flex-1 relative h-3">
            {activities.map((a, i) => {
              if (i % 5 !== 0 && i !== activities.length - 1) return null;
              const leftPct = (i / Math.max(1, activities.length - 1)) * 100;
              return (
                <span
                  key={i}
                  className="absolute text-[9px] font-mono text-slate-500 whitespace-nowrap -translate-x-1/2"
                  style={{ left: `${leftPct}%` }}
                >
                  {formatDayShort(a.activity_date)}
                </span>
              );
            })}
          </div>
        </div>
      )}

      {/* Footer summary */}
      {!loading && activities.length > 0 && (
        <p className="text-[10px] text-slate-500 mt-3">
          {totalEpisodes} episode{totalEpisodes === 1 ? '' : 's'} across {activeDays} active day
          {activeDays === 1 ? '' : 's'}
        </p>
      )}
    </div>
  );
}