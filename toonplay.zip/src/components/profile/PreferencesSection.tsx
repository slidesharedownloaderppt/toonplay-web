import { useEffect, useState } from 'react';
import { userApi } from '../../lib/api';
import { toast } from 'sonner';

interface Props {
  user: any;
  onUserChange?: (u: any) => void;
}

function ToggleRow({
  label,
  description,
  checked,
  onChange,
  disabled,
}: {
  label: string;
  description: string;
  checked: boolean;
  onChange: (v: boolean) => void;
  disabled?: boolean;
}) {
  return (
    <label className="flex items-start justify-between gap-3 py-3 cursor-pointer">
      <div className="min-w-0">
        <p className="text-xs text-white">{label}</p>
        <p className="text-[11px] text-slate-500 mt-0.5">{description}</p>
      </div>
      <button
        type="button"
        disabled={disabled}
        onClick={() => onChange(!checked)}
        className={`relative w-10 h-5 rounded-full transition shrink-0 cursor-pointer ${
          checked ? 'bg-indigo-600' : 'bg-[#2e3252]'
        } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
      >
        <span
          className={`absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full transition-transform ${
            checked ? 'translate-x-5' : ''
          }`}
        />
      </button>
    </label>
  );
}

export function PreferencesSection({ user, onUserChange }: Props) {
  const [prefs, setPrefs] = useState({
    auto_play: Boolean(user?.auto_play),
    auto_next: Boolean(user?.auto_next),
    auto_skip: Boolean(user?.auto_skip),
    show_watchlist: Boolean(user?.show_watchlist),
    show_history: Boolean(user?.show_history),
    show_stats: Boolean(user?.show_stats),
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setPrefs({
      auto_play: Boolean(user?.auto_play),
      auto_next: Boolean(user?.auto_next),
      auto_skip: Boolean(user?.auto_skip),
      show_watchlist: Boolean(user?.show_watchlist),
      show_history: Boolean(user?.show_history),
      show_stats: Boolean(user?.show_stats),
    });
  }, [user]);

  const save = async (patch: Partial<typeof prefs>) => {
    const previous = prefs;
    const next = { ...prefs, ...patch };
    setPrefs(next);
    setSaving(true);
    try {
      const res = await userApi.updatePreferences(next);
      toast.success('Preferences saved');
      if (onUserChange) onUserChange(res.user);
    } catch (err: any) {
      toast.error(err?.message || 'Failed to save');
      setPrefs(previous);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-white tracking-tight">Preferences</h2>
      </div>

      {/* Player */}
      <div className="bg-[#14172b] border border-[#23263f] rounded-2xl p-5">
        <h3 className="text-[11px] uppercase tracking-wider text-slate-500 font-semibold mb-2">
          Player
        </h3>
        <div className="divide-y divide-[#23263f]">
          <ToggleRow
            label="Auto play"
            description="Start playing the selected episode automatically"
            checked={prefs.auto_play}
            disabled={saving}
            onChange={(v) => save({ auto_play: v })}
          />
          <ToggleRow
            label="Auto next"
            description="Go to the next episode when the current one ends"
            checked={prefs.auto_next}
            disabled={saving}
            onChange={(v) => save({ auto_next: v })}
          />
          <ToggleRow
            label="Auto skip"
            description="Skip intros and outros automatically"
            checked={prefs.auto_skip}
            disabled={saving}
            onChange={(v) => save({ auto_skip: v })}
          />
        </div>
      </div>

      {/* Privacy */}
      <div className="bg-[#14172b] border border-[#23263f] rounded-2xl p-5">
        <h3 className="text-[11px] uppercase tracking-wider text-slate-500 font-semibold mb-2">
          Privacy
        </h3>
        <div className="divide-y divide-[#23263f]">
          <ToggleRow
            label="Show stats"
            description="Let others see your XP, level and watch totals"
            checked={prefs.show_stats}
            disabled={saving}
            onChange={(v) => save({ show_stats: v })}
          />
          <ToggleRow
            label="Show watchlist"
            description="Let others see your watchlist preview"
            checked={prefs.show_watchlist}
            disabled={saving}
            onChange={(v) => save({ show_watchlist: v })}
          />
          <ToggleRow
            label="Show history"
            description="Let others see your recent watch history"
            checked={prefs.show_history}
            disabled={saving}
            onChange={(v) => save({ show_history: v })}
          />
        </div>
      </div>
    </div>
  );
}