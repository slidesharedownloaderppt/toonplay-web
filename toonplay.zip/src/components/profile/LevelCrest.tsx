import React from 'react';
import { getXpTier } from '../../lib/xpTiers';

interface Props {
  level: number;
  /** Rendered height in pixels. Width auto-scales. Default 44. */
  size?: number;
  /** Optional className override */
  className?: string;
  /** If true, show "LV" label + level number inside the crest. Default true. */
  showLabel?: boolean;
}

/**
 * Hexagonal level crest — the polygon badge shown on the avatar.
 * Colors + glow are driven by the user's tier from `xpTiers.ts`.
 */
export const LevelCrest: React.FC<Props> = ({
  level,
  size = 44,
  className = '',
  showLabel = true,
}) => {
  const tier = getXpTier(level);
  const gradientId = `crest-bg-${tier.name.toLowerCase()}-${Math.abs(level)}`;
  const width = Math.round(size * (36 / 42)); // keep 36:42 aspect

  return (
    <div
      className={`relative flex items-center justify-center ${className}`}
      style={{ filter: `drop-shadow(0 0 6px ${tier.glow})` }}
      title={`Level ${level} (${tier.name})`}
    >
      <svg
        viewBox="0 0 36 42"
        className="drop-shadow-[0_4px_12px_rgba(0,0,0,0.9)]"
        style={{ height: size, width }}
        aria-hidden="true"
      >
        <defs>
          <linearGradient x1="0%" y1="0%" x2="0%" y2="100%" id={gradientId}>
            <stop offset="0%" stopColor={tier.crestGradient[0]} />
            <stop offset="50%" stopColor={tier.crestGradient[1]} />
            <stop offset="100%" stopColor={tier.crestGradient[2]} />
          </linearGradient>
        </defs>

        {/* Outer polygon with tier-colored stroke */}
        <polygon
          points="18,1.5 34.5,11 34.5,31 18,40.5 1.5,31 1.5,11"
          strokeWidth="1.5"
          strokeLinejoin="round"
          fill={`url(#${gradientId})`}
          stroke={tier.color}
        />

        {/* Inner accent polygon */}
        <polygon
          points="18,4 32,12 32,30 18,38 4,30 4,12"
          fill="none"
          stroke="rgba(255,255,255,0.18)"
          strokeWidth="0.75"
          strokeLinejoin="round"
        />
      </svg>

      {showLabel && (
        <div className="absolute inset-0 flex flex-col items-center justify-center pt-0.5 pointer-events-none select-none">
          <span
            className="text-[7px] font-black uppercase tracking-widest leading-none drop-shadow-[0_0_8px_currentColor]"
            style={{ color: tier.color }}
          >
            LV
          </span>
          <span
            className="text-[11px] font-black tabular-nums text-white leading-tight drop-shadow-md"
            style={{ fontSize: Math.max(9, Math.round(size * 0.25)) }}
          >
            {level}
          </span>
        </div>
      )}
    </div>
  );
};