import React from 'react';
import {
  Shield,
  Swords,
  Medal,
  Gem,
  Diamond,
  Orbit,
  Crown,
  Trophy,
  ShieldCheck,
  Skull,
  Sparkles,
  Bird,
} from 'lucide-react';
import { getXpTier, getTotalXpProgress, formatXp } from '../../lib/xpTiers';

const TIER_ICONS = {
  Bronze: Shield,
  Silver: Swords,
  Gold: Medal,
  Platinum: Gem,
  Diamond: Diamond,
  Mythic: Orbit,
  Legend: Crown,
  Champion: Trophy,
  Hero: ShieldCheck,
  Immortal: Skull,
  Celestial: Sparkles,
  Divine: Bird,
  God: Crown,
} as const;

const CosmicIcon = ({ size = 12 }: { size?: number }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 128 128"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className="shrink-0"
    aria-hidden="true"
  >
    <path
      d="M99.2266 63.9999C99.2266 82.6189 84.133 97.7126 65.514 97.7126C46.895 97.7126 31.8013 82.6189 31.8013 63.9999C31.8013 45.3809 46.895 30.2872 65.514 30.2872C84.133 30.2872 99.2266 45.3809 99.2266 63.9999Z"
      fill="currentColor"
      fillOpacity="0.12"
    />
    <path
      d="M101.227 63.9999C101.227 83.7235 85.2375 99.7126 65.514 99.7126C45.7904 99.7126 29.8013 83.7235 29.8013 63.9999C29.8013 44.2763 45.7904 28.2872 65.514 28.2872C85.2375 28.2872 101.227 44.2763 101.227 63.9999ZM65.514 97.7126C84.133 97.7126 99.2266 82.6189 99.2266 63.9999C99.2266 45.3809 84.133 30.2872 65.514 30.2872C46.895 30.2872 31.8013 45.3809 31.8013 63.9999C31.8013 82.6189 46.895 97.7126 65.514 97.7126Z"
      fill="currentColor"
    />
    <path
      d="M61.514 93.7126C80.133 93.7126 95.2267 78.6189 95.2267 59.9999C95.2267 51.7087 92.2336 44.1165 87.2689 38.245C94.5826 44.4291 99.2267 53.6722 99.2267 63.9999C99.2267 82.6189 84.133 97.7126 65.514 97.7126C55.1862 97.7126 45.9431 93.0686 39.759 85.7549C45.6306 90.7195 53.2227 93.7126 61.514 93.7126Z"
      fill="currentColor"
    />
    <path
      d="M73.8596 81.0698C100.725 65.5589 118.092 45.3424 112.649 35.9149C109.359 30.2174 98.4919 29.7645 84.4772 33.7217C86.3556 34.9365 88.3506 36.5318 89.1133 37.1777C96.2999 35.928 101.518 36.6872 103.303 39.7797C107.265 46.6427 92.8246 62.3981 71.0486 74.9705C49.2725 87.543 28.4074 92.1714 24.4451 85.3085C22.5265 81.9853 24.9228 76.5771 30.3775 70.455C30.001 68.5064 29.7964 65.6603 29.7855 64.4531C17.7893 75.4016 11.8341 85.9787 15.3596 92.085C20.8025 101.512 46.9938 96.5808 73.8596 81.0698Z"
      fill="currentColor"
    />
    <path
      d="M110.649 34.9149C116.092 44.3424 98.7253 64.5589 71.8595 80.0699C49.6098 92.9158 27.8225 98.5055 17.9008 94.6918C26.606 100.292 49.9661 94.8648 73.8595 81.0699C100.725 65.5589 118.092 45.3424 112.649 35.9149C111.714 34.2952 110.166 33.0993 108.108 32.3081C109.191 33.0047 110.047 33.8719 110.649 34.9149Z"
      fill="currentColor"
    />
    <path
      d="M100.953 33.293C98.5026 33.1389 95.7964 33.4214 93.3081 33.8756C93.0364 33.9252 92.776 33.7452 92.7264 33.4736C92.6768 33.2019 92.8568 32.9415 93.1285 32.8919C95.6611 32.4295 98.4548 32.1339 101.015 32.2949C103.564 32.4552 105.955 33.0724 107.608 34.5061C107.817 34.6871 107.839 35.0029 107.659 35.2115C107.478 35.4201 107.162 35.4425 106.953 35.2616C105.544 34.039 103.414 33.4478 100.953 33.293Z"
      fill="currentColor"
    />
    <circle cx="85.562" cy="56.5089" r="1.8125" fill="currentColor" />
    <circle cx="55.5767" cy="40.0573" r="1.8125" fill="currentColor" />
    <circle cx="42.3794" cy="53.8839" r="1.8125" fill="currentColor" />
    <circle cx="50.3169" cy="72.1339" r="2.8125" fill="currentColor" />
    <circle cx="62.9614" cy="53.6964" r="2.8125" fill="currentColor" />
    <circle cx="76.8413" cy="41.8698" r="2.8125" fill="currentColor" />
    <circle cx="72.3056" cy="69.3214" r="2.8125" fill="currentColor" />
  </svg>
);

const formatCompactXp = (xp: number): string => {
  if (xp >= 1_000_000_000) {
    return `${(xp / 1_000_000_000).toFixed(2).replace(/\.?0+$/, '')}B`;
  }

  if (xp >= 1_000_000) {
    return `${(xp / 1_000_000).toFixed(2).replace(/\.?0+$/, '')}M`;
  }

  if (xp >= 1_000) {
    return `${(xp / 1_000).toFixed(2).replace(/\.?0+$/, '')}K`;
  }

  return String(xp);
};

interface Props {
  xp: number;
  level?: number;
  className?: string;
  hideLevelOnMobile?: boolean;
}

export const XpProgressBar: React.FC<Props> = ({
  xp,
  level: levelOverride,
  className = '',
  hideLevelOnMobile = false,
}) => {
  const derived = getTotalXpProgress(xp);

  const effectiveLevel = Math.max(
    1,
    Math.floor(Number(levelOverride ?? derived.level) || 1)
  );

  const tier = getXpTier(effectiveLevel);

  const totalXp = derived.totalXp;

  const currentLevelThreshold = Math.pow(effectiveLevel - 1, 2) * 100;
  const nextThreshold = Math.pow(effectiveLevel, 2) * 100;

  const xpForNextLevel = nextThreshold - currentLevelThreshold;
  const currentLevelXp = Math.max(0, totalXp - currentLevelThreshold);

  const progressPct =
    xpForNextLevel > 0
      ? Math.max(0, Math.min(100, (currentLevelXp / xpForNextLevel) * 100))
      : 100;

  return (
    <div className={`flex flex-col justify-center ${className}`}>
      {/* Top row: "Level N · Tier" left + "total / next XP" right */}
      <div className="mb-1.5 flex items-end justify-between px-0.5 gap-2">
        <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-200 drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)] truncate">
          <span className={hideLevelOnMobile ? 'hidden lg:inline' : 'inline'}>
            Level {effectiveLevel}
            <span className="text-zinc-500 font-normal mx-1">·</span>
          </span>
<span
  className="inline-flex flex-row items-center justify-center gap-1 align-middle leading-none"
  style={{ color: tier.light }}
>
{tier.name === 'Cosmic' ? (
  <CosmicIcon size={12} />
) : (
  React.createElement(TIER_ICONS[tier.name], {
    size: 12,
    strokeWidth: 2.2,
    className: 'shrink-0',
    'aria-hidden': true,
  })
)}
  {tier.name}
</span>
        </span>
        <span className="text-[10px] font-semibold text-zinc-200 drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)] tabular-nums shrink-0">
{formatCompactXp(totalXp)}{' '}
<span className="text-zinc-400">
  / {formatCompactXp(nextThreshold)} XP
</span>
        </span>
      </div>

      {/* Bar */}
      <div className="relative h-1.5 w-full rounded-sm bg-black/80 ring-1 ring-white/15 shadow-md overflow-hidden">
        {/* Shimmer layer */}
        <div
          className="absolute inset-0 rounded-sm pointer-events-none"
          style={{
            background:
              'linear-gradient(90deg, transparent, rgba(255,255,255,0.06), transparent)',
            backgroundSize: '200% 100%',
            animation: 'xp-bar-shimmer 3s linear infinite',
          }}
        />

        {/* Fill */}
        <div
          className="relative h-full rounded-sm transition-[width] duration-1000 ease-out"
          style={{
            width: `${progressPct}%`,
            background: tier.progressGradient,
            boxShadow: `0 0 8px ${tier.glow}`,
          }}
        >
          {/* Right-edge gloss */}
          <div className="absolute right-0 top-0 h-full w-4 rounded-r-sm bg-gradient-to-l from-white/60 to-transparent pointer-events-none" />
        </div>
      </div>

      {/* Inline keyframes */}
      <style>{`
        @keyframes xp-bar-shimmer {
          0%   { background-position: 200% 0; }
          100% { background-position: -200% 0; }
        }
      `}</style>
    </div>
  );
};