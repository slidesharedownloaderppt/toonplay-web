import { computeTopGenreShares } from '../../lib/genreStats';

interface Props {
  genres: any[];
  totalEpisodes?: number;
}

export function TopGenresCard({ genres, totalEpisodes }: Props) {
  const { items } = computeTopGenreShares(genres, totalEpisodes, 8);

  if (items.length === 0) {
    return (
      <div className="bg-[#14172b] border border-[#2e3252] rounded-2xl p-5">
        <div className="mb-3">
          <h3 className="text-sm font-semibold text-white">Top genres</h3>
          <p className="text-[11px] text-slate-500 mt-0.5">By episodes watched</p>
        </div>
        <p className="text-xs text-slate-500">No genre data yet.</p>
      </div>
    );
  }

  return (
    <div className="bg-[#14172b] border border-[#2e3252] rounded-2xl p-5">
      <div className="mb-3">
        <h3 className="text-sm font-semibold text-white">Top genres</h3>
        <p className="text-[11px] text-slate-500 mt-0.5">By episodes watched</p>
      </div>

      <ul className="space-y-2.5">
        {items.map((g) => {
          const eps = g.episodes_watched;
          const pct = g.percentage;
          const barWidth = g.barWidth;

          return (
            <li key={g.genre}>
              <div className="flex justify-between items-baseline text-xs mb-1">
                <span className="text-slate-300 truncate">{g.genre}</span>
                <span className="text-slate-300 tabular-nums shrink-0 ml-2">
                  {eps}{' '}
                  <span className="text-gray-600">· {pct}%</span>
                </span>
              </div>
              <div className="h-[3px] bg-[#0b0c16] rounded-full overflow-hidden">
                <div
                  className="h-full bg-indigo-500 rounded-full transition-[width] duration-500"
                  style={{ width: `${Math.max(2, barWidth)}%` }}
                />
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}