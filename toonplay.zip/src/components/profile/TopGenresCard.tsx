interface Props {
  genres: any[];
}

export function TopGenresCard({ genres }: Props) {
  if (!genres || genres.length === 0) {
    return (
      <div className="bg-[#14172b] border border-[#2e3252] rounded-2xl p-5">
        <div className="mb-3">
          <h3 className="text-sm font-semibold text-white">Top genres</h3>
          <p className="text-[11px] text-slate-500 mt-0.5">By episodes watched</p>
        </div>
        <p className="text-xs text-slate-500">No genre data yet.</p>
      </div>
    );
  }

  const items = genres.slice(0, 8);
  const maxEps = Math.max(1, ...items.map((g) => Number(g.episodes_watched || 0)));
  const total = items.reduce((s, g) => s + Number(g.episodes_watched || 0), 0) || 1;

  return (
    <div className="bg-[#14172b] border border-[#2e3252] rounded-2xl p-5">
      <div className="mb-3">
        <h3 className="text-sm font-semibold text-white">Top genres</h3>
        <p className="text-[11px] text-slate-500 mt-0.5">By episodes watched</p>
      </div>

      <ul className="space-y-2.5">
        {items.map((g) => {
          const eps = Number(g.episodes_watched || 0);
          const pct = Math.round((eps / total) * 100);      // share of all genres
          const barWidth = (eps / maxEps) * 100;             // relative to top genre

          return (
            <li key={g.genre}>
              <div className="flex justify-between items-baseline text-xs mb-1">
                <span className="text-slate-300 truncate">{g.genre}</span>
                <span className="text-slate-300 tabular-nums shrink-0 ml-2">
                  {eps}{' '}
                  <span className="text-gray-600">· {pct}%</span>
                </span>
              </div>
              <div className="h-[3px] bg-[#0b0c16] rounded-full overflow-hidden">
                <div
                  className="h-full bg-indigo-500 rounded-full transition-[width] duration-500"
                  style={{ width: `${Math.max(2, barWidth)}%` }}
                />
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}