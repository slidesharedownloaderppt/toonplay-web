import React from 'react';
import { ArrowLeft, Flame } from 'lucide-react';
import { XpProgressBar } from './XpProgressBar';
import { AvatarWithFrame, getFallbackAvatarUrl } from './AvatarWithFrame';
import { TierUsername, resolveEffectiveLevel } from './TierUsername';

interface Props {
  user: any;
  onNavigate: (path: string) => void;
}

/**
 * Compact activity-page hero header matching the reference `ac-id` / `ac-level` / `ac-streak` layout.
 * - Back button → profile
 * - Avatar
 * - Name (tier-colored) + @username · Activity
 * - XP bar (via shared XpProgressBar) + streak row
 */
export const ActivityHeader: React.FC<Props> = ({ user, onNavigate }) => {
  const username = user.username || '';
  const displayName = user.display_name || username || 'User';
  const avatarUrl = user.avatar_url || getFallbackAvatarUrl(username || 'user');

  const xp = Math.max(0, Number(user.xp || 0));
  const level = resolveEffectiveLevel(user.level, xp);

  const currentStreak = Math.max(0, Number(user.current_streak_days || 0));
  const bestStreak = Math.max(0, Number(user.best_streak_days || 0));

  return (
    <header className="relative -mt-16 w-full overflow-hidden bg-[#0a0b10] pt-16">
      {/* Background blur layer — uses avatar as ambient color */}
      <div className="pointer-events-none absolute inset-0 z-0" aria-hidden="true">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-25 blur-3xl scale-110"
          style={{ backgroundImage: `url(${avatarUrl})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#070811] via-[#070811]/75 to-[#070811]/40" />
      </div>

      {/* Content */}
      <div className="relative z-10 mx-auto max-w-7xl px-4 pt-5 pb-4 sm:px-6 sm:pb-7 md:px-8">
        {/* Back button */}
        <button
          type="button"
          onClick={() => onNavigate(`/u/${username}`)}
          className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-400 hover:text-white transition-colors cursor-pointer mb-3"
        >
          <ArrowLeft className="h-4 w-4" strokeWidth={2.25} />
          Profile
        </button>

        {/* Main ID row */}
        <div className="flex flex-wrap items-center gap-3 sm:gap-4">
          {/* Avatar + Frame */}
          <AvatarWithFrame
            avatarUrl={user.avatar_url}
            frameUrl={user.profile_frame_url}
            username={username}
            alt={displayName}
            className="h-16 w-16 sm:h-20 sm:w-20"
            avatarClassName="border-2 border-[#070811]"
            loading="eager"
          />

          {/* Name block */}
          <div className="min-w-0 flex-1">
            <div className="flex min-w-0 flex-wrap items-center gap-2">
              <TierUsername
                as="h1"
                name={displayName}
                level={level}
                xp={xp}
                className="truncate text-2xl font-extrabold tracking-tight sm:text-3xl max-w-full"
              />
            </div>
            <p className="mt-0.5 truncate text-sm text-slate-400">
              @{username} <span className="text-slate-600">· Activity</span>
            </p>
          </div>

          {/* Level + XP block */}
          <div className="w-full sm:w-auto sm:min-w-[220px] sm:max-w-[280px] shrink-0">
            {/* XP bar with tier name — shared component */}
            <XpProgressBar xp={xp} level={level} />

            {/* Streak row */}
            <div className="flex items-center gap-1.5 mt-1.5 text-[11px] text-slate-400">
              <Flame className="h-3.5 w-3.5 text-orange-400" />
              <span>
                <b className="text-slate-200">{currentStreak}</b>{' '}
                day streak
              </span>
              {bestStreak > 0 && (
                <span className="text-slate-600">· best {bestStreak}</span>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};