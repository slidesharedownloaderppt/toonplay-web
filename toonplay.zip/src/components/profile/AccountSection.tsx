import { useState, useEffect } from 'react';
import {
  Pencil,
  Save,
  Loader2,
  Calendar,
  Upload,
  Check,
  X,
  Image as ImageIcon,
  Sparkles,
  RotateCcw,
  Ban,
} from 'lucide-react';
import {
  DEFAULT_PROFILE_BANNER_URL,
  isAuthoritativeProfileFrameUrl,
} from '../../api';
import { userApi } from '../../lib/api';
import { AvatarWithFrame } from './AvatarWithFrame';
import { TierUsername } from './TierUsername';
import { toast } from 'sonner';

interface Props {
  user: any;
  onEditAvatar: () => void;
  onEditBanner: () => void;
  onEditFrame: () => void;
  onSaved: () => void;
}

function sanitizeUsername(v: string): string {
  return v.toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 30);
}

export function AccountSection({
  user,
  onEditAvatar,
  onEditBanner,
  onEditFrame,
  onSaved,
}: Props) {
  const [username, setUsername] = useState(user?.username || '');
  const [displayName, setDisplayName] = useState(user?.display_name || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [busy, setBusy] = useState(false);
  const [appearanceBusy, setAppearanceBusy] = useState<'frame' | 'banner' | null>(null);
  const [usernameStatus, setUsernameStatus] = useState<
    'idle' | 'checking' | 'available' | 'taken'
  >('idle');

  // Re-sync form when the user object changes externally
  useEffect(() => {
    setUsername(user?.username || '');
    setDisplayName(user?.display_name || '');
    setBio(user?.bio || '');
  }, [user?.id, user?.username]);

  const usernameChanged =
    username.trim().toLowerCase() !== (user?.username || '').toLowerCase();

  // Debounced availability check with AbortController to prevent stale overwrites
  useEffect(() => {
    if (!usernameChanged) {
      setUsernameStatus('idle');
      return;
    }
    const clean = sanitizeUsername(username);
    if (clean.length < 3) {
      setUsernameStatus('idle');
      return;
    }
    setUsernameStatus('checking');
    const controller = new AbortController();
    const t = window.setTimeout(async () => {
      try {
        const res = await fetch(`/api/users/${encodeURIComponent(clean)}`, {
          signal: controller.signal,
        });
        if (controller.signal.aborted) return;
        if (res.status === 404) {
          setUsernameStatus('available');
        } else if (res.ok) {
          setUsernameStatus('taken');
        } else {
          setUsernameStatus('idle');
        }
      } catch (err: any) {
        if (err?.name === 'AbortError' || controller.signal.aborted) return;
        setUsernameStatus('idle');
      }
    }, 400);
    return () => {
      window.clearTimeout(t);
      controller.abort();
    };
  }, [username, usernameChanged]);

  const joinedDate = user?.joined_at
    ? new Date(user.joined_at).toLocaleDateString(undefined, {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      })
    : '—';

  const canSave =
    !busy && !(usernameChanged && usernameStatus !== 'available');

  const handleSave = async () => {
    if (!canSave) return;
    setBusy(true);
    try {
      const payload: any = {
        display_name: displayName.trim() || undefined,
        bio: bio.trim(),
      };
      if (usernameChanged && usernameStatus === 'available') {
        payload.username = sanitizeUsername(username);
      }
      await userApi.updateProfile(payload);
      toast.success('Profile updated');
      onSaved();
    } catch (err: any) {
      toast.error(err?.message || 'Failed to save');
    } finally {
      setBusy(false);
    }
  };

  const handleQuickRemoveFrame = async () => {
    if (appearanceBusy || !user?.profile_frame_url) return;
    setAppearanceBusy('frame');
    try {
      await userApi.updateProfile({ profile_frame_url: null });
      toast.success('Profile frame removed');
      onSaved();
    } catch (err: any) {
      toast.error(err?.message || 'Failed to remove frame');
    } finally {
      setAppearanceBusy(null);
    }
  };

  const handleQuickResetBanner = async () => {
    if (appearanceBusy || !user?.profile_banner_url) return;
    setAppearanceBusy('banner');
    try {
      await userApi.updateProfile({ profile_banner_url: null });
      toast.success('Default banner restored');
      onSaved();
    } catch (err: any) {
      toast.error(err?.message || 'Failed to reset banner');
    } finally {
      setAppearanceBusy(null);
    }
  };

  const activeBannerUrl =
    String(user?.profile_banner_url || '').trim() || DEFAULT_PROFILE_BANNER_URL;
  const hasCustomBanner = Boolean(String(user?.profile_banner_url || '').trim());
  const hasFrame = isAuthoritativeProfileFrameUrl(user?.profile_frame_url);

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-white tracking-tight">Account</h2>

      {/* ── User card ─────────────────────────────────────── */}
      <div className="flex flex-col sm:flex-row gap-5 p-5 rounded-2xl bg-[#14172b] border border-[#23263f]">
        <div className="relative shrink-0 self-start sm:self-center p-1">
          <AvatarWithFrame
            avatarUrl={user?.avatar_url}
            frameUrl={user?.profile_frame_url}
            username={user?.username}
            alt={user?.display_name || user?.username || 'avatar'}
            className="w-20 h-20"
            avatarClassName="border-2 border-[#2e3252]"
            loading="eager"
          />
          <button
            type="button"
            onClick={onEditAvatar}
            title="Change avatar"
            aria-label="Change avatar"
            className="absolute bottom-0 right-0 z-30 w-7 h-7 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white flex items-center justify-center shadow-lg transition-colors cursor-pointer"
          >
            <Pencil className="w-3 h-3" />
          </button>
        </div>

        <div className="flex-1 min-w-0">
          <p className="text-[11px] text-emerald-400 font-medium mb-1">
            Synced to cloud
          </p>
          <TierUsername
            as="h3"
            name={user?.display_name || user?.username || 'User'}
            level={user?.level}
            xp={user?.xp}
            className="text-lg font-semibold truncate block max-w-full"
          />
          <p className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
            <Calendar className="w-3 h-3" />
            Joined {joinedDate}
          </p>
          <p className="text-[11px] text-slate-600 mt-1 truncate">
            @{user?.username || 'user'}
            {user?.email ? ` · ${user.email}` : ''}
          </p>
        </div>
      </div>

      {/* ── Profile Appearance (Avatar, Frame, Banner) ───── */}
      <div className="p-5 rounded-2xl bg-[#14172b] border border-[#23263f] space-y-4">
        <div>
          <h3 className="text-sm font-semibold text-white">Profile Appearance</h3>
          <p className="text-[11px] text-slate-500 mt-0.5">
            Customize your avatar, decorative avatar frame, and public profile banner.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3.5">
          {/* Avatar + Frame controls */}
          <div className="p-4 rounded-xl bg-[#0b0d16] border border-[#23263f] flex flex-col justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="p-1 shrink-0">
                <AvatarWithFrame
                  avatarUrl={user?.avatar_url}
                  frameUrl={user?.profile_frame_url}
                  username={user?.username}
                  alt="Avatar and frame preview"
                  className="w-14 h-14"
                  avatarClassName="border-2 border-[#2e3252]"
                  loading="eager"
                />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-semibold text-white">Avatar &amp; Frame</p>
                <p className="text-[11px] text-slate-500 mt-0.5 leading-snug">
                  {hasFrame
                    ? 'Active frame is displayed on your avatar across the site.'
                    : 'No frame selected — using standard avatar style.'}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={onEditAvatar}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#14172b] hover:bg-[#1c2038] border border-[#2e3252] text-slate-200 text-xs font-medium transition-colors cursor-pointer"
              >
                <Pencil className="w-3.5 h-3.5 text-indigo-400" />
                Change Avatar
              </button>
              <button
                type="button"
                onClick={onEditFrame}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-colors cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                {hasFrame ? 'Change Frame' : 'Choose Frame'}
              </button>
              {hasFrame && (
                <button
                  type="button"
                  onClick={handleQuickRemoveFrame}
                  disabled={appearanceBusy !== null}
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-transparent hover:bg-rose-500/10 border border-[#23263f] hover:border-rose-500/40 text-rose-400 text-xs font-medium disabled:opacity-50 transition-colors cursor-pointer"
                >
                  {appearanceBusy === 'frame' ? (
                    <Loader2 className="w-3 h-3 animate-spin" />
                  ) : (
                    <Ban className="w-3 h-3" />
                  )}
                  Remove
                </button>
              )}
            </div>
          </div>

          {/* Public Profile Banner control */}
          <div className="p-4 rounded-xl bg-[#0b0d16] border border-[#23263f] flex flex-col justify-between gap-3">
            <div className="relative h-24 w-full rounded-lg overflow-hidden border border-[#23263f] bg-[#070811]">
              <img
                src={activeBannerUrl}
                alt="Public profile banner preview"
                loading="lazy"
                decoding="async"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover opacity-90"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src =
                    DEFAULT_PROFILE_BANNER_URL;
                }}
              />
              <div className="absolute inset-0 bg-[#070811]/25" />
              <div className="absolute inset-x-0 bottom-0 h-12 bg-gradient-to-t from-[#070811] via-[#070811]/55 to-transparent" />
              <div className="absolute bottom-1.5 left-2.5 right-2.5 flex items-center justify-between gap-2">
                <span className="text-[11px] font-medium text-white drop-shadow">
                  Public Profile Banner
                </span>
                <span className="text-[10px] text-slate-300 drop-shadow">
                  {hasCustomBanner ? 'Custom' : 'Default'}
                </span>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={onEditBanner}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-colors cursor-pointer"
              >
                <ImageIcon className="w-3.5 h-3.5" />
                {hasCustomBanner ? 'Change Banner' : 'Choose Banner'}
              </button>
              {hasCustomBanner && (
                <button
                  type="button"
                  onClick={handleQuickResetBanner}
                  disabled={appearanceBusy !== null}
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-transparent hover:bg-slate-800/60 border border-[#23263f] text-slate-300 text-xs font-medium disabled:opacity-50 transition-colors cursor-pointer"
                >
                  {appearanceBusy === 'banner' ? (
                    <Loader2 className="w-3 h-3 animate-spin" />
                  ) : (
                    <RotateCcw className="w-3 h-3" />
                  )}
                  Reset
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* ── Editable form ─────────────────────────────────── */}
      <div className="p-5 rounded-2xl bg-[#14172b] border border-[#23263f] space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Username */}
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">
              Username
            </label>
            <div className="relative">
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(sanitizeUsername(e.target.value))}
                maxLength={30}
                placeholder="your_username"
                className="w-full bg-[#06070d] border border-[#23263f] rounded-lg pl-3 pr-9 py-2.5 text-white text-sm focus:outline-none focus:border-indigo-500/60 transition-colors"
              />
              <div className="absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none">
                {usernameStatus === 'checking' && (
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-slate-500" />
                )}
                {usernameStatus === 'available' && (
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                )}
                {usernameStatus === 'taken' && (
                  <X className="w-3.5 h-3.5 text-rose-400" />
                )}
              </div>
            </div>
            <p className="text-[10px] mt-1">
              {usernameChanged && usernameStatus === 'checking' && (
                <span className="text-slate-500">Checking availability…</span>
              )}
              {usernameChanged && usernameStatus === 'available' && (
                <span className="text-emerald-400">Available — saves on submit.</span>
              )}
              {usernameChanged && usernameStatus === 'taken' && (
                <span className="text-rose-400">Username already taken.</span>
              )}
              {usernameChanged && usernameStatus === 'idle' && (
                <span className="text-slate-600">
                  3–30 chars, letters, numbers, underscore.
                </span>
              )}
              {!usernameChanged && (
                <span className="text-slate-600">
                  3–30 chars, letters, numbers, underscore.
                </span>
              )}
            </p>
          </div>

          {/* Display name */}
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">
              Display Name
            </label>
            <input
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              maxLength={191}
              placeholder="Your display name"
              className="w-full bg-[#06070d] border border-[#23263f] rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-indigo-500/60 transition-colors"
            />
            <p className="text-[10px] text-slate-600 mt-1">
              Up to 191 characters. Emoji welcome.
            </p>
          </div>
        </div>

        {/* Bio */}
        <div>
          <label className="block text-xs font-medium text-slate-400 mb-1.5">Bio</label>
          <textarea
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            rows={3}
            maxLength={500}
            placeholder="Tell others a bit about yourself…"
            className="w-full bg-[#06070d] border border-[#23263f] rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-indigo-500/60 resize-none transition-colors"
          />
          <p className="text-[10px] text-slate-600 mt-1 text-right">
            {bio.length}/500
          </p>
        </div>

        <div className="flex justify-end pt-2 border-t border-[#23263f]">
          <button
            onClick={handleSave}
            disabled={!canSave}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
          >
            {busy ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Save className="w-3.5 h-3.5" />
            )}
            <span>{busy ? 'Saving…' : 'Save changes'}</span>
          </button>
        </div>
      </div>

      <p className="text-[10px] text-slate-600 flex items-center gap-1.5">
        <Upload className="w-3 h-3 shrink-0" />
        Avatars, decorative frames, and public profile banners sync directly to your account.
      </p>
    </div>
  );
}