import { useState, useEffect } from 'react';
import { Pencil, Save, Loader2, Calendar, Upload, Check, X } from 'lucide-react';
import { userApi } from '../../lib/api';
import { toast } from 'sonner';

interface Props {
  user: any;
  onEditAvatar: () => void;
  onSaved: () => void;
}

function sanitizeUsername(v: string): string {
  return v.toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 30);
}

export function AccountSection({ user, onEditAvatar, onSaved }: Props) {
  const [username, setUsername] = useState(user?.username || '');
  const [displayName, setDisplayName] = useState(user?.display_name || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [busy, setBusy] = useState(false);
  const [usernameStatus, setUsernameStatus] = useState<
    'idle' | 'checking' | 'available' | 'taken'
  >('idle');

  // Re-sync form when the user object changes externally
  useEffect(() => {
    setUsername(user?.username || '');
    setDisplayName(user?.display_name || '');
    setBio(user?.bio || '');
  }, [user?.id, user?.username]);

  const usernameChanged =
    username.trim().toLowerCase() !== (user?.username || '').toLowerCase();

  // Debounced availability check
  useEffect(() => {
    if (!usernameChanged) {
      setUsernameStatus('idle');
      return;
    }
    const clean = sanitizeUsername(username);
    if (clean.length < 3) {
      setUsernameStatus('idle');
      return;
    }
    setUsernameStatus('checking');
    const t = setTimeout(async () => {
      try {
        const res = await fetch(`/api/users/${encodeURIComponent(clean)}`);
        if (res.status === 404) {
          setUsernameStatus('available');
        } else if (res.ok) {
          setUsernameStatus('taken');
        } else {
          setUsernameStatus('idle');
        }
      } catch {
        setUsernameStatus('idle');
      }
    }, 400);
    return () => clearTimeout(t);
  }, [username, usernameChanged]);

  const joinedDate = user?.joined_at
    ? new Date(user.joined_at).toLocaleDateString(undefined, {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      })
    : '—';

  const canSave =
    !busy && !(usernameChanged && usernameStatus !== 'available');

  const handleSave = async () => {
    if (!canSave) return;
    setBusy(true);
    try {
      const payload: any = {
        display_name: displayName.trim() || undefined,
        bio: bio.trim(),
      };
      if (usernameChanged && usernameStatus === 'available') {
        payload.username = sanitizeUsername(username);
      }
      await userApi.updateProfile(payload);
      toast.success('Profile updated');
      onSaved();
    } catch (err: any) {
      toast.error(err?.message || 'Failed to save');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-white tracking-tight">Account</h2>

      {/* ── User card ─────────────────────────────────────── */}
      <div className="flex flex-col sm:flex-row gap-5 p-5 rounded-2xl bg-[#14172b] border border-[#23263f]">
        <div className="relative shrink-0 self-start sm:self-center">
          <img
            src={
              user?.avatar_url ||
              `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(
                user?.username || 'user'
              )}`
            }
            alt={user?.username || 'avatar'}
            className="w-20 h-20 rounded-2xl object-cover border-2 border-[#2e3252]"
            onError={(e) => {
              (e.target as HTMLImageElement).src = `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(
                user?.username || 'user'
              )}`;
            }}
          />
          <button
            onClick={onEditAvatar}
            title="Change avatar"
            className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white flex items-center justify-center shadow-lg transition-colors cursor-pointer"
          >
            <Pencil className="w-3 h-3" />
          </button>
        </div>

        <div className="flex-1 min-w-0">
          <p className="text-[11px] text-emerald-400 font-medium mb-1">
            Synced to cloud
          </p>
          <h3 className="text-lg font-semibold text-white flex items-center gap-1.5 truncate">
            {user?.display_name || user?.username || 'User'}
          </h3>
          <p className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
            <Calendar className="w-3 h-3" />
            Joined {joinedDate}
          </p>
          <p className="text-[11px] text-slate-600 mt-1 truncate">
            @{user?.username || 'user'}
            {user?.email ? ` · ${user.email}` : ''}
          </p>
        </div>
      </div>

      {/* ── Editable form ─────────────────────────────────── */}
      <div className="p-5 rounded-2xl bg-[#14172b] border border-[#23263f] space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Username */}
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">
              Username
            </label>
            <div className="relative">
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(sanitizeUsername(e.target.value))}
                maxLength={30}
                placeholder="your_username"
                className="w-full bg-[#06070d] border border-[#23263f] rounded-lg pl-3 pr-9 py-2.5 text-white text-sm focus:outline-none focus:border-indigo-500/60 transition-colors"
              />
              <div className="absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none">
                {usernameStatus === 'checking' && (
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-slate-500" />
                )}
                {usernameStatus === 'available' && (
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                )}
                {usernameStatus === 'taken' && (
                  <X className="w-3.5 h-3.5 text-rose-400" />
                )}
              </div>
            </div>
            <p className="text-[10px] mt-1">
              {usernameChanged && usernameStatus === 'checking' && (
                <span className="text-slate-500">Checking availability…</span>
              )}
              {usernameChanged && usernameStatus === 'available' && (
                <span className="text-emerald-400">Available — saves on submit.</span>
              )}
              {usernameChanged && usernameStatus === 'taken' && (
                <span className="text-rose-400">Username already taken.</span>
              )}
              {usernameChanged && usernameStatus === 'idle' && (
                <span className="text-slate-600">
                  3–30 chars, letters, numbers, underscore.
                </span>
              )}
              {!usernameChanged && (
                <span className="text-slate-600">
                  3–30 chars, letters, numbers, underscore.
                </span>
              )}
            </p>
          </div>

          {/* Display name */}
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">
              Display Name
            </label>
            <input
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              maxLength={191}
              placeholder="Your display name"
              className="w-full bg-[#06070d] border border-[#23263f] rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-indigo-500/60 transition-colors"
            />
            <p className="text-[10px] text-slate-600 mt-1">
              Up to 191 characters. Emoji welcome.
            </p>
          </div>
        </div>

        {/* Bio */}
        <div>
          <label className="block text-xs font-medium text-slate-400 mb-1.5">Bio</label>
          <textarea
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            rows={3}
            maxLength={500}
            placeholder="Tell others a bit about yourself…"
            className="w-full bg-[#06070d] border border-[#23263f] rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-indigo-500/60 resize-none transition-colors"
          />
          <p className="text-[10px] text-slate-600 mt-1 text-right">
            {bio.length}/500
          </p>
        </div>

        <div className="flex justify-end pt-2 border-t border-[#23263f]">
          <button
            onClick={handleSave}
            disabled={!canSave}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
          >
            {busy ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Save className="w-3.5 h-3.5" />
            )}
            <span>{busy ? 'Saving…' : 'Save changes'}</span>
          </button>
        </div>
      </div>

      <p className="text-[10px] text-slate-600 flex items-center gap-1.5">
        <Upload className="w-3 h-3" />
        Avatar upload via URL or from the gallery. Max 1MB (JPEG, PNG, GIF, WEBP).
      </p>
    </div>
  );
}