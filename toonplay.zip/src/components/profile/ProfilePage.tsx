import { useEffect, useState, useCallback, type ReactElement } from 'react';
import {
  User as UserIcon,
  Settings as SettingsIcon,
  Lock,
  LogOut,
  Trash2,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { userApi, statsApi, watchlistApi, historyApi } from '../../lib/api';
import { toast } from 'sonner';
import { PublicProfileView } from './PublicProfileView';
import { AvatarPickerModal } from './AvatarPickerModal';
import { BannerPickerModal } from './BannerPickerModal';
import { FramePickerModal } from './FramePickerModal';
import { UnifiedAnime } from '../../types';
import { AccountSection } from './AccountSection';
import { PreferencesSection } from './PreferencesSection';
import { SecuritySection } from './SecuritySection';
import { DeleteAccountModal } from './DeleteAccountModal';

type Section = 'account' | 'preferences' | 'security';

interface Props {
  username: string;
  onNavigate: (path: string) => void;
  watchlist?: UnifiedAnime[];
  onToggleWatchlist?: (anime: UnifiedAnime) => void;
  onPlayAnime?: (
    anime: UnifiedAnime,
    lang?: string,
    season?: number,
    ep?: number
  ) => void;
  onProfilePageLoadingChange?: (loading: boolean) => void;
}

export function ProfilePage({
  username,
  onNavigate,
  watchlist = [],
  onToggleWatchlist,
  onPlayAnime,
  onProfilePageLoadingChange,
}: Props) {
  const { user: authUser, isAuthenticated, loading: authLoading, refresh, logout } = useAuth();
  const isOwn = !username;

  const [data, setData] = useState<any>(null);
  const [summary, setSummary] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [avatarModalOpen, setAvatarModalOpen] = useState(false);
  const [bannerModalOpen, setBannerModalOpen] = useState(false);
  const [frameModalOpen, setFrameModalOpen] = useState(false);
  const [deleteAccountOpen, setDeleteAccountOpen] = useState(false);
  const [activeSection, setActiveSection] = useState<Section>('account');

  useEffect(() => {
    if (isOwn && authLoading) return;

    if (isOwn && !isAuthenticated) {
      setLoading(false);
      setData(null);
      setSummary(null);
      setError(null);
      onProfilePageLoadingChange?.(false);
      return;
    }

    let cancelled = false;
    setLoading(true);
    setError(null);
    setData(null);
    setSummary(null);
    onProfilePageLoadingChange?.(true);

    const load = async () => {
      try {
        if (isOwn) {
          const [profileRes, summaryRes, wlRes, histRes] = await Promise.all([
            userApi.profile(),
            statsApi.summary().catch(() => ({ summary: null } as any)),
            watchlistApi.list(1, 100).catch(() => ({ items: [] } as any)),
            historyApi.list(1, 100).catch(() => ({ items: [] } as any)),
          ]);
          if (cancelled) return;
          setData({
            user: profileRes.user,
            watchlist: wlRes.items || [],
            history: histRes.items || [],
          });
          setSummary(summaryRes.summary);
        } else {
          const res = await userApi.publicProfile(username);
          if (cancelled) return;
          setData(res.profile);
        }
      } catch (err: any) {
        if (cancelled) return;
        if (isOwn && err?.status === 401) {
          setData(null);
          setLoading(false);
          onProfilePageLoadingChange?.(false);
          return;
        }
        setError(err?.message || 'Failed to load profile');
      } finally {
        if (!cancelled) {
          setLoading(false);
          onProfilePageLoadingChange?.(false);
        }
      }
    };

    load();
    return () => {
      cancelled = true;
    };
  }, [username, isOwn, isAuthenticated, authLoading, onProfilePageLoadingChange]);

  const handleAvatarSaved = async () => {
    await refresh();
    setAvatarModalOpen(false);
    try {
      const [profileRes] = await Promise.all([userApi.profile()]);
      setData((prev: any) => ({ ...prev, user: profileRes.user }));
    } catch {}
  };

  const handleAccountSaved = async () => {
    await refresh();
    try {
      const [profileRes] = await Promise.all([userApi.profile()]);
      setData((prev: any) => ({ ...prev, user: profileRes.user }));
    } catch {}
  };

  const handleLogout = async () => {
    setData(null);
    setSummary(null);
    setError(null);
    setLoading(true);

    try {
      await logout();
    } catch {}

    onProfilePageLoadingChange?.(false);
    toast.success('Logged out');
    onNavigate('/');
  };

if (isOwn && !isAuthenticated) {
  return (
    <div className="min-h-screen bg-[#0b0c16] flex items-center justify-center px-4 py-16">
      <div className="w-full max-w-sm text-center space-y-5">
        <div className="mx-auto w-14 h-14 rounded-2xl bg-[#14172b] border border-[#23263f] flex items-center justify-center">
          <Lock className="w-6 h-6 text-indigo-400" />
        </div>

        <div className="space-y-1.5">
          <h1 className="text-lg font-semibold text-white">
            You've been signed out
          </h1>
          <p className="text-sm text-slate-400">
            Sign in again to access your profile.
          </p>
        </div>

        <button
          onClick={() => onNavigate('/')}
          className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium transition-colors cursor-pointer"
        >
          Back to home
        </button>
      </div>
    </div>
  );
}

  if (loading) return null;

  const user = (isOwn ? data?.user : data) || {};

  if (error || !data || Object.keys(user).length === 0) {
    const isNotFound = error?.toLowerCase().includes('not found');

    return (
      <div className="min-h-screen bg-[#0b0c16] flex items-center justify-center px-4 py-16">
        <div className="w-full max-w-sm text-center space-y-5">
          <div className="mx-auto w-14 h-14 rounded-2xl bg-[#14172b] border border-[#23263f] flex items-center justify-center">
            <Lock className="w-6 h-6 text-indigo-400" />
          </div>

          <div className="space-y-1.5">
            <h1 className="text-lg font-semibold text-white">
              {isNotFound ? 'User Not Found' : 'Profile Unavailable'}
            </h1>
            <p className="text-sm text-slate-400">
              {error || 'Profile information is currently unavailable. Please try again later.'}
            </p>
          </div>

          <button
            onClick={() => onNavigate('/')}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium transition-colors cursor-pointer"
          >
            Back to home
          </button>
        </div>
      </div>
    );
  }

  if (!isOwn) {
    return (
      <PublicProfileView
        profile={user}
        onNavigate={onNavigate}
        watchlist={watchlist}
        onToggleWatchlist={onToggleWatchlist}
        onPlayAnime={onPlayAnime}
      />
    );
  }

  const sections: { id: Section; label: string; icon: ReactElement }[] = [
    { id: 'account', label: 'Account', icon: <UserIcon className="w-4 h-4" /> },
    { id: 'preferences', label: 'Preferences', icon: <SettingsIcon className="w-4 h-4" /> },
    { id: 'security', label: 'Security', icon: <Lock className="w-4 h-4" /> },
  ];

  return (
    <>
      <div className="max-w-6xl mx-auto px-4 py-10">
        <div className="mb-5">
          <h1 className="text-xl sm:text-2xl font-semibold text-zinc-100 tracking-tight">
            Settings
          </h1>
          <p className="text-xs text-zinc-500 mt-0.5">
            Manage your profile, preferences, and security.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-[220px_1fr] gap-5">
          <aside className="hidden md:block self-start sticky top-24">
            <div className="p-3 rounded-2xl bg-[#14172b] border border-[#23263f] space-y-4">
              <div>
                <h2 className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider px-2 mb-2">
                  Settings
                </h2>
                <nav className="space-y-1">
                  {sections.map((s) => (
                    <button
                      key={s.id}
                      onClick={() => setActiveSection(s.id)}
                      className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                        activeSection === s.id
                          ? 'bg-indigo-600 text-white'
                          : 'text-slate-400 hover:text-white hover:bg-[#1c2038]'
                      }`}
                    >
                      {s.icon}
                      <span>{s.label}</span>
                    </button>
                  ))}
                </nav>
              </div>

              <div className="pt-3 border-t border-[#23263f]">
                <h3 className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider px-2 mb-2">
                  Account Info
                </h3>
                <div className="space-y-2 px-2 text-[11px]">
                  <div>
                    <p className="text-slate-600">Email</p>
                    <p className="text-slate-300 truncate">{user.email || '—'}</p>
                  </div>
                  <div>
                    <p className="text-slate-600">Status</p>
                    <p className="text-emerald-400 flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                      Verified
                    </p>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-[#23263f]">
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 transition-colors cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sign out</span>
                </button>
              </div>
            </div>
          </aside>

          <div className="md:hidden mb-1">
            <div className="flex gap-1 p-1 rounded-xl bg-[#14172b] border border-[#23263f]">
              {sections.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setActiveSection(s.id)}
                  className={`flex-1 min-w-0 flex items-center justify-center gap-1.5 px-2 py-2 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                    activeSection === s.id
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="shrink-0">{s.icon}</span>
                  <span className="truncate min-w-0">{s.label}</span>
                </button>
              ))}
            </div>
          </div>

          <main className="min-w-0">
            {activeSection === 'account' && (
              <AccountSection
                user={user}
                onEditAvatar={() => setAvatarModalOpen(true)}
                onEditBanner={() => setBannerModalOpen(true)}
                onEditFrame={() => setFrameModalOpen(true)}
                onSaved={handleAccountSaved}
              />
            )}

            {activeSection === 'preferences' && (
              <PreferencesSection
                user={user}
                onUserChange={async () => {
                  await refresh();
                  try {
                    const profileRes = await userApi.profile();
                    setData((prev: any) => ({ ...prev, user: profileRes.user }));
                  } catch {}
                }}
              />
            )}

            {activeSection === 'security' && (
              <>
                <SecuritySection onSaved={handleAccountSaved} />

                {/* ── Danger Zone ── */}
                <div className="mt-4 p-5 rounded-2xl bg-[#14172b] border border-rose-900/40">
                  <div className="mb-3">
                    <h3 className="text-sm font-semibold text-rose-300">Danger Zone</h3>
                    <p className="text-xs text-slate-400 mt-1">
                      Permanently erase your account and all associated data. This action cannot be undone.
                    </p>
                  </div>
<button
  type="button"
  onClick={() => setDeleteAccountOpen(true)}
  className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-mono bg-rose-800 hover:bg-rose-700 text-white font-medium border border-rose-700/60 transition-colors cursor-pointer"
>
  <Trash2 className="w-3.5 h-3.5" />
  <span>Delete my account</span>
</button>
                </div>
              </>
            )}
          </main>
        </div>
      </div>

      <AvatarPickerModal
        open={avatarModalOpen}
        currentAvatarUrl={user?.avatar_url || null}
        currentFrameUrl={user?.profile_frame_url || null}
        username={user?.username}
        onClose={() => setAvatarModalOpen(false)}
        onSaved={handleAvatarSaved}
      />

      <BannerPickerModal
        open={bannerModalOpen}
        currentBannerUrl={user?.profile_banner_url || null}
        onClose={() => setBannerModalOpen(false)}
        onSaved={async () => {
          setBannerModalOpen(false);
          await handleAccountSaved();
        }}
      />

      <FramePickerModal
        open={frameModalOpen}
        currentAvatarUrl={user?.avatar_url || null}
        currentFrameUrl={user?.profile_frame_url || null}
        username={user?.username}
        onClose={() => setFrameModalOpen(false)}
        onSaved={async () => {
          setFrameModalOpen(false);
          await handleAccountSaved();
        }}
      />

      <DeleteAccountModal
        open={deleteAccountOpen}
        onClose={() => setDeleteAccountOpen(false)}
        onDeleted={() => {
          setData(null);
          setSummary(null);
          onNavigate('/');
        }}
      />
    </>
  );
}