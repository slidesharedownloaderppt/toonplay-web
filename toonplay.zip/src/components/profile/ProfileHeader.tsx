import React, { useEffect, useRef, useState } from 'react';
import {
  Calendar,
  Activity,
  Info,
  Check,
  UserPlus,
  UserCheck,
  Clock,
  Users,
  Tv,
  LoaderCircle,
  X as XIcon,
} from 'lucide-react';
import { friendsApi } from '../../lib/api';
import { DEFAULT_PROFILE_BANNER_URL } from '../../api';
import { LevelCrest } from './LevelCrest';
import { XpProgressBar } from './XpProgressBar';
import { ProfileInfoModal } from './ProfileInfoModal';
import { AvatarWithFrame } from './AvatarWithFrame';
import { TierUsername, resolveEffectiveLevel } from './TierUsername';
import { getXpTier } from '../../lib/xpTiers';
import { formatDate } from '../../lib/time';
import { useAuth } from '../../context/AuthContext';

interface Props {
  user: any;
  isOwn: boolean;
  onEditAvatar?: () => void;
  onAvatarClick?: () => void;
  onActivityClick?: () => void;
  onNavigate?: (path: string) => void;
}

export const ProfileHeader: React.FC<Props> = ({
  user,
  isOwn,
  onEditAvatar,
  onAvatarClick,
  onActivityClick,
  onNavigate,
}) => {
const { isAuthenticated } = useAuth();
const [infoOpen, setInfoOpen] = useState(false);
  const infoBtnRef = useRef<HTMLButtonElement>(null);

  // Friend System States
  const [friendStatus, setFriendStatus] = useState<
    'self' | 'friends' | 'pending_sent' | 'pending_received' | 'none'
  >('none');
  const [friendsCount, setFriendsCount] = useState<number>(0);
  const [requestId, setRequestId] = useState<string | undefined>();
  const [friendLoading, setFriendLoading] = useState<boolean>(false);

  const xp = Math.max(0, Number(user?.xp || 0));
  const level = resolveEffectiveLevel(user?.level, xp);
  const tier = getXpTier(level);

  const displayName = user?.display_name || user?.username || 'Unknown';
  const username = user?.username || '';
  const customBannerUrl = String(user?.profile_banner_url || '').trim();
  const [bannerFailed, setBannerFailed] = useState(false);
  const [defaultBannerFailed, setDefaultBannerFailed] = useState(false);

  useEffect(() => {
    setBannerFailed(false);
    setDefaultBannerFailed(false);
  }, [customBannerUrl]);

  const resolvedBannerUrl =
    !bannerFailed && customBannerUrl ? customBannerUrl : DEFAULT_PROFILE_BANNER_URL;
  const joined = formatDate(user?.joined_at);

  const completedAnime = Number(user?.completed_anime || 0);
  const showsCount = Number(user?.total_anime_watched || 0);
  const watchingCount = Number(user?.watching || 0);

  const profileUrl =
    typeof window !== 'undefined'
      ? `${window.location.origin}/u/${username}`
      : `/u/${username}`;

  const handleInfoToggle = () => {
    setInfoOpen((v) => !v);
  };

useEffect(() => {
  if (!username || !isAuthenticated) {
    setFriendStatus('none');
    setRequestId(undefined);
    setFriendsCount(0);
    return;
  }

  let cancelled = false;
  setFriendLoading(true);

  friendsApi.status(username)
    .then((res) => {
      if (!cancelled && res.success) {
        setFriendStatus(res.status);
        setFriendsCount(res.friendsCount || 0);
        setRequestId(res.requestId);
      }
    })
    .catch(() => {})
    .finally(() => {
      if (!cancelled) setFriendLoading(false);
    });

  return () => {
    cancelled = true;
  };
}, [username, isAuthenticated]);

const openLogin = () => {
  window.dispatchEvent(
    new CustomEvent('toonplay:open-auth', { detail: { step: 'login' } })
  );
};

const handleSendRequest = async () => {
  if (!isAuthenticated) {
    openLogin();
    return;
  }

  if (friendLoading) return;

  try {
    setFriendLoading(true);

    const res = await friendsApi.sendRequest(username);

    if (res.success) {
      const statusRes = await friendsApi.status(username);

      if (statusRes.success) {
        setFriendStatus(statusRes.status);
        setFriendsCount(statusRes.friendsCount || 0);
        setRequestId(statusRes.requestId);
      }
    }
  } catch (err: any) {
    alert(err.message || 'Failed to send friend request');
  } finally {
    setFriendLoading(false);
  }
};

const handleRespondRequest = async (
  action: 'accept' | 'decline' | 'cancel'
) => {
  if (!isAuthenticated) {
    openLogin();
    return;
  }

  if (!requestId || friendLoading) return;

  try {
    setFriendLoading(true);

    const res = await friendsApi.respondRequest(requestId, action);

    if (res.success) {
      setRequestId(undefined);

      if (action === 'accept') {
        setFriendStatus('friends');
        setFriendsCount((c) => c + 1);
      } else {
        setFriendStatus('none');
      }
    }
  } catch (err: any) {
    alert(err.message || 'Failed to respond to request');

    const statusRes = await friendsApi.status(username).catch(() => null);
    if (statusRes?.success) {
      setFriendStatus(statusRes.status);
      setFriendsCount(statusRes.friendsCount || 0);
      setRequestId(statusRes.requestId);
    }
  } finally {
    setFriendLoading(false);
  }
};

const handleRemoveFriend = async () => {
  if (!isAuthenticated) {
    openLogin();
    return;
  }

  if (friendLoading) return;
  if (!confirm(`Remove @${username} from your friends?`)) return;

  try {
    setFriendLoading(true);

    const res = await friendsApi.removeFriend(username);

    if (res.success) {
      setFriendStatus('none');
      setRequestId(undefined);
      setFriendsCount((c) => Math.max(0, c - 1));
    }
  } catch (err: any) {
    alert(err.message || 'Failed to remove friend');
  } finally {
    setFriendLoading(false);
  }
};

  // ---- Compact icon-button styling (matches site's dark gray chrome) ----
  const iconBtnBase =
    'flex h-7 w-7 items-center justify-center rounded-full bg-black/60 border border-white/10 backdrop-blur-md shadow-sm transition-colors focus:outline-none cursor-pointer';

  return (
    <>
      {/* ================= BANNER ================= */}
      <div className="relative -mt-16 h-52 sm:h-64 md:h-80 lg:h-96 w-full overflow-hidden border-b-0 lg:border-b lg:border-white/5 bg-[#070811] pt-16">
        <div className="pointer-events-none absolute inset-0 z-0 overflow-hidden select-none">
          <div className="relative h-full w-full">
            {!defaultBannerFailed && (
              <img
                src={resolvedBannerUrl}
                alt=""
                aria-hidden="true"
                referrerPolicy="no-referrer"
                className="absolute inset-0 h-full w-full object-cover opacity-90 transition-opacity duration-300"
                onError={() => {
                  if (customBannerUrl && !bannerFailed) {
                    setBannerFailed(true);
                  } else {
                    setDefaultBannerFailed(true);
                  }
                }}
              />
            )}
            <div className="absolute inset-0 bg-[#070811]/25" />
            <div
              className="absolute inset-x-0 top-0 h-px z-10"
              style={{
                background:
                  'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.12) 25%, rgba(255,255,255,0.18) 50%, rgba(255,255,255,0.12) 75%, transparent 100%)',
              }}
            />
            <div
              className="absolute -top-24 -left-16 h-[28rem] w-[32rem] rounded-full opacity-20 blur-[90px]"
              style={{
                background:
                  'radial-gradient(circle, rgba(99,102,241,0.5) 0%, transparent 70%)',
              }}
            />
            <div
              className="absolute -top-28 right-0 h-[30rem] w-[34rem] rounded-full opacity-15 blur-[100px]"
              style={{
                background:
                  'radial-gradient(circle, rgba(99,102,241,0.5) 0%, rgba(139,92,246,0.18) 40%, transparent 70%)',
              }}
            />
            <div
              className="absolute bottom-0 inset-x-0 h-44 opacity-15 blur-3xl"
              style={{
                background:
                  'radial-gradient(ellipse 60% 50% at 50% 100%, rgba(99,102,241,0.35) 0%, transparent 80%)',
              }}
            />
            <div
              className="absolute inset-0 opacity-25"
              style={{
                backgroundImage:
                  'linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px)',
                backgroundSize: '24px 24px',
                maskImage:
                  'radial-gradient(ellipse 90% 80% at 50% 45%, black 45%, transparent 100%)',
                WebkitMaskImage:
                  'radial-gradient(ellipse 90% 80% at 50% 45%, black 45%, transparent 100%)',
              }}
            />
            <div
              className="absolute inset-0"
              style={{
                background:
                  'radial-gradient(ellipse 100% 90% at 50% 45%, transparent 60%, rgba(7,8,17,0.38) 100%)',
              }}
            />
          </div>

          <div className="absolute inset-x-0 top-0 h-20 sm:h-28 z-[1] bg-gradient-to-b from-[#070811]/75 via-[#070811]/25 to-transparent" />
          <div className="absolute inset-x-0 bottom-0 h-32 sm:h-40 z-[2] bg-gradient-to-t from-[#070811] via-[#070811]/60 to-transparent" />
        </div>
      </div>

      {/* ================= AVATAR + NAME ================= */}
      <div className="relative z-10 mx-auto max-w-7xl -mt-12 sm:-mt-14 lg:-mt-24 px-4 sm:px-6 md:px-8 pb-4 sm:pb-6">
        <div className="flex w-full flex-col items-center gap-4 lg:flex-row lg:items-end lg:justify-between lg:gap-8">
          <div className="flex flex-col items-center gap-4 lg:flex-row lg:items-end lg:gap-6">
            {/* Avatar + frame + crest */}
            <div className="relative shrink-0 h-24 w-24 sm:h-28 sm:w-28 lg:h-36 lg:w-36">
              <button
                type="button"
                onClick={isOwn ? onAvatarClick || onEditAvatar : undefined}
                className={`relative z-10 h-full w-full rounded-full bg-transparent border-0 p-0 ${
                  isOwn ? 'cursor-pointer group' : 'cursor-default'
                }`}
                aria-label={isOwn ? 'Change avatar' : `${displayName}'s avatar`}
              >
                <AvatarWithFrame
                  avatarUrl={user?.avatar_url}
                  frameUrl={user?.profile_frame_url}
                  username={username}
                  alt={displayName}
                  className="h-full w-full"
                  avatarClassName="border-4 border-[#070811] shadow-2xl"
                  loading="eager"
                />
              </button>

              <button
                type="button"
                className="group absolute -bottom-3 sm:-bottom-3.5 lg:-bottom-4 left-1/2 z-30 flex -translate-x-1/2 items-center justify-center cursor-pointer transition-all duration-300 hover:scale-[1.03] hover:brightness-115 active:scale-[0.98]"
                title={`Level ${level} (${tier.name})`}
                aria-label={`Level ${level} (${tier.name})`}
              >
                <LevelCrest level={level} size={44} />
              </button>
            </div>

            {/* Name + meta */}
            <div className="text-center lg:mt-3 lg:pb-2 lg:text-left min-w-0 max-w-full">
              <div className="mb-1 flex flex-wrap items-center justify-center gap-2 lg:justify-start">
                <TierUsername
                  as="h1"
                  name={displayName}
                  level={level}
                  xp={xp}
                  className="text-2xl font-extrabold tracking-tight sm:text-3xl max-w-full break-words"
                />

                {/* Verified tick */}
                <div className="relative group/tick">
                  <div
                    className="flex h-[22px] w-[22px] shrink-0 items-center justify-center rounded-full shadow-sm cursor-help bg-emerald-500"
                    aria-label="Verified Account"
                  >
                    <Check className="h-3.5 w-3.5 text-black" strokeWidth={3} />
                  </div>
                  <span className="pointer-events-none absolute left-1/2 top-full z-40 mt-1.5 -translate-x-1/2 whitespace-nowrap rounded-md border border-white/10 bg-[#0a0a0a] px-2 py-1 text-[10px] font-medium text-white opacity-0 shadow-xl backdrop-blur-md transition-opacity duration-150 group-hover/tick:opacity-100">
                    Verified Account
                  </span>
                </div>

                {/* Info button */}
                <button
                  ref={infoBtnRef}
                  onClick={handleInfoToggle}
                  className={`${iconBtnBase} text-zinc-200 hover:bg-white/10 hover:text-white`}
                  aria-label="Profile options"
                  title="Profile Info"
                >
                  <Info className="h-4 w-4" />
                </button>

                {/* ===== Compact Friend Action (between Info & Activity) ===== */}
                {!isOwn && (
                  <div className="relative">
                    {/* none → send request */}
                    {friendStatus === 'none' && (
                      <button
                        type="button"
                        onClick={handleSendRequest}
                        disabled={friendLoading}
                        className={`${iconBtnBase} text-zinc-200 hover:bg-white/10 hover:text-white disabled:opacity-50`}
                        aria-label="Add friend"
                        title="Add friend"
                      >
                        {friendLoading ? <LoaderCircle className="h-3.5 w-3.5 animate-spin" /> : <UserPlus className="h-4 w-4" />}
                      </button>
                    )}

                    {/* pending_sent → clock, click to cancel */}
                    {friendStatus === 'pending_sent' && (
                      <button
                        type="button"
                        onClick={() => handleRespondRequest('cancel')}
                        disabled={friendLoading}
                        className={`${iconBtnBase} text-amber-300 hover:bg-amber-500/10 disabled:opacity-50`}
                        aria-label="Cancel friend request"
                        title="Request sent — click to cancel"
                      >
                        {friendLoading ? <LoaderCircle className="h-3.5 w-3.5 animate-spin" /> : <Clock className="h-4 w-4" />}
                      </button>
                    )}

                    {/* pending_received → check, click to accept; secondary X to decline */}
                    {friendStatus === 'pending_received' && (
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => handleRespondRequest('accept')}
                          disabled={friendLoading}
                          className={`${iconBtnBase} text-emerald-300 hover:bg-emerald-500/10 disabled:opacity-50`}
                          aria-label="Accept friend request"
                          title="Accept friend request"
                        >
                          {friendLoading ? <LoaderCircle className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-4 w-4" />}
                        </button>
                        <button
                          type="button"
                          onClick={() => handleRespondRequest('decline')}
                          disabled={friendLoading}
                          className={`${iconBtnBase} text-rose-300 hover:bg-rose-500/10 disabled:opacity-50`}
                          aria-label="Decline friend request"
                          title="Decline friend request"
                        >
                          {friendLoading ? <LoaderCircle className="h-3.5 w-3.5 animate-spin" /> : <XIcon className="h-4 w-4" />}
                        </button>
                      </div>
                    )}

                    {/* friends → user-check, click to remove */}
                    {friendStatus === 'friends' && (
                      <button
                        type="button"
                        onClick={handleRemoveFriend}
                        disabled={friendLoading}
                        className={`${iconBtnBase} text-emerald-300 hover:bg-emerald-500/10 disabled:opacity-50`}
                        aria-label="Remove friend"
                        title="Friends — click to remove"
                      >
                        {friendLoading ? <LoaderCircle className="h-3.5 w-3.5 animate-spin" /> : <UserCheck className="h-4 w-4" />}
                      </button>
                    )}
                  </div>
                )}

                {/* Activity button */}
                <button
                  type="button"
                  onClick={onActivityClick}
                  className={`${iconBtnBase} text-zinc-200 hover:bg-white/10 hover:text-white`}
                  aria-label="View activity"
                  title="Activity"
                >
                  <Activity className="h-4 w-4" />
                </button>
              </div>

              {/* @username */}
              <p className="mb-2 hidden text-sm font-semibold text-zinc-200 drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)] lg:block">
                @{username}
              </p>

              {/* Joined + anime + friends count (single dark-gray line) */}
              <div className="flex flex-wrap items-center justify-center gap-3 text-xs text-zinc-300 drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)] lg:justify-start">
                {joined && (
                  <span className="flex items-center gap-1.5">
                    <Calendar className="h-3.5 w-3.5 text-zinc-400" />
                    Joined {joined}
                  </span>
                )}

                <span className="flex items-center gap-1.5">
                  <Tv className="h-3.5 w-3.5 text-zinc-400" />
                  {showsCount} shows
                </span>

                <span className="flex items-center gap-1.5">
                  <Users className="h-3.5 w-3.5 text-zinc-400" />
                  {friendsCount} {friendsCount === 1 ? 'friend' : 'friends'}
                </span>
              </div>

              {/* XP bar */}
              <div className="mt-2 flex w-[170px] lg:w-full lg:max-w-[240px] flex-col justify-center mx-auto lg:mx-0">
                <XpProgressBar xp={xp} level={level} hideLevelOnMobile />
              </div>
            </div>
          </div>

          {/* Right: stats duo */}
          {(isOwn || Number(user?.show_stats) !== 0) && (
            <div className="flex shrink-0 gap-6 pb-2 sm:gap-8 lg:gap-12 lg:pb-0">
              <div className="text-center">
                <div className="text-xl font-bold text-white tabular-nums drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] sm:text-2xl lg:text-3xl">
                  {watchingCount}
                </div>
                <div className="text-[10px] font-bold tracking-wider text-zinc-300 uppercase drop-shadow-[0_1px_3px_rgba(0,0,0,0.9)]">
                  Watching
                </div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold text-white tabular-nums drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] sm:text-2xl lg:text-3xl">
                  {completedAnime}
                </div>
                <div className="text-[10px] font-bold tracking-wider text-zinc-300 uppercase drop-shadow-[0_1px_3px_rgba(0,0,0,0.9)]">
                  Completed
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <ProfileInfoModal
        open={infoOpen}
        onClose={() => setInfoOpen(false)}
        username={username}
        level={level}
        xp={xp}
        profileUrl={profileUrl}
        anchorRef={infoBtnRef}
      />
    </>
  );
};