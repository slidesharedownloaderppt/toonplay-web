import { useEffect, useMemo, useRef, useState } from 'react';
import { X, Loader2, Check, Search, RotateCcw } from 'lucide-react';
import {
  DEFAULT_PROFILE_BANNER_URL,
  fetchBannerCatalog,
  type BannerCatalogCategory,
} from '../../api';
import { userApi } from '../../lib/api';
import { toast } from 'sonner';

interface Props {
  open: boolean;
  currentBannerUrl: string | null;
  onClose: () => void;
  onSaved: (newUrl: string | null) => void;
}

export function BannerPickerModal({
  open,
  currentBannerUrl,
  onClose,
  onSaved,
}: Props) {
  const [categories, setCategories] = useState<BannerCatalogCategory[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<string | null>(currentBannerUrl);
  const [visible, setVisible] = useState(false);
  const closeTimerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (closeTimerRef.current !== null) window.clearTimeout(closeTimerRef.current);
    };
  }, []);

  useEffect(() => {
    if (!open) {
      setVisible(false);
      return;
    }
    if (closeTimerRef.current !== null) {
      window.clearTimeout(closeTimerRef.current);
      closeTimerRef.current = null;
    }
    setSelected(currentBannerUrl);
    setSearch('');
    setActiveCategory('All');
    const raf = requestAnimationFrame(() => setVisible(true));
    return () => cancelAnimationFrame(raf);
  }, [open, currentBannerUrl]);

  useEffect(() => {
    if (!open || categories.length > 0) return;
    let cancelled = false;
    setLoading(true);
    fetchBannerCatalog()
      .then((res) => {
        if (!cancelled) setCategories(res.categories);
      })
      .catch((err) => {
        if (cancelled) return;
        console.error('[banner catalog]', err);
        toast.error('Could not load banners — check your connection');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [open, categories.length]);

  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') handleClose();
    };
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener('keydown', onKey);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, saving]);

  const totalCount = useMemo(
    () => categories.reduce((sum, c) => sum + c.banners.length, 0),
    [categories]
  );

  const filteredCategories = useMemo(() => {
    const q = search.trim().toLowerCase();
    const scoped =
      activeCategory === 'All'
        ? categories
        : categories.filter((c) => c.label === activeCategory);

    if (!q) return scoped;
    return scoped
      .map((cat) => {
        const catMatches = cat.label.toLowerCase().includes(q);
        return {
          ...cat,
          banners: catMatches
            ? cat.banners
            : cat.banners.filter((b) => b.label.toLowerCase().includes(q)),
        };
      })
      .filter((cat) => cat.banners.length > 0);
  }, [categories, activeCategory, search]);

  const previewUrl = selected || DEFAULT_PROFILE_BANNER_URL;
  const normalizedCurrent = currentBannerUrl || null;
  const normalizedSelected =
    selected && selected !== DEFAULT_PROFILE_BANNER_URL ? selected : null;
  const canSave = !saving && normalizedSelected !== normalizedCurrent;

  const scheduleClose = () => {
    setVisible(false);
    if (closeTimerRef.current !== null) window.clearTimeout(closeTimerRef.current);
    closeTimerRef.current = window.setTimeout(() => {
      closeTimerRef.current = null;
      onClose();
    }, 200);
  };

  const handleClose = () => {
    if (saving) return;
    scheduleClose();
  };

  const handleSave = async () => {
    if (!canSave) return;
    setSaving(true);
    try {
      await userApi.updateProfile({ profile_banner_url: normalizedSelected });
      toast.success(
        normalizedSelected
          ? 'Public profile banner updated'
          : 'Restored default profile banner'
      );
      onSaved(normalizedSelected);
      scheduleClose();
    } catch (err: any) {
      toast.error(err?.message || 'Failed to update banner');
    } finally {
      setSaving(false);
    }
  };

  const handleResetDefault = async () => {
    if (saving) return;
    setSaving(true);
    try {
      await userApi.updateProfile({ profile_banner_url: null });
      toast.success('Default banner restored');
      onSaved(null);
      scheduleClose();
    } catch (err: any) {
      toast.error(err?.message || 'Failed to reset banner');
    } finally {
      setSaving(false);
    }
  };

  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Profile banner picker"
      onClick={handleClose}
      className="fixed inset-0 z-[220] flex items-start sm:items-center justify-center p-2 sm:p-6 overflow-y-auto bg-black/80 backdrop-blur-sm transition-opacity duration-200 ease-out"
      style={{ opacity: visible ? 1 : 0 }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-3xl bg-[#0b0d16] border border-[#2e3252] rounded-2xl shadow-2xl shadow-black/80 my-4 sm:my-6 overflow-hidden"
        style={{
          transform: visible
            ? 'translateY(0) scale(1)'
            : 'translateY(12px) scale(0.96)',
          opacity: visible ? 1 : 0,
          transition:
            'transform 220ms cubic-bezier(0.22, 1, 0.36, 1), opacity 180ms ease',
        }}
      >
        {/* Header */}
        <div className="px-4 sm:px-6 pt-4 pb-3 border-b border-[#23263f] flex items-start justify-between gap-3">
          <div>
            <h2 className="text-base font-semibold text-white tracking-tight">
              Public Profile Banner
            </h2>

<p className="text-[11px] text-slate-500 mt-0.5">
  Personalize your public profile with a custom banner.
  {totalCount > 0 ? ` · ${totalCount} banners available` : ''}
</p>

          </div>
          <button
            type="button"
            onClick={handleClose}
            aria-label="Close"
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#1c2038] transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Live Preview + Search + Category Filter */}
        <div className="px-4 sm:px-6 py-3 border-b border-[#23263f] bg-[#0d1019] space-y-3">
          <div className="relative h-24 sm:h-32 w-full rounded-xl overflow-hidden border border-[#2e3252] bg-[#070811]">
            <img
              src={previewUrl}
              alt="Selected banner preview"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover opacity-90"
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src =
                  DEFAULT_PROFILE_BANNER_URL;
              }}
            />
            <div className="absolute inset-0 bg-[#070811]/25" />
            <div className="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-[#070811] via-[#070811]/55 to-transparent" />
            <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between gap-2">
              <span className="text-[11px] font-medium text-white drop-shadow">
                {normalizedSelected ? 'Custom Banner Preview' : 'Default Banner'}
              </span>
              <span className="text-[10px] text-slate-300/90 drop-shadow">
                Public Profile Only
              </span>
            </div>
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search banners by anime..."
              className="w-full bg-[#06070d] border border-[#23263f] rounded-lg pl-8 pr-2.5 py-1.5 text-[11px] text-white placeholder:text-slate-600 focus:outline-none focus:border-indigo-500/60"
            />
          </div>

          {categories.length > 0 && (
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 thin-scrollbar">
              <button
                type="button"
                onClick={() => setActiveCategory('All')}
                className={`shrink-0 px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors cursor-pointer border ${
                  activeCategory === 'All'
                    ? 'bg-indigo-600 text-white border-indigo-500'
                    : 'bg-[#06070d] text-slate-400 hover:text-white border-[#23263f]'
                }`}
              >
                All ({totalCount})
              </button>
              {categories.map((cat) => (
                <button
                  key={cat.label}
                  type="button"
                  onClick={() => setActiveCategory(cat.label)}
                  className={`shrink-0 px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors cursor-pointer border ${
                    activeCategory === cat.label
                      ? 'bg-indigo-600 text-white border-indigo-500'
                      : 'bg-[#06070d] text-slate-400 hover:text-white border-[#23263f]'
                  }`}
                >
                  {cat.label}{' '}
                  <span className="opacity-65">({cat.banners.length})</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Body */}
        {loading ? (
          <div className="h-64 flex items-center justify-center">
            <Loader2 className="w-5 h-5 animate-spin text-indigo-400" />
          </div>
        ) : categories.length === 0 ? (
          <div className="h-64 flex flex-col items-center justify-center gap-2 text-xs text-slate-500 px-6 text-center">
            <p>Could not load banners.</p>
            <button
              type="button"
              onClick={() => {
                setLoading(true);
                fetchBannerCatalog()
                  .then((res) => setCategories(res.categories))
                  .catch(() => toast.error('Still failing — check your network'))
                  .finally(() => setLoading(false));
              }}
              className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-semibold cursor-pointer transition-colors"
            >
              Retry
            </button>
          </div>
        ) : filteredCategories.length === 0 ? (
          <div className="h-64 flex items-center justify-center text-xs text-slate-500 px-4 text-center">
            No banners match &quot;{search}&quot;.
          </div>
        ) : (
          <div className="max-h-[48vh] sm:max-h-[380px] overflow-y-auto thin-scrollbar">
            {filteredCategories.map((cat) => (
              <div
                key={cat.label}
                className="border-b border-[#23263f] last:border-b-0"
              >
                <div className="px-4 sm:px-6 pt-3.5 pb-2 flex items-baseline gap-2">
                  <span className="text-xs font-semibold text-white">
                    {cat.label}
                  </span>
                  <span className="text-[10px] text-slate-500">
                    {cat.banners.length}{' '}
                    {cat.banners.length === 1 ? 'banner' : 'banners'}
                  </span>
                </div>

                <div className="px-4 sm:px-6 pb-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                  {cat.banners.map((b) => {
                    const isDefaultCard = Boolean(b.isDefault);
                    const isSelected = isDefaultCard
                      ? !normalizedSelected
                      : selected === b.url;

                    return (
                      <button
                        key={`${cat.label}:${b.id}`}
                        type="button"
                        onClick={() =>
                          setSelected(isDefaultCard ? null : b.url)
                        }
                        aria-pressed={isSelected}
                        className={`relative aspect-[16/7] rounded-xl overflow-hidden border-2 transition-colors cursor-pointer group text-left ${
                          isSelected
                            ? 'border-indigo-500 ring-2 ring-indigo-500/40'
                            : 'border-[#23263f] hover:border-[#3a3f66]'
                        }`}
                      >
                        <img
                          src={b.url}
                          alt={b.label}
                          loading="lazy"
                          decoding="async"
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/15 to-transparent" />
                        <span className="absolute bottom-1.5 left-2 right-7 text-[10px] font-medium text-white truncate drop-shadow">
                          {isDefaultCard ? 'Default Banner' : b.label}
                        </span>
                        {isSelected && (
                          <span className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-indigo-600 flex items-center justify-center shadow">
                            <Check className="w-3 h-3 text-white" />
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Footer */}
        <div className="px-4 sm:px-6 py-3 border-t border-[#23263f] flex flex-wrap items-center gap-2 bg-[#0d1019]">
          <button
            type="button"
            onClick={handleResetDefault}
            disabled={saving || !currentBannerUrl}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-transparent hover:bg-slate-800/60 border border-[#23263f] text-slate-300 text-[11px] font-medium disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors"
          >
            <RotateCcw className="w-3 h-3" />
            Reset to default
          </button>

          <div className="flex-1" />

          <button
            type="button"
            onClick={handleClose}
            disabled={saving}
            className="px-3 py-1.5 rounded-lg bg-[#14172b] hover:bg-[#1c2038] border border-[#23263f] text-slate-300 text-[11px] font-medium disabled:opacity-50 cursor-pointer transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={!canSave}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-semibold disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer transition-colors"
          >
            {saving ? (
              <Loader2 className="w-3 h-3 animate-spin" />
            ) : (
              <Check className="w-3 h-3" />
            )}
            <span>{saving ? 'Saving…' : 'Save banner'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
