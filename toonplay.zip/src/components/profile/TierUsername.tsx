import React from 'react';
import { getLevelProgress, getXpTier, type XpTierName } from '../../lib/xpTiers';

export interface TierUsernameProps {
  name: string;
  level?: number | null;
  xp?: number | null;
  as?: 'span' | 'h1' | 'h2' | 'h3' | 'p';
  className?: string;
  title?: string;
}

/**
 * Strict minimum level required to unlock the premium anime-inspired
 * animated username system (including kinetic per-character motion).
 * Levels 1–29 (Bronze, Silver, Gold) strictly keep the existing standard
 * tier styling with stationary characters.
 */
export const PREMIUM_ANIMATION_MIN_LEVEL = 30;

export type AnimeUsernameStyle =
  | 'cryo-lightning'
  | 'phantom-crystal'
  | 'sakura-storm'
  | 'sovereign-gold'
  | 'inferno-blaze'
  | 'emerald-overdrive'
  | 'crimson-eclipse'
  | 'starfall-astral'
  | 'nebula-prism'
  | 'solar-divinity'
  | 'transcendent-aurora';

const TIER_CLASS_MAP: Record<XpTierName, string> = {
  Bronze: 'tp-tier-name-bronze',
  Silver: 'tp-tier-name-silver',
  Gold: 'tp-tier-name-gold',
  Platinum: 'tp-tier-name-platinum',
  Diamond: 'tp-tier-name-diamond',
  Mythic: 'tp-tier-name-mythic',
  Legend: 'tp-tier-name-legend',
  Champion: 'tp-tier-name-champion',
  Hero: 'tp-tier-name-hero',
  Immortal: 'tp-tier-name-immortal',
  Celestial: 'tp-tier-name-celestial',
  Cosmic: 'tp-tier-name-cosmic',
  Divine: 'tp-tier-name-divine',
  God: 'tp-tier-name-god',
};

/**
 * Distinct anime-inspired visual & kinetic character-motion themes mapped
 * strictly to the 11 existing Level 30+ tiers (Platinum through God).
 * Levels 1–29 intentionally map to null.
 */
export const TIER_ANIME_STYLE_MAP: Record<XpTierName, AnimeUsernameStyle | null> = {
  Bronze: null,
  Silver: null,
  Gold: null,
  Platinum: 'cryo-lightning',
  Diamond: 'phantom-crystal',
  Mythic: 'sakura-storm',
  Legend: 'sovereign-gold',
  Champion: 'inferno-blaze',
  Hero: 'emerald-overdrive',
  Immortal: 'crimson-eclipse',
  Celestial: 'starfall-astral',
  Cosmic: 'nebula-prism',
  Divine: 'solar-divinity',
  God: 'transcendent-aurora',
};

/**
 * Splits a username into Unicode-safe graphemes so surrogate pairs / emojis
 * never tear when animating individual characters for Level 30+ users.
 */
export function splitUsernameGraphemes(text: string): string[] {
  if (!text) return [];
  const IntlWithSegmenter = Intl as typeof Intl & {
    Segmenter?: new (
      locales?: string | string[],
      options?: { granularity?: 'grapheme' | 'word' | 'sentence' }
    ) => { segment: (input: string) => Iterable<{ segment: string }> };
  };
  if (typeof Intl !== 'undefined' && typeof IntlWithSegmenter.Segmenter === 'function') {
    const segmenter = new IntlWithSegmenter.Segmenter(undefined, {
      granularity: 'grapheme',
    });
    return Array.from(segmenter.segment(text), (s) => s.segment);
  }
  return Array.from(text);
}

/**
 * Resolves the user's effective level strictly from backend-provided level / XP
 * using the existing XP progression formula in `src/lib/xpTiers.ts` and `server.ts`.
 */
export function resolveEffectiveLevel(level?: number | null, xp?: number | null): number {
  const rawLevel = Number(level || 0);
  const numericLevel = Number.isFinite(rawLevel) ? Math.floor(rawLevel) : 0;
  const rawXp = Number(xp || 0);
  if (Number.isFinite(rawXp) && rawXp > 0) {
    const derived = getLevelProgress(rawXp).level;
    return Math.max(1, Math.max(numericLevel || 1, derived));
  }
  return Math.max(1, numericLevel || 1);
}

/**
 * Strict Level 30+ eligibility gate for the premium anime-inspired username
 * animation system (including moving text characters). Always computed from
 * backend-provided level/XP.
 */
export function isPremiumUsernameEligible(
  level?: number | null,
  xp?: number | null
): boolean {
  return resolveEffectiveLevel(level, xp) >= PREMIUM_ANIMATION_MIN_LEVEL;
}

export interface TierUsernameStyleInfo {
  effectiveLevel: number;
  tierName: XpTierName;
  tierClass: string;
  fallbackColor: string;
  isPremiumAnime: boolean;
  hasAnimatedCharacters: boolean;
  animeStyle: AnimeUsernameStyle | null;
}

export function getTierUsernameClass(
  level?: number | null,
  xp?: number | null
): TierUsernameStyleInfo {
  const effectiveLevel = resolveEffectiveLevel(level, xp);
  const tier = getXpTier(effectiveLevel);
  const isPremiumAnime = effectiveLevel >= PREMIUM_ANIMATION_MIN_LEVEL;
  const animeStyle = isPremiumAnime ? TIER_ANIME_STYLE_MAP[tier.name] : null;

  const classes = ['tp-tier-name', TIER_CLASS_MAP[tier.name]];
  if (isPremiumAnime) {
    classes.push('tp-tier-premium');
    if (effectiveLevel >= 40 && tier.name === 'Platinum') {
      classes.push('tp-tier-premium-ascended');
    }
  }

  return {
    effectiveLevel,
    tierName: tier.name,
    tierClass: classes.join(' '),
    fallbackColor: tier.light,
    isPremiumAnime,
    hasAnimatedCharacters: isPremiumAnime,
    animeStyle,
  };
}

/**
 * Centralized username presentation component used across the entire site
 * (Public Profile, User Activity, Leaderboard, Global Header, Settings, Friends, Info Modal).
 *
 * - Levels 1–29 (Bronze, Silver, Gold): renders existing tier-based styling
 *   as stationary text.
 * - Levels 30+ (Platinum through God): unlocks the premium anime-inspired
 *   presentation where every character in the username physically animates
 *   with tier-specific kinetic motion, moving specular text gradients,
 *   glowing auras, and atmospheric particle overlays.
 */
export const TierUsername: React.FC<TierUsernameProps> = ({
  name,
  level,
  xp,
  as = 'span',
  className = '',
  title,
}) => {
  const {
    effectiveLevel,
    tierName,
    tierClass,
    fallbackColor,
    isPremiumAnime,
    hasAnimatedCharacters,
    animeStyle,
  } = getTierUsernameClass(level, xp);
  const Tag = as;

  const renderAnimatedCharacters = () => {
    const tokens = name.split(/(\s+)/);
    let charIndex = 0;

    return tokens.map((token, tokenIdx) => {
      if (!token) return null;
      if (/^\s+$/.test(token)) {
        return (
          <span key={`sp-${tokenIdx}`} className="tp-tier-space" aria-hidden="true">
            {token}
          </span>
        );
      }

      const graphemes = splitUsernameGraphemes(token);
      return (
        <span key={`w-${tokenIdx}`} className="tp-tier-word" aria-hidden="true">
          {graphemes.map((char, idx) => {
            const currentIndex = charIndex++;
            return (
              <span
                key={`c-${tokenIdx}-${idx}`}
                className="tp-tier-char"
                style={{ '--tp-char-i': currentIndex } as React.CSSProperties}
              >
                {char}
              </span>
            );
          })}
        </span>
      );
    });
  };

  return (
    <Tag
      className={`${tierClass} ${className}`.trim()}
      style={{ '--tp-tier-fallback': fallbackColor } as React.CSSProperties}
      data-tier={tierName.toLowerCase()}
      data-level={effectiveLevel}
      data-premium-anime={isPremiumAnime ? 'true' : 'false'}
      data-animated-chars={hasAnimatedCharacters ? 'true' : 'false'}
      data-anime-style={animeStyle || undefined}
      aria-label={hasAnimatedCharacters ? name : undefined}
      title={title}
    >
      {hasAnimatedCharacters ? renderAnimatedCharacters() : name}
    </Tag>
  );
};
