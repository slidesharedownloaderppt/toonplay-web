import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { User as UserIcon, Link as LinkIcon, Check } from 'lucide-react';
import { TierUsername } from './TierUsername';

interface Props {
  open: boolean;
  onClose: () => void;
  username: string;
  level?: number | null;
  xp?: number | null;
  profileUrl: string;
  anchorRef?: React.RefObject<HTMLElement | null>;
  onCopied?: () => void;
}

export const ProfileInfoModal: React.FC<Props> = ({
  open,
  onClose,
  username,
  level,
  xp,
  profileUrl,
  anchorRef,
  onCopied,
}) => {
  const [visible, setVisible] = useState(false);
  const [copied, setCopied] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState<{ top: number; left: number } | null>(null);

  useEffect(() => {
    if (open) {
      const id = requestAnimationFrame(() => setVisible(true));
      return () => cancelAnimationFrame(id);
    }
    setVisible(false);
  }, [open]);

  useLayoutEffect(() => {
    if (!open) {
      setPos(null);
      return;
    }

    let rafId = 0;

    const update = () => {
      rafId = 0;
      const btn = anchorRef?.current;
      if (!btn) return;
      const rect = btn.getBoundingClientRect();
      if (rect.width === 0 && rect.height === 0) return;

      const cardW = cardRef.current?.offsetWidth ?? 240;
      const halfW = cardW / 2;
      const rawLeft = rect.left + rect.width / 2;
      const clampedLeft = Math.max(
        halfW + 8,
        Math.min(window.innerWidth - halfW - 8, rawLeft)
      );

      const next = { top: rect.bottom + 8, left: clampedLeft };
      setPos((prev) =>
        prev && prev.top === next.top && prev.left === next.left ? prev : next
      );
    };

    const scheduleUpdate = () => {
      if (rafId !== 0) return;
      rafId = requestAnimationFrame(update);
    };

    update();
    // Re-measure once after initial portal mount so actual cardRef.offsetWidth is used
    scheduleUpdate();

    let ro: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined') {
      ro = new ResizeObserver(scheduleUpdate);
      if (anchorRef?.current) ro.observe(anchorRef.current);
      if (cardRef.current) ro.observe(cardRef.current);
    }

    window.addEventListener('resize', scheduleUpdate, { passive: true });
    window.addEventListener('scroll', scheduleUpdate, { capture: true, passive: true });

    return () => {
      if (rafId !== 0) cancelAnimationFrame(rafId);
      ro?.disconnect();
      window.removeEventListener('resize', scheduleUpdate);
      window.removeEventListener('scroll', scheduleUpdate, true);
    };
  }, [open, anchorRef]);

  useEffect(() => {
    if (!open) return;

    const onDocClick = (e: MouseEvent) => {
      const target = e.target as Node;
      if (cardRef.current?.contains(target)) return;
      if (anchorRef?.current?.contains(target)) return;
      onClose();
    };

    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };

    const id = window.setTimeout(() => {
      document.addEventListener('mousedown', onDocClick);
      document.addEventListener('keydown', onKey);
    }, 0);

    return () => {
      window.clearTimeout(id);
      document.removeEventListener('mousedown', onDocClick);
      document.removeEventListener('keydown', onKey);
    };
  }, [open, onClose, anchorRef]);

  useEffect(() => {
    if (!copied) return;
    const t = window.setTimeout(() => setCopied(false), 2000);
    return () => window.clearTimeout(t);
  }, [copied]);

  const handleCopy = async () => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(profileUrl);
      } else {
        const input = document.createElement('input');
        input.value = profileUrl;
        document.body.appendChild(input);
        input.select();
        document.execCommand('copy');
        document.body.removeChild(input);
      }
      setCopied(true);
      onCopied?.();
    } catch {
      /* silent */
    }
  };

  if (!open || !pos) return null;

  const content = (
    <div
      ref={cardRef}
      role="menu"
      aria-label="Profile info"
      className={`fixed w-max min-w-[160px] max-w-[min(280px,calc(100vw-24px))] rounded-lg border border-white/10 bg-[#0a0a0a] p-1 shadow-xl backdrop-blur-md transition-opacity duration-150 ease-out ${
        visible ? 'opacity-100' : 'opacity-0 pointer-events-none'
      }`}
      style={{
        top: pos.top,
        left: pos.left,
        zIndex: 30,
        transform: 'translateX(-50%)',
      }}
      onClick={(e) => e.stopPropagation()}
    >
      <div className="flex w-full min-w-0 items-start gap-2 rounded-md px-2 py-1.5 text-sm text-gray-300">
        <UserIcon className="h-3.5 w-3.5 shrink-0 text-gray-400 mt-0.5" />
        <span className="min-w-0 flex-1 break-words leading-snug">
          Also known as{' '}
          <TierUsername
            name={`@${username}`}
            level={level}
            xp={xp}
            className="font-semibold break-all"
          />
        </span>
      </div>

      <button
        type="button"
        onClick={handleCopy}
        className="flex w-full min-w-0 items-start gap-2 rounded-md px-2 py-1.5 text-left text-sm text-gray-300 transition-colors hover:bg-white/10 hover:text-white cursor-pointer"
      >
        {copied ? (
          <Check className="h-3.5 w-3.5 shrink-0 text-emerald-400 mt-0.5" />
        ) : (
          <LinkIcon className="h-3.5 w-3.5 shrink-0 text-gray-400 mt-0.5" />
        )}
        <span
          className={`min-w-0 flex-1 break-words leading-snug ${copied ? 'text-emerald-400' : ''}`}
        >
          {copied ? 'Copied!' : 'Copy Profile URL'}
        </span>
      </button>
    </div>
  );

  return createPortal(content, document.body);
};