import React, { useEffect, useState, useCallback, useRef } from 'react';
import { X } from 'lucide-react';
import { LoginPage } from './LoginPage';
import { RegisterPage } from './RegisterPage';
import { ForgotPasswordPage } from './ForgotPasswordPage';

export type AuthStep = 'login' | 'register' | 'forgot-password';

interface AuthModalProps {
  isOpen: boolean;
  initialStep?: AuthStep;
  onClose: () => void;
  onSuccess?: () => void;
  onNavigate?: (path: string) => void;
}

export function AuthModal({
  isOpen,
  initialStep = 'login',
  onClose,
  onSuccess,
  onNavigate,
}: AuthModalProps) {
  const [step, setStep] = useState<AuthStep>(initialStep);
  const [visible, setVisible] = useState(false);
  const closeTimerRef = useRef<number | null>(null);
  const safeNavigate = onNavigate ?? (() => {});

  useEffect(() => {
    return () => {
      if (closeTimerRef.current !== null) window.clearTimeout(closeTimerRef.current);
    };
  }, []);

  // Reset step + fade in when opened
  useEffect(() => {
    if (isOpen) {
      if (closeTimerRef.current !== null) {
        window.clearTimeout(closeTimerRef.current);
        closeTimerRef.current = null;
      }
      setStep(initialStep);
      const raf = requestAnimationFrame(() => setVisible(true));
      return () => cancelAnimationFrame(raf);
    } else {
      setVisible(false);
    }
  }, [isOpen, initialStep]);

  // Lock scroll
  useEffect(() => {
    if (!isOpen) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prev;
    };
  }, [isOpen]);

  const handleClose = useCallback(() => {
    setVisible(false);
    if (closeTimerRef.current !== null) window.clearTimeout(closeTimerRef.current);
    // Let the fade-out finish before unmounting
    closeTimerRef.current = window.setTimeout(() => {
      closeTimerRef.current = null;
      onClose();
    }, 180);
  }, [onClose]);

  // Escape closes
  useEffect(() => {
    if (!isOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') handleClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [isOpen, handleClose]);

  const handleSuccess = () => {
    onSuccess?.();
    handleClose();
  };

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Authentication"
      className="fixed inset-0 z-[300] flex items-start justify-center p-3 sm:p-6 overflow-y-auto overflow-x-hidden bg-black/80 backdrop-blur-sm transition-opacity duration-200 ease-out"
      onClick={handleClose}
      style={{ opacity: visible ? 1 : 0 }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-md max-h-[calc(100dvh-1.5rem)] bg-[#14172b] border border-[#2e3252] rounded-2xl shadow-2xl shadow-black/80 my-auto overflow-hidden flex flex-col"
        style={{
          transform: visible ? 'translateY(0)' : 'translateY(12px)',
          opacity: visible ? 1 : 0,
          transition:
            'transform 260ms cubic-bezier(0.22, 1, 0.36, 1), opacity 220ms ease',
        }}
      >
        {/* Progress dots — visual indicator of the 3 auth steps */}
        <div className="flex items-center justify-center gap-1.5 pt-4 pb-1 shrink-0">
          {(['login', 'register', 'forgot-password'] as AuthStep[]).map((s) => (
            <span
              key={s}
              className={`h-1 rounded-full transition-all duration-300 ${
                step === s ? 'w-6 bg-indigo-500' : 'w-1.5 bg-[#2e3252]'
              }`}
            />
          ))}
        </div>

        <button
          type="button"
          onClick={handleClose}
          aria-label="Close"
          className="absolute top-3 right-3 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#1c2038] transition-colors cursor-pointer z-10"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="px-6 pb-6 sm:px-8 sm:pb-8 min-h-[420px] overflow-y-auto overflow-x-hidden flex-1 auth-modal-scroll">
          {/* Step content with crossfade */}
          <div
            key={step}
            className="animate-in fade-in slide-in-from-bottom-2 duration-200"
          >
            {step === 'login' && (
              <LoginPage
                variant="modal"
                onNavigate={safeNavigate}
                onSwitchStep={(next) => setStep(next)}
                onSuccess={handleSuccess}
              />
            )}

            {step === 'register' && (
              <RegisterPage
                variant="modal"
                onNavigate={safeNavigate}
                onSwitchStep={(next) => setStep(next)}
                onSuccess={handleSuccess}
              />
            )}

            {step === 'forgot-password' && (
              <ForgotPasswordPage
                variant="modal"
                onNavigate={safeNavigate}
                onSwitchStep={(next) => setStep(next)}
                onSuccess={handleSuccess}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}