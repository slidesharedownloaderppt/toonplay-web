import React, { useEffect, useState, useCallback } from 'react';
import { X } from 'lucide-react';
import { LoginPage } from './LoginPage';
import { RegisterPage } from './RegisterPage';
import { ForgotPasswordPage } from './ForgotPasswordPage';

export type AuthStep = 'login' | 'register' | 'forgot-password';

interface AuthModalProps {
  isOpen: boolean;
  initialStep?: AuthStep;
  onClose: () => void;
  onSuccess?: () => void;
  onNavigate?: (path: string) => void;
}

const STEP_KEY_TO_INDEX: Record<AuthStep, number> = {
  login: 0,
  register: 1,
  'forgot-password': 2,
};

export function AuthModal({
  isOpen,
  initialStep = 'login',
  onClose,
  onSuccess,
  onNavigate,
}: AuthModalProps) {
  const [step, setStep] = useState<AuthStep>(initialStep);
  const [visible, setVisible] = useState(false);
  const safeNavigate = onNavigate ?? (() => {});

  // Reset step + fade in when opened
  useEffect(() => {
    if (isOpen) {
      setStep(initialStep);
      const raf = requestAnimationFrame(() => setVisible(true));
      return () => cancelAnimationFrame(raf);
    } else {
      setVisible(false);
    }
  }, [isOpen, initialStep]);

  // Lock scroll
  useEffect(() => {
    if (!isOpen) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prev;
    };
  }, [isOpen]);

  const handleClose = useCallback(() => {
    setVisible(false);
    // Let the fade-out finish before unmounting
    setTimeout(() => onClose(), 180);
  }, [onClose]);

  // Escape closes
  useEffect(() => {
    if (!isOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') handleClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [isOpen, handleClose]);

  const handleSuccess = () => {
    onSuccess?.();
    handleClose();
  };

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Authentication"
      className="fixed inset-0 z-[300] flex items-start justify-center p-3 sm:p-6 overflow-y-auto overflow-x-hidden"
      onClick={handleClose}
      style={{
        backgroundColor: visible ? 'rgba(0,0,0,0.78)' : 'rgba(0,0,0,0)',
        backdropFilter: visible ? 'blur(8px)' : 'blur(0px)',
        transition: 'background-color 220ms ease, backdrop-filter 220ms ease',
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-md max-h-[calc(100dvh-1.5rem)] bg-[#14172b] border border-[#2e3252] rounded-2xl shadow-2xl shadow-black/80 my-auto overflow-hidden flex flex-col"
        style={{
          transform: visible ? 'translateY(0)' : 'translateY(12px)',
          opacity: visible ? 1 : 0,
          transition:
            'transform 260ms cubic-bezier(0.22, 1, 0.36, 1), opacity 220ms ease',
        }}
      >
        {/* Progress dots — visual indicator of the 3 auth steps */}
        <div className="flex items-center justify-center gap-1.5 pt-4 pb-1 shrink-0">
          {(['login', 'register', 'forgot-password'] as AuthStep[]).map((s) => (
            <span
              key={s}
              className={`h-1 rounded-full transition-all duration-300 ${
                step === s ? 'w-6 bg-indigo-500' : 'w-1.5 bg-[#2e3252]'
              }`}
            />
          ))}
        </div>

        <button
          type="button"
          onClick={handleClose}
          aria-label="Close"
          className="absolute top-3 right-3 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#1c2038] transition-colors cursor-pointer z-10"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="px-6 pb-6 sm:px-8 sm:pb-8 min-h-[420px] overflow-y-auto overflow-x-hidden flex-1 auth-modal-scroll">
          {/* Step content with crossfade */}
          <div
            key={step}
            className="animate-in fade-in slide-in-from-bottom-2 duration-200"
          >
            {step === 'login' && (
              <LoginPage
                variant="modal"
                onNavigate={safeNavigate}
                onSwitchStep={(next) => setStep(next)}
                onSuccess={handleSuccess}
              />
            )}

            {step === 'register' && (
              <RegisterPage
                variant="modal"
                onNavigate={safeNavigate}
                onSwitchStep={(next) => setStep(next)}
                onSuccess={handleSuccess}
              />
            )}

            {step === 'forgot-password' && (
              <ForgotPasswordPage
                variant="modal"
                onNavigate={safeNavigate}
                onSwitchStep={(next) => setStep(next)}
                onSuccess={handleSuccess}
              />
            )}
          </div>
        </div>
      </div>

      {/* Thin scrollbar for the modal content */}
      <style>{`
        .auth-modal-scroll {
          scrollbar-width: thin;
          scrollbar-color: #3a3f63 transparent;
        }
        .auth-modal-scroll::-webkit-scrollbar {
          width: 6px;
          height: 0;
        }
        .auth-modal-scroll::-webkit-scrollbar-track {
          background: transparent;
        }
        .auth-modal-scroll::-webkit-scrollbar-thumb {
          background-color: #3a3f63;
          border-radius: 9999px;
        }
        .auth-modal-scroll::-webkit-scrollbar-thumb:hover {
          background-color: #4a5080;
        }
      `}</style>
    </div>
  );
}