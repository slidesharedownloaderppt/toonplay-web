import { useState, FormEvent } from 'react';
import { ArrowLeft } from 'lucide-react';
import { authApi, setToken } from '../../lib/api';
import { useAuth } from '../../context/AuthContext';
import { toast } from 'sonner';

type Step = 'email' | 'otp' | 'reset';

interface Props {
  onNavigate: (path: string) => void;
  variant?: 'page' | 'modal';
  onSwitchStep?: (step: 'login' | 'register' | 'forgot-password') => void;
  onSuccess?: () => void;
}

export function ForgotPasswordPage({
  onNavigate,
  variant = 'page',
  onSwitchStep,
  onSuccess,
}: Props) {
  const { refresh } = useAuth();
  const [step, setStep] = useState<Step>('email');
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [resetToken, setResetToken] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isModal = variant === 'modal';

  const handleEmail = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await authApi.forgotPassword(email.trim());
      toast.success('If that email exists, a code has been sent.');
      setStep('otp');
    } catch (err: any) {
      setError(err?.message || 'Failed to send code');
    } finally {
      setBusy(false);
    }
  };

  const handleOtp = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const res = await authApi.verifyOtp(email.trim(), otp.trim());
      setResetToken(res.resetToken);
      toast.success('Code verified');
      setStep('reset');
    } catch (err: any) {
      setError(err?.message || 'Invalid OTP');
    } finally {
      setBusy(false);
    }
  };

  const handleReset = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    if (newPassword.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    if (newPassword !== confirm) {
      setError('Passwords do not match.');
      return;
    }
    setBusy(true);
    try {
      const res = await authApi.resetPassword(email.trim(), resetToken, newPassword);
      if (res?.token) {
        setToken(res.token);
        await refresh();
      }
      toast.success('Password reset! You are now logged in.');
      if (onSuccess) onSuccess();
      else onNavigate('/');
    } catch (err: any) {
      setError(err?.message || 'Failed to reset password');
    } finally {
      setBusy(false);
    }
  };

  const goLogin = () => {
    if (onSwitchStep) onSwitchStep('login');
    else onNavigate('/login');
  };

  const inputClass =
    'w-full bg-[#0b0c16] border border-[#2e3252] rounded-lg px-3.5 py-3 text-white text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition';

  const content = (
    <div className="space-y-6">
      <div className="text-center space-y-1.5">
        <h1 className="text-2xl font-bold text-white tracking-tight">
          Reset password
        </h1>
        <p className="text-sm text-slate-400">
          {step === 'email' && "Enter your email — we'll send a 6-digit code."}
          {step === 'otp' && 'Enter the 6-digit code from your email.'}
          {step === 'reset' && 'Choose a new password for your account.'}
        </p>
      </div>

      {error && (
        <div className="px-3.5 py-2.5 rounded-lg bg-red-950/50 border border-red-900/60 text-red-300 text-xs">
          {error}
        </div>
      )}

      {step === 'email' && (
        <form onSubmit={handleEmail} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">
              Email
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              autoComplete="email"
              className={inputClass}
              placeholder="you@example.com"
            />
          </div>
          <button
            type="submit"
            disabled={busy}
            className="cursor-pointer w-full bg-indigo-600 hover:bg-indigo-500 active:scale-[0.99] disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium rounded-lg py-3 text-sm transition-all"
          >
            {busy ? 'Sending…' : 'Send code'}
          </button>
        </form>
      )}

      {step === 'otp' && (
        <form onSubmit={handleOtp} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">
              6-digit code
            </label>
            <input
              type="text"
              value={otp}
              onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
              required
              inputMode="numeric"
              maxLength={6}
              className="w-full bg-[#0b0c16] border border-[#2e3252] rounded-lg px-3.5 py-3.5 text-white text-xl tracking-[0.5em] text-center font-mono outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition"
              placeholder="000000"
            />
          </div>
          <button
            type="submit"
            disabled={busy || otp.length !== 6}
            className="cursor-pointer w-full bg-indigo-600 hover:bg-indigo-500 active:scale-[0.99] disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium rounded-lg py-3 text-sm transition-all"
          >
            {busy ? 'Verifying…' : 'Verify code'}
          </button>
          <button
            type="button"
            onClick={() => {
              setStep('email');
              setOtp('');
              setError(null);
            }}
            className="cursor-pointer w-full flex items-center justify-center gap-1.5 text-xs text-slate-400 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Use a different email
          </button>
        </form>
      )}

      {step === 'reset' && (
        <form onSubmit={handleReset} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">
              New password
            </label>
            <input
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              required
              minLength={6}
              autoComplete="new-password"
              className={inputClass}
              placeholder="At least 6 characters"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">
              Confirm password
            </label>
            <input
              type="password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              required
              minLength={6}
              autoComplete="new-password"
              className={inputClass}
              placeholder="Same as above"
            />
          </div>
          <button
            type="submit"
            disabled={busy}
            className="cursor-pointer w-full bg-indigo-600 hover:bg-indigo-500 active:scale-[0.99] disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium rounded-lg py-3 text-sm transition-all"
          >
            {busy ? 'Resetting…' : 'Reset password'}
          </button>
        </form>
      )}

      <p className="text-center text-sm text-slate-400">
        Remember your password?{' '}
        <button
          type="button"
          onClick={goLogin}
          className="cursor-pointer text-indigo-400 hover:text-indigo-300 font-medium transition-colors"
        >
          Sign in
        </button>
      </p>
    </div>
  );

  if (isModal) return <>{content}</>;

  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4 py-16">
      <div className="w-full max-w-md bg-[#14172b] border border-[#2e3252] rounded-2xl p-8 shadow-2xl">
        {content}
      </div>
    </div>
  );
}