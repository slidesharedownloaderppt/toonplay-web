import { useEffect, useRef, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { toast } from 'sonner';

interface Props {
  onSuccess?: () => void;
}

export function GoogleButton({ onSuccess }: Props) {
  const { loginWithGoogle } = useAuth();
  const ref = useRef<HTMLDivElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const [clientId, setClientId] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const [btnWidth, setBtnWidth] = useState<number | null>(null); // null = not measured yet

  // Measure container width ONCE on mount; update only on real resize
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;

    let lastWidth = 0;

    const update = () => {
      const w = Math.floor(el.getBoundingClientRect().width);
      const clamped = Math.max(200, Math.min(400, w));
      // Only update if it actually changed — prevents redundant re-renders
      if (clamped !== lastWidth) {
        lastWidth = clamped;
        setBtnWidth(clamped);
      }
    };

    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    let cancelled = false;
    fetch('/api/config/public')
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (cancelled) return;
        const id = d?.googleClientId;
        if (id) {
          setClientId(id);
        } else {
          console.warn('[GoogleButton] /api/config/public returned no googleClientId');
        }
      })
      .catch((err) => {
        if (!cancelled) console.warn('[GoogleButton] failed to load config', err);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    // Wait until BOTH clientId AND measured width are available
    if (!clientId || btnWidth === null) return;

    const init = () => {
      const gsi = (window as any).google?.accounts?.id;
      if (!gsi || !ref.current) return;

      gsi.initialize({
        client_id: clientId,
        callback: async (response: { credential: string }) => {
          try {
            await loginWithGoogle(response.credential);
            toast.success('Signed in with Google');
            onSuccess?.();
          } catch (err: any) {
            toast.error(err?.message || 'Google sign-in failed');
          }
        },
      });

      ref.current.innerHTML = '';
      gsi.renderButton(ref.current, {
        theme: 'outline',
        size: 'large',
        width: btnWidth,
        text: 'continue_with',
        shape: 'pill',
        logo_alignment: 'center',
      });

      setReady(true);
    };

    const existing = document.querySelector('script[data-gsi]') as HTMLScriptElement | null;
    if (existing) {
      if ((window as any).google?.accounts?.id) init();
      else existing.addEventListener('load', init, { once: true });
    } else {
      const script = document.createElement('script');
      script.src = 'https://accounts.google.com/gsi/client';
      script.async = true;
      script.defer = true;
      script.dataset.gsi = '1';
      script.onload = init;
      script.onerror = () => console.warn('[GoogleButton] failed to load GSI script');
      document.head.appendChild(script);
    }
  }, [clientId, loginWithGoogle, onSuccess, btnWidth]);

  return (
    <div
      ref={wrapRef}
      className="w-full h-11 min-h-[44px] relative flex items-center justify-center overflow-hidden"
    >
      {!clientId || btnWidth === null ? (
        <div className="absolute inset-0 flex items-center justify-center rounded-full border border-[#2e3252] bg-[#0b0c16]">
          <span className="text-xs text-slate-500">Continue with Google</span>
        </div>
      ) : (
        <div
          ref={ref}
          className={`absolute inset-0 flex items-center justify-center transition-opacity duration-150 ${
            ready ? 'opacity-100' : 'opacity-0 pointer-events-none'
          }`}
          style={{ maxWidth: '100%' }}
        />
      )}
    </div>
  );
}