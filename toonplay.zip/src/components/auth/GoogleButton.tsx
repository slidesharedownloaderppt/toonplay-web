import { useEffect, useRef, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { toast } from 'sonner';

interface Props {
  onSuccess?: () => void;
  onError?: (message: string | null) => void;
  disabled?: boolean;
}

interface GoogleTokenResponse {
  access_token?: string;
  error?: string;
  error_description?: string;
}

interface GoogleTokenClientError {
  type?: 'popup_failed_to_open' | 'popup_closed' | 'unknown' | string;
  message?: string;
}

interface GoogleTokenClient {
  requestAccessToken: (overrideConfig?: { prompt?: string }) => void;
}

interface GoogleOAuth2Namespace {
  initTokenClient: (config: {
    client_id: string;
    scope: string;
    prompt?: string;
    callback: (response: GoogleTokenResponse) => void;
    error_callback?: (error: GoogleTokenClientError) => void;
  }) => GoogleTokenClient;
}

const GSI_SCRIPT_SRC = 'https://accounts.google.com/gsi/client';
const GOOGLE_OAUTH_SCOPE = 'openid email profile';

let cachedGoogleClientId: string | null = null;
let clientIdRequest: Promise<string | null> | null = null;
let gsiScriptRequest: Promise<GoogleOAuth2Namespace | null> | null = null;

function getGoogleOAuth2(): GoogleOAuth2Namespace | null {
  return ((window as unknown as { google?: { accounts?: { oauth2?: GoogleOAuth2Namespace } } })
    .google?.accounts?.oauth2 ?? null);
}

function fetchGoogleClientId(): Promise<string | null> {
  if (cachedGoogleClientId) return Promise.resolve(cachedGoogleClientId);
  if (clientIdRequest) return clientIdRequest;

  clientIdRequest = fetch('/api/config/public')
    .then((r) => (r.ok ? r.json() : null))
    .then((data) => {
      const id = typeof data?.googleClientId === 'string' ? data.googleClientId.trim() : '';
      if (id) {
        cachedGoogleClientId = id;
        return id;
      }
      return null;
    })
    .catch(() => null)
    .finally(() => {
      clientIdRequest = null;
    });

  return clientIdRequest;
}

function loadGoogleOAuth2Client(): Promise<GoogleOAuth2Namespace | null> {
  const existingApi = getGoogleOAuth2();
  if (existingApi) return Promise.resolve(existingApi);
  if (gsiScriptRequest) return gsiScriptRequest;

  gsiScriptRequest = new Promise<GoogleOAuth2Namespace | null>((resolve) => {
    const existingScript = document.querySelector(
      'script[data-gsi="1"]'
    ) as HTMLScriptElement | null;

    const handleLoad = () => {
      resolve(getGoogleOAuth2());
    };
    const handleError = () => {
      resolve(null);
    };

    if (existingScript) {
      if (getGoogleOAuth2()) {
        resolve(getGoogleOAuth2());
        return;
      }
      existingScript.addEventListener('load', handleLoad, { once: true });
      existingScript.addEventListener('error', handleError, { once: true });
      return;
    }

    const script = document.createElement('script');
    script.src = GSI_SCRIPT_SRC;
    script.async = true;
    script.defer = true;
    script.dataset.gsi = '1';
    script.addEventListener('load', handleLoad, { once: true });
    script.addEventListener('error', handleError, { once: true });
    document.head.appendChild(script);
  }).finally(() => {
    gsiScriptRequest = null;
  });

  return gsiScriptRequest;
}

function GoogleLogoSvg() {
  return (
    <svg
      width="18"
      height="18"
      viewBox="0 0 24 24"
      aria-hidden="true"
      className="shrink-0"
    >
      <path
        fill="#4285F4"
        d="M23.745 12.27c0-.79-.07-1.54-.19-2.27h-11.3v4.51h6.47c-.29 1.48-1.14 2.73-2.4 3.58v3h3.86c2.26-2.09 3.56-5.17 3.56-8.82z"
      />
      <path
        fill="#34A853"
        d="M12.255 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96h-3.98v3.09C3.515 21.3 7.565 24 12.255 24z"
      />
      <path
        fill="#FBBC05"
        d="M5.525 14.29c-.25-.72-.38-1.49-.38-2.29s.14-1.57.38-2.29V6.62h-3.98a11.86 11.86 0 0 0 0 10.76l3.98-3.09z"
      />
      <path
        fill="#EA4335"
        d="M12.255 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C18.205 1.19 15.495 0 12.255 0c-4.69 0-8.74 2.7-10.71 6.62l3.98 3.09c.95-2.85 3.6-4.96 6.73-4.96z"
      />
    </svg>
  );
}

export function GoogleButton({ onSuccess, onError, disabled = false }: Props) {
  const { loginWithGoogle } = useAuth();
  const [busy, setBusy] = useState(false);
  const inFlightRef = useRef(false);
  const mountedRef = useRef(true);
  const clientIdRef = useRef<string | null>(cachedGoogleClientId);

  // Preload public Google Client ID and GSI OAuth2 runtime in the background
  // so clicking the static button opens Google's OAuth popup synchronously inside
  // the user click gesture (never affecting button layout or visual rendering).
  useEffect(() => {
    mountedRef.current = true;
    void fetchGoogleClientId().then((id) => {
      if (mountedRef.current && id) {
        clientIdRef.current = id;
      }
    });
    void loadGoogleOAuth2Client();

    return () => {
      mountedRef.current = false;
    };
  }, []);

  const finishAttempt = () => {
    inFlightRef.current = false;
    if (mountedRef.current) {
      setBusy(false);
    }
  };

  const reportError = (message: string) => {
    onError?.(message);
    toast.error(message);
  };

  const startGoogleOAuthPopup = (clientId: string, oauth2: GoogleOAuth2Namespace) => {
    const tokenClient = oauth2.initTokenClient({
      client_id: clientId,
      scope: GOOGLE_OAUTH_SCOPE,
      prompt: 'select_account',
      callback: async (response: GoogleTokenResponse) => {
        if (!response || response.error || !response.access_token) {
          finishAttempt();
          if (response?.error === 'access_denied') {
            reportError('Google sign-in was cancelled.');
          } else {
            reportError(
              response?.error_description || 'Google sign-in failed. Please try again.'
            );
          }
          return;
        }

        try {
          await loginWithGoogle({ accessToken: response.access_token });
          finishAttempt();
          onError?.(null);
          toast.success('Signed in with Google');
          onSuccess?.();
        } catch (err: any) {
          finishAttempt();
          reportError(err?.message || 'Google sign-in failed. Please try again.');
        }
      },
      error_callback: (err: GoogleTokenClientError) => {
        finishAttempt();
        if (err?.type === 'popup_closed') {
          // User dismissed the Google chooser window — reset silently so they can retry.
          return;
        }
        if (err?.type === 'popup_failed_to_open') {
          reportError(
            'Google sign-in popup was blocked. Please allow popups and try again.'
          );
          return;
        }
        reportError('Unable to open Google sign-in. Please try again.');
      },
    });

    tokenClient.requestAccessToken({ prompt: 'select_account' });
  };

  const handleClick = async () => {
    if (disabled || inFlightRef.current) return;

    inFlightRef.current = true;
    setBusy(true);
    onError?.(null);

    // Fast path: when config and GSI OAuth2 runtime are already loaded, launch the
    // Google OAuth authorization popup synchronously within the user click event.
    const readyClientId = clientIdRef.current || cachedGoogleClientId;
    const readyOAuth2 = getGoogleOAuth2();
    if (readyClientId && readyOAuth2) {
      try {
        startGoogleOAuthPopup(readyClientId, readyOAuth2);
      } catch {
        finishAttempt();
        reportError('Unable to start Google sign-in. Please try again.');
      }
      return;
    }

    // Fallback path: user clicked immediately after page mount before prefetch finished.
    try {
      const [clientId, oauth2] = await Promise.all([
        readyClientId ? Promise.resolve(readyClientId) : fetchGoogleClientId(),
        readyOAuth2 ? Promise.resolve(readyOAuth2) : loadGoogleOAuth2Client(),
      ]);

      if (clientId) clientIdRef.current = clientId;

      if (!clientId) {
        finishAttempt();
        reportError('Google sign-in is not configured on this server.');
        return;
      }

      if (!oauth2) {
        finishAttempt();
        reportError('Could not connect to Google sign-in. Check your connection and try again.');
        return;
      }

      startGoogleOAuthPopup(clientId, oauth2);
    } catch {
      finishAttempt();
      reportError('Unable to start Google sign-in. Please try again.');
    }
  };

  return (
    <button
      type="button"
      onClick={handleClick}
      disabled={disabled || busy}
      aria-busy={busy}
      className="cursor-pointer w-full h-11 min-h-[44px] px-4 flex items-center justify-center gap-3 rounded-lg bg-white hover:bg-[#f3f4f6] active:bg-[#e5e7eb] active:scale-[0.99] border border-slate-200/90 text-[#1f2937] font-medium text-sm shadow-sm transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400 focus-visible:ring-offset-2 focus-visible:ring-offset-[#14172b] disabled:opacity-65 disabled:cursor-not-allowed disabled:active:scale-100 select-none"
    >
      {busy ? (
        <>
          <Loader2 className="w-4 h-4 animate-spin text-slate-600 shrink-0" aria-hidden="true" />
          <span>Signing in with Google…</span>
        </>
      ) : (
        <>
          <GoogleLogoSvg />
          <span>Continue with Google</span>
        </>
      )}
    </button>
  );
}