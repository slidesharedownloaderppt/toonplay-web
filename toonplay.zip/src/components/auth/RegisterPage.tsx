import { useState, FormEvent } from 'react';
import { useAuth } from '../../context/AuthContext';
import { GoogleButton } from './GoogleButton';
import { toast } from 'sonner';

interface Props {
  onNavigate: (path: string) => void;
  variant?: 'page' | 'modal';
  onSwitchStep?: (step: 'login' | 'register' | 'forgot-password') => void;
  onSuccess?: () => void;
}

export function RegisterPage({
  onNavigate,
  variant = 'page',
  onSwitchStep,
  onSuccess,
}: Props) {
  const { register } = useAuth();
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isModal = variant === 'modal';

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (busy) return;
    setError(null);
    const cleanUsername = username.trim().toLowerCase();
    if (cleanUsername.length < 3) {
      setError('Username must be at least 3 characters.');
      return;
    }
    if (!/^[a-z0-9_]+$/.test(cleanUsername)) {
      setError('Username may only contain letters, numbers, and underscores.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    if (password !== confirm) {
      setError('Passwords do not match.');
      return;
    }
    setBusy(true);
    try {
      await register(
        username.trim().toLowerCase(),
        email.trim(),
        password,
        displayName.trim() || undefined
      );
      toast.success('Welcome to ToonPlay!');
      if (onSuccess) onSuccess();
      else onNavigate('/');
    } catch (err: any) {
      const msg = err?.message || 'Registration failed';
      setError(msg);
      toast.error(msg);
    } finally {
      setBusy(false);
    }
  };

  const goLogin = () => {
    if (onSwitchStep) onSwitchStep('login');
    else onNavigate('/login');
  };

  const handleGoogleSuccess = () => {
    if (onSuccess) onSuccess();
    else onNavigate('/');
  };

  const content = (
    <div className="space-y-6">
      <div className="text-center space-y-1.5">
        <h1 className="text-2xl font-bold text-white tracking-tight">
          Create your account
        </h1>
        <p className="text-sm text-slate-400">
          Join ToonPlay and start tracking your journey
        </p>
      </div>

      {error && (
        <div className="px-3.5 py-2.5 rounded-lg bg-red-950/50 border border-red-900/60 text-red-300 text-xs">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-medium text-slate-400 mb-1.5">
            Username
          </label>
          <input
            type="text"
            value={username}
            onChange={(e) =>
              setUsername(
                e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 30)
              )
            }
            required
            minLength={3}
            maxLength={30}
            autoComplete="username"
            autoCapitalize="none"
            autoCorrect="off"
            spellCheck={false}
            className="w-full bg-[#0b0c16] border border-[#2e3252] rounded-lg px-3.5 py-3 text-white text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition"
            placeholder="Choose a username"
          />
          <p className="text-[10px] text-slate-600 mt-1">
            3–30 chars · letters, numbers, underscores only
          </p>
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-400 mb-1.5">
            Display Name <span className="text-slate-600">(optional)</span>
          </label>
          <input
            type="text"
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
            maxLength={191}
            className="w-full bg-[#0b0c16] border border-[#2e3252] rounded-lg px-3.5 py-3 text-white text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition"
            placeholder="e.g. Shadow King"
          />
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-400 mb-1.5">
            Email
          </label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            autoComplete="email"
            className="w-full bg-[#0b0c16] border border-[#2e3252] rounded-lg px-3.5 py-3 text-white text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition"
            placeholder="you@example.com"
          />
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-400 mb-1.5">
            Password
          </label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            minLength={6}
            autoComplete="new-password"
            className="w-full bg-[#0b0c16] border border-[#2e3252] rounded-lg px-3.5 py-3 text-white text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition"
            placeholder="At least 6 characters"
          />
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-400 mb-1.5">
            Confirm Password
          </label>
          <input
            type="password"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            required
            minLength={6}
            autoComplete="new-password"
            className="w-full bg-[#0b0c16] border border-[#2e3252] rounded-lg px-3.5 py-3 text-white text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition"
            placeholder="Same as above"
          />
        </div>

        <button
          type="submit"
          disabled={busy}
          className="cursor-pointer w-full bg-indigo-600 hover:bg-indigo-500 active:scale-[0.99] disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium rounded-lg py-3 text-sm transition-all"
        >
          {busy ? 'Creating account…' : 'Create account'}
        </button>
      </form>

      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-[#2e3252]" />
        </div>
        <div className="relative flex justify-center text-[11px] uppercase tracking-wider">
          <span className="bg-[#14172b] px-3 text-slate-500">or continue with</span>
        </div>
      </div>

      <GoogleButton
        onSuccess={handleGoogleSuccess}
        onError={setError}
        disabled={busy}
      />

      <p className="text-center text-sm text-slate-400">
        Already have an account?{' '}
        <button
          type="button"
          onClick={goLogin}
          className="cursor-pointer text-indigo-400 hover:text-indigo-300 font-medium transition-colors"
        >
          Sign in
        </button>
      </p>
    </div>
  );

  if (isModal) return <>{content}</>;

  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4 py-16">
      <div className="w-full max-w-md bg-[#14172b] border border-[#2e3252] rounded-2xl p-8 shadow-2xl">
        {content}
      </div>
    </div>
  );
}