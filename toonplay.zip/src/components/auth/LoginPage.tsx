import { useState, FormEvent } from 'react';
import { Eye, EyeOff, AlertCircle } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { GoogleButton } from './GoogleButton';
import { ApiError } from '../../lib/api';
import { toast } from 'sonner';

interface Props {
  onNavigate: (path: string) => void;
  variant?: 'page' | 'modal';
  onSwitchStep?: (step: 'login' | 'register' | 'forgot-password') => void;
  onSuccess?: () => void;
}

export function LoginPage({
  onNavigate,
  variant = 'page',
  onSwitchStep,
  onSuccess,
}: Props) {
  const { login } = useAuth();
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isModal = variant === 'modal';

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (busy) return;

    // Client-side guard: catch obvious typos BEFORE hitting the server
    const id = identifier.trim();
    if (!id) {
      setError('Please enter your username or email.');
      return;
    }
    if (!password) {
      setError('Please enter your password.');
      return;
    }
    if (password !== password.trim()) {
      setError('Your password has leading/trailing spaces. Please remove them.');
      return;
    }

    setError(null);
    setBusy(true);
    try {
      await login(id, password);
      toast.success('Welcome back!');
      if (onSuccess) onSuccess();
      else onNavigate('/');
    } catch (err: any) {
      // Classify the failure so the message is actionable
      const isApiErr = err instanceof ApiError;
      const status = isApiErr ? err.status : 0;

      let msg: string;
      if (status === 401) {
        // Distinguish the two sub-cases WITHOUT leaking which one is wrong.
        // If identifier looks like an email, nudge toward email; else username.
        const looksLikeEmail = id.includes('@');
        msg = looksLikeEmail
          ? 'Incorrect email or password. Double-check both and try again.'
          : 'Incorrect username or password. Double-check both and try again.';
        // Keep identifier so user can retype password quickly
        setPassword('');
      } else if (status === 429) {
        msg = 'Too many login attempts. Please wait a minute and try again.';
      } else if (status >= 500) {
        msg = 'Server error. Please try again in a moment.';
      } else if (isApiErr && err.message && !/invalid credentials/i.test(err.message)) {
        // Server sent a more specific error — show it verbatim
        msg = err.message;
      } else if (!isApiErr) {
        // Network failure / fetch threw
        msg = "Can't reach the server. Check your connection and try again.";
      } else {
        msg = 'Login failed. Please try again.';
      }

      setError(msg);
      toast.error(msg);
    } finally {
      setBusy(false);
    }
  };

  const goForgot = () => {
    if (onSwitchStep) onSwitchStep('forgot-password');
    else onNavigate('/forgot-password');
  };

  const goRegister = () => {
    if (onSwitchStep) onSwitchStep('register');
    else onNavigate('/register');
  };

  const handleGoogleSuccess = () => {
    if (onSuccess) onSuccess();
    else onNavigate('/');
  };

  const content = (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center space-y-1.5">
        <h1 className="text-2xl font-bold text-white tracking-tight">
          Welcome back
        </h1>
        <p className="text-sm text-slate-400">
          Sign in to sync your watchlist and stats
        </p>
      </div>

      {/* Error */}
      {error && (
        <div className="flex items-start gap-2 px-3.5 py-2.5 rounded-lg bg-red-950/50 border border-red-900/60 text-red-300 text-xs leading-relaxed">
          <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Form */}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-medium text-slate-400 mb-1.5">
            Username or Email
          </label>
          <input
            type="text"
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
            required
            disabled={busy}
            autoComplete="username"
            autoCapitalize="none"
            autoCorrect="off"
            spellCheck={false}
            className="w-full bg-[#0b0c16] border border-[#2e3252] rounded-lg px-3.5 py-3 text-white text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition disabled:opacity-60"
            placeholder="you@example.com"
          />
        </div>

        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="block text-xs font-medium text-slate-400">
              Password
            </label>
            <button
              type="button"
              onClick={goForgot}
              className="cursor-pointer text-[11px] text-indigo-400 hover:text-indigo-300 transition-colors"
            >
              Forgot?
            </button>
          </div>
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              disabled={busy}
              autoComplete="current-password"
              autoCapitalize="none"
              autoCorrect="off"
              spellCheck={false}
              className="w-full bg-[#0b0c16] border border-[#2e3252] rounded-lg px-3.5 py-3 pr-11 text-white text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition disabled:opacity-60"
              placeholder="••••••••"
            />
            <button
              type="button"
              onClick={() => setShowPassword((s) => !s)}
              tabIndex={-1}
              aria-label={showPassword ? 'Hide password' : 'Show password'}
              className="cursor-pointer absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors"
            >
              {showPassword ? (
                <EyeOff className="w-4 h-4" />
              ) : (
                <Eye className="w-4 h-4" />
              )}
            </button>
          </div>
          <p className="mt-1.5 text-[11px] text-slate-500">
            Passwords are case-sensitive. Caps Lock may be on.
          </p>
        </div>

        <button
          type="submit"
          disabled={busy}
          className="cursor-pointer w-full bg-indigo-600 hover:bg-indigo-500 active:scale-[0.99] disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium rounded-lg py-3 text-sm transition-all"
        >
          {busy ? 'Signing in…' : 'Sign in'}
        </button>
      </form>

      {/* Divider */}
      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-[#2e3252]" />
        </div>
        <div className="relative flex justify-center text-[11px] uppercase tracking-wider">
          <span className="bg-[#14172b] px-3 text-slate-500">or continue with</span>
        </div>
      </div>

      {/* Google */}
      <GoogleButton
        onSuccess={handleGoogleSuccess}
        onError={setError}
        disabled={busy}
      />

      {/* Switch to register */}
      <p className="text-center text-sm text-slate-400">
        Don't have an account?{' '}
        <button
          type="button"
          onClick={goRegister}
          className="cursor-pointer text-indigo-400 hover:text-indigo-300 font-medium transition-colors"
        >
          Create one
        </button>
      </p>
    </div>
  );

  if (isModal) return <>{content}</>;

  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4 py-16">
      <div className="w-full max-w-md bg-[#14172b] border border-[#2e3252] rounded-2xl p-8 shadow-2xl">
        {content}
      </div>
    </div>
  );
}