import { useState, useRef, useEffect } from 'react';
import {
  User as UserIcon,
  LogOut,
  Bookmark,
  History,
  LogIn,
  AtSign,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { joinedAgo } from '../../lib/time';
import { AvatarWithFrame } from '../profile/AvatarWithFrame';
import { TierUsername } from '../profile/TierUsername';
import { toast } from 'sonner';

type AuthStep = 'login' | 'register' | 'forgot-password';

interface Props {
  onNavigate: (path: string) => void;
  onOpenAuth?: (step: AuthStep) => void;
}

export function UserMenu({ onNavigate, onOpenAuth }: Props) {
  const { user, isAuthenticated, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('mousedown', onClick);
    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('mousedown', onClick);
      document.removeEventListener('keydown', onKeyDown);
    };
  }, [open]);

  const close = () => setOpen(false);

  const go = (path: string) => {
    close();
    onNavigate(path);
  };

  const openAuth = (step: AuthStep) => {
    close();
    if (onOpenAuth) {
      onOpenAuth(step);
    } else {
      onNavigate(`/${step === 'forgot-password' ? 'forgot-password' : step}`);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="relative" ref={ref}>
        <button
          onClick={() => setOpen((v) => !v)}
          aria-label="Account"
          title="Account"
          className="w-8.5 h-8.5 rounded-full bg-gradient-to-tr from-indigo-700 via-indigo-600 to-indigo-500 p-0.5 border border-[#373a5a] hover:border-indigo-400 hover:scale-105 transition-[transform,border-color] cursor-pointer flex items-center justify-center shadow-md shadow-indigo-950/50"
        >
          <div className="w-full h-full rounded-full bg-[#111322] flex items-center justify-center overflow-hidden">
            <UserIcon className="w-3.5 h-3.5 text-indigo-300" />
          </div>
        </button>

        {open && (
          <div className="absolute right-0 mt-2.5 w-56 bg-[#121424] border border-[#2a2d48] rounded-xl shadow-2xl shadow-black/80 py-2 z-50 text-xs animate-in fade-in duration-150">
            <div className="px-3.5 pb-2.5 border-b border-[#23263f]">
              <p className="text-xs font-medium text-slate-100">Welcome</p>
              <p className="text-[11px] text-slate-500">Sign in to sync your watchlist</p>
            </div>

            <div className="py-1">
              <button
                onClick={() => openAuth('login')}
                className="w-full flex items-center gap-2 px-3.5 py-2 text-xs text-slate-300 hover:bg-[#1a1d33] hover:text-white transition-colors cursor-pointer"
              >
                <LogIn className="w-3.5 h-3.5" /> Login
              </button>
              <button
                onClick={() => openAuth('register')}
                className="w-full flex items-center gap-2 px-3.5 py-2 text-xs text-slate-300 hover:bg-[#1a1d33] hover:text-white transition-colors cursor-pointer"
              >
                <UserIcon className="w-3.5 h-3.5" /> Sign up
              </button>
            </div>

            <div className="border-t border-[#23263f] pt-1">
              <button
                onClick={() => go('/watchlist')}
                className="w-full flex items-center gap-2 px-3.5 py-2 text-xs text-slate-300 hover:bg-[#1a1d33] hover:text-white transition-colors cursor-pointer"
              >
                <Bookmark className="w-3.5 h-3.5" /> Watchlist
              </button>
              <button
                onClick={() => go('/history')}
                className="w-full flex items-center gap-2 px-3.5 py-2 text-xs text-slate-300 hover:bg-[#1a1d33] hover:text-white transition-colors cursor-pointer"
              >
                <History className="w-3.5 h-3.5" /> History
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  const displayName = user?.display_name || user?.username || 'User';

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-2 p-1 sm:pr-2.5 rounded-full bg-[#14172b] border border-[#2e3252] hover:border-indigo-500 transition cursor-pointer"
        aria-label="Account menu"
      >
        <AvatarWithFrame
          avatarUrl={user?.avatar_url}
          frameUrl={user?.profile_frame_url}
          username={user?.username}
          alt={displayName}
          className="w-7 h-7"
          avatarClassName="border border-transparent"
          showInitialFallback
          loading="eager"
        />
        <TierUsername
          name={displayName}
          level={user?.level}
          xp={user?.xp}
          className="hidden sm:inline-block text-xs font-semibold max-w-[100px] truncate"
        />
      </button>

      {open && (
        <div className="absolute right-0 mt-2 w-56 bg-[#14172b] border border-[#2e3252] rounded-xl shadow-2xl overflow-hidden z-50">
          <div className="px-3 py-3 border-b border-[#2e3252]">
            <TierUsername
              as="p"
              name={displayName}
              level={user?.level}
              xp={user?.xp}
              className="text-sm font-semibold truncate block"
            />
            <p className="text-[11px] text-slate-400 truncate">{user?.email}</p>
            <p className="text-[11px] text-slate-500 truncate mt-0.5">{joinedAgo(user?.joined_at)}</p>
          </div>

          <button
            onClick={() => go('/profile')}
            className="w-full flex items-center gap-2 px-3 py-2 text-xs text-slate-300 hover:bg-[#1c2038] hover:text-white cursor-pointer"
          >
            <UserIcon className="w-3.5 h-3.5" /> Profile
          </button>

          <button
            onClick={() => go(`/u/${user?.username}`)}
            className="w-full flex items-center gap-2 px-3 py-2 text-xs text-slate-300 hover:bg-[#1c2038] hover:text-white cursor-pointer"
          >
            <AtSign className="w-3.5 h-3.5" /> Public Profile
          </button>

          <button
            onClick={() => go('/watchlist')}
            className="w-full flex items-center gap-2 px-3 py-2 text-xs text-slate-300 hover:bg-[#1c2038] hover:text-white cursor-pointer"
          >
            <Bookmark className="w-3.5 h-3.5" /> Watchlist
          </button>

          <button
            onClick={() => go('/history')}
            className="w-full flex items-center gap-2 px-3 py-2 text-xs text-slate-300 hover:bg-[#1c2038] hover:text-white cursor-pointer"
          >
            <History className="w-3.5 h-3.5" /> History
          </button>

          <div className="border-t border-[#2e3252]">
            <button
              onClick={async () => {
                close();
                await logout();
                toast.success('Logged out');
              }}
              className="w-full flex items-center gap-2 px-3 py-2 text-xs text-red-400 hover:bg-[#1c2038] hover:text-red-300 transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" /> Log out
            </button>
          </div>
        </div>
      )}
    </div>
  );
}