import React from 'react';

export const ProfileSettingsSkeleton: React.FC = () => {
  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      {/* Page title */}
      <div className="mb-5 space-y-1">
        <div className="w-32 h-6 bg-[#16182c] rounded animate-pulse" />
        <div className="w-64 h-3 bg-[#16182c]/70 rounded animate-pulse" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-[220px_1fr] gap-5">
        {/* ── Sidebar (desktop) ── */}
        <aside className="hidden md:block self-start">
          <div className="p-3 rounded-2xl bg-[#14172b] border border-[#23263f] space-y-4">
            {/* Settings nav */}
            <div>
              <div className="w-16 h-2.5 bg-[#1a1d33] rounded mb-2 ml-2 animate-pulse" />
              <div className="space-y-1">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div
                    key={i}
                    className="flex items-center gap-2.5 px-3 py-2 rounded-lg animate-pulse"
                  >
                    <div className="w-4 h-4 rounded bg-[#1a1d33]" />
                    <div className="w-20 h-3 bg-[#1a1d33] rounded" />
                  </div>
                ))}
              </div>
            </div>

            {/* Account Info */}
            <div className="pt-3 border-t border-[#23263f]">
              <div className="w-24 h-2.5 bg-[#1a1d33] rounded mb-2 ml-2 animate-pulse" />
              <div className="space-y-2 px-2">
                <div className="space-y-1">
                  <div className="w-12 h-2 bg-[#1a1d33]/70 rounded animate-pulse" />
                  <div className="w-36 h-3 bg-[#1a1d33] rounded animate-pulse" />
                </div>
                <div className="space-y-1">
                  <div className="w-12 h-2 bg-[#1a1d33]/70 rounded animate-pulse" />
                  <div className="w-20 h-3 bg-[#1a1d33] rounded animate-pulse" />
                </div>
              </div>
            </div>

            {/* Sign out */}
            <div className="pt-3 border-t border-[#23263f]">
              <div className="flex items-center gap-2 px-3 py-2 animate-pulse">
                <div className="w-3.5 h-3.5 rounded bg-[#1a1d33]" />
                <div className="w-16 h-3 bg-[#1a1d33] rounded" />
              </div>
            </div>
          </div>
        </aside>

        {/* ── Mobile tabs ── */}
        <div className="md:hidden mb-1">
          <div className="flex gap-1 p-1 rounded-xl bg-[#14172b] border border-[#23263f]">
            {Array.from({ length: 3 }).map((_, i) => (
              <div
                key={i}
                className="flex-1 h-8 rounded-lg bg-[#1a1d33]/70 animate-pulse"
              />
            ))}
          </div>
        </div>

        {/* ── Main content: AccountSection skeleton ── */}
        <main className="min-w-0 space-y-4">
          <div className="bg-[#14172b] border border-[#23263f] rounded-2xl p-5 sm:p-6 space-y-5 animate-pulse">
            {/* Section header */}
            <div className="space-y-1.5">
              <div className="w-28 h-4 bg-[#1a1d33] rounded" />
              <div className="w-56 h-2.5 bg-[#1a1d33]/70 rounded" />
            </div>

            {/* Avatar row */}
            <div className="flex items-center gap-4 pt-1">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-[#0f1122] border border-[#22253d]" />
              <div className="space-y-2">
                <div className="w-28 h-8 bg-[#1a1d33] rounded-lg" />
                <div className="w-40 h-2.5 bg-[#1a1d33]/70 rounded" />
              </div>
            </div>

            {/* Display name + Username (2-col on sm+) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="space-y-1.5">
                <div className="w-24 h-2.5 bg-[#1a1d33]/70 rounded" />
                <div className="w-full h-10 bg-[#0f1122] border border-[#22253d] rounded-lg" />
              </div>
              <div className="space-y-1.5">
                <div className="w-20 h-2.5 bg-[#1a1d33]/70 rounded" />
                <div className="w-full h-10 bg-[#0f1122] border border-[#22253d] rounded-lg" />
              </div>
            </div>

            {/* Email (full width) */}
            <div className="space-y-1.5">
              <div className="w-16 h-2.5 bg-[#1a1d33]/70 rounded" />
              <div className="w-full h-10 bg-[#0f1122] border border-[#22253d] rounded-lg" />
            </div>

            {/* Bio (full width, taller) */}
            <div className="space-y-1.5">
              <div className="w-12 h-2.5 bg-[#1a1d33]/70 rounded" />
              <div className="w-full h-24 bg-[#0f1122] border border-[#22253d] rounded-lg" />
            </div>

            {/* Save button */}
            <div className="pt-2">
              <div className="w-32 h-9 bg-[#1a1d33] rounded-lg" />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};