import React from 'react';
import { MessageCircle, Megaphone, Send } from 'lucide-react';

interface TelegramJoinModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const WHATSAPP_CHANNEL_URL = 'https://whatsapp.com/channel/0029VbDe6udFXUucYq41Uu1Q';
const TELEGRAM_CHANNEL_URL = 'https://t.me/toonplay_official';
const TELEGRAM_GROUP_URL   = 'https://t.me/ToonPlayCommunity';

export const TelegramJoinModal: React.FC<TelegramJoinModalProps> = ({
  isOpen,
  onClose,
}) => {
  const openExternal = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer');
    onClose();
  };

  return (
    <div
      data-no-direct-link-ad="true"
      aria-hidden={!isOpen}
      className={`fixed inset-0 z-[200] flex items-center justify-center p-4
        bg-black/65 backdrop-blur-[2px]
        transition-opacity duration-300 ease-out
        ${isOpen ? 'opacity-100 cursor-pointer' : 'pointer-events-none opacity-0'}`}
      onClick={onClose}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="join-modal-title"
        className={`relative w-full max-w-[420px] rounded-2xl
          border border-white/10 bg-[#171923] p-6 text-center
          shadow-2xl shadow-black/40
          transition-all duration-300 ease-out
          ${isOpen
            ? 'translate-y-0 scale-100 opacity-100'
            : 'translate-y-3 scale-95 opacity-0'}`}
        onClick={(event) => event.stopPropagation()}
      >
        <button
          type="button"
          onClick={onClose}
          aria-label="Close"
          className="absolute right-3 top-3 flex h-8 w-8 items-center
            justify-center rounded-full text-xl text-slate-400
            transition-colors hover:bg-white/10 hover:text-white
            cursor-pointer"
        >
          ×
        </button>

        <div className="mx-auto mb-4 flex h-14 w-14 items-center
          justify-center rounded-full bg-[#25D366]/10 text-[#25D366]">
          <MessageCircle className="h-7 w-7" />
        </div>

        <h2
          id="join-modal-title"
          className="text-xl font-bold text-white"
        >
          Stay Connected with ToonPlay
        </h2>

        <p className="mt-2 text-sm leading-6 text-slate-400">
          Follow our channels for new release updates, or join the
          Telegram group to chat with fans and get help.
        </p>

        <div className="mt-6 space-y-2.5">

          {/* ── WhatsApp Channel — PRIMARY (updates) ── */}
          <button
            type="button"
            onClick={() => openExternal(WHATSAPP_CHANNEL_URL)}
            className="group flex w-full items-center gap-3
              rounded-xl bg-[#25D366] px-4 py-3 text-left
              text-sm font-semibold text-emerald-950 transition-colors
              hover:bg-[#1ebe5b] active:scale-[0.98]
              cursor-pointer"
          >
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-emerald-950/15 text-emerald-950">
              <Megaphone className="h-4 w-4" />
            </span>
            <span className="flex-1">
              <span className="block">Follow on WhatsApp</span>
              <span className="block text-[11px] font-normal text-emerald-900/80">
                New releases &amp; announcements
              </span>
            </span>
          </button>

          {/* ── Telegram Channel — updates ── */}
          <button
            type="button"
            onClick={() => openExternal(TELEGRAM_CHANNEL_URL)}
            className="group flex w-full items-center gap-3
              rounded-xl border border-sky-500/30 bg-sky-500/10 px-4 py-3 text-left
              text-sm font-semibold text-sky-300 transition-colors
              hover:bg-sky-500/20 active:scale-[0.98]
              cursor-pointer"
          >
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-sky-500/20">
              <Megaphone className="h-4 w-4" />
            </span>
            <span className="flex-1">
              <span className="block">Follow on Telegram</span>
              <span className="block text-[11px] font-normal text-sky-200/70">
                Telegram announcements
              </span>
            </span>
          </button>

          {/* ── Telegram Group — community ── */}
          <button
            type="button"
            onClick={() => openExternal(TELEGRAM_GROUP_URL)}
            className="group flex w-full items-center gap-3
              rounded-xl border border-indigo-500/30 bg-indigo-500/10 px-4 py-3 text-left
              text-sm font-semibold text-indigo-300 transition-colors
              hover:bg-indigo-500/20 active:scale-[0.98]
              cursor-pointer"
          >
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-indigo-500/20">
              <Send className="h-4 w-4" />
            </span>
            <span className="flex-1">
              <span className="block">Join Telegram Group</span>
              <span className="block text-[11px] font-normal text-indigo-200/70">
                Chat with other fans
              </span>
            </span>
          </button>

        </div>

        <button
          type="button"
          onClick={onClose}
          className="mt-4 text-sm text-slate-400 transition-colors
            hover:text-white cursor-pointer"
        >
          Maybe later
        </button>
      </div>
    </div>
  );
};