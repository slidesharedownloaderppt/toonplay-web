import React, { useEffect, useRef, useState, useCallback, useMemo, memo } from 'react';
import { createPortal } from 'react-dom';
import {
  Play, Pause, Volume2, VolumeX, Maximize, Minimize, Loader2,
  PictureInPicture2, AlertCircle, Settings2, Subtitles, Languages,
  RotateCcw, RotateCw, Check, ChevronLeft, Gauge, Type, X,
  SlidersHorizontal, Bold, MoveVertical,
} from 'lucide-react';
import {
  fetchMovieboxStream,
  type MovieboxStreamAudioOption,
  type MovieboxStreamResponse,
} from '../api.ts';

const SubtitleCueStyle = memo(({ size, weight }: { size: number; weight: number }) => (
  <style>{`
video::cue {
  font-size: ${size}% !important;
  font-weight: ${weight} !important;
}
  `}</style>
));
SubtitleCueStyle.displayName = 'SubtitleCueStyle';

const SHAKA_SRC =
  'https://ajax.googleapis.com/ajax/libs/shaka-player/4.7.11/shaka-player.compiled.js';

declare global {
  interface Window {
    shaka?: any;
  }
}

export interface MergedAudioOption {
  kind: 'in-manifest' | 'outer';
  audioKey: string;
  label: string;
  lanCode?: string;
  trackIndex?: number;
  subjectId?: string;
  detailPath?: string;
}

interface CustomPlayerProps {
  streamUrl: string;
  preloadedStream?: MovieboxStreamResponse | null;
  cachedDubOptions?: MovieboxStreamAudioOption[] | null;
  activeDubOption?: MovieboxStreamAudioOption | null;
  autoPlay?: boolean;
  startAt?: number;
  onReady?: (duration: number) => void;
  onProgress?: (currentTime: number, duration: number) => void;
  onEnded?: () => void;
  onError?: (message: string) => void;
  onAudioOptionsChange?: (options: MergedAudioOption[], activeLabel: string | null) => void;
}

const LANG_LABEL: Record<string, string> = {
  hi: 'Hindi', kn: 'Kannada', bn: 'Bengali', ta: 'Tamil', te: 'Telugu',
  ml: 'Malayalam', mr: 'Marathi', pa: 'Punjabi', gu: 'Gujarati', ur: 'Urdu',
  or: 'Odia', as: 'Assamese', mai: 'Maithili', sat: 'Santali', kok: 'Konkani',
  ne: 'Nepali', si: 'Sinhala', en: 'English', ja: 'Japanese', ko: 'Korean',
  fr: 'French', de: 'German', es: 'Spanish', pt: 'Portuguese', ru: 'Russian',
  zh: 'Chinese', ar: 'Arabic', th: 'Thai', vi: 'Vietnamese', id: 'Indonesian',
  und: 'Audio',
  hin: 'Hindi',
  tam: 'Tamil',
  tel: 'Telugu',
  mal: 'Malayalam',
  kan: 'Kannada',
  ben: 'Bengali',
  jpn: 'Japanese',
  jap: 'Japanese',
  kor: 'Korean',
  eng: 'English',
};

function langLabel(raw: string): string {
  const key = String(raw || '').trim().toLowerCase();
  if (!key) return 'Audio';
  if (LANG_LABEL[key]) return LANG_LABEL[key];
  // Try first two/three chars
  if (LANG_LABEL[key.slice(0, 2)]) return LANG_LABEL[key.slice(0, 2)];
  if (LANG_LABEL[key.slice(0, 3)]) return LANG_LABEL[key.slice(0, 3)];
  // Fallback: capitalise
  return key.charAt(0).toUpperCase() + key.slice(1);
}

function dedupeLabels(labels: string[]): string[] {
  const seen = new Map<string, number>();
  return labels.map((raw) => {
    const base = String(raw || 'Audio').trim();
    const key = base.toLowerCase();
    const count = seen.get(key) ?? 0;
    seen.set(key, count + 1);
    return count === 0 ? base : `${base} ${count + 1}`;
  });
}

function loadShaka(): Promise<any> {
  if (window.shaka) return Promise.resolve(window.shaka);
  return new Promise((resolve, reject) => {
    const existing = document.querySelector(`script[src="${SHAKA_SRC}"]`) as HTMLScriptElement | null;
    if (existing) {
      existing.addEventListener('load', () => resolve(window.shaka));
      existing.addEventListener('error', () => reject(new Error('shaka load failed')));
      return;
    }
    const s = document.createElement('script');
    s.src = SHAKA_SRC;
    s.async = true;
    s.onload = () => resolve(window.shaka);
    s.onerror = () => reject(new Error('shaka load failed'));
    document.head.appendChild(s);
  });
}

function fmtTime(s: number): string {
  if (!Number.isFinite(s) || s < 0) s = 0;
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = Math.floor(s % 60);
  return h > 0
    ? `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`
    : `${m}:${String(sec).padStart(2, '0')}`;
}

function srtToVtt(srt: string): string {
  const cleaned = srt
    .replace(/\r+/g, '')
    .replace(/^\uFEFF/, '')
    .replace(/(\d+)\n(\d{2}:\d{2}:\d{2}),(\d{3}) --> (\d{2}:\d{2}:\d{2}),(\d{3})/g,
      (_m, _n, h1, ms1, h2, ms2) => `${h1}.${ms1} --> ${h2}.${ms2}`);
  return `WEBVTT\n\n${cleaned}`;
}

export const CustomPlayer: React.FC<CustomPlayerProps> = ({
  streamUrl,
  preloadedStream = null,
  cachedDubOptions = null,
  activeDubOption = null,
  autoPlay = true,
  startAt = 0,
  onReady,
  onProgress,
  onEnded,
  onError,
  onAudioOptionsChange,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const playerRef = useRef<any>(null);
  const progressTimerRef = useRef<number | null>(null);
  const hideTimerRef = useRef<number | null>(null);
  const reportedReadyRef = useRef(false);
const scrubRef = useRef<boolean>(false);
const lastPointerTypeRef = useRef<string>('mouse');
  const settingsRef = useRef<HTMLDivElement | null>(null);
  const settingsPanelRef = useRef<HTMLDivElement | null>(null);

  const [isLoading, setIsLoading] = useState(true);
  const [isBuffering, setIsBuffering] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(1);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [scrubTime, setScrubTime] = useState<number | null>(null);

  const [qualityTracks, setQualityTracks] = useState<any[]>([]);
  const [textTracks, setTextTracks] = useState<any[]>([]);
  const [inManifestAudio, setInManifestAudio] = useState<any[]>([]);
  const [mergedAudio, setMergedAudio] = useState<MergedAudioOption[]>([]);
const [activeAudioLabel, setActiveAudioLabel] = useState<string | null>(null);
const [activeAudioKey, setActiveAudioKey] = useState<string | null>(null);
  const [activeQualityId, setActiveQualityId] = useState<number | 'auto'>('auto');
  const [activeTextId, setActiveTextId] = useState<number | 'off'>('off');
const [playbackRate, setPlaybackRate] = useState(1);
const [outerVersion, setOuterVersion] = useState(0);

// Subtitle customization
const [subtitleSize, setSubtitleSize] = useState(100);
const [subtitleWeight, setSubtitleWeight] = useState(400);
const [subtitlePosition, setSubtitlePosition] = useState(0);

const [showSettings, setShowSettings] = useState(false);
const [isTouchDevice, setIsTouchDevice] = useState(false);

useEffect(() => {
  const mql = window.matchMedia('(pointer: coarse)');
  const updateTouchDevice = () => {
    setIsTouchDevice(mql.matches || navigator.maxTouchPoints > 0);
  };
  updateTouchDevice();
  mql.addEventListener?.('change', updateTouchDevice);
  return () => mql.removeEventListener?.('change', updateTouchDevice);
}, []);

const sortedQualityTracks = useMemo(
  () => qualityTracks.slice().sort((a, b) => (b.height || 0) - (a.height || 0)),
  [qualityTracks]
);
const [isSettingsClosing, setIsSettingsClosing] = useState(false);
const settingsCloseTimerRef = useRef<number | null>(null);

const [settingsView, setSettingsView] = useState<
  'root' | 'quality' | 'speed' | 'audio' | 'subtitles' | 'subtitleStyle'
>('root');

  const outerOptionsRef = useRef<MovieboxStreamAudioOption[]>(cachedDubOptions || []);
  const activeOuterRef = useRef<MovieboxStreamAudioOption | null>(activeDubOption || null);
  const cachedDubOptionsRef = useRef<MovieboxStreamAudioOption[] | null>(cachedDubOptions);
  const activeDubOptionRef = useRef<MovieboxStreamAudioOption | null>(activeDubOption);
  const preloadedStreamRef = useRef<MovieboxStreamResponse | null>(preloadedStream);
  const lastLoadedStreamUrlRef = useRef<string>('');
  const resumeTimeOnSwitchRef = useRef<number>(0);

  preloadedStreamRef.current = preloadedStream;
  cachedDubOptionsRef.current = cachedDubOptions;
  activeDubOptionRef.current = activeDubOption;

  // Keep cached dub options & active selection synchronized without overwriting
  // Flow A Dub API options from subsequent stream responses.
  useEffect(() => {
    if (cachedDubOptions && cachedDubOptions.length > 0) {
      outerOptionsRef.current = cachedDubOptions;
      activeOuterRef.current =
        activeDubOption ||
        cachedDubOptions.find((option) => option.active) ||
        null;
      setOuterVersion((v) => v + 1);
    } else if (activeDubOption) {
      activeOuterRef.current = activeDubOption;
      setOuterVersion((v) => v + 1);
    }
  }, [cachedDubOptions, activeDubOption]);

const closeSettings = useCallback(() => {
  if (settingsCloseTimerRef.current) {
    window.clearTimeout(settingsCloseTimerRef.current);
  }

  setIsSettingsClosing(true);

  settingsCloseTimerRef.current = window.setTimeout(() => {
    setShowSettings(false);
    setIsSettingsClosing(false);
    setSettingsView('root');
    settingsCloseTimerRef.current = null;
  }, 180);
}, []);

useEffect(() => {
  return () => {
    if (settingsCloseTimerRef.current) {
      window.clearTimeout(settingsCloseTimerRef.current);
      settingsCloseTimerRef.current = null;
    }
  };
}, []);


const bumpControls = useCallback(() => {
  setShowControls(true);

  if (hideTimerRef.current) {
    window.clearTimeout(hideTimerRef.current);
    hideTimerRef.current = null;
  }

  if (isTouchDevice) {
    if (showSettings) return;

    hideTimerRef.current = window.setTimeout(() => {
      setShowControls(false);
      hideTimerRef.current = null;
    }, 3000);
  } else if (isFullscreen) {
    hideTimerRef.current = window.setTimeout(() => {
      if (!showSettings) {
        setShowControls(false);
      }
      hideTimerRef.current = null;
    }, 3000);
  }
}, [closeSettings, isTouchDevice, isFullscreen, showSettings]);

useEffect(() => {
  if (!isFullscreen || isTouchDevice) return;

  if (hideTimerRef.current) {
    window.clearTimeout(hideTimerRef.current);
    hideTimerRef.current = null;
  }

  hideTimerRef.current = window.setTimeout(() => {
    if (!showSettings) {
      setShowControls(false);
    }
    hideTimerRef.current = null;
  }, 3000);

  return () => {
    if (hideTimerRef.current) {
      window.clearTimeout(hideTimerRef.current);
      hideTimerRef.current = null;
    }
  };
}, [isFullscreen, isTouchDevice, showSettings]);

useEffect(() => {
  if (!isTouchDevice) return;

  if (hideTimerRef.current) {
    window.clearTimeout(hideTimerRef.current);
    hideTimerRef.current = null;
  }

  if (showSettings || !showControls) return;

  hideTimerRef.current = window.setTimeout(() => {
    setShowControls(false);
    hideTimerRef.current = null;
  }, 3000);

  return () => {
    if (hideTimerRef.current) {
      window.clearTimeout(hideTimerRef.current);
      hideTimerRef.current = null;
    }
  };
}, [isTouchDevice, showSettings, showControls]);

// Merge in-manifest + outer audio using unique audio identities.
useEffect(() => {
  const outer: MovieboxStreamAudioOption[] = outerOptionsRef.current;

  const activeOuter =
    activeOuterRef.current ||
    outer.find((o) => o.active) ||
    null;

  const singleManifestLang =
    inManifestAudio.length === 1
      ? String(inManifestAudio[0]?.language || inManifestAudio[0]?.label || '').toLowerCase()
      : '';

  if (
    singleManifestLang &&
    singleManifestLang !== 'und' &&
    activeOuter &&
    (!activeOuter.lanCode || activeOuter.lanCode.toLowerCase() === 'und')
  ) {
    window.dispatchEvent(
      new CustomEvent('toonplay:moviebox-manifest-language', {
        detail: { lanCode: singleManifestLang },
      })
    );
  }

  const inOptionsRaw = inManifestAudio.map((t: any, i: number) => {
    const language = String(t.language || t.label || 'und').toLowerCase();
    const audioId = String(t.audioId ?? t.id ?? i);
    const roles = Array.isArray(t.roles) ? t.roles : [];

    return {
      kind: 'in-manifest' as const,
      audioKey: `manifest:${audioId}:${language}:${roles.join(',')}`,
      label: langLabel(language),
      lanCode: language,
      trackIndex: i,
    };
  });

  const outerOptionsRaw = outer.map((o) => {
    const isActiveOuter = Boolean(
      activeOuter &&
        o.subjectId === activeOuter.subjectId &&
        o.detailPath === activeOuter.detailPath
    );
    const rawCode = String(o.lanCode || o.language || 'und')
      .replace(/\s*dub$/i, '')
      .toLowerCase();
    const resolvedLang =
      (rawCode === 'und' || rawCode === 'original audio') &&
      isActiveOuter &&
      singleManifestLang &&
      singleManifestLang !== 'und'
        ? singleManifestLang
        : rawCode;

    return {
      kind: 'outer' as const,
      audioKey: `outer:${o.subjectId}:${o.detailPath}`,
      label: langLabel(resolvedLang),
      lanCode:
        (!o.lanCode || o.lanCode.toLowerCase() === 'und') &&
        isActiveOuter &&
        singleManifestLang &&
        singleManifestLang !== 'und'
          ? singleManifestLang
          : o.lanCode || resolvedLang,
      subjectId: o.subjectId,
      detailPath: o.detailPath,
    };
  });

  const activeOuterMatchesList = Boolean(
    activeOuter &&
      outerOptionsRaw.some(
        (o) =>
          o.subjectId === activeOuter.subjectId &&
          o.detailPath === activeOuter.detailPath
      )
  );

  // Keep multi-track in-manifest player audio distinct from MovieBox outer dubs.
  // For single-track MovieBox streams whose active outer dub is already in outerOptionsRaw,
  // avoid duplicating the currently playing language (e.g. "French" + "French 2").
  const includeSingleManifest =
    inOptionsRaw.length > 1 ||
    outerOptionsRaw.length === 0 ||
    !activeOuterMatchesList;

  const allRaw = includeSingleManifest
    ? [...inOptionsRaw, ...outerOptionsRaw]
    : [...outerOptionsRaw];
  const labels = dedupeLabels(allRaw.map((o) => o.label));

  const merged: MergedAudioOption[] = allRaw.map((o, i) => ({
    ...o,
    label: labels[i],
  }));

  const activeManifestIndex = inManifestAudio.findIndex(
    (t: any) => t.active
  );

  const activeManifestOption =
    includeSingleManifest && activeManifestIndex >= 0
      ? merged[activeManifestIndex]
      : null;

  const activeOuterOption = activeOuter
    ? merged.find(
        (o) =>
          o.kind === 'outer' &&
          o.subjectId === activeOuter.subjectId &&
          o.detailPath === activeOuter.detailPath
      ) || null
    : null;

  const activeOption =
    inManifestAudio.length > 1
      ? activeManifestOption || activeOuterOption
      : activeOuterOption || activeManifestOption;
  const activeLabel = activeOption?.label || null;
  const activeKey = activeOption?.audioKey || null;

  setMergedAudio(merged);
  setActiveAudioLabel(activeLabel);
  setActiveAudioKey(activeKey);

  onAudioOptionsChange?.(merged, activeLabel);

  window.dispatchEvent(
    new CustomEvent('toonplay:moviebox-audio-options', {
      detail: {
        options: merged,
        activeLabel,
        activeAudioKey: activeKey,
      },
    })
  );
}, [inManifestAudio, outerVersion, onAudioOptionsChange]);

  // Setup
  const preloadedPlaybackUrl = preloadedStream?.data?.streams?.[0]?.url || '';
  useEffect(() => {
    let cancelled = false;
    reportedReadyRef.current = false;
    const createdBlobUrls: string[] = [];
    let detachVideoListeners: (() => void) | null = null;

    // Preserve current playback position when switching languages within the same mounted player.
    const existingVideo = videoRef.current;
    if (
      lastLoadedStreamUrlRef.current &&
      lastLoadedStreamUrlRef.current !== streamUrl &&
      existingVideo &&
      Number.isFinite(existingVideo.currentTime) &&
      existingVideo.currentTime > 1
    ) {
      resumeTimeOnSwitchRef.current = existingVideo.currentTime;
    }

    async function setup() {
      setIsLoading(true);
      setIsBuffering(false);
      setError(null);
      setQualityTracks([]);
      setTextTracks([]);
      setInManifestAudio([]);
      if (!(cachedDubOptionsRef.current && cachedDubOptionsRef.current.length > 0)) {
        setMergedAudio([]);
        setActiveAudioLabel(null);
      }
      setActiveQualityId('auto');
      setActiveTextId('off');
      setPlaybackRate(1);
      setSettingsView('root');

      try {
        // Reuse pre-fetched stream payload from MovieBox in-memory session cache when available
        // so initialization and switching back to a cached language never trigger extra API calls.
        const json =
          preloadedStreamRef.current?.success &&
          preloadedStreamRef.current?.data?.streams?.[0]?.url
            ? preloadedStreamRef.current
            : await fetchMovieboxStream(streamUrl);
        if (cancelled) return;

        const data = json.data;
        const stream = data.streams?.[0];
        if (!stream?.url) throw new Error('No stream URL');
        lastLoadedStreamUrlRef.current = streamUrl;

        // Preserve cached Dub API options when provided (Flow A / session cache);
        // never overwrite them with a new stream endpoint response's audioOptions.
        const lockedDubs = cachedDubOptionsRef.current;
        if (lockedDubs && lockedDubs.length > 0) {
          outerOptionsRef.current = lockedDubs;
          activeOuterRef.current =
            activeDubOptionRef.current ||
            lockedDubs.find((option) => option.active) ||
            null;
        } else {
          outerOptionsRef.current = data.audioOptions || [];
          activeOuterRef.current =
            data.activeAudio ||
            outerOptionsRef.current.find((option) => option.active) ||
            null;
        }
        setOuterVersion((v) => v + 1);

        const shaka = await loadShaka();
        if (cancelled) return;
        shaka.polyfill.installAll();
        if (!shaka.Player.isBrowserSupported()) {
          throw new Error('Browser not supported by shaka');
        }

        const video = videoRef.current;
        if (!video) throw new Error('Video element missing');

        if (playerRef.current) {
          try { await playerRef.current.destroy(); } catch {}
          playerRef.current = null;
        }

        const player = new shaka.Player();

        await player.attach(video);
        if (cancelled) {
          try { await player.destroy(); } catch {}
          return;
        }
        playerRef.current = player;

        player.configure({
          textDisplayer: {
            fontScaleFactor: subtitleSize / 100,
          },
        });

        player.addEventListener('error', (e: any) => {
          const d = e?.detail;
          const msg = d?.message || 'Playback error';
          setError(msg);
          onError?.(msg);
        });

        const onTimeUpdate = () => {
          if (scrubRef.current) return;
          setCurrentTime(video.currentTime);
          if (Number.isFinite(video.duration)) setDuration(video.duration);
        };
        const onPlay = () => setIsPlaying(true);
        const onPause = () => setIsPlaying(false);
        const onEndedEv = () => onEnded?.();
        const onVolumeChange = () => {
          setVolume(video.volume);
          setIsMuted(video.muted);
        };
        const onDurationChange = () => {
          if (Number.isFinite(video.duration)) setDuration(video.duration);
        };
        let initialSeekPending = false;

        const onWaiting = () => {
          setIsBuffering(true);
        };

        const onPlaying = () => {
          setIsBuffering(false);
          setIsPlaying(true);
        };

        const onCanPlay = () => {
          if (!video.seeking && !initialSeekPending) {
            setIsBuffering(false);
          }
        };

        const onSeeked = () => {
          if (!video.seeking) {
            initialSeekPending = false;

            if (video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA) {
              setIsBuffering(false);
            }
          }
        };

        video.addEventListener('timeupdate', onTimeUpdate);
        video.addEventListener('play', onPlay);
        video.addEventListener('pause', onPause);
        video.addEventListener('ended', onEndedEv);
        video.addEventListener('volumechange', onVolumeChange);
        video.addEventListener('durationchange', onDurationChange);
        video.addEventListener('waiting', onWaiting);
        video.addEventListener('playing', onPlaying);
        video.addEventListener('canplay', onCanPlay);
        video.addEventListener('seeked', onSeeked);

        detachVideoListeners = () => {
          video.removeEventListener('timeupdate', onTimeUpdate);
          video.removeEventListener('play', onPlay);
          video.removeEventListener('pause', onPause);
          video.removeEventListener('ended', onEndedEv);
          video.removeEventListener('volumechange', onVolumeChange);
          video.removeEventListener('durationchange', onDurationChange);
          video.removeEventListener('waiting', onWaiting);
          video.removeEventListener('playing', onPlaying);
          video.removeEventListener('canplay', onCanPlay);
          video.removeEventListener('seeked', onSeeked);
        };

        await player.load(stream.url);
        if (cancelled) return;

        // Load captions in the background so subtitle downloads/registration do not
        // delay autoplay and player readiness below. Preserve registration order.
        const extCaptions = stream.captions?.extCaptions || [];
        if (extCaptions.length > 0) {
          void (async () => {
            const fetchedCaptions = await Promise.all(
              extCaptions.map(async (cap: any) => {
                if (!cap?.url) return null;
                try {
                  const srtRes = await fetch(cap.url);
                  if (!srtRes.ok) return null;
                  const srtText = await srtRes.text();
                  return { cap, vtt: srtToVtt(srtText) };
                } catch (err) {
                  console.warn('[Moviebox] Failed to fetch caption', cap?.lan, err);
                  return null;
                }
              })
            );
            if (cancelled) return;

            for (const item of fetchedCaptions) {
              if (!item || cancelled) continue;
              try {
                const blob = new Blob([item.vtt], { type: 'text/vtt' });
                const blobUrl = URL.createObjectURL(blob);
                createdBlobUrls.push(blobUrl);
                const label = item.cap.lanName || langLabel(item.cap.lan || 'und');
                await player.addTextTrackAsync(
                  blobUrl,
                  item.cap.lan || 'und',
                  'subtitles',
                  'text/vtt',
                  '',
                  label
                );
              } catch (err) {
                console.warn('[Moviebox] Failed to add caption', item.cap?.lan, err);
              }
            }
            if (!cancelled) setTextTracks(player.getTextTracks() || []);
          })();
        }

        if (cancelled) return;

        const effectiveStartAt =
          resumeTimeOnSwitchRef.current > 1 ? resumeTimeOnSwitchRef.current : startAt;
        resumeTimeOnSwitchRef.current = 0;

        if (effectiveStartAt > 1) {
          initialSeekPending = true;
          setIsBuffering(true);
          video.currentTime = effectiveStartAt;
        }
        if (autoPlay) {
          try { await video.play(); } catch {}
        }

        const dur = Number.isFinite(video.duration) ? video.duration : (stream.duration || 0);
        setDuration(dur);
        if (!reportedReadyRef.current) {
          reportedReadyRef.current = true;
          onReady?.(dur);
        }

        const variants = player.getVariantTracks() || [];
        setQualityTracks(variants);
        setTextTracks(player.getTextTracks() || []);

const refreshAudioTracks = () => {
  const variants = player.getVariantTracks() || [];
  const activeVariant = variants.find((track: any) => track.active);
  const audioMap = new Map<string, any>();

  for (const track of variants) {
    if (!track.audioId && !track.language) continue;

    const language = String(track.language || track.label || 'und');
    const roles = Array.isArray(track.audioRoles)
      ? track.audioRoles
      : Array.isArray(track.roles)
        ? track.roles
        : [];

    const audioId = track.audioId ?? track.id;
    const key = `${audioId}|${language.toLowerCase()}|${roles.join(',')}`;

    const audioOption = {
      ...track,
      id: audioId,
      audioId,
      variantId: track.id,
      language,
      roles,
    };

    const existing = audioMap.get(key);

    // Prefer the active variant when multiple video qualities
    // contain the same audio track.
    if (!existing || track.active) {
      audioMap.set(key, audioOption);
    }
  }

  setInManifestAudio(Array.from(audioMap.values()));
};

player.addEventListener('trackschanged', refreshAudioTracks);
player.addEventListener('variantchanged', refreshAudioTracks);
refreshAudioTracks();

        setIsLoading(false);
      } catch (e: any) {
        if (cancelled) return;
        const msg = e?.message || 'Failed to load stream';
        setError(msg);
        onError?.(msg);
        setIsLoading(false);
      }
    }

    setup();

    return () => {
      cancelled = true;
      if (detachVideoListeners) {
        detachVideoListeners();
        detachVideoListeners = null;
      }
      if (progressTimerRef.current) window.clearInterval(progressTimerRef.current);
      if (hideTimerRef.current) window.clearTimeout(hideTimerRef.current);
      const p = playerRef.current;
      if (p) {
        try { p.destroy(); } catch {}
        playerRef.current = null;
      }
      for (const blobUrl of createdBlobUrls) {
        try { URL.revokeObjectURL(blobUrl); } catch {}
      }
      createdBlobUrls.length = 0;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [streamUrl, preloadedPlaybackUrl]);

  // Progress emitter
  useEffect(() => {
    if (progressTimerRef.current) window.clearInterval(progressTimerRef.current);
    progressTimerRef.current = window.setInterval(() => {
      if (document.hidden) return;
      const v = videoRef.current;
      if (!v || v.paused) return;
      if (!Number.isFinite(v.currentTime) || v.currentTime <= 0) return;
      if (Number.isFinite(v.duration) && v.currentTime >= v.duration - 3) return;
      onProgress?.(v.currentTime, Number.isFinite(v.duration) ? v.duration : 0);
    }, 5000);
    return () => {
      if (progressTimerRef.current) window.clearInterval(progressTimerRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [streamUrl]);
  
  const selectManifestAudioTrack = (p: any, selectedOption: any) => {
  const variants = p.getVariantTracks() || [];

  const candidates = variants.filter(
    (track: any) =>
      String(track.audioId ?? track.id) === String(selectedOption.audioId ?? selectedOption.id)
  );

  if (!candidates.length) {
    console.warn('[Moviebox] Matching audio variant not found:', selectedOption);
    return null;
  }

  const activeVariant = variants.find((track: any) => track.active);

  // Prefer the same video quality to avoid an unnecessary quality change.
  const selectedTrack =
    candidates.find(
      (track: any) =>
        activeVariant &&
        String(track.videoId ?? '') === String(activeVariant.videoId ?? '')
    ) ||
    candidates.sort(
      (a: any, b: any) => (b.bandwidth || 0) - (a.bandwidth || 0)
    )[0];

  p.selectVariantTrack(selectedTrack, true);

  return selectedTrack;
};
  
  // Listen for audio-switch events from WatchPage.
  useEffect(() => {
    const onInManifest = (ev: Event) => {
      const detail = (ev as CustomEvent<{
        trackIndex: number;
        label: string;
      }>).detail;

      if (typeof detail?.trackIndex !== 'number') return;

      const p = playerRef.current;
      if (!p) return;

      const selectedOption = inManifestAudio[detail.trackIndex];
      if (!selectedOption) return;

const track = selectManifestAudioTrack(p, selectedOption);

if (!track) return;

try {
  const label = detail.label || langLabel(track.language || 'und');
  const audioKey = mergedAudio.find(
    (o) =>
      o.kind === 'in-manifest' &&
      o.trackIndex === detail.trackIndex
  )?.audioKey || null;

  setActiveAudioLabel(label);
  setActiveAudioKey(audioKey);

  window.dispatchEvent(
    new CustomEvent('toonplay:moviebox-audio-options', {
      detail: {
        options: mergedAudio,
        activeLabel: label,
        activeAudioKey: audioKey,
      },
    })
  );
} catch (err) {
  console.error('[Moviebox] Manifest audio selection failed:', err);
}
    };

    window.addEventListener('toonplay:moviebox-in-manifest-audio', onInManifest);
    return () => {
      window.removeEventListener('toonplay:moviebox-in-manifest-audio', onInManifest);
    };
  }, [inManifestAudio, mergedAudio]);


// Close settings when tapping/clicking anywhere outside the settings panel.
useEffect(() => {
  if (!showSettings) return;

  const onOutsidePointerDown = (e: PointerEvent) => {
    const target = e.target as Node;

    if (
      settingsPanelRef.current?.contains(target) ||
      settingsRef.current?.contains(target)
    ) {
      return;
    }

    closeSettings();
  };

  document.addEventListener('pointerdown', onOutsidePointerDown, true);

  return () => {
    document.removeEventListener('pointerdown', onOutsidePointerDown, true);
  };
}, [showSettings, closeSettings]);

  const togglePlay = useCallback(async () => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) { try { await v.play(); } catch {} }
    else v.pause();
  }, []);

  const skip = useCallback((delta: number) => {
    const v = videoRef.current;
    if (!v) return;
    const target = Math.max(0, Math.min((v.duration || 0), v.currentTime + delta));
    v.currentTime = target;
    setCurrentTime(target);
    bumpControls();
  }, [bumpControls]);

  const seekTo = useCallback((t: number) => {
    const v = videoRef.current;
    if (!v) return;
    v.currentTime = t;
    setCurrentTime(t);
  }, []);

  const onSeekStart = useCallback(() => { scrubRef.current = true; }, []);
  const onSeekChange = useCallback((t: number) => {
    setScrubTime(t);
    seekTo(t);
  }, [seekTo]);
  const onSeekEnd = useCallback(() => {
    scrubRef.current = false;
    setScrubTime(null);
  }, []);

  const toggleMute = useCallback(() => {
    const v = videoRef.current;
    if (!v) return;
    v.muted = !v.muted;
  }, []);

  const changeVolume = useCallback((v0: number) => {
    const v = videoRef.current;
    if (!v) return;
    v.volume = v0;
    v.muted = v0 === 0;
  }, []);

const toggleFullscreen = useCallback(async () => {
  const el = containerRef.current;
  if (!el) return;

  try {
    if (!document.fullscreenElement) {
      await el.requestFullscreen();
      setIsFullscreen(true);

      // Lock mobile screen to landscape after entering fullscreen.
      try {
        const orientation = screen.orientation as any;

        if (orientation?.lock) {
          await orientation.lock('landscape');
        }
      } catch (err) {
        console.warn('[Player] Landscape orientation lock unavailable:', err);
      }
    } else {
      await document.exitFullscreen();
      setIsFullscreen(false);

      try {
        const orientation = screen.orientation as any;
        orientation?.unlock?.();
      } catch {}
    }
  } catch (err) {
    console.error('[Player] Fullscreen failed:', err);
  }
}, []);

useEffect(() => {
  const onFs = () => {
    const active = Boolean(document.fullscreenElement);
    setIsFullscreen(active);

    if (!active) {
      try {
        const orientation = screen.orientation as any;
        orientation?.unlock?.();
      } catch {}
    }
  };

  document.addEventListener('fullscreenchange', onFs);

  return () => {
    document.removeEventListener('fullscreenchange', onFs);
  };
}, []);

  const togglePip = useCallback(async () => {
    const v = videoRef.current as any;
    if (!v) return;
    try {
      if (document.pictureInPictureElement) {
        await (document as any).exitPictureInPicture();
      } else if (v.requestPictureInPicture) {
        await v.requestPictureInPicture();
      }
    } catch {}
  }, []);

  const selectQuality = useCallback((trackId: number | 'auto') => {
    const p = playerRef.current;
    if (!p) return;
    if (trackId === 'auto') {
      p.configure({ abr: { enabled: true } });
      setActiveQualityId('auto');
    } else {
      p.configure({ abr: { enabled: false } });
      const t = qualityTracks.find((x) => x.id === trackId);
      if (t) p.selectVariantTrack(t, true);
      setActiveQualityId(trackId);
    }
  }, [qualityTracks]);

const selectInManifestAudio = useCallback((index: number) => {
  const p = playerRef.current;
  if (!p) return;

  const selectedOption = inManifestAudio[index];
  if (!selectedOption) return;

  const track = selectManifestAudioTrack(p, selectedOption);
  if (!track) return;

  const option = mergedAudio.find(
    (o) =>
      o.kind === 'in-manifest' &&
      o.trackIndex === index
  );

  if (!option) return;

const label = option.label;

setActiveAudioLabel(label);
setActiveAudioKey(option.audioKey);

window.dispatchEvent(
  new CustomEvent('toonplay:moviebox-audio-user-selected', {
    detail: {
      lanCode: option.lanCode,
    },
  })
);

  window.dispatchEvent(
    new CustomEvent('toonplay:moviebox-audio-options', {
      detail: {
        options: mergedAudio,
        activeLabel: label,
        activeAudioKey: option.audioKey,
      },
    })
  );
}, [inManifestAudio, mergedAudio]);

  const selectText = useCallback((trackId: number | 'off') => {
    const p = playerRef.current;
    if (!p) return;
    if (trackId === 'off') {
      p.setTextTrackVisibility(false);
      setActiveTextId('off');
      return;
    }
    const t = textTracks.find((x) => x.id === trackId);
    if (t) {
      p.selectTextTrack(t);
      p.setTextTrackVisibility(true);
      setActiveTextId(trackId);
    }
  }, [textTracks]);
  
  // Apply subtitle size immediately when changed.
useEffect(() => {
  const p = playerRef.current;
  if (!p) return;

  try {
    p.configure({
      textDisplayer: {
        fontScaleFactor: subtitleSize / 100,
      },
    });
  } catch (err) {
    console.warn('[Moviebox] Subtitle size update failed:', err);
  }
}, [subtitleSize]);

// Apply vertical position to native WebVTT subtitle cues.
useEffect(() => {
  const video = videoRef.current;
  if (!video || activeTextId === 'off') return;

  const applySubtitlePosition = () => {
    const tracks = video.textTracks;
    const targetLine = 100 - subtitlePosition;

    for (let i = 0; i < tracks.length; i++) {
      const track = tracks[i];

      // Only modify the currently visible subtitle track.
      if (track.mode !== 'showing' || !track.cues) continue;

      for (let j = 0; j < track.cues.length; j++) {
        const cue = track.cues[j] as VTTCue;

        if (subtitlePosition === 0 && (cue.snapToLines !== false || cue.line === 'auto')) {
          continue;
        }
        if (typeof cue.line === 'number' && cue.snapToLines === false &&
            cue.line === targetLine) {
          continue;
        }

        try {
          cue.snapToLines = false;
          cue.line = targetLine;
        } catch (err) {
          console.warn('[Moviebox] Subtitle positioning failed:', err);
        }
      }
    }
  };

  applySubtitlePosition();

  if (subtitlePosition === 0) return;

  video.addEventListener('timeupdate', applySubtitlePosition);
  video.addEventListener('loadeddata', applySubtitlePosition);

  return () => {
    video.removeEventListener('timeupdate', applySubtitlePosition);
    video.removeEventListener('loadeddata', applySubtitlePosition);
  };
}, [subtitlePosition, activeTextId]);

  const applyPlaybackRate = useCallback((rate: number) => {
    const v = videoRef.current;
    if (!v) return;
    v.playbackRate = rate;
    setPlaybackRate(rate);
  }, []);

  const qualityLabel =
    activeQualityId === 'auto'
      ? 'Auto'
      : (() => {
          const q = qualityTracks.find((x) => x.id === activeQualityId);
          return q?.height ? `${q.height}p` : 'Auto';
        })();

  const textLabel =
    activeTextId === 'off'
      ? 'Off'
      : (() => {
          const t = textTracks.find((x) => x.id === activeTextId);
          return t?.label || t?.language || 'On';
        })();

  const hasSettings =
    qualityTracks.length > 0 ||
    mergedAudio.length > 1 ||
    textTracks.length > 0 ||
    true; // speed always available

const displayTime = scrubTime != null ? scrubTime : currentTime;

const progressPercent =
  duration > 0
    ? Math.min(100, Math.max(0, (displayTime / duration) * 100))
    : 0;

  const speeds = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];

  // Shared settings panel: anchored dropdown on desktop, centered modal on touch devices.
  const settingsMenu = showSettings && (
    <div
  ref={settingsPanelRef}
  className={`${isTouchDevice ? 'relative' : 'absolute bottom-full right-0 mb-2'} moviebox-settings-panel w-64 ${isTouchDevice ? 'max-h-[min(80dvh,560px)]' : 'max-h-80'} overflow-y-auto moviebox-player-scroll rounded-xl bg-[#111214] border border-white/10 shadow-2xl text-sm ${
    isSettingsClosing ? 'moviebox-settings-exit' : 'moviebox-settings-enter'
  }`}
>
                    {/* Root view */}
                    {settingsView === 'root' && (
                      <>
<div className="flex items-center justify-between px-3 py-2 border-b border-white/10">
  <span className="text-[11px] uppercase tracking-wide text-white/50">
    Settings
  </span>

  <button
    onClick={closeSettings}
    className="p-1 rounded-md text-white/50 hover:text-white hover:bg-white/10 active:bg-white/20 transition-colors cursor-pointer"
    title="Close settings"
    aria-label="Close settings"
  >
    <X className="w-4 h-4" />
  </button>
</div>
                        <button onClick={() => setSettingsView('quality')} className="w-full flex items-center justify-between px-3 py-2 text-left text-xs hover:bg-white/10 transition-colors cursor-pointer">
                          <span className="flex items-center gap-2"><Settings2 className="w-3.5 h-3.5 text-white/70" />Quality</span>
                          <span className="text-white/60">{qualityLabel}</span>
                        </button>
                        <button onClick={() => setSettingsView('speed')} className="w-full flex items-center justify-between px-3 py-2 text-left text-xs hover:bg-white/10 transition-colors cursor-pointer">
                          <span className="flex items-center gap-2"><Gauge className="w-3.5 h-3.5 text-white/70" />Speed</span>
                          <span className="text-white/60">{playbackRate === 1 ? 'Normal' : `${playbackRate}x`}</span>
                        </button>
                        {mergedAudio.length > 0 && (
                          <button onClick={() => setSettingsView('audio')} className="w-full flex items-center justify-between px-3 py-2 text-left text-xs hover:bg-white/10 transition-colors cursor-pointer">
                            <span className="flex items-center gap-2"><Languages className="w-3.5 h-3.5 text-white/70" />Audio</span>
                            <span className="text-white/60 truncate max-w-[80px]">{activeAudioLabel || 'Audio'}</span>
                          </button>
                        )}
                        {textTracks.length > 0 && (
                          <button onClick={() => setSettingsView('subtitles')} className="w-full flex items-center justify-between px-3 py-2 text-left text-xs hover:bg-white/10 transition-colors cursor-pointer">
                            <span className="flex items-center gap-2"><Type className="w-3.5 h-3.5 text-white/70" />Subtitles</span>
                            <span className="text-white/60">{textLabel}</span>
                          </button>
                        )}
{textTracks.length > 0 && (
  <button
    onClick={() => setSettingsView('subtitleStyle')}
    className="w-full flex items-center justify-between px-3 py-2 text-left text-xs hover:bg-white/10 transition-colors cursor-pointer"
  >
    <span className="flex items-center gap-2">
      <SlidersHorizontal className="w-3.5 h-3.5 text-white/70" />
      Customizer
    </span>
    <span className="text-white/50">Adjust</span>
  </button>
)}
                      </>
                    )}

                    {/* Quality submenu */}
                    {settingsView === 'quality' && (
                      <>
                        <button onClick={() => setSettingsView('root')} className="w-full flex items-center gap-1 px-3 py-2 text-left text-[11px] uppercase tracking-wide text-white/60 border-b border-white/10 hover:bg-white/10 transition-colors cursor-pointer">
                          <ChevronLeft className="w-3.5 h-3.5" />Quality
                        </button>
                        <button
                          onClick={() => selectQuality('auto')}
                          className={`w-full flex items-center justify-between px-3 py-2 text-left text-xs hover:bg-white/10 transition-colors cursor-pointer ${activeQualityId === 'auto' ? 'text-white' : 'text-white/80'}`}
                        >
                          <span>Auto</span>
                          {activeQualityId === 'auto' && <Check className="w-3.5 h-3.5 text-white" />}
                        </button>
                        {sortedQualityTracks.map((t: any) => (
                            <button
                              key={`q-${t.id}`}
                              onClick={() => selectQuality(t.id)}
                              className={`w-full flex items-center justify-between px-3 py-2 text-left text-xs hover:bg-white/10 transition-colors cursor-pointer ${activeQualityId === t.id ? 'text-white' : 'text-white/80'}`}
                            >
                              <span>
                                {t.height ? `${t.height}p` : 'Unknown'}
                                {t.bandwidth ? ` · ${Math.round(t.bandwidth / 1000)}k` : ''}
                              </span>
                              {activeQualityId === t.id && <Check className="w-3.5 h-3.5 text-white" />}
                            </button>
                          ))}
                      </>
                    )}

                    {/* Speed submenu */}
                    {settingsView === 'speed' && (
                      <>
                        <button onClick={() => setSettingsView('root')} className="w-full flex items-center gap-1 px-3 py-2 text-left text-[11px] uppercase tracking-wide text-white/60 border-b border-white/10 hover:bg-white/10 transition-colors cursor-pointer">
                          <ChevronLeft className="w-3.5 h-3.5" />Speed
                        </button>
                        {speeds.map((s) => (
                          <button
                            key={s}
                            onClick={() => { applyPlaybackRate(s); }}
                            className={`w-full flex items-center justify-between px-3 py-2 text-left text-xs hover:bg-white/10 transition-colors cursor-pointer ${playbackRate === s ? 'text-white' : 'text-white/80'}`}
                          >
                            <span>{s === 1 ? 'Normal' : `${s}x`}</span>
                            {playbackRate === s && <Check className="w-3.5 h-3.5 text-white" />}
                          </button>
                        ))}
                      </>
                    )}

                    {/* Audio submenu */}
                    {settingsView === 'audio' && (
                      <>
                        <button onClick={() => setSettingsView('root')} className="w-full flex items-center gap-1 px-3 py-2 text-left text-[11px] uppercase tracking-wide text-white/60 border-b border-white/10 hover:bg-white/10 transition-colors cursor-pointer">
                          <ChevronLeft className="w-3.5 h-3.5" />Audio
                        </button>
                        {mergedAudio.length === 0 && (
                          <div className="px-3 py-2 text-xs text-white/50">No audio options</div>
                        )}
                        {mergedAudio.map((opt, idx) => (
                          <button
                            key={`audio-${opt.kind}-${idx}`}
                            onClick={() => {
                              if (opt.kind === 'in-manifest' && typeof opt.trackIndex === 'number') {
                                selectInManifestAudio(opt.trackIndex);
                              } else if (opt.kind === 'outer' && opt.subjectId && opt.detailPath) {
window.dispatchEvent(new CustomEvent('toonplay:moviebox-audio-select', {
  detail: {
    subjectId: opt.subjectId,
    detailPath: opt.detailPath,
    label: opt.label,
    lanCode: opt.lanCode,
  },
}));
closeSettings();
                              }
                            }}
                            className={`w-full flex items-center justify-between px-3 py-2 text-left text-xs hover:bg-white/10 transition-colors cursor-pointer ${activeAudioKey === opt.audioKey ? 'text-white' : 'text-white/80'}`}
                          >
                            <span>{opt.label}</span>
                            {activeAudioKey === opt.audioKey && <Check className="w-3.5 h-3.5 text-white" />}
                          </button>
                        ))}
                      </>
                    )}

                    {/* Subtitles submenu */}
                    {settingsView === 'subtitles' && (
                      <>
                        <button onClick={() => setSettingsView('root')} className="w-full flex items-center gap-1 px-3 py-2 text-left text-[11px] uppercase tracking-wide text-white/60 border-b border-white/10 hover:bg-white/10 transition-colors cursor-pointer">
                          <ChevronLeft className="w-3.5 h-3.5" />Subtitles
                        </button>
                        <button
                          onClick={() => selectText('off')}
                          className={`w-full flex items-center justify-between px-3 py-2 text-left text-xs hover:bg-white/10 transition-colors cursor-pointer ${activeTextId === 'off' ? 'text-white' : 'text-white/80'}`}
                        >
                          <span>Off</span>
                          {activeTextId === 'off' && <Check className="w-3.5 h-3.5 text-white" />}
                        </button>
                        {textTracks.map((t: any) => (
                          <button
                            key={`s-${t.id}`}
                            onClick={() => selectText(t.id)}
                            className={`w-full flex items-center justify-between px-3 py-2 text-left text-xs hover:bg-white/10 transition-colors cursor-pointer ${activeTextId === t.id ? 'text-white' : 'text-white/80'}`}
                          >
                            <span>{t.label || t.language || 'Subtitle'}</span>
                            {activeTextId === t.id && <Check className="w-3.5 h-3.5 text-white" />}
                          </button>
                        ))}
                      </>
                    )}
                    {/* Subtitle customization submenu */}
{settingsView === 'subtitleStyle' && (
  <div className="p-3 space-y-4">

    {/* Customizer header */}
    <div className="flex items-center justify-between border-b border-white/10 pb-2">
      <button
        onClick={() => setSettingsView('root')}
        className="flex items-center gap-1.5 text-xs font-semibold text-white/80 hover:text-white transition-colors cursor-pointer"
        title="Back to settings"
      >
        <ChevronLeft className="w-4 h-4" />
        Customizer
      </button>

      <button
        onClick={closeSettings}
        className="p-1 rounded-md text-white/50 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
        title="Close"
        aria-label="Close customizer"
      >
        <X className="w-4 h-4" />
      </button>
    </div>

    {/* Subtitle size */}
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <span className="flex items-center gap-2 text-xs text-white/80">
          <Type className="w-3.5 h-3.5 text-white/60" />
          Size
        </span>
        <span className="text-xs text-white/50 tabular-nums">
          {subtitleSize}%
        </span>
      </div>

      <input
        type="range"
        min={75}
        max={175}
        step={5}
        value={subtitleSize}
        onChange={(e) => setSubtitleSize(Number(e.target.value))}
        className="moviebox-player-range w-full cursor-pointer"
        style={{
          '--progress': `${((subtitleSize - 75) / 100) * 100}%`,
        } as React.CSSProperties}
      />
    </div>

    {/* Subtitle boldness */}
    <div className="space-y-2">
      <span className="flex items-center gap-2 text-xs text-white/80">
        <Bold className="w-3.5 h-3.5 text-white/60" />
        Boldness
      </span>

      <div className="grid grid-cols-3 gap-1">
        {[
          { label: 'Normal', value: 400 },
          { label: 'Medium', value: 600 },
          { label: 'Bold', value: 700 },
        ].map((option) => (
          <button
            key={option.value}
            onClick={() => setSubtitleWeight(option.value)}
            className={`py-2 rounded-lg text-xs transition-colors ${
              subtitleWeight === option.value
                ? 'bg-white text-black'
                : 'bg-white/10 text-white/70 hover:bg-white/20'
            }`}
          >
            {option.label}
          </button>
        ))}
      </div>
    </div>

    {/* Vertical subtitle position */}
    <div className="space-y-2">
      <div className="flex items-center justify-between">
          <span className="flex items-center gap-2 text-xs text-white/80">
            <MoveVertical className="w-3.5 h-3.5 text-white/60" />
            Vertical position
          </span>
        <span className="text-xs text-white/50 tabular-nums">
          {subtitlePosition === 0 ? 'Default' : `${subtitlePosition}% higher`}
        </span>
      </div>

      <input
        type="range"
        min={0}
        max={25}
        step={1}
        value={subtitlePosition}
        onChange={(e) => setSubtitlePosition(Number(e.target.value))}
        className="moviebox-player-range w-full cursor-pointer"
        style={{
          '--progress': `${(subtitlePosition / 25) * 100}%`,
        } as React.CSSProperties}
      />

      <div className="flex justify-between text-[10px] text-white/40">
        <span>Bottom</span>
        <span>Higher</span>
      </div>
    </div>

    {/* Reset customization */}
    <button
      onClick={() => {
        setSubtitleSize(100);
        setSubtitleWeight(400);
        setSubtitlePosition(0);
      }}
      className="w-full py-2 rounded-lg bg-white/10 hover:bg-white/15 text-xs text-white/80 transition-colors"
    >
      Reset to default
    </button>

  </div>
)}
                  </div>
  );

  return (
<div
  ref={containerRef}
  style={{
    '--moviebox-subtitle-weight': subtitleWeight,
    '--moviebox-subtitle-offset': `-${subtitlePosition}%`,
  } as React.CSSProperties}
  className="relative w-full h-full bg-black select-none text-white"
onMouseMove={bumpControls}
onMouseLeave={() => {
  if (!isTouchDevice) {
    setShowControls(false);
    closeSettings();

    if (hideTimerRef.current) {
      window.clearTimeout(hideTimerRef.current);
      hideTimerRef.current = null;
    }
  }
}}
    >
      <SubtitleCueStyle size={subtitleSize} weight={subtitleWeight} />


<video
  ref={videoRef}
  playsInline
  className="w-full h-full bg-black"
  onPointerDown={(e) => {
    lastPointerTypeRef.current = e.pointerType;
  }}
onClick={() => {
  if (lastPointerTypeRef.current === 'touch') {
    if (showControls) {
      // Single tap hides visible controls.
      if (hideTimerRef.current !== null) {
        window.clearTimeout(hideTimerRef.current);
        hideTimerRef.current = null;
      }

      setShowControls(false);
      closeSettings();
    } else {
      // Single tap shows hidden controls for 3 seconds.
      bumpControls();
    }

    return;
  }

  // Normal mouse/desktop behavior.
  bumpControls();
  togglePlay();
}}
/>

      {isLoading && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/70 pointer-events-none">
          <Loader2 className="w-10 h-10 text-white/80 animate-spin mb-2" />
        </div>
      )}

      {!isLoading && !error && isBuffering && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-14 h-14 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center">
            <Loader2 className="w-7 h-7 text-white/90 animate-spin" />
          </div>
        </div>
      )}

      {error && !isLoading && (
        <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-black/85">
          <AlertCircle className="w-10 h-10 text-white/80 mb-2" />
          <span className="text-sm text-white font-medium mb-1">Playback error</span>
          <span className="text-xs text-white/60 max-w-md">{error}</span>
        </div>
      )}

      <div
        className={`absolute inset-x-0 bottom-0 z-20 px-2 sm:px-4 pb-2 sm:pb-3 pt-10 bg-gradient-to-t from-black/90 via-black/50 to-transparent transition-opacity duration-200 ${
          showControls ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
      >
        <div className="flex items-center gap-2 sm:gap-3">
          <span className="text-[10px] sm:text-[11px] font-mono text-white/80 tabular-nums w-10 sm:w-12 text-right">
            {fmtTime(displayTime)}
          </span>
          <input
            type="range"
            min={0}
            max={Math.max(1, duration)}
            step={0.1}
            value={Math.min(displayTime, duration || 0)}
            onMouseDown={onSeekStart}
            onTouchStart={onSeekStart}
            onChange={(e) => onSeekChange(Number(e.target.value))}
            onMouseUp={onSeekEnd}
            onTouchEnd={onSeekEnd}
            onKeyUp={onSeekEnd}
            className="moviebox-player-range flex-1 cursor-pointer"
            style={{ '--progress': `${progressPercent}%` } as React.CSSProperties}
          />
          <span className="text-[10px] sm:text-[11px] font-mono text-white/80 tabular-nums w-10 sm:w-12">
            {fmtTime(duration)}
          </span>
        </div>

        <div className="mt-1.5 sm:mt-2 flex items-center justify-between gap-2">
          <div className="flex items-center gap-0.5 sm:gap-1">
            <button onClick={() => skip(-10)} className="p-1.5 sm:p-2 rounded-lg hover:bg-white/10 active:bg-white/20 transition-colors cursor-pointer" title="Rewind 10s">
              <RotateCcw className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
            <button onClick={togglePlay} className="p-1.5 sm:p-2 rounded-lg hover:bg-white/10 active:bg-white/20 transition-colors cursor-pointer" title={isPlaying ? 'Pause' : 'Play'}>
              {isPlaying ? <Pause className="w-5 h-5 sm:w-6 sm:h-6" /> : <Play className="w-5 h-5 sm:w-6 sm:h-6" />}
            </button>
            <button onClick={() => skip(10)} className="p-1.5 sm:p-2 rounded-lg hover:bg-white/10 active:bg-white/20 transition-colors cursor-pointer" title="Forward 10s">
              <RotateCw className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>

            <div className="hidden xs:flex items-center gap-1 ml-1">
              <button onClick={toggleMute} className="p-1.5 sm:p-2 rounded-lg hover:bg-white/10 active:bg-white/20 transition-colors cursor-pointer" title={isMuted ? 'Unmute' : 'Mute'}>
                {isMuted || volume === 0 ? <VolumeX className="w-4 h-4 sm:w-5 sm:h-5" /> : <Volume2 className="w-4 h-4 sm:w-5 sm:h-5" />}
              </button>
              <input
                type="range"
                min={0}
                max={1}
                step={0.01}
                value={isMuted ? 0 : volume}
                onChange={(e) => changeVolume(Number(e.target.value))}
                className="moviebox-player-range w-14 sm:w-20 cursor-pointer"
              />
            </div>
          </div>

          <div className="flex items-center gap-0.5 sm:gap-1">
            {mergedAudio.length > 1 && (
              <button
                onClick={() => { setShowSettings(true); setSettingsView('audio'); }}
                className="hidden sm:flex items-center gap-1 px-1.5 sm:px-2 py-1.5 rounded-lg hover:bg-white/10 active:bg-white/20 transition-colors text-xs cursor-pointer"
                title="Audio"
              >
                <Languages className="w-4 h-4 sm:w-5 sm:h-5" />
                <span className="hidden md:inline">{activeAudioLabel || 'Audio'}</span>
              </button>
            )}

            {textTracks.length > 0 && (
              <button
                onClick={() => { setShowSettings(true); setSettingsView('subtitles'); }}
                className="p-1.5 sm:p-2 rounded-lg hover:bg-white/10 active:bg-white/20 transition-colors cursor-pointer"
                title="Subtitles"
              >
                <Subtitles className="w-4 h-4 sm:w-5 sm:h-5" />
              </button>
            )}

            {hasSettings && (
              <div className="relative" ref={settingsRef}>
<button
  onClick={() => {
    if (showSettings) {
      closeSettings();
    } else {
      if (settingsCloseTimerRef.current) {
        window.clearTimeout(settingsCloseTimerRef.current);
        settingsCloseTimerRef.current = null;
      }

      setIsSettingsClosing(false);
      setSettingsView('root');
      setShowSettings(true);
    }
  }}
  className="p-1.5 sm:p-2 rounded-lg hover:bg-white/10 active:bg-white/20 transition-colors cursor-pointer"
  title="Settings"
>
                  <Settings2 className="w-4 h-4 sm:w-5 sm:h-5" />
                </button>
                {showSettings && (
                  isTouchDevice
                    ? createPortal(
<div
  className="moviebox-mobile-settings-overlay"
  onPointerDown={(e) => {
    if (e.target === e.currentTarget) {
      closeSettings();
    }
  }}
>
  <div
    className="moviebox-mobile-settings-center"
    onPointerDown={(e) => e.stopPropagation()}
  >
                            {settingsMenu}
                          </div>
                        </div>,
                        (document.fullscreenElement || document.body) as HTMLElement
                      )
                    : settingsMenu
                )}
              </div>
            )}

            <button onClick={togglePip} className="p-1.5 sm:p-2 rounded-lg hover:bg-white/10 active:bg-white/20 transition-colors cursor-pointer" title="Picture in picture">
              <PictureInPicture2 className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>

            <button onClick={toggleFullscreen} className="p-1.5 sm:p-2 rounded-lg hover:bg-white/10 active:bg-white/20 transition-colors cursor-pointer" title={isFullscreen ? 'Exit fullscreen' : 'Fullscreen'}>
              {isFullscreen ? <Minimize className="w-4 h-4 sm:w-5 sm:h-5" /> : <Maximize className="w-4 h-4 sm:w-5 sm:h-5" />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};