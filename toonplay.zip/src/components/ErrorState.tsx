import React from 'react';
import { AlertCircle, RefreshCw, Radio } from 'lucide-react';

interface ErrorStateProps {
  errorMessage: string;
  onRetry: () => void;
  isRetrying: boolean;
}

export const ErrorState: React.FC<ErrorStateProps> = ({
  errorMessage,
  onRetry,
  isRetrying,
}) => {
  return (
    <div className="w-full min-h-[70vh] flex items-center justify-center p-6 bg-[#0b0c16]">
      <div className="max-w-md w-full bg-[#101222] border border-[#262942] rounded-2xl p-8 text-center shadow-2xl shadow-black/80 space-y-5">
        <div className="w-14 h-14 rounded-full bg-rose-950/40 border border-rose-800/40 text-rose-400 flex items-center justify-center mx-auto">
          <AlertCircle className="w-7 h-7" />
        </div>

        <div className="space-y-2">
          <h2 className="text-lg font-semibold text-white">Unable to Connect to Streaming Network</h2>
          <p className="text-xs text-slate-400 leading-relaxed">
            {errorMessage ||
              'Could not establish a connection to the ToonPlay streaming servers. Please verify your internet connection and retry.'}
          </p>
        </div>

        <div className="p-3 bg-[#0a0b16] rounded-xl border border-[#202338] text-[11px] font-mono text-indigo-300 text-left space-y-1">
          <div className="flex items-center gap-2">
            <Radio className="w-3.5 h-3.5 text-indigo-400" />
            <span className="text-slate-400">Status:</span>
            <span className="text-indigo-200">Reconnection Available</span>
          </div>
          <p className="text-slate-500">Encrypted Fast-Delivery Streaming Protocol</p>
        </div>

        <button
          onClick={onRetry}
          disabled={isRetrying}
          className="w-full py-2.5 px-4 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 disabled:opacity-50 rounded-xl transition-all duration-200 flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 cursor-pointer"
        >
          <RefreshCw className={`w-4 h-4 ${isRetrying ? 'animate-spin' : ''}`} />
          <span>{isRetrying ? 'Connecting...' : 'Retry Connection'}</span>
        </button>
      </div>
    </div>
  );
};
