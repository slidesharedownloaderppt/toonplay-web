import React from 'react';

export const WatchSkeleton: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#070811] text-slate-100 pb-20">
      {/* Header bar */}
      <div className="border-b border-[#181a2e] bg-[#0b0c16]/95 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-2.5 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="w-20 h-7 rounded-lg bg-[#16182c] animate-pulse" />
            <div className="hidden sm:block w-px h-5 bg-[#22253d]" />
            <div className="w-32 sm:w-48 h-4 bg-[#16182c] rounded animate-pulse" />
            <div className="w-16 h-5 rounded-md bg-[#16182c] animate-pulse" />
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <div className="w-20 h-8 rounded-lg bg-[#16182c] animate-pulse" />
            <div className="w-16 h-8 rounded-lg bg-[#16182c] animate-pulse" />
            <div className="hidden lg:block w-20 h-8 rounded-lg bg-[#16182c] animate-pulse" />
          </div>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-8 pt-4">
        <div className="grid gap-4 lg:gap-6 grid-cols-1 xl:grid-cols-[minmax(0,1fr)_340px] 2xl:grid-cols-[minmax(0,1fr)_380px]">
          <div className="space-y-4 min-w-0">
            {/* Player box */}
            <div className="rounded-2xl overflow-hidden bg-black border border-[#1d2036] shadow-2xl shadow-black/80">
              <div className="relative w-full aspect-video bg-gradient-to-br from-[#0c0e18] via-[#0a0c14] to-[#04050b] flex items-center justify-center animate-pulse">
                <div className="w-14 h-14 rounded-full bg-[#181a2e] border border-[#222540]" />
              </div>

              {/* Server + audio control bars */}
              <div className="p-3 sm:p-4 bg-[#0d0f1e] border-t border-[#1a1d35] flex flex-col gap-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <div className="w-16 h-3 bg-[#181a30]/70 rounded animate-pulse" />
                    <div className="w-20 h-7 rounded-xl bg-[#181a30] animate-pulse" />
                    <div className="w-20 h-7 rounded-xl bg-[#181a30] animate-pulse" />
                  </div>
                  <div className="flex items-center gap-2 self-end sm:self-auto">
                    <div className="w-24 h-7 rounded-xl bg-[#181a30] animate-pulse" />
                    <div className="w-8 h-7 rounded-xl bg-[#181a30] animate-pulse" />
                  </div>
                </div>

                <div className="pt-2.5 border-t border-[#17192e] flex flex-wrap items-center gap-2">
                  <div className="w-24 h-3 bg-[#181a30]/70 rounded animate-pulse" />
                  <div className="w-16 h-7 rounded-xl bg-[#181a30] animate-pulse" />
                  <div className="w-16 h-7 rounded-xl bg-[#181a30] animate-pulse" />
                  <div className="w-16 h-7 rounded-xl bg-[#181a30] animate-pulse" />
                </div>
              </div>
            </div>

            {/* Anime info card */}
            <div className="p-4 sm:p-6 rounded-2xl bg-[#0f1122] border border-[#1e213d] flex flex-col sm:flex-row gap-5 items-start animate-pulse">
              <div className="w-24 sm:w-28 shrink-0 aspect-[3/4] rounded-xl bg-[#16182c] border border-[#262947]" />
              <div className="flex-1 space-y-3 w-full">
                <div className="flex flex-wrap items-center gap-2">
                  <div className="w-24 h-5 rounded bg-[#181a30]" />
                  <div className="w-12 h-4 rounded bg-[#181a30]/70" />
                  <div className="w-16 h-4 rounded bg-[#181a30]/70" />
                </div>
                <div className="w-3/4 h-6 rounded bg-[#181a30]" />
                <div className="space-y-2">
                  <div className="w-full h-3 bg-[#181a30]/70 rounded" />
                  <div className="w-full h-3 bg-[#181a30]/70 rounded" />
                  <div className="w-2/3 h-3 bg-[#181a30]/70 rounded" />
                </div>
                <div className="flex flex-wrap gap-1.5 pt-1">
                  <div className="w-14 h-5 rounded bg-[#181a30]/70" />
                  <div className="w-16 h-5 rounded bg-[#181a30]/70" />
                  <div className="w-12 h-5 rounded bg-[#181a30]/70" />
                  <div className="w-20 h-5 rounded bg-[#181a30]/70" />
                </div>
              </div>
            </div>
          </div>

          {/* Episodes sidebar */}
          <aside className="flex flex-col gap-4">
            <div className="p-4 rounded-2xl bg-[#0f1122] border border-[#1e213d] flex flex-col h-full max-h-[750px] animate-pulse">
              <div className="pb-3 border-b border-[#1b1e36] flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-[#181a30]" />
                  <div className="w-20 h-4 rounded bg-[#181a30]" />
                </div>
                <div className="w-16 h-7 rounded-lg bg-[#181a30]" />
              </div>

              <div className="py-3 border-b border-[#1b1e36]">
                <div className="w-full h-10 rounded-lg bg-[#14162a] border border-[#222540]" />
              </div>

              <div className="pt-3 pb-2">
                <div className="w-full h-8 rounded-lg bg-[#14162a] border border-[#222540]" />
              </div>

              <div className="flex-1 overflow-hidden pt-1 space-y-1.5 min-h-[300px]">
                <div className="grid grid-cols-[repeat(auto-fill,minmax(2.75rem,1fr))] gap-2">
                  {Array.from({ length: 24 }).map((_, i) => (
                    <div
                      key={i}
                      className="aspect-square rounded-xl bg-[#14162a] border border-[#222540]"
                    />
                  ))}
                </div>
              </div>
            </div>
          </aside>
        </div>

        {/* Recommendations */}
        <section className="mt-10 pt-6 border-t border-[#1b1e33] space-y-4 animate-pulse">
          <div className="space-y-1">
            <div className="w-32 h-3 bg-[#181a30]/70 rounded" />
            <div className="w-40 h-6 bg-[#181a30] rounded" />
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5 sm:gap-4.5">
            {Array.from({ length: 6 }).map((_, i) => (
              <div
                key={i}
                className="relative rounded-xl bg-[#121424] border border-[#22253c] overflow-hidden aspect-[2/3]"
              >
                <div className="absolute inset-0 bg-[#0d0e1b]" />
                <div className="absolute top-2 right-2 w-14 h-5 rounded bg-[#181a30]/90 border border-[#23263d]" />
                <div className="absolute inset-x-0 bottom-0 p-2.5 sm:p-3 flex flex-col gap-1.5">
                  <div className="w-16 h-2.5 bg-[#181a30] rounded" />
                  <div className="w-full h-3.5 bg-[#181a30] rounded" />
                  <div className="pt-1.5 mt-0.5 border-t border-white/10 flex items-center gap-2">
                    <div className="flex-1 h-6 bg-[#181a30] rounded-md" />
                    <div className="w-7 h-6 bg-[#181a30] rounded-md" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
};