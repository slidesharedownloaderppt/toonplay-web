import React from 'react';

export const InfoSkeleton: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#0b0c16] text-slate-100 pb-20">

      {/* Hero backdrop section */}
      <div className="relative w-full min-h-[420px] md:min-h-[500px] flex items-end overflow-hidden bg-gradient-to-br from-[#14162e] via-[#0c0d18] to-[#080912]">
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pt-10 pb-6">

          {/* Breadcrumb */}
          <div className="mb-4 flex items-center gap-2">
            <div className="w-12 h-3 bg-[#181a30]/70 rounded animate-pulse" />
            <div className="w-2 h-3 bg-[#181a30]/40 rounded" />
            <div className="w-16 h-3 bg-[#181a30]/70 rounded animate-pulse" />
            <div className="w-2 h-3 bg-[#181a30]/40 rounded" />
            <div className="w-40 h-3 bg-[#181a30]/70 rounded animate-pulse" />
          </div>

          {/* Poster + title block */}
          <div className="flex flex-col md:flex-row md:items-end gap-6 md:gap-8">
            <div className="w-40 sm:w-52 md:w-60 shrink-0 aspect-[3/4] rounded-2xl bg-[#16182c] border border-[#2b2f4a] shadow-2xl shadow-black/80 animate-pulse" />

            <div className="flex-1 space-y-4">
              <div className="flex flex-wrap items-center gap-2">
                <div className="w-24 h-5 rounded-md bg-[#181a30] animate-pulse" />
                <div className="w-3 h-3 rounded bg-[#181a30]/50" />
                <div className="w-12 h-4 rounded bg-[#181a30]/70 animate-pulse" />
                <div className="w-3 h-3 rounded bg-[#181a30]/50" />
                <div className="w-24 h-4 rounded bg-[#181a30]/70 animate-pulse" />
                <div className="w-3 h-3 rounded bg-[#181a30]/50" />
                <div className="w-20 h-4 rounded bg-[#181a30]/70 animate-pulse" />
              </div>

              <div className="space-y-2">
                <div className="w-full max-w-2xl h-8 sm:h-10 lg:h-12 bg-[#181a30] rounded-lg animate-pulse" />
                <div className="w-3/4 max-w-xl h-8 sm:h-10 lg:h-12 bg-[#181a30] rounded-lg animate-pulse" />
              </div>

              <div className="pt-2 flex flex-wrap items-center gap-3">
                <div className="w-32 h-11 rounded-xl bg-indigo-600/40 animate-pulse" />
                <div className="w-40 h-11 rounded-xl bg-[#181a30] animate-pulse" />
                <div className="w-24 h-11 rounded-xl bg-[#181a30] animate-pulse" />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8 space-y-10">

        {/* Story overview */}
        <section className="space-y-3">
          <div className="w-40 h-6 bg-[#16182c] rounded animate-pulse" />
          <div className="space-y-2 max-w-4xl">
            <div className="w-full h-4 bg-[#16182c]/70 rounded animate-pulse" />
            <div className="w-full h-4 bg-[#16182c]/70 rounded animate-pulse" />
            <div className="w-4/5 h-4 bg-[#16182c]/70 rounded animate-pulse" />
          </div>
        </section>

        {/* Series metrics */}
        <section className="space-y-3">
          <div className="w-40 h-3 bg-[#181a30]/70 rounded animate-pulse" />
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-2xl">
            {Array.from({ length: 3 }).map((_, i) => (
              <div
                key={i}
                className="p-4 rounded-xl bg-[#121424] border border-[#22253d] flex items-center gap-3.5 animate-pulse"
              >
                <div className="w-10 h-10 rounded-lg bg-[#181a30] shrink-0" />
                <div className="space-y-1.5 flex-1">
                  <div className="w-20 h-2.5 bg-[#181a30]/70 rounded" />
                  <div className="w-12 h-5 bg-[#181a30] rounded" />
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Genres */}
        <section className="space-y-2.5">
          <div className="w-20 h-3 bg-[#181a30]/70 rounded animate-pulse" />
          <div className="flex flex-wrap gap-2">
            {Array.from({ length: 6 }).map((_, i) => (
              <div
                key={i}
                className="w-16 h-7 rounded-lg bg-[#14172a] border border-[#242844] animate-pulse"
              />
            ))}
          </div>
        </section>

        {/* Audio dubs */}
        <section className="space-y-2.5">
          <div className="w-40 h-3 bg-[#181a30]/70 rounded animate-pulse" />
          <div className="flex flex-wrap gap-2">
            {Array.from({ length: 4 }).map((_, i) => (
              <div
                key={i}
                className="w-20 h-7 rounded-lg bg-[#14172a] border border-[#242844] animate-pulse"
              />
            ))}
          </div>
        </section>

        {/* Recommendations */}
        <section className="pt-6 border-t border-[#1b1e33] space-y-4">
          <div className="space-y-1">
            <div className="w-32 h-3 bg-[#181a30]/70 rounded animate-pulse" />
            <div className="w-40 h-6 bg-[#181a30] rounded animate-pulse" />
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5 sm:gap-4.5">
            {Array.from({ length: 6 }).map((_, i) => (
              <div
                key={i}
                className="relative rounded-xl bg-[#121424] border border-[#22253c] overflow-hidden aspect-[2/3] animate-pulse"
              >
                <div className="absolute inset-0 bg-[#0d0e1b]" />
                <div className="absolute top-2 right-2 w-14 h-5 rounded bg-[#181a30]/90 border border-[#23263d]" />
                <div className="absolute inset-x-0 bottom-0 p-2.5 sm:p-3 flex flex-col gap-1.5">
                  <div className="w-16 h-2.5 bg-[#181a30] rounded" />
                  <div className="w-full h-3.5 bg-[#181a30] rounded" />
                  <div className="pt-1.5 mt-0.5 border-t border-white/10 flex items-center gap-2">
                    <div className="flex-1 h-6 bg-[#181a30] rounded-md" />
                    <div className="w-7 h-6 bg-[#181a30] rounded-md" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};