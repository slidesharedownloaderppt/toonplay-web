import React from 'react';

export const UserActivitySkeleton: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#070811] text-white">
      {/* 1. ActivityHeader skeleton — compact, matches real header */}
      <header className="relative w-full overflow-hidden bg-[#0a0b10]">
        {/* Background tint layer */}
        <div className="pointer-events-none absolute inset-0 z-0" aria-hidden="true">
          <div className="absolute inset-0 bg-gradient-to-t from-[#070811] via-[#070811]/75 to-[#070811]/40 animate-pulse" />
        </div>

        <div className="relative z-10 mx-auto max-w-7xl px-4 pt-5 pb-4 sm:px-6 sm:pb-7 md:px-8">
          {/* Back button */}
          <div className="w-20 h-4 bg-[#16182c]/70 rounded animate-pulse mb-3" />

          {/* Main ID row */}
          <div className="flex flex-wrap items-center gap-3 sm:gap-4">
            {/* Avatar */}
            <div className="h-16 w-16 sm:h-20 sm:w-20 shrink-0 rounded-full border-2 border-[#070811] bg-[#14172b] animate-pulse" />

            {/* Name block */}
            <div className="min-w-0 flex-1 space-y-1.5">
              <div className="w-40 sm:w-52 h-7 sm:h-8 bg-[#16182c] rounded animate-pulse" />
              <div className="w-32 h-3.5 bg-[#16182c]/70 rounded animate-pulse" />
            </div>

            {/* Level + XP block */}
            <div className="w-full sm:w-auto sm:min-w-[220px] sm:max-w-[280px] shrink-0 space-y-2">
              <div className="w-full h-3.5 bg-[#16182c]/70 rounded-full animate-pulse" />
              <div className="flex items-center gap-1.5">
                <div className="w-3.5 h-3.5 rounded bg-[#16182c]/70 animate-pulse" />
                <div className="w-24 h-3 bg-[#16182c]/70 rounded animate-pulse" />
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* MAIN CONTENT */}
      <main className="mx-auto max-w-7xl px-4 pb-16 sm:px-6 md:px-8 pt-6">
        <div className="flex flex-col gap-4">

          {/* 2. StatTiles — 6 tiles */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <div
                key={i}
                className="bg-[#14172b] border border-[#2e3252] rounded-xl p-3.5 space-y-2 animate-pulse"
              >
                <div className="w-6 h-6 rounded-md bg-[#1a1d33]" />
                <div className="w-16 h-5 bg-[#1a1d33] rounded" />
                <div className="w-20 h-2.5 bg-[#1a1d33]/70 rounded" />
              </div>
            ))}
          </div>

          {/* 3+4. ActivityChart + TopGenresCard */}
          <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_360px] gap-4">
            <div className="bg-[#14172b] border border-[#2e3252] rounded-2xl p-5 space-y-4 animate-pulse">
              <div className="flex items-center justify-between">
                <div className="w-32 h-4 bg-[#1a1d33] rounded" />
                <div className="flex items-center gap-1">
                  <div className="w-12 h-6 bg-[#1a1d33] rounded-md" />
                  <div className="w-12 h-6 bg-[#1a1d33] rounded-md" />
                  <div className="w-12 h-6 bg-[#1a1d33] rounded-md" />
                </div>
              </div>
              <div className="h-48 sm:h-56 bg-[#0f1122] border border-[#22253d] rounded-xl" />
            </div>

            <div className="bg-[#14172b] border border-[#2e3252] rounded-2xl p-5 space-y-3 animate-pulse">
              <div className="w-28 h-4 bg-[#1a1d33] rounded" />
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <div className="w-24 h-3 bg-[#1a1d33] rounded" />
                    <div className="w-8 h-3 bg-[#1a1d33]/70 rounded" />
                  </div>
                  <div className="w-full h-2 bg-[#0f1122] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#1a1d33] rounded-full"
                      style={{ width: `${90 - i * 14}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 5+6. MostWatchedCard + All-time stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-[#14172b] border border-[#2e3252] rounded-2xl p-5 space-y-3 animate-pulse">
              <div className="w-32 h-4 bg-[#1a1d33] rounded" />
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className="w-10 h-14 rounded-md bg-[#0f1122] border border-[#22253d]" />
                  <div className="flex-1 space-y-1.5">
                    <div className="w-32 h-3 bg-[#1a1d33] rounded" />
                    <div className="w-20 h-2.5 bg-[#1a1d33]/70 rounded" />
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-[#14172b] border border-[#2e3252] rounded-2xl p-5 animate-pulse">
              <div className="w-20 h-4 bg-[#1a1d33] rounded mb-3" />
              <div className="grid grid-cols-2 gap-x-4 gap-y-3">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="space-y-1.5">
                    <div className="w-20 h-2.5 bg-[#1a1d33]/70 rounded" />
                    <div className="w-16 h-4 bg-[#1a1d33] rounded" />
                  </div>
                ))}
              </div>
            </div>
          </div>

        </div>
      </main>
    </div>
  );
};