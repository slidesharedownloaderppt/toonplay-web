import React, { useState, useEffect, useRef } from 'react';
import { Play, Bookmark, Check, Film, Tv, X } from 'lucide-react';
import { UnifiedAnime } from '../types.ts';


const LANG_DISPLAY: Record<string, string> = {
  // Hindi
  hi: 'Hindi',
  hin: 'Hindi',
  hindi: 'Hindi',

  // English
  en: 'English',
  eng: 'English',
  english: 'English',

  // Japanese
  ja: 'Japanese',
  jp: 'Japanese',
  jpn: 'Japanese',
  jap: 'Japanese',
  japanese: 'Japanese',

  // Korean
  ko: 'Korean',
  kor: 'Korean',
  korean: 'Korean',

  // Indian languages
  ta: 'Tamil',
  tam: 'Tamil',
  tamil: 'Tamil',

  te: 'Telugu',
  tel: 'Telugu',
  telugu: 'Telugu',

  ml: 'Malayalam',
  mal: 'Malayalam',
  malayalam: 'Malayalam',

  kn: 'Kannada',
  kan: 'Kannada',
  kannada: 'Kannada',

  bn: 'Bengali',
  ben: 'Bengali',
  bengali: 'Bengali',

  // Other languages
  fr: 'French',
  fra: 'French',
  fre: 'French',
  french: 'French',

  es: 'Spanish',
  spa: 'Spanish',
  spanish: 'Spanish',

  pt: 'Portuguese',
  por: 'Portuguese',
  'pt-br': 'Brazilian Portuguese',

  de: 'German',
  deu: 'German',
  ger: 'German',
  german: 'German',

  ru: 'Russian',
  rus: 'Russian',
  russian: 'Russian',

  zh: 'Chinese',
  zho: 'Chinese',
  chi: 'Chinese',
  'zh-cn': 'Chinese',
  'zh-tw': 'Traditional Chinese',

  ar: 'Arabic',
  ara: 'Arabic',
  arabic: 'Arabic',

  id: 'Indonesian',
  ind: 'Indonesian',
  indonesian: 'Indonesian',

  th: 'Thai',
  tha: 'Thai',
  thai: 'Thai',

  vi: 'Vietnamese',
  vie: 'Vietnamese',
  vietnamese: 'Vietnamese',

  tr: 'Turkish',
  tur: 'Turkish',
  turkish: 'Turkish',

  it: 'Italian',
  ita: 'Italian',
  italian: 'Italian',
};


const getLangLabel = (lang?: string): string | undefined => {
  if (!lang) return undefined;
  return LANG_DISPLAY[lang.toLowerCase()] || lang;
};

interface AnimeCardProps {
  anime: UnifiedAnime;
  onSelect: (anime: UnifiedAnime) => void;
  onPlay: (anime: UnifiedAnime) => void;
  isBookmarked: boolean;
  onToggleWatchlist: (anime: UnifiedAnime) => void;
  onRemove?: (anime: UnifiedAnime) => void;
}

export const AnimeCard: React.FC<AnimeCardProps> = React.memo(({
  anime,
  onSelect,
  onPlay,
  isBookmarked,
  onToggleWatchlist,
  onRemove,
}) => {
  const [imageFailed, setImageFailed] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);
  const imgRef = useRef<HTMLImageElement | null>(null);

  // Reset or immediately sync cached-image state whenever the poster URL changes.
  useEffect(() => {
    const img = imgRef.current;
    if (img && img.complete && img.naturalWidth > 0) {
      setImageLoaded(true);
      setImageFailed(false);
    } else {
      setImageLoaded(false);
      setImageFailed(false);
    }
  }, [anime.image]);

  const handleCardClick = () => {
    onSelect(anime);
  };

  const handlePlayClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onPlay(anime);
  };

  const handleBookmarkClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onToggleWatchlist(anime);
  };

  const getMetadataString = () => {
    if (anime.category === 'latest') {
      const parts: string[] = [];
      if (anime.season) parts.push(anime.season);
      if (anime.episodes) parts.push(anime.episodes);
      if (parts.length === 0) parts.push('NEW RELEASE');
      return parts.join(' · ');
    }
    if (anime.type === 'movie') {
      return 'FILM · 1080P';
    }
    const label = String(anime.displayType || 'SERIES').toUpperCase();
    return `${label} · SUB / DUB`;
  };

  const getPlaybackContext = (): string | null => {
    const parts: string[] = [];

    if (anime.type !== 'movie') {
      if (anime.seasonNumber != null || anime.episodeNumber != null) {
        const s = anime.seasonNumber != null ? `S${anime.seasonNumber}` : '';
        const e = anime.episodeNumber != null ? `E${anime.episodeNumber}` : '';
        if (s || e) parts.push(`${s}${s && e ? ':' : ''}${e}`);
      }
    }

    const langLabel = getLangLabel(anime.lang);
    if (langLabel) parts.push(langLabel);

    if (anime.server) {
      const m = anime.server.match(/multi-(\d+)/i);
      if (m) parts.push(`Multi ${m[1]}`);
    }

    return parts.length > 0 ? parts.join(' · ') : null;
  };

  const playbackContext = getPlaybackContext();

  return (
    <div
      onClick={handleCardClick}
      className="group relative flex flex-col aspect-[2/3] bg-[#121424] border border-[#22253c] hover:border-indigo-500/50 rounded-xl overflow-hidden transition-[border-color,box-shadow] duration-200 hover:shadow-md hover:shadow-black/40 cursor-pointer select-none"
    >
      <div className="absolute inset-0 bg-[#0d0e1b] overflow-hidden">
        {/* Placeholder — visible until the real image reports loaded */}
        {!imageLoaded && !imageFailed && (
          <img
            src="/images/placeholder.webp"
            alt=""
            aria-hidden="true"
            decoding="async"
            draggable="false"
            onDragStart={(e) => e.preventDefault()}
            className="absolute inset-0 w-full h-full object-cover object-center pointer-events-none select-none"
          />
        )}

        {!imageFailed && anime.image ? (
          <img
            ref={imgRef}
            src={anime.image}
            alt={anime.title}
            loading="lazy"
            decoding="async"
            draggable="false"
            onDragStart={(e) => e.preventDefault()}
            referrerPolicy="no-referrer"
            onLoad={() => setImageLoaded(true)}
            onError={() => setImageFailed(true)}
            className={`absolute inset-0 w-full h-full object-cover object-center transition-[transform,opacity] duration-300 ease-out pointer-events-none select-none ${
              imageLoaded ? 'opacity-100 group-hover:scale-104' : 'opacity-0'
            }`}
          />
        ) : (
          <div className="absolute inset-0 bg-gradient-to-br from-[#121428] via-[#161932] to-[#0d0e1d] flex flex-col items-center justify-center p-4 text-center">
            {anime.type === 'movie' ? (
              <Film className="w-7 h-7 text-indigo-400/50 mb-2" />
            ) : (
              <Tv className="w-7 h-7 text-indigo-400/50 mb-2" />
            )}
            <span className="text-xs font-normal text-indigo-200 line-clamp-2">
              {anime.title}
            </span>
          </div>
        )}

        <div className="absolute inset-x-0 bottom-0 h-3/5 bg-gradient-to-t from-[#0a0b16] via-[#0a0b16]/85 to-transparent pointer-events-none" />

        <div className="absolute top-2 right-2 flex items-center gap-1.5">
          <div className="flex items-center gap-1 text-[10px] font-normal text-slate-300 bg-[#0c0e1a]/92 px-1.5 py-0.5 rounded border border-[#23263d]">
            {anime.displayType ? (
              <>
                {String(anime.displayType).toUpperCase() === 'MOVIE' ? (
                  <Film className="w-2.5 h-2.5 text-indigo-400" />
                ) : (
                  <Tv className="w-2.5 h-2.5 text-indigo-400" />
                )}
                <span>{String(anime.displayType).toUpperCase()}</span>
              </>
            ) : anime.type === 'movie' ? (
              <>
                <Film className="w-2.5 h-2.5 text-indigo-400" />
                <span>MOVIE</span>
              </>
            ) : (
              <>
                <Tv className="w-2.5 h-2.5 text-indigo-400" />
                <span>SERIES</span>
              </>
            )}
          </div>
          {onRemove && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onRemove(anime);
              }}
              title="Remove"
              aria-label={`Remove ${anime.title}`}
              className="w-5 h-5 rounded bg-[#0c0e1a]/92 hover:bg-rose-600 border border-[#23263d] hover:border-rose-500 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
            >
              <X className="w-3 h-3" />
            </button>
          )}
        </div>

        <div className="absolute inset-x-0 bottom-0 p-2.5 sm:p-3 flex flex-col gap-1.5">
          {playbackContext ? (
            <div className="text-[10px] font-mono text-emerald-300 truncate flex items-center gap-1">
              <span className="w-1 h-1 rounded-full bg-emerald-400 shrink-0" aria-hidden="true" />
              <span className="truncate">{playbackContext}</span>
            </div>
          ) : (
            <div className="text-[10px] font-mono text-indigo-300 truncate">
              {getMetadataString()}
            </div>
          )}

          <h3
            title={anime.title}
            className="text-xs sm:text-[13px] font-medium text-slate-100 group-hover:text-indigo-300 transition-colors line-clamp-2 leading-snug"
          >
            {anime.title}
          </h3>

          <div className="pt-1.5 mt-0.5 border-t border-white/10 flex items-center justify-between gap-2">
            <button
              onClick={handlePlayClick}
              aria-label={`Stream ${anime.title}`}
              title="Stream Now"
              className="flex-1 py-1 px-2 rounded-md bg-[#181a2e]/95 hover:bg-indigo-600 text-slate-200 hover:text-white border border-[#282b45] hover:border-indigo-500 transition-colors flex items-center justify-center gap-1.5 text-[11px] font-normal cursor-pointer"
            >
              <Play className="w-3 h-3 fill-current" />
              <span>Watch</span>
            </button>

            <button
              onClick={handleBookmarkClick}
              aria-label={isBookmarked ? 'Remove from Watchlist' : 'Add to Watchlist'}
              title={isBookmarked ? 'In Watchlist' : 'Save to Watchlist'}
              className={`p-1.5 rounded-md border transition-colors cursor-pointer ${
                isBookmarked
                  ? 'bg-indigo-950/90 border-indigo-500 text-indigo-200'
                  : 'bg-[#181a2e]/95 hover:bg-[#20233d] border-[#282b45] text-slate-400 hover:text-white hover:border-indigo-400'
              }`}
            >
              {isBookmarked ? (
                <Check className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <Bookmark className="w-3.5 h-3.5" />
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
});
AnimeCard.displayName = 'AnimeCard';