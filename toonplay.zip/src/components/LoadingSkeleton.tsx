import React from 'react';

export const LoadingSkeleton: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#0b0c16] text-slate-100 flex flex-col font-sans selection:bg-indigo-600 selection:text-white">

      {/* Navbar */}
      <header className="sticky top-0 z-40 w-full bg-gradient-to-b from-black/80 via-black/35 to-transparent border-transparent">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-3 md:gap-6 h-16 sm:h-17">

            <div className="flex items-center gap-2.5 sm:gap-3.5 shrink-0">
              <div className="md:hidden w-8 h-8 rounded-lg bg-[#16182c] animate-pulse" />
              <div className="h-7 sm:h-7.5 w-20 rounded bg-[#16182c] animate-pulse" />
            </div>

            <div className="hidden md:flex items-center gap-6 xl:gap-8">
              <div className="w-12 h-4 bg-[#16182c] rounded animate-pulse" />
              <div className="w-12 h-4 bg-[#16182c] rounded animate-pulse" />
              <div className="w-16 h-4 bg-[#16182c] rounded animate-pulse" />
              <div className="w-20 h-4 bg-[#16182c] rounded animate-pulse" />
            </div>

            <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
              <div className="hidden md:block w-20 h-7 bg-[#16182c] rounded-full animate-pulse" />
              <div className="hidden md:block w-48 lg:w-64 h-8 bg-[#16182c] rounded-lg animate-pulse" />
              <div className="md:hidden w-8 h-8 bg-[#16182c] rounded-lg animate-pulse" />
              <div className="hidden md:block w-8 h-8 bg-[#16182c] rounded-lg animate-pulse" />
              <div className="w-8.5 h-8.5 rounded-full bg-[#16182c] animate-pulse" />
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 w-full">

        {/* HeroBanner */}
        <section className="relative w-full -mt-16 sm:-mt-17 min-h-[580px] md:min-h-[660px] lg:min-h-[720px] flex items-end overflow-hidden bg-gradient-to-b from-[#14162e] via-[#0d0e1b] to-[#0b0c16]">
          <div className="absolute bottom-0 inset-x-0 h-32 sm:h-36 z-[5] pointer-events-none select-none bg-gradient-to-b from-transparent via-[#0b0c16]/80 to-[#0b0c16]" />
          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pt-28 sm:pt-32 lg:pt-36 pb-4 md:pb-5">
            <div className="max-w-2xl space-y-3.5">

              <div className="w-full max-w-lg h-12 sm:h-14 bg-[#181a30] rounded-lg animate-pulse" />

              <div className="flex flex-wrap items-center gap-2">
                <div className="w-10 h-4 bg-[#181a30] rounded animate-pulse" />
                <div className="w-12 h-4 bg-[#181a30] rounded animate-pulse" />
                <div className="w-14 h-4 bg-[#181a30] rounded animate-pulse" />
              </div>

              <div className="space-y-2">
                <div className="w-full h-3.5 bg-[#181a30]/80 rounded animate-pulse" />
                <div className="w-full h-3.5 bg-[#181a30]/80 rounded animate-pulse" />
                <div className="w-3/5 h-3.5 bg-[#181a30]/80 rounded animate-pulse" />
              </div>

              <div className="pt-2 flex flex-wrap items-center gap-3">
                <div className="w-32 h-10 bg-indigo-600/40 rounded-xl animate-pulse" />
                <div className="w-40 h-10 bg-[#181a30] rounded-xl animate-pulse" />
              </div>
            </div>

            <div className="mt-7 pt-4 border-t border-[#1e2136] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-2.5 overflow-hidden">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div
                    key={i}
                    className={`shrink-0 w-24 sm:w-28 h-12 rounded-lg bg-[#121426] border animate-pulse ${
                      i === 0 ? 'border-indigo-500/40' : 'border-[#262940]'
                    }`}
                  />
                ))}
              </div>
              <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
                <div className="w-8 h-8 rounded-lg bg-[#141628] border border-[#262942] animate-pulse" />
                <div className="w-12 h-3 bg-[#181a30] rounded animate-pulse" />
                <div className="w-8 h-8 rounded-lg bg-[#141628] border border-[#262942] animate-pulse" />
              </div>
            </div>
          </div>
        </section>

        {/* Downloads Banner Skeleton */}
        <section className="w-full bg-[#0b0c16] pt-4 pb-6">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="w-full aspect-[6.79/1] sm:aspect-[8/1] lg:aspect-[14.96/1] rounded-xl bg-[#16182c] animate-pulse" />
          </div>
        </section>

        {/* Share Skeleton */}
        <section className="w-full bg-[#0b0c16] pb-4">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="w-full h-16 sm:h-20 rounded-xl bg-[#121424] border border-[#22253d] animate-pulse" />
          </div>
        </section>

        {/* LanguageGridSection */}
        <section className="bg-[#0b0c16] py-6 border-b border-[#1b1e33]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between gap-4 mb-4">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-[#16182c] animate-pulse" />
                <div className="w-56 h-5 bg-[#16182c] rounded animate-pulse" />
              </div>
            </div>

            <div className="grid grid-cols-3 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-9 gap-2.5">
              {Array.from({ length: 9 }).map((_, i) => (
                <div
                  key={i}
                  className="p-2.5 rounded-xl bg-[#121424] border border-[#22253d] flex flex-col justify-between gap-1 min-h-[60px] animate-pulse"
                >
                  <div className="w-10 h-3 bg-[#181a30] rounded" />
                  <div className="space-y-1">
                    <div className="w-16 h-3.5 bg-[#181a30] rounded" />
                    <div className="w-12 h-2.5 bg-[#181a30]/70 rounded" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ContinueWatchingSection Skeleton */}
        <section className="py-7 border-b border-[#1b1e33] bg-[#0b0c16]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between gap-4 mb-5">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-[#16182c] animate-pulse" />
                <div className="w-48 h-5 bg-[#16182c] rounded animate-pulse" />
              </div>
              <div className="w-16 h-7 bg-[#121424] border border-[#24273e] rounded-lg animate-pulse" />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3.5">
              {Array.from({ length: 4 }).map((_, i) => (
                <div
                  key={i}
                  className="relative rounded-xl bg-[#121424] border border-[#22253c] overflow-hidden animate-pulse"
                >
                  <div className="w-full aspect-video bg-[#0d0e1b]" />
                  <div className="p-3 space-y-2">
                    <div className="w-3/4 h-3.5 bg-[#181a30] rounded" />
                    <div className="w-1/2 h-2.5 bg-[#181a30]/70 rounded" />
                    <div className="w-full h-1.5 bg-[#181a30]/70 rounded-full mt-2" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CatalogTabsSection — tab bar only */}
        <section className="bg-[#0e101f] border-y border-[#1c1f36] py-4">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3.5">
              <div className="flex items-center gap-1.5 p-1 bg-[#121424] border border-[#23263d] rounded-xl w-fit">
                <div className="w-24 h-7 bg-[#16182c] rounded-lg animate-pulse" />
                <div className="w-16 h-7 bg-[#16182c] rounded-lg animate-pulse" />
                <div className="w-20 h-7 bg-[#16182c] rounded-lg animate-pulse" />
              </div>
              <div className="flex items-center gap-1.5 p-1 bg-[#121424] border border-[#23263d] rounded-xl w-fit">
                <div className="w-20 h-7 bg-[#16182c] rounded-lg animate-pulse" />
                <div className="w-18 h-7 bg-[#16182c] rounded-lg animate-pulse" />
              </div>
            </div>
          </div>
        </section>

        {/* AnimeSection — Latest (defaults to HIN/TAM/TEL) */}
        <section className="py-7 border-b border-[#1b1e33]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-5">
              <div className="space-y-1">
                <div className="w-40 h-3 bg-[#16182c] rounded animate-pulse" />
                <div className="w-56 h-6 bg-[#16182c] rounded animate-pulse" />
              </div>
              <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
                {/* Language tab pills — second pill (HIN/TAM/TEL) is active */}
                <div className="flex items-center bg-[#121424] border border-[#24273e] p-0.5 rounded-lg">
                  <div className="w-14 h-6 bg-[#16182c] rounded-md animate-pulse" />
                  <div className="w-20 h-6 bg-indigo-600/40 rounded-md animate-pulse ml-0.5" />
                </div>
                {/* See All */}
                <div className="w-20 h-8 bg-[#121424] border border-[#24273e] rounded-lg animate-pulse" />
                {/* View toggle */}
                <div className="w-14 h-8 bg-[#121424] border border-[#24273e] rounded-lg animate-pulse" />
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5 sm:gap-4.5">
              {Array.from({ length: 12 }).map((_, i) => (
                <div
                  key={i}
                  className="relative rounded-xl bg-[#121424] border border-[#22253c] overflow-hidden aspect-[2/3] animate-pulse"
                >
                  <div className="absolute inset-0 bg-[#0d0e1b]" />
                  <div className="absolute top-2 right-2 w-14 h-5 rounded bg-[#181a30]/90 border border-[#23263d]" />
                  <div className="absolute inset-x-0 bottom-0 p-2.5 sm:p-3 flex flex-col gap-1.5">
                    <div className={`bg-[#181a30] rounded ${i % 2 === 0 ? 'w-16' : 'w-20'} h-2.5`} />
                    <div className="w-full h-3.5 bg-[#181a30] rounded" />
                    <div className="pt-1.5 mt-0.5 border-t border-white/10 flex items-center gap-2">
                      <div className="flex-1 h-6 bg-[#181a30] rounded-md" />
                      <div className="w-7 h-6 bg-[#181a30] rounded-md" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* AnimeSection — Childhood Related Shows (carousel) */}
        <section className="py-7 border-b border-[#1b1e33]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-5">
              <div className="space-y-1">
                <div className="w-44 h-3 bg-[#16182c] rounded animate-pulse" />
                <div className="w-60 h-6 bg-[#16182c] rounded animate-pulse" />
              </div>
              <div className="flex items-center gap-2 self-start sm:self-auto">
                <div className="w-8 h-8 bg-[#121424] border border-[#24273e] rounded-lg animate-pulse" />
                <div className="w-8 h-8 bg-[#121424] border border-[#24273e] rounded-lg animate-pulse" />
              </div>
            </div>

            <div className="flex gap-3.5 sm:gap-4.5 overflow-hidden">
              {Array.from({ length: 6 }).map((_, i) => (
                <div
                  key={i}
                  className="relative shrink-0 w-[160px] sm:w-[180px] md:w-[200px] rounded-xl bg-[#121424] border border-[#22253c] overflow-hidden aspect-[2/3] animate-pulse"
                >
                  <div className="absolute inset-0 bg-[#0d0e1b]" />
                  <div className="absolute top-2 right-2 w-14 h-5 rounded bg-[#181a30]/90 border border-[#23263d]" />
                  <div className="absolute inset-x-0 bottom-0 p-2.5 sm:p-3 flex flex-col gap-1.5">
                    <div className="w-16 h-2.5 bg-[#181a30] rounded" />
                    <div className="w-full h-3.5 bg-[#181a30] rounded" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* AnimeSection — Popular Series */}
        <section className="py-7 border-b border-[#1b1e33]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-5">
              <div className="space-y-1">
                <div className="w-32 h-3 bg-[#16182c] rounded animate-pulse" />
                <div className="w-48 h-6 bg-[#16182c] rounded animate-pulse" />
              </div>
              <div className="flex items-center gap-2 self-start sm:self-auto">
                <div className="w-16 h-8 bg-[#121424] border border-[#24273e] rounded-lg animate-pulse" />
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5 sm:gap-4.5">
              {Array.from({ length: 12 }).map((_, i) => (
                <div
                  key={i}
                  className="relative rounded-xl bg-[#121424] border border-[#22253c] overflow-hidden aspect-[2/3] animate-pulse"
                >
                  <div className="absolute inset-0 bg-[#0d0e1b]" />
                  <div className="absolute top-2 right-2 w-14 h-5 rounded bg-[#181a30]/90 border border-[#23263d]" />
                  <div className="absolute inset-x-0 bottom-0 p-2.5 sm:p-3 flex flex-col gap-1.5">
                    <div className="w-16 h-2.5 bg-[#181a30] rounded" />
                    <div className="w-full h-3.5 bg-[#181a30] rounded" />
                    <div className="pt-1.5 mt-0.5 border-t border-white/10 flex items-center gap-2">
                      <div className="flex-1 h-6 bg-[#181a30] rounded-md" />
                      <div className="w-7 h-6 bg-[#181a30] rounded-md" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* AnimeSection — Popular Movies */}
        <section className="py-7 border-b border-[#1b1e33]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-5">
              <div className="space-y-1">
                <div className="w-36 h-3 bg-[#16182c] rounded animate-pulse" />
                <div className="w-52 h-6 bg-[#16182c] rounded animate-pulse" />
              </div>
              <div className="flex items-center gap-2 self-start sm:self-auto">
                <div className="w-16 h-8 bg-[#121424] border border-[#24273e] rounded-lg animate-pulse" />
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5 sm:gap-4.5">
              {Array.from({ length: 12 }).map((_, i) => (
                <div
                  key={i}
                  className="relative rounded-xl bg-[#121424] border border-[#22253c] overflow-hidden aspect-[2/3] animate-pulse"
                >
                  <div className="absolute inset-0 bg-[#0d0e1b]" />
                  <div className="absolute top-2 right-2 w-14 h-5 rounded bg-[#181a30]/90 border border-[#23263d]" />
                  <div className="absolute inset-x-0 bottom-0 p-2.5 sm:p-3 flex flex-col gap-1.5">
                    <div className="w-16 h-2.5 bg-[#181a30] rounded" />
                    <div className="w-full h-3.5 bg-[#181a30] rounded" />
                    <div className="pt-1.5 mt-0.5 border-t border-white/10 flex items-center gap-2">
                      <div className="flex-1 h-6 bg-[#181a30] rounded-md" />
                      <div className="w-7 h-6 bg-[#181a30] rounded-md" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

      </main>

      {/* Footer */}
      <footer className="w-full border-t border-[#1b1e33] bg-[#070812] pt-12 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-8 border-b border-[#181a2e]">
            <div className="md:col-span-2 space-y-3">
              <div className="flex items-center gap-2.5">
                <div className="w-6 h-6 rounded bg-[#16182c] animate-pulse" />
                <div className="w-20 h-5 rounded bg-[#16182c] animate-pulse" />
              </div>
              <div className="space-y-2 max-w-md">
                <div className="w-full h-3 bg-[#16182c] rounded animate-pulse" />
                <div className="w-full h-3 bg-[#16182c] rounded animate-pulse" />
                <div className="w-3/4 h-3 bg-[#16182c] rounded animate-pulse" />
              </div>
            </div>

            <div className="space-y-3">
              <div className="w-20 h-3 bg-[#16182c] rounded animate-pulse" />
              <div className="space-y-2">
                <div className="w-32 h-3 bg-[#16182c]/70 rounded animate-pulse" />
                <div className="w-28 h-3 bg-[#16182c]/70 rounded animate-pulse" />
                <div className="w-24 h-3 bg-[#16182c]/70 rounded animate-pulse" />
              </div>
            </div>

            <div className="space-y-3">
              <div className="w-20 h-3 bg-[#16182c] rounded animate-pulse" />
              <div className="space-y-2">
                <div className="w-24 h-3 bg-[#16182c]/70 rounded animate-pulse" />
                <div className="w-28 h-3 bg-[#16182c]/70 rounded animate-pulse" />
                <div className="w-26 h-3 bg-[#16182c]/70 rounded animate-pulse" />
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-6">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="w-20 h-3 bg-[#16182c]/70 rounded animate-pulse" />
            ))}
          </div>

          <div className="max-w-3xl mx-auto space-y-2">
            <div className="w-full h-3 bg-[#16182c]/70 rounded animate-pulse" />
            <div className="w-11/12 h-3 bg-[#16182c]/70 rounded animate-pulse mx-auto" />
          </div>

          <div className="pt-4 border-t border-[#141629] flex justify-center">
            <div className="w-48 h-3 bg-[#16182c]/70 rounded animate-pulse" />
          </div>
        </div>
      </footer>
    </div>
  );
};