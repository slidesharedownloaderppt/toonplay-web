import React, { useState, useRef, useEffect } from 'react';
import {
  Search,
  Bookmark,
  Menu,
  X,
  ChevronDown,
  Globe,
  Clock,
  Home,
  Sparkles,
  Flame,
  ArrowRight,
  Trophy,
  Film,
  Users,
} from 'lucide-react';
import { LANGUAGES_LIST } from './LanguageGridSection.tsx';
import { UserMenu } from './auth/UserMenu.tsx';

const TelegramIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 11.944 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" />
  </svg>
);

interface NavbarProps {
  watchlistCount: number;
  historyCount: number;
  onOpenSearch: (initialQuery?: string) => void;
  onNavigate: (path: string) => void;
  activeMainTab?: 'all' | 'anime' | 'cartoon' | 'watchlist' | 'history';
  currentView?: string;
  onSelectTab?: (tab: 'all' | 'anime' | 'cartoon' | 'watchlist' | 'history') => void;
  onSelectLanguage?: (langCode: string) => void;
  onNavigateView?: (view: any, param?: string) => void;
  onOpenAuth?: (step: 'login' | 'register' | 'forgot-password') => void;
}

export const Navbar: React.FC<NavbarProps> = React.memo(({
  watchlistCount,
  historyCount,
  onOpenSearch,
  onNavigate,
  currentView = 'home',
  activeMainTab = 'all',
  onOpenAuth,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [langDropdownOpen, setLangDropdownOpen] = useState(false);
  const [mobileLangOpen, setMobileLangOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const langMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (langMenuRef.current && !langMenuRef.current.contains(e.target as Node)) {
        setLangDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [mobileMenuOpen]);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLanguageClick = (langCode: string) => {
    setLangDropdownOpen(false);
    setMobileMenuOpen(false);
    onNavigate(`/language/${langCode}`);
  };

  const handleNavClick = (path: string) => {
    setMobileMenuOpen(false);
    onNavigate(path);
  };

  return (
    <>
      <header
        className={`sticky top-0 z-40 w-full transition-[background-color,padding,box-shadow] duration-300 ${
          scrolled
            ? 'bg-[#0c0d17]/95 backdrop-blur-md border-b border-[#22253b] shadow-lg shadow-black/60'
            : 'bg-gradient-to-b from-black/80 via-black/35 to-transparent border-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-3 md:gap-6 h-16">

            <div className="flex items-center gap-2.5 sm:gap-3.5 shrink-0">

              <button
                type="button"
                onClick={() => setMobileMenuOpen(true)}
                className="md:hidden p-2 text-slate-300 hover:text-white rounded-lg hover:bg-[#1a1c2e] border border-[#23263b] transition-colors cursor-pointer"
                aria-label="Open navigation menu"
              >
                <Menu className="w-4.5 h-4.5" />
              </button>

<button
  type="button"
  onClick={() => handleNavClick('/')}
  className="flex items-center text-left group focus:outline-none cursor-pointer"
  aria-label="ToonPlay Home"
>
  <img
    src="/images/toonplay-logo.webp"
    alt="ToonPlay Logo"
    className="h-7 sm:h-7.5 w-auto object-contain group-hover:scale-105 transition-transform duration-200"
  />
</button>
            </div>

            <nav className="hidden md:flex items-center gap-6 xl:gap-8 text-sm font-normal text-slate-300">

              <button
                onClick={() => handleNavClick('/')}
                className={`hover:text-indigo-300 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  currentView === 'home' && activeMainTab === 'all' ? 'text-indigo-400 font-medium' : ''
                }`}
              >
                Home
              </button>

              <button
                onClick={() => handleNavClick('/category/anime')}
                className={`hover:text-indigo-300 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  currentView === 'anime' ? 'text-indigo-400 font-medium' : ''
                }`}
              >
                Anime
              </button>

              <button
                onClick={() => handleNavClick('/category/cartoon')}
                className={`hover:text-indigo-300 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  currentView === 'cartoon' ? 'text-indigo-400 font-medium' : ''
                }`}
              >
                Cartoons
              </button>
              
              <button
  onClick={() => handleNavClick('/movies')}
  className={`hover:text-indigo-300 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
    currentView === 'movies' ? 'text-indigo-400 font-medium' : ''
  }`}
>
  Movies
</button>
              

              <div
                className="relative"
                ref={langMenuRef}
                onMouseEnter={() => setLangDropdownOpen(true)}
                onMouseLeave={() => setLangDropdownOpen(false)}
              >
                <button
                  type="button"
                  onClick={() => setLangDropdownOpen(!langDropdownOpen)}
                  className={`hover:text-indigo-300 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer py-1 ${
                    currentView === 'language' || currentView === 'languages'
                      ? 'text-indigo-400 font-medium'
                      : 'text-slate-300'
                  }`}
                >
                  <Globe className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Languages</span>
                  <ChevronDown
                    className={`w-3.5 h-3.5 transition-transform duration-200 ${
                      langDropdownOpen ? 'rotate-180 text-indigo-400' : ''
                    }`}
                  />
                </button>

                {langDropdownOpen && (
                  <div className="absolute top-full left-0 mt-1 w-52 bg-[#111324] border border-[#262a42] rounded-xl shadow-2xl shadow-black/80 py-1.5 z-50 animate-in fade-in duration-150">
                    <div className="px-3.5 py-1.5 flex items-center justify-between border-b border-[#1c1f36] mb-1">
                      <span className="text-[10px] font-mono text-indigo-400 uppercase tracking-wider">
                        Audio Tracks
                      </span>
                      <button
                        onClick={() => {
                          setLangDropdownOpen(false);
                          handleNavClick('/languages');
                        }}
                        className="text-[10px] font-mono text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer"
                      >
                        <span>View All</span>
                        <ArrowRight className="w-2.5 h-2.5" />
                      </button>
                    </div>
                    {LANGUAGES_LIST.map((lang) => (
                      <button
                        key={lang.code}
                        onClick={() => handleLanguageClick(lang.code)}
                        className="w-full px-3.5 py-2 text-left text-xs text-slate-300 hover:text-white hover:bg-[#181a32] transition-colors cursor-pointer flex items-center justify-between"
                      >
                        <span className="font-medium">{lang.name}</span>
                        <span className="text-[11px] font-mono text-slate-400">{lang.native}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </nav>

            <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">

              <a
                href="https://t.me/toonplay_official"
                target="_blank"
                rel="noopener noreferrer"
                className="hidden xl:flex py-1.5 px-3 rounded-full bg-white text-black text-xs gap-1.5 items-center w-fit hover:bg-gray-100 transition-all cursor-pointer whitespace-nowrap"
                title="Join ToonPlay Telegram"
                aria-label="Join ToonPlay Telegram"
              >
                Join now
                <TelegramIcon className="w-3.5 h-3.5" />
              </a>

              <button
                type="button"
                onClick={() => onOpenSearch('')}
                className="hidden lg:flex items-center relative w-48 lg:w-64 px-3 py-1.5 text-xs text-slate-400 bg-[#141624] hover:bg-[#181a2c] hover:text-slate-200 border border-[#262940] hover:border-indigo-500/60 rounded-lg transition-all cursor-pointer text-left group"
                aria-label="Open Search Modal"
                title="Search anime, cartoon, movie (⌘K)"
              >
                <Search className="w-3.5 h-3.5 text-slate-400 group-hover:text-indigo-400 mr-2 shrink-0 transition-colors" />
                <span className="truncate flex-1">Search anime, cartoon, movie...</span>
                <kbd className="hidden lg:inline-flex items-center px-1.5 py-0.5 text-[10px] font-mono text-slate-400 bg-[#1c1f33] rounded border border-[#2a2e48]">
                  ⌘K
                </kbd>
              </button>

              <button
                type="button"
                onClick={() => onOpenSearch('')}
                aria-label="Search anime, cartoon, movie"
                title="Search anime, cartoon, movie"
                className="lg:hidden p-2 text-slate-300 hover:text-white bg-[#141624] hover:bg-[#1b1e32] border border-[#262940] rounded-lg transition-colors cursor-pointer"
              >
                <Search className="w-4 h-4" />
                </button>
<button
  type="button"
  onClick={() => handleNavClick('/leaderboard')}
  aria-label="Navigate to Leaderboard"
  title="Global Leaderboard"
  className={`hidden md:flex p-2 rounded-lg transition-colors cursor-pointer border ${
    currentView === 'leaderboard'
      ? 'bg-indigo-600/20 text-white border-indigo-500/40'
      : 'text-slate-300 hover:text-white bg-[#141624] hover:bg-[#1b1e32] border-[#262940]'
  }`}
>
  <Trophy className="w-4 h-4 text-indigo-400" />
</button>

              <button
                type="button"
                onClick={() => handleNavClick('/friends')}
                aria-label="Community Friends"
                title="Community Friends"
                className={`hidden md:flex relative p-2 rounded-lg transition-colors cursor-pointer border ${
                  currentView === 'friends'
                    ? 'bg-indigo-600/20 text-white border-indigo-500/40'
                    : 'text-slate-300 hover:text-white bg-[#141624] hover:bg-[#1b1e32] border-[#262940]'
                }`}
              >
                <Users className="w-4 h-4 text-indigo-400" />
              </button>
              <UserMenu onNavigate={onNavigate} onOpenAuth={onOpenAuth} />
            </div>
          </div>
        </div>
      </header>

      <div
        className={`fixed inset-0 z-[100] md:hidden transition-[visibility,opacity] duration-300 ease-in-out ${
          mobileMenuOpen ? 'opacity-100 visible pointer-events-auto' : 'opacity-0 invisible pointer-events-none'
        }`}
        aria-hidden={!mobileMenuOpen}
      >

        <div
          onClick={() => setMobileMenuOpen(false)}
          className={`absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity duration-300 ease-in-out ${
            mobileMenuOpen ? 'opacity-100' : 'opacity-0'
          }`}
          aria-hidden="true"
        />

        <aside
          className={`absolute inset-y-0 left-0 w-72 max-w-[85vw] bg-[#0d0f1e] border-r border-[#24273e] shadow-2xl flex flex-col z-10 transition-transform duration-300 ease-in-out ${
            mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
          }`}
        >

          <div className="flex items-center justify-between px-5 py-4 border-b border-[#202339] bg-[#101224]">
            <div className="flex items-center">
              <img
                src="/images/toonplay-logo.webp"
                alt="ToonPlay Logo"
                className="h-6 w-auto object-contain"
              />
            </div>
            <button
              type="button"
              onClick={() => setMobileMenuOpen(false)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#1a1c32] transition-colors cursor-pointer"
              aria-label="Close menu"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-1.5 text-sm thin-scrollbar">

            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenSearch('');
              }}
              className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-slate-300 hover:text-white bg-[#141628] hover:bg-[#1a1d35] border border-[#232742] transition-colors cursor-pointer mb-2"
            >
              <Search className="w-4 h-4 text-indigo-400" />
              <span className="text-xs text-slate-400">Search anime, cartoon &amp; movie...</span>
            </button>

            <button
              type="button"
              onClick={() => handleNavClick('/')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-colors cursor-pointer ${
                currentView === 'home'
                  ? 'bg-indigo-600/20 text-indigo-300 font-medium border border-indigo-500/30'
                  : 'text-slate-300 hover:bg-[#15182c]'
              }`}
            >
              <Home className="w-4 h-4 text-indigo-400" />
              <span>Home</span>
            </button>

            <button
              type="button"
              onClick={() => handleNavClick('/category/anime')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-colors cursor-pointer ${
                currentView === 'anime'
                  ? 'bg-indigo-600/20 text-indigo-300 font-medium border border-indigo-500/30'
                  : 'text-slate-300 hover:bg-[#15182c]'
              }`}
            >
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <span>Anime</span>
            </button>

            <button
              type="button"
              onClick={() => handleNavClick('/category/cartoon')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-colors cursor-pointer ${
                currentView === 'cartoon'
                  ? 'bg-indigo-600/20 text-indigo-300 font-medium border border-indigo-500/30'
                  : 'text-slate-300 hover:bg-[#15182c]'
              }`}
            >
              <Flame className="w-4 h-4 text-indigo-400" />
              <span>Cartoons</span>
            </button>
            
            <button
  type="button"
  onClick={() => handleNavClick('/category/movies')}
  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-colors cursor-pointer ${
    currentView === 'movies'
      ? 'bg-indigo-600/20 text-indigo-300 font-medium border border-indigo-500/30'
      : 'text-slate-300 hover:bg-[#15182c]'
  }`}
>
  <Film className="w-4 h-4 text-indigo-400" />
  <span>Movies</span>
</button>

<button
              type="button"
              onClick={() => handleNavClick('/leaderboard')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-colors cursor-pointer ${
                currentView === 'leaderboard'
                  ? 'bg-indigo-600/20 text-indigo-300 font-medium border border-indigo-500/30'
                  : 'text-slate-300 hover:bg-[#15182c]'
              }`}
            >
              <Trophy className="w-4 h-4 text-indigo-400" />
              <span>Leaderboard</span>
            </button>

            <button
              type="button"
              onClick={() => handleNavClick('/friends')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-colors cursor-pointer ${
                currentView === 'friends'
                  ? 'bg-indigo-600/20 text-indigo-300 font-medium border border-indigo-500/30'
                  : 'text-slate-300 hover:bg-[#15182c]'
              }`}
            >
              <Users className="w-4 h-4 text-indigo-400" />
              <span>Friends</span>
            </button>

            <div className="pt-2 border-t border-[#1e2136]">
              <div className="flex items-center justify-between px-3.5 py-2">
                <button
                  type="button"
                  onClick={() => handleNavClick('/languages')}
                  className="flex items-center gap-3 text-slate-300 hover:text-white cursor-pointer"
                >
                  <Globe className="w-4 h-4 text-indigo-400" />
                  <span>Languages & Audio</span>
                </button>
                <button
                  type="button"
                  onClick={() => setMobileLangOpen(!mobileLangOpen)}
                  className="p-1 text-slate-400 hover:text-indigo-400 cursor-pointer"
                >
                  <ChevronDown
                    className={`w-4 h-4 transition-transform ${
                      mobileLangOpen ? 'rotate-180 text-indigo-400' : ''
                    }`}
                  />
                </button>
              </div>

              {mobileLangOpen && (
                <div className="mt-1 pl-4 pr-1 space-y-1">
                  {LANGUAGES_LIST.map((lang) => (
                    <button
                      type="button"
                      key={lang.code}
                      onClick={() => handleLanguageClick(lang.code)}
                      className="w-full text-left py-2 px-3 rounded-lg text-xs text-slate-300 hover:text-white hover:bg-[#181a30] transition-colors flex items-center justify-between cursor-pointer"
                    >
                      <span>{lang.name}</span>
                      <span className="text-[11px] font-mono text-slate-400">
                        {lang.native}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="pt-2 border-t border-[#1e2136] space-y-1">
              <button
                type="button"
                onClick={() => handleNavClick('/watchlist')}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-colors cursor-pointer ${
                  currentView === 'watchlist'
                    ? 'bg-indigo-600/20 text-indigo-300 font-medium border border-indigo-500/30'
                    : 'text-slate-300 hover:bg-[#15182c]'
                }`}
              >
                <span className="flex items-center gap-3">
                  <Bookmark className="w-4 h-4 text-indigo-400" />
                  <span>My Watchlist</span>
                </span>
                <span className="text-xs bg-indigo-950 text-indigo-300 px-2 py-0.5 rounded font-mono tabular-nums border border-indigo-800/40">
                  {watchlistCount}
                </span>
              </button>

              <button
                type="button"
                onClick={() => handleNavClick('/history')}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-colors cursor-pointer ${
                  currentView === 'history'
                    ? 'bg-indigo-600/20 text-indigo-300 font-medium border border-indigo-500/30'
                    : 'text-slate-300 hover:bg-[#15182c]'
                }`}
              >
                <span className="flex items-center gap-3">
                  <Clock className="w-4 h-4 text-indigo-400" />
                  <span>Watch History</span>
                </span>
                <span className="text-xs bg-indigo-950 text-indigo-300 px-2 py-0.5 rounded font-mono tabular-nums border border-indigo-800/40">
                  {historyCount}
                </span>
              </button>
            </div>
          </div>

          <div className="p-4 border-t border-[#202339] bg-[#101224] flex items-center justify-between gap-3">
            <a
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setMobileMenuOpen(false)}
              className="py-2 px-4 rounded-full bg-white text-black text-xs flex gap-2 items-center w-fit hover:bg-gray-100 transition shrink-0"
              href="https://t.me/toonplay_official"
            >
              Join Telegram now
              <TelegramIcon className="w-3.5 h-3.5" />
            </a>
            <span className="text-[11px] text-emerald-400 flex items-center gap-1.5 font-mono shrink-0">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              Online
            </span>
          </div>
        </aside>
      </div>
    </>
  );
});
Navbar.displayName = 'Navbar';
