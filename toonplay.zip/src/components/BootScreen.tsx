import React, { useEffect, useRef } from 'react';
import { Play } from 'lucide-react';

const TAGLINE = 'WAKING THE NINJA...';

export const BootScreen: React.FC<{
  visible?: boolean;
  onComplete?: () => void;
}> = ({ visible = true, onComplete }) => {
  const barRef = useRef<HTMLDivElement | null>(null);
  const labelRef = useRef<HTMLSpanElement | null>(null);
  const onCompleteRef = useRef(onComplete);

  // Keep the latest callback without re-triggering the animation loop.
  useEffect(() => {
    onCompleteRef.current = onComplete;
  }, [onComplete]);

  useEffect(() => {
    if (!visible) return;

    const start = performance.now();
    let raf = 0;

    const tick = (now: number) => {
      const pct = Math.min(100, ((now - start) / 1400) * 100);
      if (barRef.current) {
        barRef.current.style.width = `${pct}%`;
      }
      if (labelRef.current) {
        labelRef.current.textContent = `${Math.round(pct)}% SYNCED`;
      }

      if (pct < 100) {
        raf = requestAnimationFrame(tick);
      } else {
        onCompleteRef.current?.();
      }
    };

    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [visible]); // ← only `visible`, no `onComplete`

  if (!visible) return null;

  return (
    <div
      id="intro-onboarding-wrapper"
      className="fixed inset-0 z-50 bg-[#070811] flex flex-col items-center justify-center p-6 text-center select-none"
    >
      <div className="flex flex-col items-center">
        <div className="w-14 h-14 rounded-full border border-[#1a1d33] bg-[#0b0c16] p-3 text-indigo-400 flex items-center justify-center shadow-lg shadow-indigo-500/5 animate-pulse mb-4">
          <Play className="w-6 h-6 fill-indigo-400/20 stroke-[1.5px] ml-0.5" />
        </div>

        <h1 className="text-xl font-sans font-extrabold tracking-wide text-white">
          Toon<span className="text-indigo-400 font-medium">Play</span>
        </h1>

        <span className="text-[9px] font-mono tracking-widest text-[#a5b4fc] block mt-1.5 uppercase font-bold">
          {TAGLINE}
        </span>

        <div className="w-56 h-[3px] bg-[#14162a] rounded-full overflow-hidden mt-8">
          <div
            ref={barRef}
            className="h-full bg-indigo-500 rounded-full transition-all duration-75"
            style={{ width: '0%' }}
          />
        </div>

        <span
          ref={labelRef}
          className="text-[10px] font-mono text-slate-500 mt-3 tabular-nums"
        >
          0% SYNCED
        </span>
      </div>
    </div>
  );
};

