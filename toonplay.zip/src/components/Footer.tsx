import React, { useEffect, useRef, useState } from 'react';
import { Trophy, Clapperboard } from 'lucide-react';

const TelegramIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 11.944 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" />
  </svg>
);

interface FooterProps {
  onNavigateTab?: (tab: 'all' | 'anime' | 'cartoon' | 'watchlist' | 'history') => void;
  onNavigate?: (path: string) => void;
}

export const Footer: React.FC<FooterProps> = React.memo(({ onNavigateTab, onNavigate }) => {
  const handleNav = (path: string, legacyTab?: 'all' | 'anime' | 'cartoon' | 'watchlist' | 'history') => {
    if (onNavigate) {
      onNavigate(path);
    } else if (legacyTab && onNavigateTab) {
      onNavigateTab(legacyTab);
    }
  };

  const [showMobileNav, setShowMobileNav] = useState(true);
  const lastScrollYRef = useRef(0);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      const prev = lastScrollYRef.current;
      if (currentScrollY < prev) {
        setShowMobileNav((v) => (v ? v : true));
      } else if (currentScrollY > prev && currentScrollY > 100) {
        setShowMobileNav((v) => (v ? false : v));
      }
      lastScrollYRef.current = currentScrollY;
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const activeMobileTab: 'home' | 'anime' | 'cartoon' | 'leaderboard' | 'movies' | null = (() => {
    if (typeof window === 'undefined') return null;
    const path = window.location.pathname.toLowerCase();
    if (path === '/category/anime' || path === '/anime') return 'anime';
    if (path === '/category/cartoon' || path === '/cartoon') return 'cartoon';
    if (path === '/leaderboard' || path === '/leaderboards') return 'leaderboard';
    if (path === '/movies' || path === '/category/movies') return 'movies'; // Added Movies
    if (path === '/' || path === '/home') return 'home';
    return null;
  })();

  return (
    <>
    <footer className="w-full border-t border-[#1b1e33] bg-[#070812] pt-12 pb-8 text-slate-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">

        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-8 border-b border-[#181a2e]">

          <div className="md:col-span-2 space-y-3">
            <button
              onClick={() => handleNav('/', 'all')}
              className="flex items-center text-left group cursor-pointer focus:outline-none"
            >
              <img
                src="/images/toonplay-logo.webp"
                alt="ToonPlay Logo"
                className="h-7 w-auto object-contain group-hover:scale-105 transition-transform"
              />
            </button>
<p className="text-xs text-slate-400 max-w-md leading-relaxed">
  Watch anime online, stream cartoons, movies, and series on ToonPlay. Discover
  your favourite entertainment across multiple genres and audio languages.
</p>
            <div className="flex flex-col gap-2">
              <a
                target="_blank"
                rel="noopener noreferrer"
                className="py-1.5 px-3 rounded-full bg-white text-black text-xs flex gap-1.5 items-center w-fit hover:bg-gray-100 transition"
                href="https://t.me/toonplay_official"
              >
                Join now
                <TelegramIcon className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          <div className="space-y-3 text-xs">
            <h4 className="font-semibold text-slate-200 tracking-wider uppercase text-[11px] font-mono">
              Categories
            </h4>
            <ul className="space-y-2 text-slate-400">
              <li>
                <button
                  type="button"
                  onClick={() => handleNav('/', 'all')}
                  className="hover:text-indigo-400 transition-colors cursor-pointer text-left"
                >
                  All Streaming Catalog
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleNav('/category/anime', 'anime')}
                  className="hover:text-indigo-400 transition-colors cursor-pointer text-left"
                >
                  Anime Series & Films
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleNav('/category/cartoon', 'cartoon')}
                  className="hover:text-indigo-400 transition-colors cursor-pointer text-left"
                >
                  Cartoon Series
                </button>
              </li>
            </ul>
          </div>

          <div className="space-y-3 text-xs">
            <h4 className="font-semibold text-slate-200 tracking-wider uppercase text-[11px] font-mono">
              My Library
            </h4>
            <ul className="space-y-2 text-slate-400">
              <li>
                <button
                  type="button"
                  onClick={() => handleNav('/watchlist', 'watchlist')}
                  className="hover:text-indigo-400 transition-colors cursor-pointer text-left"
                >
                  Saved Watchlist
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleNav('/history', 'history')}
                  className="hover:text-indigo-400 transition-colors cursor-pointer text-left"
                >
                  Streaming History
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleNav('/languages')}
                  className="hover:text-indigo-400 transition-colors cursor-pointer text-left"
                >
                  Languages & Audio
                </button>
              </li>
            </ul>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-6 text-[11px] font-mono text-slate-400">
          <button
            type="button"
            onClick={() => handleNav('/about')}
            className="hover:text-white transition-colors cursor-pointer select-none"
          >
            ABOUT
          </button>
          <span className="text-slate-800">|</span>
          <button
            type="button"
            onClick={() => handleNav('/contact')}
            className="hover:text-white transition-colors cursor-pointer select-none"
          >
            CONTACT
          </button>
          <span className="text-slate-800">|</span>
          <button
            type="button"
            onClick={() => handleNav('/terms')}
            className="hover:text-white transition-colors cursor-pointer select-none"
          >
            TERMS
          </button>
          <span className="text-slate-800">|</span>
          <button
            type="button"
            onClick={() => handleNav('/dmca')}
            className="hover:text-white transition-colors cursor-pointer select-none"
          >
            DMCA
          </button>
        </div>

        <div className="max-w-3xl mx-auto text-center space-y-2">
<p className="text-[11px] leading-relaxed text-slate-500">
  Disclaimer: ToonPlay provides access to anime, cartoons, movies, and series through
  third-party video sources. We do not host, upload, or store video files on our
  servers. All media is hosted by external providers. For copyright concerns or
  removal requests, please contact us or the respective host.
</p>
        </div>

        <div className="pt-4 border-t border-[#141629] text-center text-xs text-slate-500 font-mono">
          <p>© {new Date().getFullYear()} ToonPlay. All rights reserved.</p>
        </div>
      </div>
    </footer>
    <nav
  className={`fixed bottom-3 left-4 right-4 mx-auto w-auto max-w-[420px] z-50 block md:hidden transition-all duration-300 ease-in-out ${
    showMobileNav
      ? 'translate-y-0 opacity-100 pointer-events-auto'
      : 'translate-y-24 opacity-0 pointer-events-none'
  }`}
  aria-label="Mobile bottom navigation"
>
<div className="relative w-full h-16 backdrop-blur-lg bg-[#070812]/95 border border-[#1b1e33] shadow-2xl shadow-black/60 overflow-hidden rounded-full">
          <ul className="flex items-center justify-between px-1 w-full h-full">
            {/* 1. Anime */}
            <li className="flex-1 flex flex-col items-center justify-center">
              <button
                type="button"
                onClick={() => handleNav('/category/anime', 'anime')}
                className="flex flex-col items-center justify-center w-full h-full relative group cursor-pointer gap-0.5"
                aria-label="Anime"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 32 32"
                  fill="currentColor"
                  className={`w-5 h-5 transition-colors duration-300 ${
                    activeMobileTab === 'anime'
                      ? 'text-indigo-400'
                      : 'text-slate-400 group-hover:text-indigo-400'
                  }`}
                >
                  <path d="M3.912 17.959c-0.303-3.823 0.963-7.599 3.509-10.464 2.548-2.859 6.152-4.563 9.98-4.708 3.828-0.141 7.547 1.281 10.301 3.943 2.761 2.661 4.308 6.328 4.297 10.161v-0.891c0-8.839-7.161-16-16-16s-16 7.161-16 16c0 8.839 7.161 16 16 16h1.068c-7.385-0.521-13.115-6.645-13.156-14.041zM25.599 18.667c-5.749 0.021-7.183-7.984-1.776-9.959-1.583-0.844-3.359-1.276-5.156-1.239-4.531 0-8.615 2.728-10.349 6.911-1.733 4.188-0.776 9.005 2.428 12.208 3.203 3.204 8.020 4.161 12.208 2.428 4.183-1.735 6.911-5.819 6.911-10.349 0.032-0.713-0.025-1.432-0.176-2.136-0.876 1.401-2.437 2.219-4.089 2.136z"/>
                </svg>
                <span className={`text-[9px] font-medium leading-none ${activeMobileTab === 'anime' ? 'text-indigo-400' : 'text-slate-400'}`}>Anime</span>
              </button>
            </li>

            {/* 2. Cartoon (Custom Icon) */}
            <li className="flex-1 flex flex-col items-center justify-center">
              <button
                type="button"
                onClick={() => handleNav('/category/cartoon', 'cartoon')}
                className="flex flex-col items-center justify-center w-full h-full relative group cursor-pointer gap-0.5"
                aria-label="Cartoon"
              >
                {/* Replace this svg with your actual CartoonNetworkIcon component */}
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className={`w-5 h-5 transition-colors duration-300 ${
                    activeMobileTab === 'cartoon'
                      ? 'text-indigo-400'
                      : 'text-slate-400 group-hover:text-indigo-400'
                  }`}
                >
                  <circle cx="12" cy="12" r="10"/>
                  <path d="M8 14s1.5 2 4 2 4-2 4-2"/>
                  <line x1="9" x2="9.01" y1="9" y2="9"/>
                  <line x1="15" x2="15.01" y1="9" y2="9"/>
                </svg>
                {/* Or if you have the component: <CartoonNetworkIcon className="w-5 h-5" /> */}
                <span className={`text-[9px] font-medium leading-none ${activeMobileTab === 'cartoon' ? 'text-indigo-400' : 'text-slate-400'}`}>Cartoon</span>
              </button>
            </li>

            {/* 3. Home */}
            <li className="flex-1 flex flex-col items-center justify-center">
              <button
                type="button"
                onClick={() => handleNav('/', 'all')}
                className="flex flex-col items-center justify-center w-full h-full relative group cursor-pointer gap-0.5"
                aria-label="Home"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className={`w-5 h-5 transition-colors duration-300 ${
                    activeMobileTab === 'home'
                      ? 'text-indigo-400'
                      : 'text-slate-400 group-hover:text-indigo-400'
                  }`}
                >
                  <path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"></path>
                  <path d="M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                </svg>
                <span className={`text-[9px] font-medium leading-none ${activeMobileTab === 'home' ? 'text-indigo-400' : 'text-slate-400'}`}>Home</span>
              </button>
            </li>

            {/* 4. Leaderboard (Trophy) */}
            <li className="flex-1 flex flex-col items-center justify-center">
              <button
                type="button"
                onClick={() => handleNav('/leaderboard')}
                className="flex flex-col items-center justify-center w-full h-full relative group cursor-pointer gap-0.5"
                aria-label="Leaderboard"
              >
                <Trophy
                  className={`w-5 h-5 transition-colors duration-300 ${
                    activeMobileTab === 'leaderboard'
                      ? 'text-indigo-400'
                      : 'text-slate-400 group-hover:text-indigo-400'
                  }`}
                />
                <span className={`text-[9px] font-medium leading-none ${activeMobileTab === 'leaderboard' ? 'text-indigo-400' : 'text-slate-400'}`}>Ranks</span>
              </button>
            </li>

            {/* 5. Movies (Clapperboard) */}
            <li className="flex-1 flex flex-col items-center justify-center">
              <button
                type="button"
                onClick={() => handleNav('/movies', 'all')} // Adjust tab if needed
                className="flex flex-col items-center justify-center w-full h-full relative group cursor-pointer gap-0.5"
                aria-label="Movies"
              >
                <Clapperboard
                  className={`w-5 h-5 transition-colors duration-300 ${
                    activeMobileTab === 'movies'
                      ? 'text-indigo-400'
                      : 'text-slate-400 group-hover:text-indigo-400'
                  }`}
                />
                <span className={`text-[9px] font-medium leading-none ${activeMobileTab === 'movies' ? 'text-indigo-400' : 'text-slate-400'}`}>Movies</span>
              </button>
            </li>
          </ul>
        </div>
      </nav>
    </>
  );
});
Footer.displayName = 'Footer';
