import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Play, Bookmark, Star, ChevronLeft, ChevronRight, Check } from 'lucide-react';
import { HeroAnime, UnifiedAnime } from '../types.ts';
import { useDragScroll } from '../utils/useDragScroll.ts';

interface HeroBannerProps {
  heroes: HeroAnime[];
  onSelectAnime?: (anime: UnifiedAnime) => void;
  onPlayAnime: (anime: UnifiedAnime) => void;
  watchlist: UnifiedAnime[];
  onToggleWatchlist: (anime: UnifiedAnime) => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = React.memo(({
  heroes,
  onPlayAnime,
  watchlist,
  onToggleWatchlist,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [imageError, setImageError] = useState<Record<number, boolean>>({});

  const [isHeroDragging, setIsHeroDragging] = useState(false);
  const heroDragStartRef = useRef<number | null>(null);
  const heroDragTimeRef = useRef<number>(0);
  const backdropWrapRef = useRef<HTMLDivElement | null>(null);
  const contentWrapRef = useRef<HTMLDivElement | null>(null);

  const thumbnailDrag = useDragScroll<HTMLDivElement>();
  const thumbStripRef = useRef<HTMLDivElement | null>(null);
  const thumbButtonsRef = useRef<(HTMLButtonElement | null)[]>([]);

  const currentHero = heroes[currentIndex] || heroes[0];

  const handlePrev = useCallback(() => {
    setCurrentIndex((prev) => (prev === 0 ? heroes.length - 1 : prev - 1));
  }, [heroes.length]);

  const handleNext = useCallback(() => {
    setCurrentIndex((prev) => (prev + 1) % heroes.length);
  }, [heroes.length]);

  useEffect(() => {
    if (!heroes || heroes.length === 0 || isPaused || isHeroDragging) return;

    const timer = setInterval(() => {
      handleNext();
    }, 7000);

    return () => clearInterval(timer);
  }, [heroes, isPaused, isHeroDragging, handleNext]);

  useEffect(() => {
    const strip = thumbStripRef.current;
    const activeBtn = thumbButtonsRef.current[currentIndex];
    if (!strip || !activeBtn) return;
    if (thumbnailDrag.isDragging) return;

    const stripRect = strip.getBoundingClientRect();
    const btnRect = activeBtn.getBoundingClientRect();

    const margin = 16;
    const fullyVisible =
      btnRect.left >= stripRect.left + margin &&
      btnRect.right <= stripRect.right - margin;

    if (fullyVisible) return;

    const targetLeft =
      activeBtn.offsetLeft - strip.clientWidth / 2 + activeBtn.clientWidth / 2;

    strip.scrollTo({
      left: Math.max(0, targetLeft),
      behavior: 'smooth',
    });
  }, [currentIndex, thumbnailDrag.isDragging]);

  if (!currentHero) return null;

const currentUnified: UnifiedAnime = {
  id: currentHero.id,
  subjectId: currentHero.subjectId,
  title: currentHero.title,
  image: currentHero.backdrop,
  backdrop: currentHero.backdrop,
  type: (currentHero.type === 'movie' ? 'movie' : 'series') as 'series' | 'movie',
  overview: currentHero.overview,
  rating: currentHero.rating,
  year: currentHero.year,
  category: 'hero',
};

  const isInWatchlist = watchlist.some((item) => item.id === currentHero.id);

  const applyDragStyles = (dampedDiff: number, dragging: boolean) => {
    if (backdropWrapRef.current) {
      backdropWrapRef.current.style.transition = dragging
        ? 'none'
        : 'transform 450ms cubic-bezier(0.16, 1, 0.3, 1)';
      backdropWrapRef.current.style.transform = `translateX(${dampedDiff * 0.4}px)`;
    }
    if (contentWrapRef.current) {
      contentWrapRef.current.style.transition = dragging
        ? 'none'
        : 'transform 450ms cubic-bezier(0.16, 1, 0.3, 1), opacity 450ms ease-out';
      contentWrapRef.current.style.transform = `translateX(${dampedDiff * 0.75}px)`;
      contentWrapRef.current.style.opacity = dragging
        ? String(Math.max(0.65, 1 - Math.abs(dampedDiff) / 600))
        : '1';
    }
  };

  const handleHeroPointerDown = (e: React.PointerEvent<HTMLElement>) => {

    const target = e.target as HTMLElement;
    if (target.closest('button') || target.closest('a') || target.closest('input')) return;
    if (e.button !== 0 && e.pointerType === 'mouse') return;

    heroDragStartRef.current = e.clientX;
    heroDragTimeRef.current = performance.now();
    setIsHeroDragging(true);
    applyDragStyles(0, true);

    const onPointerMove = (moveEv: PointerEvent) => {
      if (heroDragStartRef.current === null) return;
      const diff = moveEv.clientX - heroDragStartRef.current;

      const dampedDiff = diff * 0.85;
      applyDragStyles(dampedDiff, true);
    };

    const onPointerUp = (upEv: PointerEvent) => {
      if (heroDragStartRef.current !== null) {
        const diff = upEv.clientX - heroDragStartRef.current;
        const timeDiff = Math.max(1, performance.now() - heroDragTimeRef.current);
        const velocity = diff / timeDiff;

        heroDragStartRef.current = null;
        setIsHeroDragging(false);
        applyDragStyles(0, false);

        if (diff < -60 || velocity < -0.4) {
          handleNext();
        } else if (diff > 60 || velocity > 0.4) {
          handlePrev();
        }
      }

      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUp);
      window.removeEventListener('pointercancel', onPointerUp);
    };

    window.addEventListener('pointermove', onPointerMove, { passive: true });
    window.addEventListener('pointerup', onPointerUp);
    window.addEventListener('pointercancel', onPointerUp);
  };

  return (
    <section
      id="hero"
      aria-label="Featured Anime Carousel"
      className="relative w-full min-h-[580px] md:min-h-[660px] lg:min-h-[720px] flex items-end overflow-x-clip bg-[#0b0c16] select-none cursor-grab active:cursor-grabbing"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onPointerDown={handleHeroPointerDown}
    >

      <div className="absolute inset-0 z-[2] pointer-events-none select-none">
        <div className="absolute inset-0 bg-gradient-to-t from-[#0b0c16] via-[#0b0c16]/85 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0b0c16] via-[#0b0c16]/80 to-transparent max-w-4xl" />
        <div className="absolute inset-x-0 top-0 h-28 bg-gradient-to-b from-[#0c0d17]/80 to-transparent" />
        <div className="absolute inset-0 bg-indigo-950/15 mix-blend-color" />
      </div>
      <div className="absolute bottom-0 inset-x-0 h-32 sm:h-36 z-[5] pointer-events-none select-none bg-gradient-to-b from-transparent via-[#0b0c16]/80 to-[#0b0c16]" />

      <div
        ref={backdropWrapRef}
        className="absolute inset-0 z-0 pointer-events-none select-none will-change-transform overflow-hidden"
        style={{
          transform: 'translateX(0px)',
          transition: 'transform 450ms cubic-bezier(0.16, 1, 0.3, 1)',
        }}
      >
        {!imageError[currentIndex] ? (
          <img
            src={currentHero.backdrop}
            alt={currentHero.title}
            fetchPriority="high"
            decoding="async"
            draggable="false"
            onDragStart={(e) => e.preventDefault()}
            referrerPolicy="no-referrer"
            onError={() => setImageError((prev) => ({ ...prev, [currentIndex]: true }))}
            className="w-full h-full object-cover object-center transform scale-105 transition-all duration-1000 ease-out brightness-90 contrast-105 pointer-events-none select-none"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-[#121426] via-[#0d0e1b] to-[#080913] flex items-center justify-center">
            <span className="text-indigo-400/20 font-bold text-6xl tracking-tighter">
              {currentHero.title}
            </span>
          </div>
        )}
      </div>

      <div
        ref={contentWrapRef}
        className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pt-28 sm:pt-32 lg:pt-36 pb-4 md:pb-5 will-change-transform"
        style={{
          transform: 'translateX(0px)',
          opacity: 1,
          transition: 'transform 450ms cubic-bezier(0.16, 1, 0.3, 1), opacity 450ms ease-out',
        }}
      >
        <div className="max-w-2xl space-y-3.5">

          <h1 className="text-2xl sm:text-4xl lg:text-5xl font-semibold text-white tracking-tight leading-tight line-clamp-2 [overflow-wrap:anywhere]">
            {currentHero.title}
          </h1>

          <div className="flex flex-wrap items-center gap-2 text-xs sm:text-sm font-normal text-indigo-300">
            <span className="flex items-center gap-1 text-amber-300 font-medium font-mono tabular-nums">
              <Star className="w-3.5 h-3.5 fill-amber-300 text-amber-300 inline" />
              {currentHero.rating}
            </span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span className="text-slate-300 font-mono tabular-nums">{currentHero.year}</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span className="text-indigo-200 capitalize font-mono">{currentHero.type}</span>
          </div>

          <p className="text-xs sm:text-sm text-slate-300 line-clamp-3 leading-relaxed font-normal">
            {currentHero.overview}
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onPlayAnime(currentUnified)}
              className="px-5 py-2.5 text-xs sm:text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 rounded-xl transition-all duration-200 flex items-center gap-2 shadow-lg shadow-indigo-600/30 hover:scale-[1.02] cursor-pointer"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>Watch Now</span>
            </button>

            <button
              onClick={() => onToggleWatchlist(currentUnified)}
              className={`px-4 py-2.5 text-xs sm:text-sm font-medium rounded-xl border transition-all duration-200 flex items-center gap-2 cursor-pointer ${
                isInWatchlist
                  ? 'bg-emerald-950/40 text-emerald-300 border-emerald-700/60 shadow-sm'
                  : 'bg-[#151726]/80 hover:bg-[#1d2035] text-slate-200 border-[#2b2f48]'
              }`}
            >
              {isInWatchlist ? (
                <>
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span>In Watchlist</span>
                </>
              ) : (
                <>
                  <Bookmark className="w-4 h-4 text-indigo-400" />
                  <span>Add to Watchlist</span>
                </>
              )}
            </button>
          </div>
        </div>

        <div className="mt-7 pt-4 border-t border-[#1e2136] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div
            ref={(el) => {
              thumbnailDrag.ref.current = el;
              thumbStripRef.current = el;
            }}
            {...thumbnailDrag.dragProps}
            className={`flex items-center gap-2.5 overflow-x-auto py-2 px-1 scrollbar-none ${
              thumbnailDrag.isDragging ? 'cursor-grabbing select-none' : 'cursor-grab'
            }`}
            style={{
              ...thumbnailDrag.dragProps.style,
              scrollbarWidth: 'none',
              msOverflowStyle: 'none',
              WebkitOverflowScrolling: 'touch',
            }}
          >
            {heroes.map((hero, idx) => (
              <button
                key={hero.id}
                ref={(el) => { thumbButtonsRef.current[idx] = el; }}
                onClick={() => {
                  if (!thumbnailDrag.hasDraggedRef?.current) {
                    setCurrentIndex(idx);
                  }
                }}
                className={`group relative text-left rounded-xl transition-all duration-200 shrink-0 cursor-pointer p-0.5 select-none ${
                  currentIndex === idx
                    ? 'border-2 border-indigo-500 shadow-md shadow-indigo-600/30 opacity-100'
                    : 'border border-[#262940] hover:border-indigo-400/60 opacity-60 hover:opacity-100'
                }`}
              >
                <div className="w-24 sm:w-28 h-12 relative rounded-lg overflow-hidden bg-[#121426] pointer-events-none">
                  <img
                    src={hero.backdrop}
                    alt={hero.title}
                    loading="lazy"
                    decoding="async"
                    draggable="false"
                    onDragStart={(e) => e.preventDefault()}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover select-none pointer-events-none"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent" />
                  <span className="absolute bottom-1 left-1.5 right-1.5 text-[10px] font-medium text-white truncate block">
                    {hero.title}
                  </span>
                </div>
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
            <button
              onClick={handlePrev}
              aria-label="Previous featured anime"
              className="p-2 rounded-lg bg-[#141628] hover:bg-[#1c1f38] text-slate-300 hover:text-white border border-[#262942] transition-colors cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <div className="px-2 text-xs font-mono tabular-nums text-indigo-300">
              {String(currentIndex + 1).padStart(2, '0')} / {String(heroes.length).padStart(2, '0')}
            </div>
            <button
              onClick={handleNext}
              aria-label="Next featured anime"
              className="p-2 rounded-lg bg-[#141628] hover:bg-[#1c1f38] text-slate-300 hover:text-white border border-[#262942] transition-colors cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
});
HeroBanner.displayName = 'HeroBanner';
