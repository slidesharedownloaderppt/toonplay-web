import React from 'react';

export const HistorySkeleton: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#0b0c16] text-slate-100 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-6">

        {/* Back + Clear History row */}
        <div className="flex items-center justify-between gap-4">
          <div className="w-[110px] h-4 bg-[#16182c]/70 rounded animate-pulse" />
          <div className="w-[118px] h-[30px] bg-[#16182c] rounded-lg animate-pulse" />
        </div>

        {/* Header block */}
        <div className="border-b border-[#1b1e33] pb-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-indigo-600/20 border border-indigo-500/30 animate-pulse" />
                <div className="w-48 sm:w-64 h-8 sm:h-9 bg-[#16182c] rounded animate-pulse" />
              </div>
              <div className="w-72 max-w-xl h-3 bg-[#16182c]/70 rounded animate-pulse" />
            </div>

            <div className="w-full sm:w-[220px] h-9 bg-[#111322] border border-[#232742] rounded-xl animate-pulse self-start sm:self-auto" />
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
            <div className="flex items-center gap-2">
              <div className="w-[124px] h-[30px] bg-[#14172b] border border-[#232742] rounded-lg animate-pulse" />
              <div className="w-[88px] h-[30px] bg-[#14172b] border border-[#232742] rounded-lg animate-pulse" />
              <div className="w-[92px] h-[30px] bg-[#14172b] border border-[#232742] rounded-lg animate-pulse" />
            </div>
            <div className="relative w-full sm:w-64 h-[32px] bg-[#111322] border border-[#232742] rounded-lg animate-pulse">
              <div className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 rounded bg-[#1e2139]" />
            </div>
          </div>
        </div>

        {/* Card grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4">
          {Array.from({ length: 12 }).map((_, i) => (
            <div
              key={i}
              className="relative rounded-xl bg-[#121424] border border-[#22253c] overflow-hidden aspect-[2/3] animate-pulse"
            >
              <div className="absolute inset-0 bg-[#0d0e1b]" />
              <div className="absolute top-2 right-2 w-14 h-5 rounded bg-[#181a30]/90 border border-[#22253c]" />
              <div className="absolute inset-x-0 bottom-0 p-2.5 sm:p-3 flex flex-col gap-1.5">
                <div className="w-16 h-2.5 bg-[#181a30] rounded" />
                <div className="w-full h-3.5 bg-[#181a30] rounded" />
                <div className="pt-1.5 mt-0.5 border-t border-white/10 flex items-center gap-2">
                  <div className="flex-1 h-6 bg-[#181a30] rounded-md" />
                  <div className="w-7 h-6 bg-[#181a30] rounded-md" />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Pagination row */}
        <div className="flex items-center justify-center gap-3 pt-8 pb-4">
          <div className="w-24 h-8 bg-[#14172b] border border-[#232742] rounded-lg animate-pulse" />
          <div className="flex items-center gap-1">
            {Array.from({ length: 5 }).map((_, i) => (
              <div
                key={i}
                className="w-7 h-7 rounded-lg bg-[#14172b] border border-[#232742] animate-pulse"
              />
            ))}
          </div>
          <div className="w-20 h-8 bg-[#14172b] border border-[#232742] rounded-lg animate-pulse" />
        </div>
      </div>
    </div>
  );
};