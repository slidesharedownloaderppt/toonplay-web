import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { Search, X, Film, Tv, Play, Bookmark, TrendingUp, Loader2, Check, ArrowRight } from 'lucide-react';
import { UnifiedAnime } from '../types.ts';
import { searchCatalog, SearchApiResultItem as SearchApiItem } from '../api.ts';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  topTrending: UnifiedAnime[];
  initialQuery?: string;
  onSelectAnime: (anime: UnifiedAnime) => void;
  onPlayAnime: (anime: UnifiedAnime) => void;
  onNavigateToSearchPage: (query: string) => void;
  watchlist: UnifiedAnime[];
  onToggleWatchlist: (anime: UnifiedAnime) => void;
}

const toDisplayType = (raw: unknown, isMovieFallback: boolean): string => {
  const s = String(raw ?? '').trim().toUpperCase();
  if (s) return s;
  return isMovieFallback ? 'MOVIE' : 'SERIES';
};

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  topTrending,
  initialQuery = '',
  onSelectAnime,
  onPlayAnime,
  onNavigateToSearchPage,
  watchlist,
  onToggleWatchlist,
}) => {
  const [query, setQuery] = useState(initialQuery);
  const [searchResults, setSearchResults] = useState<SearchApiItem[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const searchTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  const trendingList = useMemo(() => topTrending.slice(0, 5), [topTrending]);
  const watchlistIdSet = useMemo(() => new Set(watchlist.map((w) => w.id)), [watchlist]);

  const executeSearch = useCallback(async (searchTerm: string) => {
    const clean = searchTerm.trim();
    abortControllerRef.current?.abort();

    if (!clean) {
      setSearchResults([]);
      setIsSearching(false);
      return;
    }

    const controller = new AbortController();
    abortControllerRef.current = controller;
    setIsSearching(true);

    try {
      const json = await searchCatalog(clean, 1, controller.signal);
      if (controller.signal.aborted) return;
      if (json && json.success && Array.isArray(json.data)) {
        setSearchResults(json.data);
      } else {
        setSearchResults([]);
      }
    } catch (err: any) {
      if (err?.name === 'AbortError' || controller.signal.aborted) return;
      console.error('Search error:', err);
    } finally {
      if (!controller.signal.aborted) {
        setIsSearching(false);
      }
    }
  }, []);

  useEffect(() => {
    if (isOpen) {
      setQuery(initialQuery);
      const focusTimer = setTimeout(() => inputRef.current?.focus(), 60);
      document.body.style.overflow = 'hidden';
      if (initialQuery.trim()) {
        executeSearch(initialQuery.trim());
      } else {
        setSearchResults([]);
      }
      return () => {
        clearTimeout(focusTimer);
      };
    } else {
      if (searchTimeoutRef.current) clearTimeout(searchTimeoutRef.current);
      abortControllerRef.current?.abort();
      setQuery('');
      setSearchResults([]);
      setIsSearching(false);
      document.body.style.overflow = 'unset';
    }
  }, [isOpen, initialQuery, executeSearch]);

  useEffect(() => {
    return () => {
      if (searchTimeoutRef.current) clearTimeout(searchTimeoutRef.current);
      abortControllerRef.current?.abort();
      document.body.style.overflow = 'unset';
    };
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setQuery(val);

    if (searchTimeoutRef.current) clearTimeout(searchTimeoutRef.current);

    if (!val.trim()) {
      abortControllerRef.current?.abort();
      setSearchResults([]);
      setIsSearching(false);
      return;
    }

    searchTimeoutRef.current = setTimeout(() => {
      executeSearch(val);
    }, 350);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onNavigateToSearchPage(query.trim());
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-start justify-center p-3 sm:p-6 md:p-8 bg-[#05060d]/85 backdrop-blur-md overflow-y-auto thin-scrollbar animate-in fade-in duration-150"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-2xl bg-[#0e101f] border border-[#262a42] rounded-2xl shadow-2xl shadow-black/80 overflow-hidden my-6"
      >

        <form onSubmit={handleSubmit} className="flex items-center gap-3 px-5 py-3.5 border-b border-[#22253b] bg-[#111326]">
          <Search className="w-4.5 h-4.5 text-indigo-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={handleInputChange}
            placeholder="Search anime, cartoon and movie..."
            className="w-full bg-transparent text-white text-sm sm:text-base placeholder:text-slate-500 focus:outline-none"
          />
          {query && (
            <button
              type="button"
              onClick={() => {
                setQuery('');
                setSearchResults([]);
              }}
              className="text-xs text-slate-400 hover:text-white px-1.5 py-0.5 rounded cursor-pointer"
            >
              Clear
            </button>
          )}
          <button
            type="submit"
            className="hidden sm:inline-flex px-3 py-1 text-xs font-medium bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-colors cursor-pointer shrink-0"
          >
            Search
          </button>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close search"
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#1a1c32] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </form>

        <div className="p-4 sm:p-5 max-h-[62vh] overflow-y-auto thin-scrollbar">

          {isSearching && (
            <div className="py-8 flex items-center justify-center gap-2 text-indigo-300 text-xs font-mono">
              <Loader2 className="w-4 h-4 animate-spin text-indigo-400" />
              <span>Searching titles...</span>
            </div>
          )}

          {!isSearching && query.trim() !== '' && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400 mb-2 px-1">
                <span>Results for &ldquo;{query}&rdquo;</span>
                <button
                  onClick={() => {
                    onNavigateToSearchPage(query.trim());
                    onClose();
                  }}
                  className="text-indigo-400 hover:text-indigo-300 font-medium inline-flex items-center gap-1 cursor-pointer"
                >
                  <span>View full results page</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {searchResults.length > 0 ? (
                searchResults.map((item) => {
                  const isMovieType = String(item.type || '').toLowerCase() === 'movie';
                  const displayType = toDisplayType(item.type, isMovieType);

const unified: UnifiedAnime = {
  id: item.id,
  subjectId: item.subjectId,
  title: item.title,
  image: item.image,
  type: isMovieType ? 'movie' : 'series',
  displayType,
  anilistId: item.anilist_id,
  category: isMovieType ? 'movie' : 'series',
};
                  const inWatchlist = watchlistIdSet.has(item.id);

                  return (
                    <div
                      key={item.id}
                      onClick={() => {
                        onSelectAnime(unified);
                        onClose();
                      }}
                      className="group flex items-center gap-3 p-2.5 rounded-xl bg-[#131527] hover:bg-[#181a32] border border-[#23263d] hover:border-indigo-500/50 transition-all cursor-pointer"
                    >
<div className="w-12 h-16 rounded-lg overflow-hidden bg-[#0d0e1c] shrink-0 relative">
  {item.image ? (
    <img
      src={item.image}
      alt={item.title}
      loading="lazy"
      decoding="async"
      referrerPolicy="no-referrer"
      onError={(e) => {
        const img = e.currentTarget;
        img.style.display = 'none';
        const fb = img.nextElementSibling as HTMLElement | null;
        if (fb) fb.style.display = 'flex';
      }}
      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
    />
  ) : null}
  <div
    className="absolute inset-0 flex-col items-center justify-center bg-gradient-to-br from-[#181a33] to-[#0c0d18]"
    style={{ display: item.image ? 'none' : 'flex' }}
  >
    {isMovieType ? (
      <Film className="w-4 h-4 text-indigo-400/70" />
    ) : (
      <Tv className="w-4 h-4 text-indigo-400/70" />
    )}
  </div>
</div>

                      <div className="flex-1 min-w-0 pr-2">
                        <div className="flex items-center gap-1.5 text-[11px] font-mono text-indigo-400 mb-0.5">
                          {isMovieType ? (
                            <Film className="w-3 h-3 text-indigo-400 inline" />
                          ) : (
                            <Tv className="w-3 h-3 text-indigo-400 inline" />
                          )}
                          <span className="uppercase tracking-wide">{displayType}</span>
                        </div>
                        <h4 className="text-xs sm:text-sm font-medium text-white group-hover:text-indigo-300 transition-colors truncate">
                          {item.title}
                        </h4>

                        {item.categories && item.categories.length > 0 && (
                          <div className="flex items-center gap-1.5 mt-1 overflow-x-auto scrollbar-none text-[10px] text-slate-400 font-mono">
                            {item.categories.slice(0, 3).map((cat) => (
                              <span key={cat} className="capitalize">
                                {cat.replace('-', ' ')}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onPlayAnime(unified);
                            onClose();
                          }}
                          title="Watch Stream"
                          className="p-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition-colors cursor-pointer"
                        >
                          <Play className="w-3.5 h-3.5 fill-current" />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onToggleWatchlist(unified);
                          }}
                          title={inWatchlist ? 'In Watchlist' : 'Add to Watchlist'}
                          className={`p-2 rounded-lg border transition-colors cursor-pointer ${
                            inWatchlist
                              ? 'bg-indigo-950 border-indigo-500 text-indigo-200'
                              : 'bg-[#181a2e] border-[#292c48] text-slate-400 hover:text-white'
                          }`}
                        >
                          {inWatchlist ? (
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <Bookmark className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center py-12 text-slate-400">
                  <p className="text-sm text-slate-300">No matching titles found</p>
                  <p className="text-xs text-slate-500 mt-1">
                    Try searching for Naruto, One Piece, Attack on Titan, Doraemon, etc.
                  </p>
                </div>
              )}
            </div>
          )}

          {!isSearching && query.trim() === '' && (
            <div className="space-y-3">
              <div className="flex items-center gap-1.5 text-xs text-indigo-400 font-medium px-1">
                <TrendingUp className="w-4 h-4 text-indigo-400" />
                <span>Top Trending Titles</span>
              </div>

              <div className="space-y-2">
                {trendingList.map((item, idx) => {
                  const inWatchlist = watchlistIdSet.has(item.id);
                  const isMovieType = String(item.type || '').toLowerCase() === 'movie';
                  const displayType = toDisplayType(item.displayType ?? item.type, isMovieType);

                  return (
                    <div
                      key={item.id}
                      onClick={() => {
                        onSelectAnime(item);
                        onClose();
                      }}
                      className="group flex items-center gap-3 p-2.5 rounded-xl bg-[#131527] hover:bg-[#181a32] border border-[#23263d] hover:border-indigo-500/50 transition-all cursor-pointer"
                    >
                      <span className="w-5 text-center text-xs font-mono font-medium text-slate-500 group-hover:text-indigo-400">
                        0{idx + 1}
                      </span>

<div className="w-12 h-16 rounded-lg overflow-hidden bg-[#0d0e1c] shrink-0 relative">
  {item.image ? (
    <img
      src={item.image}
      alt={item.title}
      loading="lazy"
      decoding="async"
      referrerPolicy="no-referrer"
      onError={(e) => {
        const img = e.currentTarget;
        img.style.display = 'none';
        const fb = img.nextElementSibling as HTMLElement | null;
        if (fb) fb.style.display = 'flex';
      }}
      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
    />
  ) : null}
  <div
    className="absolute inset-0 flex-col items-center justify-center bg-gradient-to-br from-[#181a33] to-[#0c0d18]"
    style={{ display: item.image ? 'none' : 'flex' }}
  >
    {isMovieType ? (
      <Film className="w-4 h-4 text-indigo-400/70" />
    ) : (
      <Tv className="w-4 h-4 text-indigo-400/70" />
    )}
  </div>
</div>

                      <div className="flex-1 min-w-0 pr-2">
                        <div className="flex items-center gap-1.5 text-[11px] font-mono text-indigo-400 mb-0.5">
                          {isMovieType ? (
                            <Film className="w-3 h-3 text-indigo-400 inline" />
                          ) : (
                            <Tv className="w-3 h-3 text-indigo-400 inline" />
                          )}
                          <span className="uppercase tracking-wide">{displayType}</span>
                          {item.year && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span>{item.year}</span>
                            </>
                          )}
                        </div>
                        <h4 className="text-xs sm:text-sm font-medium text-white group-hover:text-indigo-300 transition-colors truncate">
                          {item.title}
                        </h4>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onPlayAnime(item);
                            onClose();
                          }}
                          title="Watch Stream"
                          className="p-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition-colors cursor-pointer"
                        >
                          <Play className="w-3.5 h-3.5 fill-current" />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onToggleWatchlist(item);
                          }}
                          title={inWatchlist ? 'In Watchlist' : 'Add to Watchlist'}
                          className={`p-2 rounded-lg border transition-colors cursor-pointer ${
                            inWatchlist
                              ? 'bg-indigo-950 border-indigo-500 text-indigo-200'
                              : 'bg-[#181a2e] border-[#292c48] text-slate-400 hover:text-white'
                          }`}
                        >
                          {inWatchlist ? (
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <Bookmark className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};