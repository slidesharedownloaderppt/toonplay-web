import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { ArrowLeft, ChevronLeft, ChevronRight, Loader2, Sparkles } from 'lucide-react';
import { AnimeCard } from '../components/AnimeCard.tsx';
import { UnifiedAnime, GlobalLatestReleaseAnime } from '../types.ts';
import { fetchHomeContent, fetchLatestReleases } from '../api.ts';
import { updateMetadataForRoute } from '../metadata.ts';
import { Share } from '../components/Share.tsx';

export type HomeSectionSlug =
  | 'childhood-shows'
  | 'latest-episodes'
  | 'popular-series'
  | 'blockbuster-movies';

interface HomeSectionPageProps {
  section: HomeSectionSlug;
  onSelectAnime: (anime: UnifiedAnime) => void;
  onPlayAnime: (anime: UnifiedAnime) => void;
  watchlist: UnifiedAnime[];
  onToggleWatchlist: (anime: UnifiedAnime) => void;
  onBackToHome: () => void;
  onHomeSectionPageLoadingChange?: (loading: boolean) => void;
}

const PAGE_SIZE = 12;

const SECTION_META: Record<
  HomeSectionSlug,
  { title: string; subtitle: string; badge: string }
> = {
  'childhood-shows': {
    title: 'Childhood Shows',
    subtitle: 'Nostalgic Classics',
    badge: 'Nostalgic',
  },
  'latest-episodes': {
    title: 'Latest Episodes & Releases',
    subtitle: 'Fresh Releases',
    badge: 'Latest',
  },
  'popular-series': {
    title: 'Most Popular TV Series',
    subtitle: 'Top Rated Shows',
    badge: 'Series',
  },
  'blockbuster-movies': {
    title: 'Blockbuster Anime Movies',
    subtitle: 'Feature Films',
    badge: 'Movies',
  },
};

const LATEST_LANG_TABS = ['JAP/ENG', 'HIN/TAM/TEL'] as const;
type LatestLangTab = (typeof LATEST_LANG_TABS)[number];

// Map a GlobalLatestReleaseAnime (from /latest-releases endpoint) to UnifiedAnime.
// Same shape as App.tsx's globalLatestReleases mapper — keeps displayType + anilistId + EP:N consistent.
function globalToUnified(item: GlobalLatestReleaseAnime): UnifiedAnime {
  const raw = String(item.type || '').trim().toUpperCase();
  const isMovie = raw === 'MOVIE';
  return {
    id: item.id,
    title: item.title,
    image: item.image_url,
    type: isMovie ? 'movie' : 'series',
    displayType: raw || (isMovie ? 'MOVIE' : 'SERIES'),
    season: item.season ? `Season ${item.season}` : null,
    episodes: item.latest_episode != null ? `EP:${item.latest_episode}` : null,
    anilistId: item.anilist_id,
    category: 'latest',
  };
}

export const HomeSectionPage: React.FC<HomeSectionPageProps> = ({
  section,
  onSelectAnime,
  onPlayAnime,
  watchlist,
  onToggleWatchlist,
  onBackToHome,
  onHomeSectionPageLoadingChange,
}) => {
  const initialParams = (() => {
    const params = new URLSearchParams(window.location.search);
    const pageParam = Number(params.get('page'));
    const langParam = params.get('lang');
    return {
      page: Number.isInteger(pageParam) && pageParam > 0 ? pageParam : 1,
      lang: (langParam === 'JAP/ENG' ? 'JAP/ENG' : 'HIN/TAM/TEL') as LatestLangTab,
    };
  })();

  const [page, setPage] = useState<number>(initialParams.page);
  const [latestLangTab, setLatestLangTab] = useState<LatestLangTab>(initialParams.lang);

  const [allItems, setAllItems] = useState<UnifiedAnime[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const fetchIdRef = useRef(0);
  const skipNextUrlPushRef = useRef(false);
  const didMountLangRef = useRef(false);

  const watchlistIdSet = useMemo(
    () => new Set(watchlist.map((w) => w.id)),
    [watchlist]
  );

  // Pagination metadata for /latest-releases endpoint (JAP/ENG tab only).
  const [remoteHasNext, setRemoteHasNext] = useState<boolean>(false);
  const [remoteHasPrev, setRemoteHasPrev] = useState<boolean>(false);

  const isLatestSection = section === 'latest-episodes';
  const isGlobalLatest = isLatestSection && latestLangTab === 'JAP/ENG';

  const fetchItems = useCallback(async () => {
    if (!SECTION_META[section]) {
      setAllItems([]);
      setIsLoading(false);
      onHomeSectionPageLoadingChange?.(false);
      return;
    }

    const fetchId = ++fetchIdRef.current;
    setIsLoading(true);
    setErrorMessage(null);
    onHomeSectionPageLoadingChange?.(true);

    try {
      // ── JAP/ENG tab of Latest → paginated /latest-releases endpoint ──
      if (isGlobalLatest) {
        const res = await fetchLatestReleases(page);
        if (fetchId !== fetchIdRef.current) return;

        if (!res || !res.success || !Array.isArray(res.data)) {
          throw new Error('Failed to load latest releases.');
        }

        setAllItems(res.data.map(globalToUnified));
        setRemoteHasNext(Boolean(res.pagination?.hasNext));
        setRemoteHasPrev(Boolean(res.pagination?.hasPrevious));
        return;
      }

      // ── All other sections (and HIN/TAM/TEL tab) → /home content ──
      const json = await fetchHomeContent();
      if (!json || !json.success || !json.data) {
        throw new Error('Failed to load home content.');
      }
      const data = json.data;

      let list: UnifiedAnime[] = [];

      if (section === 'childhood-shows') {
        list = (Array.isArray(data.trending) ? data.trending : []).map((item) => {
          const raw = String(item.type || '').trim().toUpperCase();
          const isMovie = raw === 'MOVIE';

          return {
            id: item.id,
            title: item.title,
            image: item.image || item.poster_image || '',
            type: isMovie ? ('movie' as const) : ('series' as const),
            displayType: raw || (isMovie ? 'MOVIE' : 'SERIES'),
            anilistId: item.anilist_id,
            category: isMovie ? ('movie' as const) : ('series' as const),
          };
        });
      } else if (section === 'latest-episodes') {
        // HIN/TAM/TEL tab — static from /home
        list = (data.latest_releases || []).map((item) => {
          const raw = String(item.type || '').trim().toUpperCase();
          const isMovie = raw === 'MOVIE';
          return {
            id: item.id,
            title: item.title,
            image: item.image,
            type: isMovie ? ('movie' as const) : ('series' as const),
            displayType: raw || (isMovie ? 'MOVIE' : 'SERIES'),
            season: item.season,
            episodes: item.episodes,
            anilistId: item.anilist_id,
            category: 'latest' as const,
          };
        });
      } else if (section === 'popular-series') {
        list = (data.popular_series || []).map((item) => ({
          id: item.id,
          title: item.title,
          image: item.image,
          type: 'series' as const,
          displayType: 'SERIES',
          anilistId: item.anilist_id,
          category: 'series' as const,
        }));
      } else if (section === 'blockbuster-movies') {
        list = (data.popular_movies || []).map((item) => ({
          id: item.id,
          title: item.title,
          image: item.image,
          type: 'movie' as const,
          displayType: 'MOVIE',
          anilistId: item.anilist_id,
          category: 'movie' as const,
        }));
      }

      if (fetchId === fetchIdRef.current) {
        setAllItems(list);
        setRemoteHasNext(false);
        setRemoteHasPrev(false);
      }
    } catch (err: any) {
      console.error(`Error loading home section ${section}:`, err);
      if (fetchId === fetchIdRef.current) {
        setErrorMessage(`Unable to load ${section}. Please retry.`);
      }
    } finally {
      if (fetchId === fetchIdRef.current) {
        setIsLoading(false);
        onHomeSectionPageLoadingChange?.(false);
      }
    }
  }, [section, isGlobalLatest, page, onHomeSectionPageLoadingChange]);

  useEffect(() => {
    fetchItems();
  }, [fetchItems]);

  // Reset to page 1 when switching tabs (so /latest-releases?page=2 doesn't leak across tabs)
  // Guarded so it does NOT fire on the very first mount — page/lang come from the URL.
  useEffect(() => {
    if (!isLatestSection) return;
    if (!didMountLangRef.current) {
      didMountLangRef.current = true;
      return;
    }
    skipNextUrlPushRef.current = true;
    setPage(1);
  }, [latestLangTab, isLatestSection]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);

    if (page > 1) {
      params.set('page', String(page));
    } else {
      params.delete('page');
    }

    if (isLatestSection && latestLangTab === 'JAP/ENG') {
      params.set('lang', 'JAP/ENG');
    } else {
      params.delete('lang');
    }

    const query = params.toString();
    const newUrl = `/section/${section}${query ? `?${query}` : ''}`;
    const currentUrl = window.location.pathname + window.location.search;

    if (skipNextUrlPushRef.current) {
      skipNextUrlPushRef.current = false;
      window.history.replaceState(window.history.state, '', newUrl);
    } else if (currentUrl !== newUrl) {
      window.history.pushState(window.history.state, '', newUrl);
    }

    updateMetadataForRoute(`/section/${section}`, {
      page,
      section,
    });
  }, [section, page, isLatestSection, latestLangTab]);

  useEffect(() => {
    const handlePopState = () => {
      const params = new URLSearchParams(window.location.search);
      const pageParam = Number(params.get('page'));
      const langParam = params.get('lang');

      setPage(Number.isInteger(pageParam) && pageParam > 0 ? pageParam : 1);
      if (isLatestSection) {
        setLatestLangTab(langParam === 'JAP/ENG' ? 'JAP/ENG' : 'HIN/TAM/TEL');
      }
    };

    window.addEventListener('popstate', handlePopState);

    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, [isLatestSection]);

  // Client-side pagination is only used for non-global-latest sections
  const totalPages = Math.max(1, Math.ceil(allItems.length / PAGE_SIZE));
  const items = useMemo(() => {
    if (isGlobalLatest) {
      // Server already paginated /latest-releases — render everything
      return allItems;
    }
    return allItems.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
  }, [allItems, page, isGlobalLatest]);

  useEffect(() => {
    if (isLoading || errorMessage) return;
    if (isGlobalLatest) return; // server drives pagination here
    if (page > totalPages) {
      skipNextUrlPushRef.current = true;
      setPage(totalPages);
    }
  }, [isLoading, errorMessage, totalPages, page, isGlobalLatest]);

  const canPrev = isGlobalLatest ? remoteHasPrev : page > 1;
  const canNext = isGlobalLatest ? remoteHasNext : page < totalPages;

  const meta =
    SECTION_META[section] ?? {
      title: 'Catalog Section',
      subtitle: 'Browse titles',
      badge: 'Catalog',
    };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1c1f36]">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToHome}
            className="p-2 rounded-xl bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] text-slate-300 hover:text-white transition-colors cursor-pointer"
            title="Back to Home"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-indigo-400 mb-0.5">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span>{meta.badge}</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-semibold text-white tracking-tight">
              {meta.title}
            </h1>
            <p className="text-xs text-slate-400">{meta.subtitle}</p>
          </div>
        </div>

        {isLatestSection && (
          <div className="flex items-center bg-[#121424] border border-[#24273e] p-0.5 rounded-lg text-[11px] font-mono self-start sm:self-auto">
            {LATEST_LANG_TABS.map((tab) => {
              const isActive = tab === latestLangTab;
              return (
                <button
                  key={tab}
                  type="button"
                  onClick={() => {
                    if (!isActive) setLatestLangTab(tab);
                  }}
                  aria-pressed={isActive}
                  className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                    isActive
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white hover:bg-[#1a1d33]'
                  }`}
                >
                  {tab}
                </button>
              );
            })}
          </div>
        )}
      </div>

      <div className="w-full min-w-0">
        <Share key={`${section}-${latestLangTab}-${page}`} embedded />
      </div>

      <div className="flex items-center justify-between text-xs">
        <span className="font-mono text-slate-400">
          {isGlobalLatest
            ? `${items.length} titles on page ${page}`
            : `${allItems.length} total · ${items.length} on this page`}
        </span>

        <div className="flex items-center gap-2 font-mono">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={!canPrev}
            className="p-1.5 rounded-lg bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] disabled:opacity-40 text-slate-300 cursor-pointer flex items-center gap-1"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Prev</span>
          </button>
          <span className="px-2 text-slate-300">
            {isGlobalLatest ? `Page ${page}` : `Page ${page} of ${totalPages}`}
          </span>
          <button
            onClick={() =>
              isGlobalLatest
                ? setPage((p) => p + 1)
                : setPage((p) => Math.min(totalPages, p + 1))
            }
            disabled={!canNext}
            className="p-1.5 rounded-lg bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] disabled:opacity-40 text-slate-300 cursor-pointer flex items-center gap-1"
          >
            <span className="hidden sm:inline">Next</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {isLoading && (
        <div className="py-20 text-center space-y-2">
          <Loader2 className="w-6 h-6 text-indigo-400 animate-spin mx-auto" />
          <p className="text-xs font-mono text-indigo-300">
            Loading {meta.badge.toLowerCase()}...
          </p>
        </div>
      )}

      {errorMessage && !isLoading && (
        <div className="p-4 rounded-xl bg-rose-950/20 border border-rose-900/40 text-center text-xs text-rose-300">
          {errorMessage}
        </div>
      )}

      {!isLoading && !errorMessage && items.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5 sm:gap-4.5">
          {items.map((item) => (
            <AnimeCard
              key={item.id}
              anime={item}
              onSelect={onSelectAnime}
              onPlay={onPlayAnime}
              isBookmarked={watchlistIdSet.has(item.id)}
              onToggleWatchlist={onToggleWatchlist}
            />
          ))}
        </div>
      )}

      {!isLoading && !errorMessage && items.length === 0 && (
        <div className="text-center py-16 text-slate-400 space-y-2">
          <p className="text-sm text-slate-300">No titles found for this page.</p>
          <p className="text-xs text-slate-500">Try going back to page 1 or switching tabs.</p>
        </div>
      )}

      {!isLoading && !errorMessage && (isGlobalLatest ? canPrev || canNext : totalPages > 1) && (
        <div className="pt-6 border-t border-[#1c1f36] flex items-center justify-center gap-3 text-xs font-mono">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={!canPrev}
            className="px-3 py-1.5 rounded-lg bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] disabled:opacity-40 text-slate-300 cursor-pointer"
          >
            Previous Page
          </button>
          <span className="text-indigo-400 font-medium">
            {isGlobalLatest ? `Page ${page}` : `Page ${page} of ${totalPages}`}
          </span>
          <button
            onClick={() =>
              isGlobalLatest
                ? setPage((p) => p + 1)
                : setPage((p) => Math.min(totalPages, p + 1))
            }
            disabled={!canNext}
            className="px-3 py-1.5 rounded-lg bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] disabled:opacity-40 text-slate-300 cursor-pointer"
          >
            Next Page
          </button>
        </div>
      )}
    </div>
  );
};