import React, { useState, useEffect, useCallback } from 'react';
import {
  Play,
  Bookmark,
  Check,
  ArrowLeft,
  Calendar,
  Clock,
  Layers,
  Tv,
  Film,
  Sparkles,
  Volume2,
  Tag,
  AlertCircle,
  Loader2,
} from 'lucide-react';
import { AnimeInfoData, UnifiedAnime } from '../types.ts';
import { fetchAnimeInfo } from '../api.ts';
import { updateMetadataForRoute } from '../metadata.ts';
import { AnimeCard } from '../components/AnimeCard.tsx';
import { Share } from '../components/Share.tsx';

interface InfoPageProps {
  id: string;
  subjectId?: string;
  onPlayAnime: (anime: UnifiedAnime) => void;
  onNavigate: (path: string) => void;
  watchlist: UnifiedAnime[];
  onToggleWatchlist: (anime: UnifiedAnime) => void;
  onBackToHome: () => void;
  onInfoPageLoadingChange?: (loading: boolean) => void;
}

const extractMovieboxSubjectId = (data: any): string | undefined => {
  if (!data || typeof data !== 'object') return undefined;

  let found: string | undefined;

  const scan = (value: any): void => {
    if (found || !value || typeof value !== 'object') return;

    if (Array.isArray(value)) {
      value.forEach(scan);
      return;
    }

    // Series: episode ID contains subjectId before &
    if (typeof value.id === 'string') {
      const match = value.id.match(/^(\d+)&/);
      if (match) {
        found = match[1];
        return;
      }
    }

    // Movies: subjectId is inside watchServers URL
    if (typeof value.url === 'string') {
      const match = value.url.match(/[?&]subjectId=(\d+)/);
      if (match) {
        found = match[1];
        return;
      }
    }

    Object.values(value).forEach(scan);
  };

  scan(data);
  return found;
};

export const InfoPage: React.FC<InfoPageProps> = ({
  id,
  subjectId,
  onPlayAnime,
  onNavigate,
  watchlist,
  onToggleWatchlist,
  onBackToHome,
  onInfoPageLoadingChange,
}) => {
  const [anime, setAnime] = useState<AnimeInfoData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [posterFailed, setPosterFailed] = useState<boolean>(false);
  const [backdropFailed, setBackdropFailed] = useState<boolean>(false);

  const loadInfo = useCallback(async (animeId: string) => {
    if (!animeId) return;

    setIsLoading(true);
    setErrorMessage(null);
    setPosterFailed(false);
    setBackdropFailed(false);
    onInfoPageLoadingChange?.(true);

    try {
      const res = await fetchAnimeInfo(
        animeId,
        undefined,
        subjectId
      );

      if (res && res.success && res.anime) {
        setAnime(res.anime);
        updateMetadataForRoute(window.location.pathname, {
          animeTitle: res.anime.title,
          animeType: String(res.anime.type || '').toUpperCase(),
          animeImage: res.anime.backdrop || res.anime.image,
        });
      } else {
        throw new Error('Title details not available or content was not found.');
      }
    } catch (err: any) {
      console.error('Failed to fetch anime info:', err);
      setErrorMessage(
        err?.message || 'Unable to retrieve title details. Please check your network and try again.'
      );
    } finally {
      setIsLoading(false);
      onInfoPageLoadingChange?.(false);
    }
  }, [onInfoPageLoadingChange, subjectId]);

  useEffect(() => {
    loadInfo(id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [id, subjectId, loadInfo]);

  const isBookmarked = anime
    ? (() => {
        const resolvedId =
          (anime as any).id ||
          (anime as any).anime_id ||
          (anime as any).reanime_id ||
          '';
        if (!resolvedId) return false;
        return watchlist.some((item) => item.id === resolvedId);
      })()
    : false;

  const toUnifiedAnime = useCallback((): UnifiedAnime | null => {
    if (!anime) return null;

    const resolvedId =
      (anime as any).id ||
      (anime as any).anime_id ||
      (anime as any).reanime_id ||
      '';

    if (!resolvedId) return null;

    const isMovieType =
      String(anime.type || '').toLowerCase() === 'movie';

    const rawType = String(anime.type || '').trim().toUpperCase();

    return {
      id: resolvedId,
      title: anime.title,
      image: anime.image,
      backdrop: anime.backdrop || anime.image,
      type: isMovieType ? 'movie' : 'series',
      displayType: rawType || (isMovieType ? 'MOVIE' : 'SERIES'),
      overview: anime.overview,
      year: anime.year,
      season: undefined,
      episodes: undefined,
      anilistId: anime.anilist_id,
      tmdbId: anime.tmdb_id,
subjectId:
  anime.subjectId ||
  subjectId ||
  extractMovieboxSubjectId(anime),
      category: isMovieType ? 'movie' : 'series',
    };
}, [anime, subjectId]);

  const isUpcoming = (() => {
    const raw = String((anime as any)?.status || '').trim().toLowerCase();
    if (!raw) return false;
    return (
      raw === 'not yet released' ||
      raw === 'not yet aired' ||
      raw === 'upcoming' ||
      raw === 'unreleased' ||
      raw === 'tba'
    );
  })();

  const handlePlay = () => {
    if (isUpcoming) return;
    const unified = toUnifiedAnime();
    if (unified) {
      onPlayAnime(unified);
    }
  };

  const handleToggleWatchlistClick = () => {
    const unified = toUnifiedAnime();
    if (unified) {
      onToggleWatchlist(unified);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center p-6 text-center">
        <Loader2 className="w-10 h-10 text-indigo-500 animate-spin mb-4" />
        <h2 className="text-lg font-medium text-white mb-1">Loading Title Details...</h2>
        <p className="text-xs text-slate-400">Fetching comprehensive streaming information</p>
      </div>
    );
  }

  if (errorMessage || !anime) {
    return (
      <div className="max-w-xl mx-auto my-20 p-8 rounded-2xl bg-[#111322] border border-[#262944] text-center">
        <AlertCircle className="w-12 h-12 text-rose-400 mx-auto mb-4" />
        <h2 className="text-xl font-semibold text-white mb-2">Failed to Load Content</h2>
        <p className="text-xs sm:text-sm text-slate-400 mb-6 leading-relaxed">
          {errorMessage || 'Requested anime could not be found.'}
        </p>
        <div className="flex items-center justify-center gap-3">
          <button
            onClick={() => loadInfo(id)}
            className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs sm:text-sm font-medium transition-colors cursor-pointer"
          >
            Retry Loading
          </button>
          <button
            onClick={onBackToHome}
            className="px-5 py-2 rounded-xl bg-[#181a2e] hover:bg-[#20233d] border border-[#282b45] text-slate-300 text-xs sm:text-sm transition-colors cursor-pointer"
          >
            Back to Home
          </button>
        </div>
      </div>
    );
  }

  const isMovie = String(anime.type || '').toLowerCase() === 'movie';
  
  const hasRealEpisodeData = Boolean(
    anime.seasonsList &&
      Array.isArray(anime.seasonsList) &&
      anime.seasonsList.length > 0
  );

  const episodeTotalDisplay = (() => {
    const n = parseInt(String(anime.episodes || '').replace(/[^\d]/g, ''), 10);
    return Number.isFinite(n) && n > 0 ? String(n) : 'N/A';
  })();


  return (
    <div className="min-h-screen bg-[#0b0c16] text-slate-100 pb-20 selection:bg-indigo-600 selection:text-white">
      <div className="relative w-full -mt-16 pt-16 min-h-[484px] md:min-h-[564px] flex items-end overflow-hidden bg-[#0b0c16]">
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
          {!backdropFailed && (anime.backdrop || anime.image) ? (
            <img
              src={anime.backdrop || anime.image}
              alt={anime.title}
              referrerPolicy="no-referrer"
              onError={() => setBackdropFailed(true)}
              className="w-full h-full object-cover object-center transform scale-105 brightness-75 contrast-105 blur-[1px]"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-[#14162e] via-[#0c0d18] to-[#080912]" />
          )}
        </div>

        <div className="absolute inset-0 z-[1] bg-gradient-to-t from-[#0b0c16] via-[#0b0c16]/85 to-transparent pointer-events-none" />
        <div className="absolute inset-0 z-[1] bg-gradient-to-r from-[#0b0c16] via-[#0b0c16]/75 to-transparent pointer-events-none" />
        <div className="absolute inset-x-0 top-0 h-28 z-[1] bg-gradient-to-b from-[#0c0d17]/80 to-transparent pointer-events-none" />

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pt-24 pb-6">
          <nav aria-label="Breadcrumb" className="mb-4 flex items-center gap-2 text-xs text-slate-400">
            <button
              onClick={onBackToHome}
              className="flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back</span>
            </button>
            <span aria-hidden="true" className="text-slate-600">/</span>
            <button
              onClick={() => onNavigate(isMovie ? '/category/anime?type=movies' : '/category/anime?type=series')}
              className="hover:text-indigo-300 transition-colors cursor-pointer capitalize"
            >
              {isMovie ? 'Movies' : 'Series'}
            </button>
            <span aria-hidden="true" className="text-slate-600">/</span>
            <span className="text-slate-300 truncate max-w-[200px] sm:max-w-md">{anime.title}</span>
          </nav>

          <div className="flex flex-col md:flex-row md:items-end gap-6 md:gap-8">
            <div className="w-40 sm:w-52 md:w-60 shrink-0 aspect-[3/4] rounded-2xl overflow-hidden bg-[#121426] border border-[#2b2f4a] shadow-2xl shadow-black/80 relative">
              {!posterFailed && anime.image ? (
                <img
                  src={anime.image}
                  alt={anime.title}
                  referrerPolicy="no-referrer"
                  onError={() => setPosterFailed(true)}
                  className="w-full h-full object-cover object-center"
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center p-4 text-center bg-gradient-to-br from-[#181a33] to-[#0c0d18]">
                  {isMovie ? <Film className="w-10 h-10 text-indigo-400 mb-2" /> : <Tv className="w-10 h-10 text-indigo-400 mb-2" />}
                  <span className="text-xs text-indigo-200">{anime.title}</span>
                </div>
              )}
              <div className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded-md bg-[#0b0c16]/80 backdrop-blur-md border border-[#2b2f48] text-[10px] font-mono uppercase tracking-wider text-indigo-300">
                {String(anime.type || (isMovie ? 'MOVIE' : 'SERIES')).toUpperCase()}
              </div>
            </div>

            <div className="flex-1 space-y-4">
              <div className="flex flex-wrap items-center gap-2 text-xs font-normal text-indigo-300">
                <span className="px-2 py-0.5 rounded-md bg-indigo-950/80 border border-indigo-700/50 text-indigo-200 font-medium">
                  {String(anime.type || '').toLowerCase() === 'movie'
                    ? 'FEATURE FILM'
                    : String(anime.type || '').toLowerCase() === 'series'
                      ? 'ANIMATED SERIES'
                      : String(anime.type || 'ANIMATED SERIES').toUpperCase()}
                </span>
                {isUpcoming && (
                  <>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span className="px-2 py-0.5 rounded-md bg-amber-950/60 border border-amber-700/50 text-amber-300 font-mono text-[10px] uppercase tracking-wider">
                      {String((anime as any).status || 'Not Yet Released').toUpperCase()}
                    </span>
                  </>
                )}
                {anime.year && (
                  <>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span className="flex items-center gap-1 text-slate-300 font-mono">
                      <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                      {anime.year}
                    </span>
                  </>
                )}
                <span aria-hidden="true" className="text-slate-600">·</span>
                <span className="text-slate-300 font-mono">1080p Ultra HD</span>
                <span aria-hidden="true" className="text-slate-600">·</span>
                <span className="text-indigo-300 font-mono">Multi Audio</span>
              </div>

              <h1 className="text-2xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight leading-tight [text-wrap:balance]">
                {anime.title}
              </h1>

              <div className="pt-2 flex flex-wrap items-center gap-3">
                {isUpcoming ? (
                  <button
                    type="button"
                    disabled
                    aria-disabled="true"
                    title="This title has not been released yet"
                    className="px-6 py-3 rounded-xl bg-[#1a1d33] text-slate-400 text-xs sm:text-sm font-medium flex items-center gap-2 border border-[#2b2f48] cursor-not-allowed opacity-80"
                  >
                    <Clock className="w-4 h-4" />
                    <span>Upcoming</span>
                  </button>
                ) : (
                  <button
                    onClick={handlePlay}
                    className="px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white text-xs sm:text-sm font-medium transition-all duration-200 flex items-center gap-2 shadow-lg shadow-indigo-600/30 hover:scale-[1.02] cursor-pointer"
                  >
                    <Play className="w-4 h-4 fill-white" />
                    <span>Watch Now</span>
                  </button>
                )}

                <button
                  onClick={handleToggleWatchlistClick}
                  className={`px-4 py-3 rounded-xl border text-xs sm:text-sm font-medium transition-all duration-200 flex items-center gap-2 cursor-pointer ${
                    isBookmarked
                      ? 'bg-emerald-950/40 text-emerald-300 border-emerald-700/60 shadow-sm'
                      : 'bg-[#151726]/80 hover:bg-[#1d2035] text-slate-200 border-[#2b2f48]'
                  }`}
                >
                  {isBookmarked ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-400" />
                      <span>In Watchlist</span>
                    </>
                  ) : (
                    <>
                      <Bookmark className="w-4 h-4 text-indigo-400" />
                      <span>Add to Watchlist</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-3 space-y-10">
        <section aria-labelledby="overview-heading" className="space-y-3">
          <h2 id="overview-heading" className="text-lg font-semibold text-white tracking-tight flex items-center gap-2">
            <span>Story Overview</span>
          </h2>
          <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-normal max-w-4xl [text-wrap:pretty]">
            {anime.overview || 'No description provided for this title.'}
          </p>

          <div className="max-w-4xl">
            <Share
              key={(anime as any).id || (anime as any).anime_id || id}
              embedded
            />
          </div>
        </section>

        {!isMovie && hasRealEpisodeData && (
          <section aria-labelledby="series-metrics-heading" className="space-y-3">
            <h2 id="series-metrics-heading" className="text-sm font-mono uppercase tracking-wider text-indigo-400">
              Series Metrics
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-2xl">
              <div className="p-4 rounded-xl bg-[#121424] border border-[#22253d] flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-lg bg-indigo-950/80 border border-indigo-700/40 flex items-center justify-center shrink-0">
                  <Layers className="w-5 h-5 text-indigo-400" />
                </div>
                <div>
                  <div className="text-[11px] font-mono text-slate-400">Total Seasons</div>
                  <div className="text-lg font-semibold text-white tabular-nums">
                    {anime.seasons || '1'}
                  </div>
                </div>
              </div>

<div className="p-4 rounded-xl bg-[#121424] border border-[#22253d] flex items-center gap-3.5">
  <div className="w-10 h-10 rounded-lg bg-indigo-950/80 border border-indigo-700/40 flex items-center justify-center shrink-0">
    <Tv className="w-5 h-5 text-indigo-400" />
  </div>
  <div>
    <div className="text-[11px] font-mono text-slate-400">Total Episodes</div>
    <div className="text-lg font-semibold text-white tabular-nums">
      {episodeTotalDisplay}
    </div>
  </div>
</div>

              <div className="p-4 rounded-xl bg-[#121424] border border-[#22253d] flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-lg bg-indigo-950/80 border border-indigo-700/40 flex items-center justify-center shrink-0">
                  <Clock className="w-5 h-5 text-indigo-400" />
                </div>
                <div>
                  <div className="text-[11px] font-mono text-slate-400">Episode Duration</div>
                  <div className="text-lg font-semibold text-white tabular-nums">
                    {anime.episodeDuration || '24 min'}
                  </div>
                </div>
              </div>
            </div>
          </section>
        )}

        {!isMovie && !hasRealEpisodeData && (
          <section aria-labelledby="series-catalog-heading" className="space-y-3">
            <h2 id="series-catalog-heading" className="text-sm font-mono uppercase tracking-wider text-indigo-400">
              Series Details
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 max-w-3xl">
              {anime.episodeDuration && (
                <div className="p-4 rounded-xl bg-[#121424] border border-[#22253d] flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-lg bg-indigo-950/80 border border-indigo-700/40 flex items-center justify-center shrink-0">
                    <Clock className="w-5 h-5 text-indigo-400" />
                  </div>
                  <div>
                    <div className="text-[11px] font-mono text-slate-400">Episode Duration</div>
                    <div className="text-lg font-semibold text-white tabular-nums">
                      {anime.episodeDuration}
                    </div>
                  </div>
                </div>
              )}

              {anime.year && (
                <div className="p-4 rounded-xl bg-[#121424] border border-[#22253d] flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-lg bg-indigo-950/80 border border-indigo-700/40 flex items-center justify-center shrink-0">
                    <Calendar className="w-5 h-5 text-indigo-400" />
                  </div>
                  <div>
                    <div className="text-[11px] font-mono text-slate-400">Release Year</div>
                    <div className="text-lg font-semibold text-white tabular-nums">
                      {anime.year}
                    </div>
                  </div>
                </div>
              )}

              {anime.season && (
                <div className="p-4 rounded-xl bg-[#121424] border border-[#22253d] flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-lg bg-indigo-950/80 border border-indigo-700/40 flex items-center justify-center shrink-0">
                    <Sparkles className="w-5 h-5 text-indigo-400" />
                  </div>
                  <div>
                    <div className="text-[11px] font-mono text-slate-400">Season</div>
                    <div className="text-lg font-semibold text-white tabular-nums">
                      {anime.season}
                    </div>
                  </div>
                </div>
              )}

              {anime.status && (
                <div className="p-4 rounded-xl bg-[#121424] border border-[#22253d] flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-lg bg-indigo-950/80 border border-indigo-700/40 flex items-center justify-center shrink-0">
                    <AlertCircle className="w-5 h-5 text-indigo-400" />
                  </div>
                  <div>
                    <div className="text-[11px] font-mono text-slate-400">Status</div>
                    <div className="text-lg font-semibold text-white tabular-nums">
                      {anime.status}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {anime.studios && anime.studios.length > 0 && (
              <div className="space-y-2 pt-2">
                <div className="text-xs font-mono uppercase tracking-wider text-slate-400">
                  Studios
                </div>
                <div className="flex flex-wrap gap-2">
                  {anime.studios.map((studio) => (
                    <span
                      key={studio}
                      className="px-3 py-1 rounded-lg bg-[#14172a] border border-[#242844] text-xs text-slate-200"
                    >
                      {studio}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {anime.external_links && Object.keys(anime.external_links).length > 0 && (
              <div className="space-y-2 pt-2">
                <div className="text-xs font-mono uppercase tracking-wider text-slate-400">
                  External Links
                </div>
                <div className="flex flex-wrap gap-2">
                  {anime.external_links.anilist && (
                    <a
                      href={anime.external_links.anilist}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-1 rounded-lg bg-[#14172a] hover:bg-indigo-950/70 border border-[#242844] hover:border-indigo-500/50 text-xs text-indigo-200 transition-colors"
                    >
                      AniList
                    </a>
                  )}
                  {anime.external_links.myanimelist && (
                    <a
                      href={anime.external_links.myanimelist}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-1 rounded-lg bg-[#14172a] hover:bg-indigo-950/70 border border-[#242844] hover:border-indigo-500/50 text-xs text-indigo-200 transition-colors"
                    >
                      MyAnimeList
                    </a>
                  )}
                </div>
              </div>
            )}

            {anime.related_seasons_and_series && anime.related_seasons_and_series.length > 0 && (() => {
              const currentIds = new Set(
                [anime.id, anime.anime_id, anime.reanime_id]
                  .filter(Boolean)
                  .map((v) => String(v).toLowerCase())
              );

              const visibleRelated = anime.related_seasons_and_series.filter((rel) => {
                const relUrl = String(rel.url || '').toLowerCase();
                if (!relUrl) return true;
                for (const cid of currentIds) {
                  if (relUrl.includes(cid)) return false;
                }
                return true;
              });

              if (visibleRelated.length === 0) return null;

              return (
                <div className="space-y-2 pt-2">
                  <div className="text-xs font-mono uppercase tracking-wider text-slate-400">
                    Related Seasons & Series
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {visibleRelated.map((rel) => (
                      <button
                        key={`${rel.title}-${rel.url || rel.label || ''}`}
                        onClick={() => {
                          if (!rel.url) return;
                          const slug = rel.url
                            .replace(/^\/anime\//, '')
                            .replace(/\/$/, '');
                          if (slug) onNavigate(`/info/${slug}`);
                        }}
                        className="flex items-center gap-3 p-2.5 rounded-xl bg-[#131527] hover:bg-[#181a32] border border-[#23263d] hover:border-indigo-500/50 transition-all cursor-pointer text-left"
                      >
                        {rel.image_url && (
                          <div className="w-12 h-16 rounded-lg overflow-hidden bg-[#0d0e1c] shrink-0">
                            <img
                              src={rel.image_url}
                              alt={rel.title}
                              loading="lazy"
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                            />
                          </div>
                        )}
                        <div className="flex-1 min-w-0">
                          <div className="text-[10px] font-mono text-indigo-400 uppercase tracking-wide mb-0.5">
                            {rel.label || rel.media_type || 'Related'}
                            {rel.year ? ` · ${rel.year}` : ''}
                          </div>
                          <div className="text-xs text-white truncate">{rel.title}</div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              );
            })()}
          </section>
        )}

        {isMovie && (
          <section aria-labelledby="movie-metrics-heading" className="space-y-3">
            <h2 id="movie-metrics-heading" className="text-sm font-mono uppercase tracking-wider text-indigo-400">
              Movie Specifications
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-xl">
              <div className="p-4 rounded-xl bg-[#121424] border border-[#22253d] flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-lg bg-indigo-950/80 border border-indigo-700/40 flex items-center justify-center shrink-0">
                  <Clock className="w-5 h-5 text-indigo-400" />
                </div>
                <div>
                  <div className="text-[11px] font-mono text-slate-400">Feature Duration</div>
                  <div className="text-lg font-semibold text-white tabular-nums">
                    {anime.duration || 'Feature Film'}
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-[#121424] border border-[#22253d] flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-lg bg-indigo-950/80 border border-indigo-700/40 flex items-center justify-center shrink-0">
                  <Calendar className="w-5 h-5 text-indigo-400" />
                </div>
                <div>
                  <div className="text-[11px] font-mono text-slate-400">Release Year</div>
                  <div className="text-lg font-semibold text-white tabular-nums">
                    {anime.year || 'N/A'}
                  </div>
                </div>
              </div>
            </div>
          </section>
        )}

        {anime.genres && anime.genres.length > 0 && (
          <section aria-labelledby="genres-heading" className="space-y-2.5">
            <h2 id="genres-heading" className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Tag className="w-3.5 h-3.5 text-indigo-400" />
              <span>Genres</span>
            </h2>
            <div className="flex flex-wrap gap-2">
              {anime.genres.map((genre) => (
                <span
                  key={genre}
                  className="px-3 py-1 rounded-lg bg-[#14172a] hover:bg-[#1a1e38] border border-[#242844] text-xs text-indigo-200 transition-colors"
                >
                  {genre}
                </span>
              ))}
            </div>
          </section>
        )}

        {anime.languages && anime.languages.length > 0 && (
          <section aria-labelledby="languages-heading" className="space-y-2.5">
            <h2 id="languages-heading" className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Volume2 className="w-3.5 h-3.5 text-indigo-400" />
              <span>Available Audio Dubs</span>
            </h2>
            <div className="flex flex-wrap gap-2">
              {anime.languages.map((lang) => (
                <button
                  key={lang}
                  onClick={() => onNavigate(`/language/${lang.toLowerCase()}`)}
                  className="px-3 py-1 rounded-lg bg-[#14172a] hover:bg-indigo-950/70 border border-[#242844] hover:border-indigo-500/50 text-xs text-slate-200 hover:text-white transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <span>{lang}</span>
                </button>
              ))}
            </div>
          </section>
        )}
        {(() => {
          const recs = anime.recommendations;
          if (!recs || recs.length === 0) return null;

          const currentIds = new Set(
            [anime.id, anime.anime_id, anime.reanime_id, anime.anilist_id != null ? String(anime.anilist_id) : null]
              .filter(Boolean)
              .map((v) => String(v).toLowerCase())
          );

          const visibleRecs = recs.filter((rec) => {
            const rid = String(rec.id || '').toLowerCase();
            if (!rid) return false;
            return !currentIds.has(rid);
          });

          if (visibleRecs.length === 0) return null;

          return (
            <section aria-labelledby="recommendations-heading" className="pt-6 border-t border-[#1b1e33] space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs font-mono text-indigo-400 mb-0.5">Recommended Titles</div>
                  <h2 id="recommendations-heading" className="text-lg sm:text-xl font-semibold text-white tracking-tight flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-300" />
                    <span>More Like This</span>
                  </h2>
                </div>
              </div>

              {(() => {
                const watchlistIdSet = new Set(watchlist.map((w) => w.id));
                return (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5 sm:gap-4.5">
                {visibleRecs.map((rec) => {
                  const isMovieRec = rec.id.startsWith('movie-') || rec.id.startsWith('film-');
                  const unifiedRec: UnifiedAnime = {
                    id: rec.id,
                    title: rec.title,
                    image: rec.image,
                    type: isMovieRec ? 'movie' : 'series',
                    displayType: isMovieRec ? 'MOVIE' : 'SERIES',
                    category: isMovieRec ? 'movie' : 'series',
                  };
                  return (
                    <AnimeCard
                      key={rec.id}
                      anime={unifiedRec}
                      onSelect={(a) => onNavigate(`/info/${a.id}`)}
                      onPlay={onPlayAnime}
                      isBookmarked={watchlistIdSet.has(rec.id)}
                      onToggleWatchlist={onToggleWatchlist}
                    />
                  );
                })}
              </div>
                );
              })()}
            </section>
          );
        })()}
      </div>
    </div>
  );
};