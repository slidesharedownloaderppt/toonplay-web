import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Film, Tv, ChevronLeft, ChevronRight, Loader2, ArrowLeft, Globe } from 'lucide-react';
import { AnimeCard } from '../components/AnimeCard.tsx';
import { LANGUAGES_LIST } from '../components/LanguageGridSection.tsx';
import { PaginatedApiResponse, UnifiedAnime } from '../types.ts';
import { fetchLanguageCatalog } from '../api.ts';
import { updateMetadataForRoute } from '../metadata.ts';
import { Share } from '../components/Share.tsx';

interface LanguagePageProps {
  language: string;
  onSelectLanguage: (lang: string) => void;
  onSelectAnime: (anime: UnifiedAnime) => void;
  onPlayAnime: (
    anime: UnifiedAnime,
    preferredLang?: string,
    seasonOverride?: number,
    episodeOverride?: number
  ) => void;
  watchlist: UnifiedAnime[];
  onToggleWatchlist: (anime: UnifiedAnime) => void;
  onBackToHome: () => void;
  onLanguagePageLoadingChange?: (loading: boolean) => void;
}

const LANGUAGE_TO_WATCH_CODE: Record<string, string> = {
  hindi: 'hin',
  english: 'eng',
  japanese: 'jpn',
  korean: 'kor',
  tamil: 'tam',
  telugu: 'tel',
  malayalam: 'mal',
  kannada: 'kan',
  bengali: 'ben',
};

export const LanguagePage: React.FC<LanguagePageProps> = ({
  language,
  onSelectLanguage,
  onSelectAnime,
  onPlayAnime,
  watchlist,
  onToggleWatchlist,
  onBackToHome,
  onLanguagePageLoadingChange,
}) => {
  const searchParams = new URLSearchParams(window.location.search);
  const paramType = (searchParams.get('type') as 'all' | 'series' | 'movies') || 'all';
  const paramPage = parseInt(searchParams.get('page') || '1', 10) || 1;

  const [subType, setSubType] = useState<'all' | 'series' | 'movies'>(
    ['all', 'series', 'movies'].includes(paramType) ? paramType : 'all'
  );
  const [page, setPage] = useState<number>(paramPage);
  const [items, setItems] = useState<UnifiedAnime[]>([]);
  const [totalPages, setTotalPages] = useState<number>(1);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const skipNextUrlSyncRef = useRef(false);
  const fetchIdRef = useRef(0);

  const currentLangObj =
    LANGUAGES_LIST.find((l) => l.code === language.toLowerCase()) || LANGUAGES_LIST[0];

  const fetchItems = useCallback(async () => {
    const fetchId = ++fetchIdRef.current;

    setIsLoading(true);
    setErrorMessage(null);
    onLanguagePageLoadingChange?.(true);

    const langCode = currentLangObj.code;

    try {
      const isAll = subType === 'all';
      const isFirstHalf = isAll ? page % 2 === 1 : true;

      const { seriesRes, moviesRes } = await fetchLanguageCatalog(langCode, subType, page);

      if (fetchId !== fetchIdRef.current) return;

      const seriesList: UnifiedAnime[] = [];
      const moviesList: UnifiedAnime[] = [];
      let seriesPages = 1;
      let moviesPages = 1;

      if (seriesRes && seriesRes.success && Array.isArray(seriesRes.data)) {
        seriesRes.data.forEach((item) => {
          seriesList.push({
            id: item.id,
            title: item.title,
            image: item.image,
            type: 'series',
            category: 'series',
          });
        });
        if (seriesRes.pagination?.totalPages) {
          seriesPages = seriesRes.pagination.totalPages;
        }
      }

      if (moviesRes && moviesRes.success && Array.isArray(moviesRes.data)) {
        moviesRes.data.forEach((item) => {
          moviesList.push({
            id: item.id,
            title: item.title,
            image: item.image,
            type: 'movie',
            category: 'movie',
          });
        });
        if (moviesRes.pagination?.totalPages) {
          moviesPages = moviesRes.pagination.totalPages;
        }
      }

      if (isAll) {

        const sHalf = isFirstHalf ? seriesList.slice(0, 6) : seriesList.slice(6, 12);
        const mHalf = isFirstHalf ? moviesList.slice(0, 6) : moviesList.slice(6, 12);

        const interleaved: UnifiedAnime[] = [];
        const maxLen = Math.max(sHalf.length, mHalf.length);
        for (let i = 0; i < maxLen; i++) {
          if (i < sHalf.length) interleaved.push(sHalf[i]);
          if (i < mHalf.length) interleaved.push(mHalf[i]);
        }

        const displayed = interleaved.slice(0, 12);
        setItems(displayed);
        setTotalPages(Math.max(seriesPages, moviesPages) * 2);
      } else if (subType === 'series') {
        setItems(seriesList.slice(0, 12));
        setTotalPages(seriesPages);
      } else {
        setItems(moviesList.slice(0, 12));
        setTotalPages(moviesPages);
      }
    } catch (err: any) {
      if (fetchId === fetchIdRef.current) {
        console.error(`Error loading ${langCode} catalog:`, err);
        setErrorMessage(`Unable to load titles in ${currentLangObj.name}. Please retry.`);
      }
    } finally {
      if (fetchId === fetchIdRef.current) {
        setIsLoading(false);
        onLanguagePageLoadingChange?.(false);
      }
    }
  }, [currentLangObj, subType, page, onLanguagePageLoadingChange]);

  useEffect(() => {
    fetchItems();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [fetchItems]);

useEffect(() => {
  if (!isLoading && !errorMessage && page > totalPages) return;
  const params = new URLSearchParams();

  if (subType !== 'all') params.set('type', subType);
  if (page > 1) params.set('page', page.toString());

  const query = params.toString() ? `?${params.toString()}` : '';
  const newUrl = `/language/${currentLangObj.code}${query}`;
  const currentUrl = window.location.pathname + window.location.search;

  if (skipNextUrlSyncRef.current) {
    skipNextUrlSyncRef.current = false;

    if (currentUrl !== newUrl) {
      window.history.replaceState(null, '', newUrl);
    }
  } else if (currentUrl !== newUrl) {
    window.history.pushState(null, '', newUrl);
  }

  updateMetadataForRoute(`/language/${currentLangObj.code}`, {
    lang: currentLangObj.code,
    subType,
    page,
  });
}, [currentLangObj.code, subType, page, isLoading, errorMessage, totalPages]);

useEffect(() => {
  const handlePopState = () => {
    const params = new URLSearchParams(window.location.search);

    const urlType = params.get('type') || 'all';
    const urlPage = Math.max(
      1,
      parseInt(params.get('page') || '1', 10) || 1
    );

    const validType = ['all', 'series', 'movies'].includes(urlType)
      ? (urlType as 'all' | 'series' | 'movies')
      : 'all';

    skipNextUrlSyncRef.current = true;

    setSubType(validType);
    setPage(urlPage);
  };

  window.addEventListener('popstate', handlePopState);

  return () => {
    window.removeEventListener('popstate', handlePopState);
  };
}, []);

useEffect(() => {
  if (isLoading || errorMessage) return;

  if (page > totalPages) {
    skipNextUrlSyncRef.current = true;
    setPage(Math.max(1, totalPages));
  }
}, [isLoading, errorMessage, page, totalPages]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1c1f36]">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToHome}
            className="p-2 rounded-xl bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] text-slate-300 hover:text-white transition-colors cursor-pointer"
            title="Back to Home"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-indigo-400 mb-0.5">
              <Globe className="w-3.5 h-3.5 text-indigo-400" />
              <span>Language Audio Filter</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-semibold text-white tracking-tight">
              {currentLangObj.name} Dubbed & Subbed ({currentLangObj.native})
            </h1>
            <p className="text-xs text-slate-400">
              Browse all animated series and movies available in {currentLangObj.name} audio
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 p-1 bg-[#121424] border border-[#23263d] rounded-xl self-start sm:self-auto text-xs">
          <button
            onClick={() => {
              setSubType('all');
              setPage(1);
            }}
            className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
              subType === 'all'
                ? 'bg-indigo-600 text-white font-medium shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            All
          </button>
          <button
            onClick={() => {
              setSubType('series');
              setPage(1);
            }}
            className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer ${
              subType === 'series'
                ? 'bg-indigo-600 text-white font-medium shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Tv className="w-3.5 h-3.5" />
            <span>Series</span>
          </button>
          <button
            onClick={() => {
              setSubType('movies');
              setPage(1);
            }}
            className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer ${
              subType === 'movies'
                ? 'bg-indigo-600 text-white font-medium shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Film className="w-3.5 h-3.5" />
            <span>Movies</span>
          </button>
        </div>
      </div>
      
<div className="w-full min-w-0">
  <Share key={`${currentLangObj.code}-${subType}-${page}`} embedded />
</div>

      <div className="flex items-center justify-between text-xs">
        <span className="font-mono text-slate-400">
          {items.length} items on this page
        </span>

        <div className="flex items-center gap-2 font-mono">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page <= 1}
            className="p-1.5 rounded-lg bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] disabled:opacity-40 text-slate-300 cursor-pointer flex items-center gap-1"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Prev</span>
          </button>
          <span className="px-2 text-slate-300">
            Page {page} of {totalPages}
          </span>
          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={page >= totalPages}
            className="p-1.5 rounded-lg bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] disabled:opacity-40 text-slate-300 cursor-pointer flex items-center gap-1"
          >
            <span className="hidden sm:inline">Next</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {isLoading && (
        <div className="py-20 text-center space-y-2">
          <Loader2 className="w-6 h-6 text-indigo-400 animate-spin mx-auto" />
          <p className="text-xs font-mono text-indigo-300">
            Loading {currentLangObj.name} streaming library...
          </p>
        </div>
      )}

      {errorMessage && !isLoading && (
        <div className="p-4 rounded-xl bg-rose-950/20 border border-rose-900/40 text-center text-xs text-rose-300">
          {errorMessage}
        </div>
      )}

      {!isLoading && !errorMessage && items.length > 0 && (() => {
        const watchlistIdSet = new Set(watchlist.map((w) => w.id));
        return (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5 sm:gap-4.5">
          {items.map((item) => (
            <AnimeCard
              key={item.id}
              anime={item}
              onSelect={onSelectAnime}
              onPlay={(anime) =>
                onPlayAnime(anime, LANGUAGE_TO_WATCH_CODE[currentLangObj.code] || currentLangObj.code)
              }
              isBookmarked={watchlistIdSet.has(item.id)}
              onToggleWatchlist={onToggleWatchlist}
            />
          ))}
        </div>
        );
      })()}

      {!isLoading && !errorMessage && items.length === 0 && (
        <div className="text-center py-20 text-slate-400 space-y-2">
          <Globe className="w-8 h-8 text-indigo-500/40 mx-auto" />
          <p className="text-sm text-slate-300">No titles found for {currentLangObj.name}</p>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Try switching to Hindi, Telugu, Japanese, or English in the selector above.
          </p>
        </div>
      )}

      {!isLoading && totalPages > 1 && (
        <div className="pt-6 border-t border-[#1c1f36] flex items-center justify-center gap-3 text-xs font-mono">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page <= 1}
            className="px-3 py-1.5 rounded-lg bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] disabled:opacity-40 text-slate-300 cursor-pointer"
          >
            Previous Page
          </button>
          <span className="text-indigo-400 font-medium">
            Page {page} of {totalPages}
          </span>
          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={page >= totalPages}
            className="px-3 py-1.5 rounded-lg bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] disabled:opacity-40 text-slate-300 cursor-pointer"
          >
            Next Page
          </button>
        </div>
      )}
    </div>
  );
};
