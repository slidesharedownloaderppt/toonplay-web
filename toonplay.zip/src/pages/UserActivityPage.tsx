import React, { useEffect, useMemo, useState } from 'react';
import {
  Bookmark,
  Play,
  Check,
  AlertCircle,
} from 'lucide-react';
import { userApi } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { AnimeCard } from '../components/AnimeCard';
import { UnifiedAnime } from '../types';
import { ActivityHeader } from '../components/profile/ActivityHeader';
import { StatTiles } from '../components/profile/StatTiles';
import { ActivityChart } from '../components/profile/ActivityChart';
import { TopGenresCard } from '../components/profile/TopGenresCard';
import { MostWatchedCard } from '../components/profile/MostWatchedCard';
import { formatDate } from '../lib/time';

interface Props {
  username: string;
  onNavigate: (path: string) => void;
  onUserActivityPageLoadingChange?: (loading: boolean) => void;
}

/**
 * /u/:username/activity — activity dashboard.
 *
 * Sections (top → bottom):
 *   1. ActivityHeader (banner + avatar + crest + XP + streak)
 *   2. StatTiles (Watch time / Episodes / Anime / Completed / Active days / Best streak)
 *   3. ActivityChart (30/90/365 tabs, per-day episodes)
 *   4. TopGenresCard + MostWatchedCard (2-col)
 *   5. All-time stats card (reference <dl class="ac-life"> style)
 *
 * No watchlist grid — the profile page /u/:username already has that.
 */
export const UserActivityPage: React.FC<Props> = ({
  username,
  onNavigate,
  onUserActivityPageLoadingChange,
}) => {
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeDays, setActiveDays] = useState(0);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    setProfile(null);
    onUserActivityPageLoadingChange?.(true);

    userApi
      .publicProfile(username)
      .then((res) => {
        if (cancelled) return;
        setProfile(res.profile);
      })
      .catch((err: any) => {
        if (!cancelled) setError(err?.message || 'Failed to load activity');
      })
      .finally(() => {
        if (!cancelled) {
          setLoading(false);
          onUserActivityPageLoadingChange?.(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [username, onUserActivityPageLoadingChange]);

  // Fetch 30-day activity once so StatTiles can show "active days"
  useEffect(() => {
    if (!username) return;
    let cancelled = false;

    userApi
      .activity(username, 30)
      .then((res) => {
        if (cancelled) return;
        const activities = res.activities || [];
        const days = activities.filter(
          (a: any) => Number(a.episodes_watched || 0) > 0
        ).length;
        setActiveDays(days);
      })
      .catch(() => {
        /* silent */
      });

    return () => {
      cancelled = true;
    };
  }, [username]);

  const { user: authUser } = useAuth();

  const user = profile || {};
  const usernameNormalized = (username || '').toLowerCase();
  const isOwner =
    !!authUser &&
    (authUser.username || '').toLowerCase() === usernameNormalized;

  // Owner always sees their own stats. Non-owner only if show_stats !== 0.
  const showStats = isOwner || Number(user.show_stats) !== 0;

  // ──────────────── Loading ────────────────
  if (loading) {
    return null;
  }

  // ──────────────── Error ────────────────
  if (error) {
    return (
      <div className="min-h-screen bg-[#070811] text-white flex items-center justify-center p-6">
        <div className="max-w-md w-full mx-auto p-8 rounded-2xl bg-[#111322] border border-[#262944] text-center">
          <AlertCircle className="w-12 h-12 text-rose-400 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-white mb-2">
            Activity Unavailable
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mb-6 leading-relaxed">
            {error}
          </p>
          <button
            onClick={() => onNavigate(`/u/${username}`)}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs sm:text-sm font-medium transition-colors cursor-pointer"
          >
            Back to Profile
          </button>
        </div>
      </div>
    );
  }

  const totalEpisodes = Number(user.total_episodes_watched || 0);
  const totalAnime = Number(user.total_anime_watched || 0);
  const completedAnime = Number(user.completed_anime || 0);
  const bestStreak = Number(user.best_streak_days || 0);
  const xp = Number(user.xp || 0);
  const joinedDate = formatDate(user.joined_at);

  return (
    <div className="min-h-screen bg-[#070811] text-white">
      {/* 1. HERO HEADER */}
      <ActivityHeader user={user} onNavigate={onNavigate} />

      {/* MAIN CONTENT */}
      <main className="mx-auto max-w-7xl px-4 pb-16 sm:px-6 md:px-8 pt-6">
        {/* Private stats state */}
        {!showStats ? (
          <div className="py-24 sm:py-32">
            <div className="flex flex-col items-center justify-center text-center">
              <div className="relative mb-6 h-20 w-20">
                <div className="absolute inset-0 rotate-6 rounded-md bg-gradient-to-tr from-indigo-500/20 to-indigo-500/5" />
                <div className="absolute inset-0 flex -rotate-3 items-center justify-center rounded-md border border-white/10 bg-[#141414] shadow-lg">
                  <Bookmark className="h-8 w-8 text-indigo-400" />
                </div>
              </div>
              <h3 className="mb-2 text-xl font-black tracking-tight text-white">
                Private Profile
              </h3>
              <p className="max-w-[280px] text-sm leading-relaxed font-medium text-zinc-400">
                This user keeps their activity private.
              </p>
            </div>
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            {/* 2. STAT TILES */}
            <StatTiles
              data={{
                episodesWatched: totalEpisodes,
                totalAnimeWatched: totalAnime,
                completedAnime,
                activeDays,
                activeDaysTotal: 30,
              }}
            />

            {/* 3. ACTIVITY CHART + 4. TOP GENRES (2-col on desktop) */}
            <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_360px] gap-4">
              <ActivityChart initialRange={30} username={username} />
              <TopGenresCard
                genres={user.stats?.topGenres || []}
                totalEpisodes={totalEpisodes}
              />
            </div>

            {/* 5. MOST WATCHED + 6. ALL-TIME STATS (2-col) */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <MostWatchedCard
                items={user.stats?.mostWatched || []}
                onNavigate={onNavigate}
              />

              {/* All-time stats card — matches reference <dl class="ac-life"> */}
              <div className="bg-[#14172b] border border-[#2e3252] rounded-2xl p-5">
                <div className="mb-3">
                  <h3 className="text-sm font-semibold text-white">All time</h3>
                </div>

                <dl className="grid grid-cols-2 gap-x-4 gap-y-3">
                  <div>
                    <dt className="text-[10px] uppercase tracking-wider text-slate-500 font-medium">
                      Member since
                    </dt>
                    <dd className="text-sm font-semibold text-white tabular-nums mt-0.5">
                      {joinedDate || '—'}
                    </dd>
                  </div>

                  <div>
                    <dt className="text-[10px] uppercase tracking-wider text-slate-500 font-medium">
                      Episodes
                    </dt>
                    <dd className="text-sm font-semibold text-white tabular-nums mt-0.5">
                      {totalEpisodes.toLocaleString()}
                    </dd>
                  </div>

                  <div>
                    <dt className="text-[10px] uppercase tracking-wider text-slate-500 font-medium">
                      Shows
                    </dt>
                    <dd className="text-sm font-semibold text-white tabular-nums mt-0.5">
                      {totalAnime}
                    </dd>
                  </div>

                  <div>
                    <dt className="text-[10px] uppercase tracking-wider text-slate-500 font-medium">
                      Completed
                    </dt>
                    <dd className="text-sm font-semibold text-white tabular-nums mt-0.5">
                      {completedAnime}
                    </dd>
                  </div>

                  <div>
                    <dt className="text-[10px] uppercase tracking-wider text-slate-500 font-medium">
                      Best streak
                    </dt>
                    <dd className="text-sm font-semibold text-white tabular-nums mt-0.5">
                      {bestStreak} days
                    </dd>
                  </div>

                  <div>
                    <dt className="text-[10px] uppercase tracking-wider text-slate-500 font-medium">
                      Total XP
                    </dt>
                    <dd className="text-sm font-semibold text-white tabular-nums mt-0.5">
                      {xp.toLocaleString()}
                    </dd>
                  </div>
                </dl>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};