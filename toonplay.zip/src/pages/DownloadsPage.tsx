import React, { useEffect, useRef, useState } from 'react';
import { Download, ArrowLeft, Search, ChevronLeft, ChevronRight } from 'lucide-react';
import { DownloadCard } from '../components/DownloadCard';
import { DownloadSeriesMeta } from '../types';

interface ManifestEntry {
  slug: string;
  meta: DownloadSeriesMeta;
}

interface Props {
  onNavigate: (path: string) => void;
  onBackToHome: () => void;
}

const PAGE_SIZE = 12;

export const DownloadsPage: React.FC<Props> = ({ onNavigate, onBackToHome }) => {
  const [series, setSeries] = useState<ManifestEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState<string>(() => {
    return new URLSearchParams(window.location.search).get('q') || '';
  });
  const [page, setPage] = useState<number>(() => {
    const p = parseInt(new URLSearchParams(window.location.search).get('page') || '1', 10);
    return Number.isFinite(p) && p > 0 ? p : 1;
  });

  const lastQueryRef = useRef(query);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);

    fetch('/downloads/index.json')
      .then((r) => {
        if (!r.ok) throw new Error('Missing /downloads/index.json manifest.');
        return r.json();
      })
      .then((json) => {
        if (cancelled) return;
        const list: ManifestEntry[] = Array.isArray(json.series) ? json.series : [];
        const parseDate = (d?: string): number => {
          if (!d) return 0;
          const dmy = d.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
          if (dmy) {
            const [, dd, mm, yyyy] = dmy;
            return new Date(Number(yyyy), Number(mm) - 1, Number(dd)).getTime();
          }
          const t = new Date(d).getTime();
          return Number.isFinite(t) ? t : 0;
        };
        const sorted = [...list].sort(
          (a, b) => parseDate(b.meta?.lastUploadDate) - parseDate(a.meta?.lastUploadDate)
        );
        setSeries(sorted);
      })
      .catch((err) => {
        if (!cancelled) setError(err?.message || 'Failed to load downloads.');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => { cancelled = true; };
  }, []);

  const filtered = query.trim()
    ? series.filter((s) =>
        s.meta.title.toLowerCase().includes(query.trim().toLowerCase())
      )
    : series;

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const currentPage = loading ? page : Math.min(page, totalPages);
  const paged = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  useEffect(() => {
    if (loading) return;

    const params = new URLSearchParams();
    if (query.trim()) params.set('q', query.trim());
    if (currentPage > 1) params.set('page', String(currentPage));

    const queryString = params.toString() ? `?${params.toString()}` : '';
    const newUrl = `/downloads${queryString}`;
    const currentUrl = window.location.pathname + window.location.search;

    if (currentUrl !== newUrl) {
      const queryChanged = query.trim() !== lastQueryRef.current.trim();

      if (queryChanged) {
        window.history.replaceState(null, '', newUrl);
      } else {
        window.history.pushState(null, '', newUrl);
      }
    }

    lastQueryRef.current = query;
  }, [query, currentPage, loading]);
  
  // Sync search and pagination with browser Back/Forward
useEffect(() => {
  const handlePopState = () => {
    const params = new URLSearchParams(window.location.search);

    const pageParam = Number(params.get('page'));
    const queryParam = params.get('q') || '';

    setPage(
      Number.isInteger(pageParam) && pageParam > 0
        ? pageParam
        : 1
    );

    setQuery(queryParam);
    lastQueryRef.current = queryParam;
  };

  window.addEventListener('popstate', handlePopState);

  return () => {
    window.removeEventListener('popstate', handlePopState);
  };
}, []);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="flex items-center gap-3 pb-4 border-b border-[#1c1f36]">
        <button
          onClick={onBackToHome}
          className="p-2 rounded-xl bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] text-slate-300 hover:text-white transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-indigo-400 mb-0.5">
            <Download className="w-3.5 h-3.5" />
            <span>Downloads</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-semibold text-white tracking-tight">
            Download Center
          </h1>
          <p className="text-xs text-slate-400">
            {loading
              ? 'Loading catalog…'
              : `${filtered.length} titles available · episodes in multiple qualities.`}
          </p>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setPage(1);
          }}
          placeholder="Search download titles…"
          className="w-full bg-[#14172b] border border-[#23263f] rounded-xl pl-10 pr-4 py-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
        />
      </div>

      {/* Pagination (top) */}
      {!loading && !error && filtered.length > 0 && (
        <div className="flex items-center justify-between text-xs">
          <span className="font-mono text-slate-400">
            Showing {paged.length} of {filtered.length} titles
          </span>
          <div className="flex items-center gap-2 font-mono">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={currentPage <= 1}
              className="p-1.5 rounded-lg bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] disabled:opacity-40 text-slate-300 cursor-pointer flex items-center gap-1"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Prev</span>
            </button>
            <span className="px-2 text-slate-300">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage >= totalPages}
              className="p-1.5 rounded-lg bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] disabled:opacity-40 text-slate-300 cursor-pointer flex items-center gap-1"
            >
              <span className="hidden sm:inline">Next</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Inline skeleton grid while loading — matches DownloadCard layout */}
      {loading && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5 sm:gap-4.5">
          {Array.from({ length: 12 }).map((_, i) => (
            <div
              key={i}
              className="relative flex flex-col aspect-[2/3] bg-[#121424] border border-[#22253c] rounded-xl overflow-hidden animate-pulse"
            >
              <div className="absolute inset-0 bg-[#0d0e1b]">
                {/* top-right type chip */}
                <div className="absolute top-2 right-2 w-12 h-4 rounded bg-[#1c2038] border border-[#23263d]" />
                {/* bottom fade */}
                <div className="absolute inset-x-0 bottom-0 h-3/5 bg-gradient-to-t from-[#0a0b16] via-[#0a0b16]/85 to-transparent" />
                {/* meta line */}
                <div className="absolute inset-x-0 bottom-0 p-2.5 sm:p-3 flex flex-col gap-1.5">
                  <div className="w-24 h-2.5 bg-[#1c2038] rounded" />
                  <div className="w-full h-3 bg-[#1c2038] rounded" />
                  <div className="w-2/3 h-3 bg-[#1c2038] rounded" />
                  <div className="pt-1.5 mt-0.5 border-t border-white/10 flex items-center gap-2">
                    <div className="flex-1 h-6 bg-[#181a2e] border border-[#282b45] rounded-md" />
                    <div className="w-7 h-7 bg-[#181a2e] border border-[#282b45] rounded-md" />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {error && !loading && (
        <div className="p-4 rounded-xl bg-rose-950/20 border border-rose-900/40 text-center text-xs text-rose-300">
          {error}
        </div>
      )}

      {!loading && !error && filtered.length === 0 && (
        <div className="py-20 text-center text-slate-400 text-sm">
          {query.trim()
            ? `No download titles matching "${query}".`
            : 'No downloadable titles yet. Add a JSON to public/downloads/ and list it in index.json.'}
        </div>
      )}

      {!loading && !error && filtered.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5 sm:gap-4.5">
          {paged.map((s) => (
            <DownloadCard
              key={s.slug}
              slug={s.slug}
              meta={s.meta}
              onOpen={(slug) => onNavigate(`/downloads/${slug}`)}
            />
          ))}
        </div>
      )}

      {/* Pagination (bottom) */}
      {!loading && !error && totalPages > 1 && (
        <div className="pt-6 border-t border-[#1c1f36] flex items-center justify-center gap-3 text-xs font-mono">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={currentPage <= 1}
            className="px-3 py-1.5 rounded-lg bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] disabled:opacity-40 text-slate-300 cursor-pointer"
          >
            Previous Page
          </button>
          <span className="text-indigo-400 font-medium">
            Page {currentPage} of {totalPages}
          </span>
          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={currentPage >= totalPages}
            className="px-3 py-1.5 rounded-lg bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] disabled:opacity-40 text-slate-300 cursor-pointer"
          >
            Next Page
          </button>
        </div>
      )}
    </div>
  );
};