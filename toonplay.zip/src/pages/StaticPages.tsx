import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  ShieldCheck,
  Mail,
  Info,
  FileText,
  AlertTriangle,
  CheckCircle2,
  Send,
  HelpCircle,
  Server,
  Layers,
  Sparkles,
  Copy,
  Check,
} from 'lucide-react';
import {
  submitContactInquiry,
  submitDmcaNotice,
  ApiResponseResult,
} from '../api.ts';

interface StaticPageProps {
  onBackToHome: () => void;
  onNavigate: (path: string) => void;
}

interface PageSEOProps {
  title: string;
  description: string;
}

const PageSEO: React.FC<PageSEOProps> = ({ title, description }) => {
  useEffect(() => {
    document.title = title;

    const setMeta = (key: string, content: string, property = false) => {
      const attribute = property ? 'property' : 'name';
      let element = document.head.querySelector<HTMLMetaElement>(`meta[${attribute}="${key}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attribute, key);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    const canonicalUrl = `https://toonplay.in${window.location.pathname === '/' ? '/' : window.location.pathname.replace(/\/+$/, '')}`;
    let canonical = document.head.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.rel = 'canonical';
      document.head.appendChild(canonical);
    }
    canonical.href = canonicalUrl;

    setMeta('description', description);
    setMeta('robots', 'index,follow,max-image-preview:large');
    setMeta('og:type', 'website', true);
    setMeta('og:site_name', 'ToonPlay', true);
    setMeta('og:title', title, true);
    setMeta('og:description', description, true);
    setMeta('og:url', canonicalUrl, true);
    setMeta('twitter:card', 'summary');
    setMeta('twitter:title', title);
    setMeta('twitter:description', description);
  }, [title, description]);

  return null;
};

export const AboutPage: React.FC<StaticPageProps> = ({ onBackToHome, onNavigate }) => {
  return (
    <div className="min-h-screen bg-[#0b0c16] text-slate-100 py-10 px-4 sm:px-6 lg:px-8">
      <PageSEO title="About ToonPlay | Anime & Cartoon Streaming Website" description="Get to know ToonPlay, an online destination to stream anime, cartoons, animated movies and series, explore dubbed anime and browse entertainment by category." />
      <div className="max-w-4xl mx-auto space-y-8">

        <button
          onClick={onBackToHome}
          className="flex items-center gap-2 text-xs font-mono text-slate-400 hover:text-white transition-colors cursor-pointer group"
        >
          <ArrowLeft className="w-4 h-4 text-indigo-400 group-hover:-translate-x-1 transition-transform" />
          <span>Back to Home</span>
        </button>

        <div className="border-b border-[#1b1e33] pb-6 space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Info className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-semibold text-white tracking-tight">
                About ToonPlay
              </h1>
              <span className="text-xs font-mono text-indigo-400">
                Anime, Cartoon, Movie & Series Streaming
              </span>
            </div>
          </div>
          <p className="text-sm text-slate-400 leading-relaxed max-w-2xl">
            ToonPlay is an online streaming website for anime fans and animation lovers. Browse anime series, cartoons, animated movies and shows, explore title details, and access available streaming options in one place.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          <div className="bg-[#0e101f] border border-[#1e2238] rounded-2xl p-5 space-y-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/20 flex items-center justify-center text-indigo-400">
              <Sparkles className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-semibold text-white">Watch Anime in Multiple Audio Languages</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Find anime with available Hindi, Telugu, Tamil, Malayalam, Kannada, Bengali, English, Japanese and Korean audio options. Dubbed and subtitled availability varies by title and streaming source.
            </p>
          </div>

          <div className="bg-[#0e101f] border border-[#1e2238] rounded-2xl p-5 space-y-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/20 flex items-center justify-center text-indigo-400">
              <Layers className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-semibold text-white">Anime, Cartoons, Movies & Series</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Browse anime series, ongoing releases, animated movies and cartoons. Search for your favourite titles, explore show information and open the available streaming options on ToonPlay.
            </p>
          </div>

          <div className="bg-[#0e101f] border border-[#1e2238] rounded-2xl p-5 space-y-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/20 flex items-center justify-center text-indigo-400">
              <Server className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-semibold text-white">Online Streaming Experience</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              ToonPlay brings available streams together through its website interface. Some video playback may use embedded players or media supplied by independent third-party providers, which control their own servers and stream availability.
            </p>
          </div>
        </div>

        <div className="bg-[#0e101f] border border-[#1e2238] rounded-2xl p-6 sm:p-8 space-y-4 text-xs sm:text-sm text-slate-300 leading-relaxed">
          <h2 className="text-base font-semibold text-white">Stream Anime, Cartoons and Animated Movies Online</h2>
          <p>
            ToonPlay makes online entertainment easy to explore. Browse anime, cartoons, animated movies and series, visit title pages, and use the available player options to stream content on supported devices.
          </p>
          <p>
            Whether you enjoy action anime, adventure shows, family-friendly cartoons or animated films, ToonPlay helps you find something to watch with searchable titles and available audio-language options.
          </p>
        </div>

        <div className="pt-4 flex flex-wrap gap-4 text-xs">
          <a
            href="/category/anime"
            onClick={(e) => { e.preventDefault(); onNavigate('/category/anime'); }}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl transition-colors cursor-pointer"
          >
            Explore Anime Catalog
          </a>
          <a
            href="/languages"
            onClick={(e) => { e.preventDefault(); onNavigate('/languages'); }}
            className="px-4 py-2 bg-[#14172b] hover:bg-[#1a1c36] border border-[#232742] text-slate-200 rounded-xl transition-colors cursor-pointer"
          >
            Audio Languages Directory
          </a>
          <a
            href="/contact"
            onClick={(e) => { e.preventDefault(); onNavigate('/contact'); }}
            className="px-4 py-2 bg-[#14172b] hover:bg-[#1a1c36] border border-[#232742] text-slate-200 rounded-xl transition-colors cursor-pointer"
          >
            Contact ToonPlay
          </a>
        </div>
      </div>
    </div>
  );
};

export const ContactPage: React.FC<StaticPageProps> = ({ onBackToHome }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    category: 'general',
    message: '',
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [savedResult, setSavedResult] = useState<ApiResponseResult | null>(null);

  const contactEmail = 'dm.toonplay@proton.me';

  const handleCopyEmail = async () => {
    try {
      await navigator.clipboard.writeText(contactEmail);
      setCopiedEmail(true);
      setTimeout(() => setCopiedEmail(false), 2000);
    } catch (err) {
      console.warn('Clipboard copy failed:', err);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const res = await submitContactInquiry(formData);
      setSavedResult(res);
      setIsSubmitted(true);
    } catch (err: any) {
      console.warn('Server contact inquiry storage failed, falling back to local simulation:', err);

      const fallbackDate = new Date();
      const dateStr = fallbackDate.toISOString().slice(0, 10);
      const nameSlug = formData.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 30) || 'user';
      const fallbackFileName = `contact_${dateStr}_${nameSlug}_${fallbackDate.getTime()}.json`;
      const fallbackRecord = {
        id: `cnt_${fallbackDate.getTime()}`,
        fileName: fallbackFileName,
        relativeFolder: 'contacts',
        fullPath: `contacts/${fallbackFileName}`,
        submittedAt: fallbackDate.toISOString(),
        recipientEmail: contactEmail,
        category: formData.category,
        subject: formData.subject,
        sender: { name: formData.name, email: formData.email },
        message: formData.message,
        status: 'recorded',
      };
      setSavedResult({
        success: true,
        fileName: fallbackFileName,
        filePath: `contacts/${fallbackFileName}`,
        record: fallbackRecord,
      });
      setIsSubmitted(true);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0b0c16] text-slate-100 py-10 px-4 sm:px-6 lg:px-8">
      <PageSEO title="Contact ToonPlay | Anime Streaming Support & Help" description="Need help with ToonPlay? Contact our team about anime streaming, video playback, missing episodes, broken player links, audio languages, technical issues or copyright requests." />
      <div className="max-w-3xl mx-auto space-y-8">

        <button
          onClick={onBackToHome}
          className="flex items-center gap-2 text-xs font-mono text-slate-400 hover:text-white transition-colors cursor-pointer group"
        >
          <ArrowLeft className="w-4 h-4 text-indigo-400 group-hover:-translate-x-1 transition-transform" />
          <span>Back to Home</span>
        </button>

        <div className="border-b border-[#1b1e33] pb-6 space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-semibold text-white tracking-tight">
                Contact ToonPlay
              </h1>
              <span className="text-xs font-mono text-indigo-400">
                Streaming Support, Inquiries & Technical Help
              </span>
            </div>
          </div>
          <p className="text-sm text-slate-400 leading-relaxed max-w-xl">
            Need help using ToonPlay? Contact us about anime and cartoon streaming, video playback problems, missing episodes, broken player links, audio-language options, website issues, feedback or copyright concerns. Use the form below or email our support team.
          </p>
        </div>

        <div className="bg-[#0e101f] border border-indigo-500/25 bg-gradient-to-r from-indigo-950/30 via-[#0e101f] to-indigo-950/15 rounded-2xl p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[11px] font-mono uppercase tracking-wider text-indigo-400 font-semibold block">
              Contact Email Address
            </span>
            <div className="flex items-center gap-2 text-white font-mono text-base sm:text-lg font-medium">
              <Mail className="w-4 h-4 text-indigo-400 shrink-0" />
              <span className="select-all">{contactEmail}</span>
            </div>
            <p className="text-xs text-slate-400">
              Contact ToonPlay about streaming playback, episode listings, audio options and general support.
            </p>
          </div>
          <div className="flex items-center gap-2.5 shrink-0">
            <a
              href={`mailto:${contactEmail}?subject=ToonPlay%20Contact%20Inquiry`}
              className="flex items-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl shadow-lg shadow-indigo-600/30 transition-colors cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send Email Directly</span>
            </a>
            <button
              type="button"
              onClick={handleCopyEmail}
              className="flex items-center gap-1.5 px-3 py-2.5 bg-[#14172b] hover:bg-[#1c203b] border border-[#232742] text-xs text-slate-300 rounded-xl transition-colors cursor-pointer"
              title="Copy email to clipboard"
            >
              {copiedEmail ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
              <span>{copiedEmail ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
        </div>

        {isSubmitted ? (
          <div className="bg-[#0e101f] border border-[#20253f] rounded-2xl p-8 space-y-6">
            <div className="text-center space-y-3">
              <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mx-auto">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <h3 className="text-lg font-semibold text-white">Message Sent Successfully</h3>
              <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto leading-relaxed">
                Thank you for contacting ToonPlay. We have received your inquiry and our team will review it shortly. Please allow up to 48 hours for a response.
              </p>
            </div>

            <div className="bg-[#0b0d18] border border-[#1e2238] rounded-xl p-4 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Reference ID</span>
                <span className="font-mono text-indigo-300 select-all">
                  {savedResult?.record?.referenceId
                    || (savedResult?.record?.id ? `INQ-${savedResult.record.id.split('_').pop()?.toUpperCase()}` : null)
                    || `INQ-${Date.now().toString(36).slice(-6).toUpperCase()}`}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Sent to</span>
                <span className="text-slate-200">{contactEmail}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Category</span>
                <span className="text-slate-200 capitalize">{formData.category.replace('-', ' ')}</span>
              </div>
            </div>

            <p className="text-[11px] text-slate-500 text-center">
              For urgent matters, email us directly at <a href={`mailto:${contactEmail}`} className="text-indigo-400 hover:underline">{contactEmail}</a>.
            </p>

            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  setIsSubmitted(false);
                  setSavedResult(null);
                  setFormData({ name: '', email: '', subject: '', category: 'general', message: '' });
                }}
                className="px-4 py-2.5 bg-[#14172b] hover:bg-[#1a1c36] border border-[#232742] text-xs text-slate-200 rounded-xl transition-colors cursor-pointer"
              >
                Send Another Message
              </button>
              <button
                type="button"
                onClick={onBackToHome}
                className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium rounded-xl transition-colors cursor-pointer"
              >
                Back to Home
              </button>
            </div>
          </div>
        ) : (
          <form
            onSubmit={handleSubmit}
            className="bg-[#0e101f] border border-[#1e2238] rounded-2xl p-6 sm:p-8 space-y-5"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-slate-300">Your Full Name</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. Alex Rivera"
                  className="w-full bg-[#111322] border border-[#232742] rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-slate-300">Email Address</label>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="name@example.com"
                  className="w-full bg-[#111322] border border-[#232742] rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-slate-300">Inquiry Category</label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="w-full bg-[#111322] border border-[#232742] rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 transition-colors cursor-pointer"
                >
                  <option value="general">General Inquiry</option>
                  <option value="broken-link">Broken Stream or Episode Link</option>
                  <option value="dub-request">Language Dub Request</option>
                  <option value="technical">Technical Bug Report</option>
                  <option value="dmca">Copyright / DMCA Takedown</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-slate-300">Subject</label>
                <input
                  type="text"
                  required
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  placeholder="Summary of inquiry"
                  className="w-full bg-[#111322] border border-[#232742] rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-300">Detailed Message</label>
              <textarea
                rows={5}
                required
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                placeholder="Provide detailed information regarding your inquiry..."
                className="w-full bg-[#111322] border border-[#232742] rounded-xl p-3.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors resize-none"
              />
            </div>

            <div className="pt-2 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <p className="text-[11px] text-slate-500">
                Your message will be sent directly to our support team at <span className="text-slate-400">{contactEmail}</span>.
              </p>
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex items-center justify-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium rounded-xl shadow-lg shadow-indigo-600/30 transition-colors cursor-pointer disabled:opacity-50 shrink-0"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{isSubmitting ? 'Recording Inquiry...' : 'Send & Save Inquiry'}</span>
              </button>
            </div>
          </form>
        )}

        <div className="bg-[#0e101f] border border-[#1e2238] rounded-2xl p-5 space-y-3">
          <div className="flex items-center gap-2 text-xs font-semibold text-white">
            <HelpCircle className="w-4 h-4 text-indigo-400" />
            <span>Streaming Support FAQs</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-400">
            <div>
              <strong className="text-slate-200 block mb-1">A video player or episode link is not working?</strong>
              Refresh the page and try the player again. If the stream is supplied by an external provider, playback interruptions or server errors may need to be resolved by that provider.
            </div>
            <div>
              <strong className="text-slate-200 block mb-1">Looking for a particular audio language?</strong>
              Visit the Languages directory to explore the audio options available on ToonPlay. Hindi, Tamil, Telugu and other language options depend on the title and streaming source.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export const TermsPage: React.FC<StaticPageProps> = ({ onBackToHome, onNavigate }) => {
  return (
    <div className="min-h-screen bg-[#0b0c16] text-slate-100 py-10 px-4 sm:px-6 lg:px-8">
      <PageSEO title="ToonPlay Terms of Service | Streaming Website Rules" description="Read the terms for using ToonPlay, an anime and cartoon streaming website. Learn about playback, third-party streams, acceptable use, copyright and user responsibilities." />
      <div className="max-w-4xl mx-auto space-y-8">

        <button
          onClick={onBackToHome}
          className="flex items-center gap-2 text-xs font-mono text-slate-400 hover:text-white transition-colors cursor-pointer group"
        >
          <ArrowLeft className="w-4 h-4 text-indigo-400 group-hover:-translate-x-1 transition-transform" />
          <span>Back to Home</span>
        </button>

        <div className="border-b border-[#1b1e33] pb-6 space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-semibold text-white tracking-tight">
                Terms of Service
              </h1>
              <span className="text-xs font-mono text-indigo-400">
                Last Updated: October 30, 2026
              </span>
            </div>
          </div>
          <p className="text-sm text-slate-400 leading-relaxed max-w-2xl">
            These Terms explain the rules for accessing and using ToonPlay, an online website for streaming and discovering anime, cartoons, animated movies and series. By visiting or using ToonPlay, you agree to these terms. Please read them before using the website.
          </p>
        </div>

        <div className="space-y-6 text-xs sm:text-sm text-slate-300 leading-relaxed">
          <section className="bg-[#0e101f] border border-[#1e2238] rounded-2xl p-6 space-y-2">
            <h2 className="text-base font-semibold text-white">1. Nature of Service</h2>
            <p>
              ToonPlay is an online streaming platform where users can browse anime, cartoons, animated movies and series and access available video streams through the website. Depending on the title, playback may be provided through embedded players or links from independent third-party services. ToonPlay does not host, upload, encode or store those third-party video files on its own servers, and external providers control their own content and stream availability.
            </p>
          </section>

          <section className="bg-[#0e101f] border border-[#1e2238] rounded-2xl p-6 space-y-2">
            <h2 className="text-base font-semibold text-white">2. Acceptable Use Policy</h2>
            <p>
              You agree to use ToonPlay lawfully and in accordance with these Terms. You must not attempt to:
            </p>
            <ul className="list-disc list-inside space-y-1 text-slate-400 pl-2">
              <li>Scrape the website or reverse-engineer its APIs using unauthorized bots or automated tools.</li>
              <li>Circumvent or tamper with security or rate-limiting features.</li>
              <li>Impersonate any service representative or falsify headers.</li>
            </ul>
          </section>

          <section className="bg-[#0e101f] border border-[#1e2238] rounded-2xl p-6 space-y-2">
            <h2 className="text-base font-semibold text-white">3. Third-Party Links & Content</h2>
            <p>
              ToonPlay may connect users to streams through embedded players or links provided by third-party websites. We do not control those providers, their content, security practices, privacy policies or uptime. Stream availability, playback quality and access requirements may change without notice. Review the terms and privacy policies of any external service you use.
            </p>
          </section>

          <section className="bg-[#0e101f] border border-[#1e2238] rounded-2xl p-6 space-y-2">
            <h2 className="text-base font-semibold text-white">4. Intellectual Property Rights</h2>
            <p>
              All trademarks, product names, logos, and registered characters displayed in anime artwork belong to their
              respective copyright owners and animation studios (e.g., Toei Animation, Studio Pierrot, MAPPA, etc.).
              Their appearance on ToonPlay is for identification and informational purposes. All rights remain with their respective owners.
            </p>
          </section>

          <section className="bg-[#0e101f] border border-[#1e2238] rounded-2xl p-6 space-y-2">
            <h2 className="text-base font-semibold text-white">5. Disclaimer of Warranties & Limitation of Liability</h2>
            <p>
              ToonPlay is provided on an &quot;AS IS&quot; and &quot;AS AVAILABLE&quot; basis without warranties of any kind. Under no circumstances
              shall ToonPlay or its operators be liable for indirect, incidental, or consequential damages arising from the use or
              inability to use the service.
            </p>
          </section>
        </div>

        <div className="pt-4 flex items-center gap-4 text-xs">
          <button
            onClick={() => onNavigate('/dmca')}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl transition-colors cursor-pointer"
          >
             Review Copyright & DMCA Policy
          </button>
          <button
            onClick={() => onNavigate('/contact')}
            className="px-4 py-2 bg-[#14172b] hover:bg-[#1a1c36] border border-[#232742] text-slate-200 rounded-xl transition-colors cursor-pointer"
          >
             Contact ToonPlay
          </button>
        </div>
      </div>
    </div>
  );
};

export const DmcaPage: React.FC<StaticPageProps> = ({ onBackToHome, onNavigate }) => {
  const [noticeSent, setNoticeSent] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [savedResult, setSavedResult] = useState<ApiResponseResult | null>(null);

  const contactEmail = 'dm.toonplay@proton.me';

  const [noticeData, setNoticeData] = useState({
    ownerName: '',
    email: '',
    copyrightWork: '',
    infringingUrls: '',
    goodFaithStatement: false,
    accuracyStatement: false,
  });

  const handleCopyEmail = async () => {
    try {
      await navigator.clipboard.writeText(contactEmail);
      setCopiedEmail(true);
      setTimeout(() => setCopiedEmail(false), 2000);
    } catch (err) {
      console.warn('Clipboard copy failed:', err);
    }
  };

  const handleTakedownSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const res = await submitDmcaNotice(noticeData);
      setSavedResult(res);
      setNoticeSent(true);
    } catch (err: any) {
      console.warn('Server DMCA notice storage failed, falling back to local simulation:', err);

      const fallbackDate = new Date();
      const dateStr = fallbackDate.toISOString().slice(0, 10);
      const workSlug = noticeData.copyrightWork.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 30) || 'work';
      const ownerSlug = noticeData.ownerName.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 25) || 'agent';
      const fallbackFileName = `dmca_${dateStr}_${workSlug}_${ownerSlug}_${fallbackDate.getTime()}.json`;
      const fallbackRecord = {
        id: `dmca_${fallbackDate.getTime()}`,
        fileName: fallbackFileName,
        relativeFolder: 'dmca',
        fullPath: `dmca/${fallbackFileName}`,
        submittedAt: fallbackDate.toISOString(),
        officialNoticeRecipient: contactEmail,
        takedownDetails: {
          copyrightOwnerOrAgent: noticeData.ownerName,
          officialEmail: noticeData.email,
          copyrightedWorkClaimed: noticeData.copyrightWork,
          infringingUrls: noticeData.infringingUrls,
        },
        legalAffirmations: {
          goodFaithStatement: noticeData.goodFaithStatement,
          accuracyStatementUnderPenaltyOfPerjury: noticeData.accuracyStatement,
        },
        status: 'recorded',
      };
      setSavedResult({
        success: true,
        fileName: fallbackFileName,
        filePath: `dmca/${fallbackFileName}`,
        record: fallbackRecord,
      });
      setNoticeSent(true);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0b0c16] text-slate-100 py-10 px-4 sm:px-6 lg:px-8">
      <PageSEO title="ToonPlay DMCA Policy | Copyright & Stream Removal" description="Read ToonPlay’s copyright and DMCA policy for its anime and cartoon streaming website. Find out how copyright owners can report a listing, stream link or other allegedly infringing material." />
      <div className="max-w-4xl mx-auto space-y-8">

        <button
          onClick={onBackToHome}
          className="flex items-center gap-2 text-xs font-mono text-slate-400 hover:text-white transition-colors cursor-pointer group"
        >
          <ArrowLeft className="w-4 h-4 text-indigo-400 group-hover:-translate-x-1 transition-transform" />
          <span>Back to Home</span>
        </button>

        <div className="border-b border-[#1b1e33] pb-6 space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-semibold text-white tracking-tight">
                DMCA & Copyright Takedown Policy
              </h1>
              <span className="text-xs font-mono text-indigo-400">
                Copyright & Stream Removal Requests
              </span>
            </div>
          </div>
          <p className="text-sm text-slate-400 leading-relaxed max-w-2xl">
            ToonPlay respects the rights of creators, studios and copyright owners. This page explains how to report a title, page, player link or other material on our anime and cartoon streaming website that you believe infringes your copyright, what information to provide, and how to submit a removal request.
          </p>
        </div>

        <div className="bg-[#0e101f] border border-indigo-500/25 bg-gradient-to-r from-indigo-950/30 via-[#0e101f] to-indigo-950/15 rounded-2xl p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[11px] font-mono uppercase tracking-wider text-indigo-400 font-semibold block">
              Contact Email Address
            </span>
            <div className="flex items-center gap-2 text-white font-mono text-base sm:text-lg font-medium">
              <Mail className="w-4 h-4 text-indigo-400 shrink-0" />
              <span className="select-all">{contactEmail}</span>
            </div>
            <p className="text-xs text-slate-400">
              Contact us here for copyright notices, stream or link removal requests, and questions about a submitted report.
            </p>
          </div>
          <div className="flex items-center gap-2.5 shrink-0">
            <a
              href={`mailto:${contactEmail}?subject=DMCA%20Takedown%20Notice%20-%20ToonPlay`}
              className="flex items-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl shadow-lg shadow-indigo-600/30 transition-colors cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send Email Directly</span>
            </a>
            <button
              type="button"
              onClick={handleCopyEmail}
              className="flex items-center gap-1.5 px-3 py-2.5 bg-[#14172b] hover:bg-[#1c203b] border border-[#232742] text-xs text-slate-300 rounded-xl transition-colors cursor-pointer"
              title="Copy email to clipboard"
            >
              {copiedEmail ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
              <span>{copiedEmail ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
        </div>

        <div className="bg-[#141226] border border-indigo-900/50 rounded-2xl p-5 flex items-start gap-4">
          <AlertTriangle className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
          <div className="text-xs sm:text-sm text-slate-300 space-y-1.5 leading-relaxed">
            <h4 className="font-semibold text-white">How Third-Party Streams Work</h4>
            <p className="text-slate-400">
              ToonPlay is a streaming website, but video playback may be delivered through embedded players or links supplied by independent third-party providers. ToonPlay does not host or store those external video files. A valid request submitted here can be reviewed for removal of the relevant ToonPlay page, listing or link. To request removal of the original file, contact the provider or website that hosts it.
            </p>
          </div>
        </div>

        <div className="bg-[#0e101f] border border-[#1e2238] rounded-2xl p-6 sm:p-8 space-y-4 text-xs sm:text-sm text-slate-300 leading-relaxed">
          <h2 className="text-base font-semibold text-white">Information to Include in a Copyright Notice</h2>
          <p>
            To help us identify and review the material, provide a clear written notice with the following information where applicable:
          </p>
          <ol className="list-decimal list-inside space-y-2 text-slate-400 pl-2">
            <li>
              A physical or electronic signature of a person authorized to act on behalf of the owner of an exclusive right that is allegedly infringed.
            </li>
            <li>
              Identification of the copyrighted work claimed to have been infringed, or a representative list of such works.
            </li>
            <li>
              Identification of the specific ToonPlay URL(s) showing the title, page, player or link that you want reviewed.
            </li>
            <li>
              Sufficient contact information, including your full name, mailing address, telephone number, and email address.
            </li>
            <li>
              A statement that you have a good-faith belief that use of the material in the manner complained of is not authorized by the copyright owner, its agent, or the law.
            </li>
            <li>
              A statement that the information in the notification is accurate, and under penalty of perjury, that you are authorized to act on behalf of the owner.
            </li>
          </ol>
        </div>

        <div className="bg-[#0e101f] border border-[#1e2238] rounded-2xl p-6 sm:p-8 space-y-5">
          <h3 className="text-base font-semibold text-white">Submit a Copyright or Stream Removal Request</h3>

          {noticeSent ? (
            <div className="bg-emerald-950/20 border border-emerald-800/40 rounded-xl p-6 space-y-5">
              <div className="text-center space-y-2">
                <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
                <h4 className="text-base font-semibold text-white">DMCA Notice Received</h4>
                <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
                  Your copyright takedown notice has been received. Our compliance team will review the reported URLs and respond within 5 business days. Please retain the reference ID below for your records.
                </p>
              </div>

              <div className="bg-[#090b14] border border-[#1e233d] rounded-xl p-4 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Reference ID</span>
                  <span className="font-mono text-indigo-300 select-all">
                    {savedResult?.record?.referenceId
                      || (savedResult?.record?.id ? `DMCA-${savedResult.record.id.split('_').pop()?.toUpperCase()}` : null)
                      || `DMCA-${Date.now().toString(36).slice(-6).toUpperCase()}`}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Submitted to</span>
                  <span className="text-slate-200">{contactEmail}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Status</span>
                  <span className="text-emerald-400">Under review</span>
                </div>
              </div>

              <p className="text-[11px] text-slate-500 text-center leading-relaxed">
                For legal correspondence or follow-up, email <a href={`mailto:${contactEmail}`} className="text-indigo-400 hover:underline">{contactEmail}</a> and include your reference ID.
              </p>

              <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setNoticeSent(false);
                    setSavedResult(null);
                    setNoticeData({
                      ownerName: '',
                      email: '',
                      copyrightWork: '',
                      infringingUrls: '',
                      goodFaithStatement: false,
                      accuracyStatement: false,
                    });
                  }}
                  className="px-4 py-2.5 bg-[#14172b] hover:bg-[#1a1c36] border border-[#232742] text-xs text-slate-200 rounded-xl transition-colors cursor-pointer"
                >
                  Submit Another Notice
                </button>
                <button
                  type="button"
                  onClick={onBackToHome}
                  className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium rounded-xl transition-colors cursor-pointer"
                >
                  Back to Home
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleTakedownSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-slate-300">Copyright Owner or Authorized Agent</label>
                  <input
                    type="text"
                    required
                    value={noticeData.ownerName}
                    onChange={(e) => setNoticeData({ ...noticeData, ownerName: e.target.value })}
                    placeholder="Full legal name"
                    className="w-full bg-[#111322] border border-[#232742] rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-slate-300">Your Contact Email</label>
                  <input
                    type="email"
                    required
                    value={noticeData.email}
                    onChange={(e) => setNoticeData({ ...noticeData, email: e.target.value })}
                    placeholder="legal@studio.com"
                    className="w-full bg-[#111322] border border-[#232742] rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-slate-300">Copyrighted Work Claimed Infringed</label>
                <input
                  type="text"
                  required
                  value={noticeData.copyrightWork}
                  onChange={(e) => setNoticeData({ ...noticeData, copyrightWork: e.target.value })}
                  placeholder="e.g. Naruto Shippūden Episode 123"
                  className="w-full bg-[#111322] border border-[#232742] rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-slate-300">ToonPlay Page, Player or Stream URLs</label>
                <textarea
                  rows={3}
                  required
                  value={noticeData.infringingUrls}
                  onChange={(e) => setNoticeData({ ...noticeData, infringingUrls: e.target.value })}
                  placeholder="Paste the exact ToonPlay page or player URL(s) you want reviewed"
                  className="w-full bg-[#111322] border border-[#232742] rounded-xl p-3.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors resize-none"
                />
              </div>

              <div className="space-y-2 pt-1 text-xs text-slate-400">
                <label className="flex items-start gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    required
                    checked={noticeData.goodFaithStatement}
                    onChange={(e) => setNoticeData({ ...noticeData, goodFaithStatement: e.target.checked })}
                    className="mt-0.5 rounded border-[#232742] bg-[#111322] text-indigo-600 focus:ring-0"
                  />
                  <span>
                    I have a good faith belief that use of the material is not authorized by the copyright owner, its agent, or the law.
                  </span>
                </label>

                <label className="flex items-start gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    required
                    checked={noticeData.accuracyStatement}
                    onChange={(e) => setNoticeData({ ...noticeData, accuracyStatement: e.target.checked })}
                    className="mt-0.5 rounded border-[#232742] bg-[#111322] text-indigo-600 focus:ring-0"
                  />
                  <span>
                    The information in this notification is accurate, and under penalty of perjury, I am authorized to act on behalf of the copyright owner.
                  </span>
                </label>
              </div>

              <div className="pt-3 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <p className="text-[11px] text-slate-500">
                  Notices are sent to our designated copyright agent at <span className="text-slate-400">{contactEmail}</span> and processed per statutory requirements.
                </p>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex items-center justify-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium rounded-xl shadow-lg shadow-indigo-600/30 transition-colors cursor-pointer disabled:opacity-50 shrink-0"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>{isSubmitting ? 'Submitting Request...' : 'Submit Copyright Request'}</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
