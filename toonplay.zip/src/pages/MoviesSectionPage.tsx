import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { ArrowLeft, ChevronLeft, ChevronRight, Loader2, Film } from 'lucide-react';
import { AnimeCard } from '../components/AnimeCard.tsx';
import { UnifiedAnime } from '../types.ts';
import {
  fetchMovieboxHome,
  getCachedMovieboxHome,
  MovieboxHomeApiResponse,
  OperatingListEntry,
  AoneroomSubject,
} from '../api.ts';
import { updateMetadataForRoute } from '../metadata.ts';
import { Share } from '../components/Share.tsx';

interface MoviesSectionPageProps {
  sectionId: string; // opId or position (as string)
  onSelectAnime: (anime: UnifiedAnime) => void;
  onPlayAnime: (anime: UnifiedAnime) => void;
  watchlist: UnifiedAnime[];
  onToggleWatchlist: (anime: UnifiedAnime) => void;
  onBackToHome: () => void;
  onMoviesSectionPageLoadingChange?: (loading: boolean) => void;
}

const PAGE_SIZE = 12;

function subjectToUnified(s: AoneroomSubject): UnifiedAnime {
  const isMovie = Number(s.subjectType) === 1;
  const isShort = Number(s.subjectType) === 7;
  const resolvedId =
    (typeof s.detailPath === 'string' && s.detailPath.trim()) || s.subjectId;
return {
  id: resolvedId,
  subjectId: s.subjectId,
  title: s.title,
  image: s.cover?.url || '',
    type: isMovie ? 'movie' : 'series',
    displayType: isMovie ? 'MOVIE' : isShort ? 'OVA' : 'SERIES',
    year: s.releaseDate ? s.releaseDate.slice(0, 4) : undefined,
    rating:
      s.imdbRatingValue && s.imdbRatingValue !== '0'
        ? s.imdbRatingValue
        : undefined,
    overview: s.description || undefined,
    category: isMovie ? 'movie' : 'series',
  };
}

export const MoviesSectionPage: React.FC<MoviesSectionPageProps> = ({
  sectionId,
  onSelectAnime,
  onPlayAnime,
  watchlist,
  onToggleWatchlist,
  onBackToHome,
  onMoviesSectionPageLoadingChange,
}) => {
  const initialPage = (() => {
    const params = new URLSearchParams(window.location.search);
    const p = Number(params.get('page'));
    return Number.isInteger(p) && p > 0 ? p : 1;
  })();

  const [page, setPage] = useState<number>(initialPage);
  const [op, setOp] = useState<OperatingListEntry | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const fetchIdRef = useRef(0);
  const skipNextUrlPushRef = useRef(false);

  const fetchSection = useCallback(async () => {
    const fetchId = ++fetchIdRef.current;
    const cached = getCachedMovieboxHome()?.data;
    if (cached) {
      const match = cached.operatingList.find(
        (o) =>
          o.type === 'SUBJECTS_MOVIE' &&
          String(o.opId || o.position) === String(sectionId)
      );
      if (match) {
        setOp(match);
        setIsLoading(false);
        onMoviesSectionPageLoadingChange?.(false);
        return;
      }
    }

    setIsLoading(true);
    setErrorMessage(null);
    onMoviesSectionPageLoadingChange?.(true);

    try {
      const json = await fetchMovieboxHome();
      if (fetchId !== fetchIdRef.current) return;
      let data: MovieboxHomeApiResponse['data'];
      if (json?.code === 0 && json?.data) {
        data = json.data;
      } else {
        throw new Error('Invalid catalog response.');
      }

      const match = data.operatingList.find(
        (o) =>
          o.type === 'SUBJECTS_MOVIE' &&
          String(o.opId || o.position) === String(sectionId)
      );

      if (!match) throw new Error('Section not found.');

      if (fetchId === fetchIdRef.current) {
        setOp(match);
      }
    } catch (err: any) {
      if (fetchId !== fetchIdRef.current) return;
      setErrorMessage(err?.message || 'Unable to load section.');
    } finally {
      if (fetchId === fetchIdRef.current) {
        setIsLoading(false);
        onMoviesSectionPageLoadingChange?.(false);
      }
    }
  }, [sectionId, onMoviesSectionPageLoadingChange]);

  useEffect(() => {
    fetchSection();
  }, [fetchSection]);

  // URL sync — same pattern as HomeSectionPage.
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (page > 1) params.set('page', String(page));
    else params.delete('page');

    const query = params.toString();
    const newUrl = `/movies/section/${encodeURIComponent(sectionId)}${
      query ? `?${query}` : ''
    }`;
    const currentUrl = window.location.pathname + window.location.search;

    if (skipNextUrlPushRef.current) {
      skipNextUrlPushRef.current = false;
      window.history.replaceState(window.history.state, '', newUrl);
    } else if (currentUrl !== newUrl) {
      window.history.pushState(window.history.state, '', newUrl);
    }

    updateMetadataForRoute(`/movies/section/${sectionId}`, {
      page,
      sectionLabel: op?.title,
    });
  }, [sectionId, page, op?.title]);

  // Popstate — re-read page from URL.
  useEffect(() => {
    const onPop = () => {
      const params = new URLSearchParams(window.location.search);
      const p = Number(params.get('page'));
      setPage(Number.isInteger(p) && p > 0 ? p : 1);
    };
    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, []);

  const allItems = useMemo<UnifiedAnime[]>(
    () => (op?.subjects || []).map(subjectToUnified),
    [op]
  );

  const watchlistIdSet = useMemo(
    () => new Set(watchlist.map((w) => w.id)),
    [watchlist]
  );

  const totalPages = Math.max(1, Math.ceil(allItems.length / PAGE_SIZE));
  const items = useMemo(
    () => allItems.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE),
    [allItems, page]
  );

  useEffect(() => {
    if (isLoading || errorMessage) return;
    if (page > totalPages) {
      skipNextUrlPushRef.current = true;
      setPage(totalPages);
    }
  }, [isLoading, errorMessage, totalPages, page]);

  const canPrev = page > 1;
  const canNext = page < totalPages;

  const title = op?.title || 'Movies';
  const subtitle = 'Collection';

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1c1f36]">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToHome}
            className="p-2 rounded-xl bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] text-slate-300 hover:text-white transition-colors cursor-pointer"
            title="Back to Home"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-indigo-400 mb-0.5">
              <Film className="w-3.5 h-3.5 text-indigo-400" />
              <span>Movies</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-semibold text-white tracking-tight">
              {title}
            </h1>
            <p className="text-xs text-slate-400">{subtitle}</p>
          </div>
        </div>
      </div>

      <div className="w-full min-w-0">
        <Share key={`${sectionId}-${page}`} embedded />
      </div>

      <div className="flex items-center justify-between text-xs">
        <span className="font-mono text-slate-400">
          {allItems.length} total · {items.length} on this page
        </span>
        <div className="flex items-center gap-2 font-mono">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={!canPrev}
            className="p-1.5 rounded-lg bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] disabled:opacity-40 text-slate-300 cursor-pointer flex items-center gap-1"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Prev</span>
          </button>
          <span className="px-2 text-slate-300">
            Page {page} of {totalPages}
          </span>
          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={!canNext}
            className="p-1.5 rounded-lg bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] disabled:opacity-40 text-slate-300 cursor-pointer flex items-center gap-1"
          >
            <span className="hidden sm:inline">Next</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {isLoading && (
        <div className="py-20 text-center space-y-2">
          <Loader2 className="w-6 h-6 text-indigo-400 animate-spin mx-auto" />
          <p className="text-xs font-mono text-indigo-300">Loading collection...</p>
        </div>
      )}

      {errorMessage && !isLoading && (
        <div className="p-4 rounded-xl bg-rose-950/20 border border-rose-900/40 text-center text-xs text-rose-300">
          {errorMessage}
        </div>
      )}

      {!isLoading && !errorMessage && items.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5 sm:gap-4.5">
          {items.map((item) => (
            <AnimeCard
              key={item.id}
              anime={item}
              onSelect={onSelectAnime}
              onPlay={onPlayAnime}
              isBookmarked={watchlistIdSet.has(item.id)}
              onToggleWatchlist={onToggleWatchlist}
            />
          ))}
        </div>
      )}

      {!isLoading && !errorMessage && items.length === 0 && (
        <div className="text-center py-16 text-slate-400 space-y-2">
          <p className="text-sm text-slate-300">No titles found for this page.</p>
        </div>
      )}

      {!isLoading && !errorMessage && totalPages > 1 && (
        <div className="pt-6 border-t border-[#1c1f36] flex items-center justify-center gap-3 text-xs font-mono">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={!canPrev}
            className="px-3 py-1.5 rounded-lg bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] disabled:opacity-40 text-slate-300 cursor-pointer"
          >
            Previous Page
          </button>
          <span className="text-indigo-400 font-medium">
            Page {page} of {totalPages}
          </span>
          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={!canNext}
            className="px-3 py-1.5 rounded-lg bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] disabled:opacity-40 text-slate-300 cursor-pointer"
          >
            Next Page
          </button>
        </div>
      )}
    </div>
  );
};

export default MoviesSectionPage;