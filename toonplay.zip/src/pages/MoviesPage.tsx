import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { ArrowLeft } from 'lucide-react';
import { HeroBanner } from '../components/HeroBanner.tsx';
import { AnimeSection } from '../components/AnimeSection.tsx';
import { Share } from '../components/Share.tsx';
import { UnifiedAnime, HeroAnime } from '../types.ts';
import {
  fetchMovieboxHome,
  getCachedMovieboxHome,
  MovieboxHomeApiResponse,
  OperatingListEntry,
  AoneroomSubject,
  OperatingBannerItem,
} from '../api.ts';
import { updateMetadataForRoute } from '../metadata.ts';

interface MoviesPageProps {
  onSelectAnime: (anime: UnifiedAnime) => void;
  onPlayAnime: (anime: UnifiedAnime) => void;
  watchlist: UnifiedAnime[];
  onToggleWatchlist: (anime: UnifiedAnime) => void;
  onBackToHome: () => void;
  onNavigate?: (path: string) => void;
  onMoviesPageLoadingChange?: (loading: boolean) => void;
}

function subjectToUnified(s: AoneroomSubject): UnifiedAnime {
  const isMovie = Number(s.subjectType) === 1;
  const isShort = Number(s.subjectType) === 7;

  const resolvedId =
    (typeof s.detailPath === 'string' && s.detailPath.trim()) ||
    s.subjectId;

return {
  id: resolvedId,
  subjectId: s.subjectId,
  title: s.title,
  image: s.cover?.url || '',
    type: isMovie ? 'movie' : 'series',
    displayType: isMovie ? 'MOVIE' : isShort ? 'OVA' : 'SERIES',
    year: s.releaseDate ? s.releaseDate.slice(0, 4) : undefined,
    rating:
      s.imdbRatingValue && s.imdbRatingValue !== '0'
        ? s.imdbRatingValue
        : undefined,
    overview: s.description || undefined,
    category: isMovie ? 'movie' : 'series',
  };
}

function bannerItemToHero(b: OperatingBannerItem): HeroAnime | null {
  if (!b.subject || b.subjectId === '0' || !b.image?.url) return null;
  const s = b.subject;

  const resolvedId =
    (typeof s.detailPath === 'string' && s.detailPath.trim()) ||
    b.subjectId;

return {
  id: resolvedId,
  subjectId: b.subjectId || s.subjectId,
  title: b.title || s.title || '',
  overview: s.description || '',
    backdrop: b.image.url,
    rating:
      s.imdbRatingValue && s.imdbRatingValue !== '0' ? s.imdbRatingValue : '—',
    year: s.releaseDate ? s.releaseDate.slice(0, 4) : '',
    type: Number(s.subjectType) === 1 ? 'movie' : 'series',
  };
}

// ── Per-row taglines ──────────────────────────────────────
const SUBTITLE_MAP: Record<string, string> = {
  '🔥Trending Now': 'Popular Right Now',
  '🆓Free Now!': 'Watch Free',
  'K-Dramas New Release': 'Fresh From Korea',
  'Top Anime': 'Fan Favourites',
  'Bollywood': 'Hindi Cinema',
  'South Indian': 'Tamil · Telugu · Malayalam',
  'Hollywood': 'International Films',
  'Coming Soon': 'Releases Soon',
  '🔥Cinema': 'In Theatres Now',
  'Indian Drama': 'Made In India',
  'Diwali Special: Full Entertainment🪔': 'Festive Picks',
  '🔥Hot Short TV': 'Short Series',
  'Western TV': 'Global Television',
  'C-Dramas New Release': 'Fresh From China',
  'Russian Drama': 'From Russia',
  'Russian Movie': 'Russian Cinema',
  'Popular Movie': 'Most Watched',
  'Popular TV': 'Top Shows',
  'Popular Anime': 'Anime Picks',
  'Gems for you': 'Handpicked',
  'Romance Film': 'Love Stories',
  'Turkish Drama': 'From Türkiye',
  'Western Series': 'International Series',
  'Military & War': 'War Stories',
  'Action Film': 'Non-Stop Action',
};

function getSubtitle(title: string): string {
  const cleaned = title
    .replace(/[\p{Emoji_Presentation}\p{Extended_Pictographic}]/gu, '')
    .trim();
  return SUBTITLE_MAP[title] || SUBTITLE_MAP[cleaned] || 'Collection';
}

// ── Main page ─────────────────────────────────────────────
export const MoviesPage: React.FC<MoviesPageProps> = ({
  onSelectAnime,
  onPlayAnime,
  watchlist,
  onToggleWatchlist,
  onBackToHome,
  onNavigate,
  onMoviesPageLoadingChange,
}) => {
  const [data, setData] = useState<MovieboxHomeApiResponse['data'] | null>(
    () => getCachedMovieboxHome()?.data ?? null
  );
  const [isLoading, setIsLoading] = useState<boolean>(
    () => !(getCachedMovieboxHome()?.data)
  );
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const fetchIdRef = useRef(0);
  const didScrollRef = useRef(false);

  const [isUnder480, setIsUnder480] = useState(() => {
    return typeof window !== 'undefined' &&
      window.matchMedia('(max-width: 479px)').matches;
  });

  useEffect(() => {
    const mediaQuery = window.matchMedia('(max-width: 479px)');
    const handleScreenChange = () => {
      setIsUnder480(mediaQuery.matches);
    };
    handleScreenChange();
    mediaQuery.addEventListener('change', handleScreenChange);
    return () => {
      mediaQuery.removeEventListener('change', handleScreenChange);
    };
  }, []);

  const load = useCallback(
    async (opts?: { silent?: boolean }) => {
      const id = ++fetchIdRef.current;
      const silent = opts?.silent === true;
      if (!silent) {
        setIsLoading(true);
        setErrorMessage(null);
        onMoviesPageLoadingChange?.(true);
      }
      try {
        const json = await fetchMovieboxHome();
        if (id !== fetchIdRef.current) return;
        if (
          json?.code === 0 &&
          json?.data &&
          Array.isArray(json.data.operatingList)
        ) {
          setData(json.data);
          setErrorMessage(null);
        } else {
          console.error('[MoviesPage] Invalid MovieBox response:', json);
          throw new Error(
            `Invalid catalog response (code: ${json?.code ?? 'unknown'}).`
          );
        }
      } catch (err: any) {
        if (id !== fetchIdRef.current) return;
        if (!getCachedMovieboxHome()?.data) {
          console.error('[MoviesPage] failed:', err);
          setErrorMessage(err?.message || 'Unable to load movies catalog.');
        }
      } finally {
        if (id === fetchIdRef.current) {
          setIsLoading(false);
          onMoviesPageLoadingChange?.(false);
        }
      }
    },
    [onMoviesPageLoadingChange]
  );

  useEffect(() => {
    const cached = getCachedMovieboxHome()?.data;
    if (cached) {
      setData(cached);
      setIsLoading(false);
      onMoviesPageLoadingChange?.(false);
      load({ silent: true });
    } else {
      load();
    }
    if (!didScrollRef.current) {
      didScrollRef.current = true;
      window.scrollTo({ top: 0, behavior: 'auto' });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    updateMetadataForRoute('/movies', {});
  }, []);

  // ── Bucket data ─────────────────────────────────────────
  const buckets = useMemo(() => {
    if (!data) {
      return {
        heroes: [] as HeroAnime[],
        rows: [] as OperatingListEntry[],
        appointments: null as OperatingListEntry | null,
      };
    }
    let heroes: HeroAnime[] = [];
    const rows: OperatingListEntry[] = [];
    let appointments: OperatingListEntry | null = null;

for (const op of data.operatingList) {
  if (op.type === 'BANNER' && op.banner?.items?.length) {
    heroes = op.banner.items
      .map(bannerItemToHero)
      .filter((x): x is HeroAnime => x !== null);
  } else if (op.type === 'SUBJECTS_MOVIE' && op.subjects?.length) {
    if (/\bshort\b/i.test(op.title || '')) continue;
    rows.push(op);
  } else if (op.type === 'APPOINTMENT_LIST' && op.subjects?.length) {
    appointments = op;
  }
}
    rows.sort((a, b) => a.position - b.position);
    return { heroes, rows, appointments };
  }, [data]);

  const PER_ROW = 12;
  const rowItems = useMemo(
    () =>
      buckets.rows.map((op) => ({
        op,
        items: op.subjects.slice(0, PER_ROW).map(subjectToUnified),
      })),
    [buckets.rows]
  );

  const appointmentItems = useMemo<UnifiedAnime[]>(
    () =>
      buckets.appointments
        ? buckets.appointments.subjects.slice(0, PER_ROW).map(subjectToUnified)
        : [],
    [buckets.appointments]
  );

  // ── Render ──────────────────────────────────────────────
  // NOTE: skeleton is handled by App.tsx's `moviesPageLoading` overlay,
  //       same as every other page in this app. We only render content here.
  if (errorMessage && !data) {
    return (
      <div className="min-h-screen bg-[#0b0c16] pt-28">
        <div className="max-w-3xl mx-auto p-4 rounded-xl bg-rose-950/20 border border-rose-900/40 text-center text-xs text-rose-300">
          {errorMessage}
          <button
            onClick={() => load()}
            className="ml-3 px-2 py-1 rounded-md bg-rose-900/40 hover:bg-rose-900/60 cursor-pointer"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0b0c16]">
      {/* HERO */}
      {buckets.heroes.length > 0 ? (
        <div className="-mt-16 sm:-mt-17">
          <HeroBanner
            heroes={buckets.heroes}
            onSelectAnime={onSelectAnime}
            onPlayAnime={onPlayAnime}
            watchlist={watchlist}
            onToggleWatchlist={onToggleWatchlist}
          />
        </div>
      ) : (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24">
          <button
            onClick={onBackToHome}
            className="p-2 rounded-xl bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] text-slate-300 hover:text-white cursor-pointer"
            title="Back to Home"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
        </div>
      )}

      <div className="mx-auto w-full max-w-7xl px-4 pt-4 pb-2 sm:px-6 lg:px-8">
        <Share embedded />
      </div>

      {/* ROWS */}
      {rowItems.map(({ op, items }) => (
        <AnimeSection
          key={`${op.opId || op.title}-${op.position}`}
          id={`movies-${op.opId || op.position}`}
          title={op.title}
          subtitle={getSubtitle(op.title)}
          items={items}
          onSelectAnime={onSelectAnime}
          onPlayAnime={onPlayAnime}
          watchlist={watchlist}
          onToggleWatchlist={onToggleWatchlist}
          defaultView={isUnder480 ? 'carousel' : 'grid'}
          maxItems={PER_ROW}
          seeAllHref={`/movies/section/${encodeURIComponent(
            op.opId || String(op.position)
          )}`}
          onSeeAll={(href) => {
            if (onNavigate) {
              onNavigate(href);
            } else {
              window.history.pushState(null, '', href);
              window.dispatchEvent(new PopStateEvent('popstate'));
              window.scrollTo(0, 0);
            }
          }}
        />
      ))}

      {/* Coming soon */}
      {appointmentItems.length > 0 && (
        <AnimeSection
          id="movies-coming-soon"
          title={buckets.appointments?.title || 'Coming Soon'}
          subtitle={getSubtitle(buckets.appointments?.title || 'Coming Soon')}
          items={appointmentItems}
          onSelectAnime={onSelectAnime}
          onPlayAnime={onPlayAnime}
          watchlist={watchlist}
          onToggleWatchlist={onToggleWatchlist}
          defaultView={isUnder480 ? 'carousel' : 'grid'}
          maxItems={PER_ROW}
        />
      )}

      {buckets.rows.length === 0 && buckets.heroes.length === 0 && (
        <div className="py-20 text-center text-xs text-slate-400 font-mono">
          No content available right now.
        </div>
      )}
    </div>
  );
};

export default MoviesPage;