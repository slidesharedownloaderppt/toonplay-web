import React, { useEffect, useMemo, useState } from 'react';
import {
  Users,
  UserPlus,
  UserCheck,
  Search,
  Check,
  X,
  UserMinus,
  ExternalLink,
  Loader2,
} from 'lucide-react';
import { friendsApi } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { AvatarWithFrame } from '../components/profile/AvatarWithFrame';
import { TierUsername } from '../components/profile/TierUsername';
import { toast } from 'sonner';

interface Props {
  onNavigate: (path: string) => void;
  onFriendsPageLoadingChange?: (loading: boolean) => void;
}

interface FriendRow {
  id: string;
  username: string;
  display_name?: string;
  avatar?: string;
  profile_frame_url?: string | null;
  level?: number;
  xp?: number;
}

interface IncomingRow {
  id: string;
  sender_id: string;
  sender_username: string;
  sender_display_name?: string;
  sender_avatar?: string;
  sender_frame_url?: string | null;
  sender_level?: number;
  sender_xp?: number;
}

interface OutgoingRow {
  id: string;
  receiver_id: string;
  receiver_username: string;
  receiver_display_name?: string;
  receiver_avatar?: string;
  receiver_frame_url?: string | null;
  receiver_level?: number;
  receiver_xp?: number;
}

interface SearchRow {
  id: string;
  username: string;
  displayName?: string;
  avatar?: string;
  profileFrameUrl?: string | null;
  level?: number;
  xp?: number;
}

export const FriendsPage: React.FC<Props> = ({ onNavigate, onFriendsPageLoadingChange }) => {
  const { isAuthenticated, loading: authLoading } = useAuth();

  const [friends, setFriends] = useState<FriendRow[]>([]);
  const [incoming, setIncoming] = useState<IncomingRow[]>([]);
  const [outgoing, setOutgoing] = useState<OutgoingRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchRow[]>([]);
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);

  const [activeTab, setActiveTab] = useState<'all' | 'requests' | 'search'>('all');
  const [actionBusy, setActionBusy] = useState<string | null>(null);
  const [confirmRemoveUsername, setConfirmRemoveUsername] = useState<string | null>(null);

  // Track local friend-state per user id so we can show the right button.
  // Derived from friends + outgoing + incoming lists.
  const friendIds = useMemo(() => new Set(friends.map((f) => String(f.id))), [friends]);
  const outgoingIds = useMemo(
    () => new Set(outgoing.map((r) => String(r.receiver_id))),
    [outgoing]
  );
  const incomingIds = useMemo(
    () => new Set(incoming.map((r) => String(r.sender_id))),
    [incoming]
  );

  const loadAll = async () => {
    if (authLoading) return;
    if (!isAuthenticated) {
      setLoading(false);
      onFriendsPageLoadingChange?.(false);
      return;
    }
    setLoading(true);
    setError(null);
    onFriendsPageLoadingChange?.(true);
    try {
      const res = await friendsApi.list();
      if (res.success) {
        setFriends(
          (res.friends || []).map((f: any) => ({
            id: String(f.id),
            username: f.username,
            display_name: f.display_name || undefined,
            avatar: f.avatar || undefined,
            profile_frame_url: f.profile_frame_url || null,
            level: f.level != null ? Number(f.level) : undefined,
            xp: f.xp != null ? Number(f.xp) : undefined,
          }))
        );
        setIncoming(
          (res.incomingRequests || []).map((r: any) => ({
            id: String(r.id),
            sender_id: String(r.sender_id),
            sender_username: r.sender_username,
            sender_display_name: r.sender_display_name || undefined,
            sender_avatar: r.sender_avatar || undefined,
            sender_frame_url: r.sender_frame_url || null,
            sender_level: r.sender_level != null ? Number(r.sender_level) : undefined,
            sender_xp: r.sender_xp != null ? Number(r.sender_xp) : undefined,
          }))
        );
        setOutgoing(
          (res.outgoingRequests || []).map((r: any) => ({
            id: String(r.id),
            receiver_id: String(r.receiver_id),
            receiver_username: r.receiver_username,
            receiver_display_name: r.receiver_display_name || undefined,
            receiver_avatar: r.receiver_avatar || undefined,
            receiver_frame_url: r.receiver_frame_url || null,
            receiver_level: r.receiver_level != null ? Number(r.receiver_level) : undefined,
            receiver_xp: r.receiver_xp != null ? Number(r.receiver_xp) : undefined,
          }))
        );
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to load friends.');
    } finally {
      setLoading(false);
      onFriendsPageLoadingChange?.(false);
    }
  };

  useEffect(() => {
    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated, authLoading]);

  // Debounced search
  useEffect(() => {
    if (activeTab !== 'search') return;
    const q = searchQuery.trim();
    if (!q) {
      setSearchResults([]);
      setSearchError(null);
      return;
    }
    let cancelled = false;
    setSearching(true);
    setSearchError(null);
    const t = setTimeout(() => {
      friendsApi
        .searchUsers(q)
        .then((res) => {
          if (cancelled) return;
          setSearchResults(
            (res.users || []).map((u: any) => ({
              id: String(u.id),
              username: u.username,
              displayName: u.displayName,
              avatar: u.avatar,
              profileFrameUrl: u.profileFrameUrl || u.profile_frame_url || null,
              level: u.level != null ? Number(u.level) : undefined,
              xp: u.xp != null ? Number(u.xp) : undefined,
            }))
          );
        })
        .catch((err: any) => {
          if (!cancelled) setSearchError(err?.message || 'Search failed.');
        })
        .finally(() => {
          if (!cancelled) setSearching(false);
        });
    }, 250);

    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [searchQuery, activeTab]);

  const handleSendRequest = async (username: string) => {
    setActionBusy(username);
    try {
      await friendsApi.sendRequest(username);
      await loadAll();
      toast.success(`Friend request sent to @${username}`);
    } catch (err: any) {
      toast.error(err?.message || 'Failed to send friend request.');
    } finally {
      setActionBusy(null);
    }
  };

  const handleAccept = async (requestId: string) => {
    setActionBusy(`req:${requestId}`);
    try {
      await friendsApi.respondRequest(requestId, 'accept');
      await loadAll();
      toast.success('Friend request accepted');
    } catch (err: any) {
      toast.error(err?.message || 'Failed to accept request.');
    } finally {
      setActionBusy(null);
    }
  };

  const handleDecline = async (requestId: string) => {
    setActionBusy(`req:${requestId}`);
    try {
      await friendsApi.respondRequest(requestId, 'decline');
      await loadAll();
    } catch (err: any) {
      toast.error(err?.message || 'Failed to decline request.');
    } finally {
      setActionBusy(null);
    }
  };

  const handleCancel = async (requestId: string) => {
    setActionBusy(`req:${requestId}`);
    try {
      await friendsApi.respondRequest(requestId, 'cancel');
      await loadAll();
    } catch (err: any) {
      toast.error(err?.message || 'Failed to cancel request.');
    } finally {
      setActionBusy(null);
    }
  };

  const handleRemove = (username: string) => {
    setConfirmRemoveUsername(username);
  };

  const executeRemoveFriend = async (username: string) => {
    setConfirmRemoveUsername(null);
    setActionBusy(`friend:${username}`);
    try {
      await friendsApi.removeFriend(username);
      await loadAll();
      toast.success(`Removed @${username} from friends`);
    } catch (err: any) {
      toast.error(err?.message || 'Failed to remove friend.');
    } finally {
      setActionBusy(null);
    }
  };

  useEffect(() => {
    if (!confirmRemoveUsername) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setConfirmRemoveUsername(null);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [confirmRemoveUsername]);

  // ---------- Not authenticated ----------
  if (!authLoading && !isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#0b0c16] flex items-center justify-center px-4 py-16">
        <div className="w-full max-w-sm text-center space-y-4">
          <div className="mx-auto w-14 h-14 rounded-2xl bg-[#14172b] border border-[#23263f] flex items-center justify-center">
            <Users className="w-6 h-6 text-indigo-400" />
          </div>
          <h1 className="text-lg font-semibold text-white">Sign in required</h1>
          <p className="text-sm text-slate-400">
            You need an account to manage friends.
          </p>
          <button
            onClick={() => onNavigate('/')}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium transition-colors cursor-pointer"
          >
            Back to home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0b0c16] text-slate-100 pt-24 pb-16 px-4 md:px-8 max-w-6xl mx-auto">
      {/* Header */}
      <div className="pb-6 border-b border-[#23263f]">
        <h1 className="text-2xl sm:text-3xl font-extrabold flex items-center gap-3">
          <Users className="w-7 h-7 text-indigo-400" />
          Friends
        </h1>
        <p className="text-slate-400 text-sm mt-1">
          Manage your friends and pending requests.
        </p>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-[#23263f] mt-6 gap-2">
        <button
          onClick={() => setActiveTab('all')}
          className={`px-4 py-2.5 text-sm font-semibold border-b-2 transition-colors flex items-center gap-2 cursor-pointer ${
            activeTab === 'all'
              ? 'border-indigo-500 text-indigo-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <UserCheck className="w-4 h-4" />
          Friends ({friends.length})
        </button>

        <button
          onClick={() => setActiveTab('requests')}
          className={`px-4 py-2.5 text-sm font-semibold border-b-2 transition-colors flex items-center gap-2 relative cursor-pointer ${
            activeTab === 'requests'
              ? 'border-indigo-500 text-indigo-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <UserPlus className="w-4 h-4" />
          Requests
          {incoming.length > 0 && (
            <span className="px-1.5 py-0.5 bg-rose-500 text-white rounded-full text-[10px] font-bold">
              {incoming.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('search')}
          className={`px-4 py-2.5 text-sm font-semibold border-b-2 transition-colors flex items-center gap-2 cursor-pointer ${
            activeTab === 'search'
              ? 'border-indigo-500 text-indigo-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Search className="w-4 h-4" />
          Find Users
        </button>
      </div>

      {/* Error */}
      {error && (
        <div className="mt-6 p-4 rounded-xl bg-rose-950/30 border border-rose-900/40 text-rose-300 text-sm">
          {error}
        </div>
      )}

      {/* Tab: Friends */}
      {!loading && activeTab === 'all' && (
        <div className="mt-6">
          {friends.length === 0 ? (
            <div className="text-center py-16 bg-[#14172b]/60 rounded-2xl border border-[#23263f]">
              <Users className="w-12 h-12 text-slate-700 mx-auto mb-3" />
              <h3 className="text-base font-semibold text-slate-300">No friends yet</h3>
              <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                Use Find Users or visit a public profile to send a friend request.
              </p>
              <button
                onClick={() => setActiveTab('search')}
                className="mt-4 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl cursor-pointer"
              >
                Search Users
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {friends.map((f) => (
                <div
                  key={f.id}
                  className="bg-[#14172b] border border-[#23263f] p-4 rounded-xl flex items-center justify-between"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <AvatarWithFrame
                      avatarUrl={f.avatar}
                      frameUrl={f.profile_frame_url}
                      username={f.username}
                      alt={f.display_name || f.username}
                      className="w-10 h-10"
                      avatarClassName="border border-[#2e3252]"
                    />
                    <div className="min-w-0">
                      <button
                        onClick={() => onNavigate(`/u/${f.username}`)}
                        className="font-semibold text-sm hover:brightness-125 transition-[filter] bg-transparent border-0 p-0 cursor-pointer text-left truncate block max-w-full"
                      >
                        <TierUsername
                          name={f.display_name || f.username}
                          level={f.level}
                          xp={f.xp}
                          className="inline-block max-w-full truncate"
                        />
                      </button>
                      {f.display_name && f.display_name !== f.username && (
                        <p className="text-[11px] text-slate-500 truncate">@{f.username}</p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => onNavigate(`/u/${f.username}`)}
                      className="p-2 rounded-lg bg-[#1c2038] hover:bg-[#242a45] text-slate-300 cursor-pointer"
                      title="View profile"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleRemove(f.username)}
                      disabled={actionBusy === `friend:${f.username}`}
                      className="p-2 rounded-lg bg-[#1c2038] hover:bg-rose-950/40 hover:text-rose-400 text-slate-400 transition-colors cursor-pointer disabled:opacity-50"
                      title="Remove friend"
                    >
                      {actionBusy === `friend:${f.username}` ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <UserMinus className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab: Requests */}
      {!loading && activeTab === 'requests' && (
        <div className="mt-6 space-y-8">
          <div>
            <h3 className="text-sm font-bold text-slate-300 uppercase tracking-wider mb-3">
              Incoming ({incoming.length})
            </h3>
            {incoming.length === 0 ? (
              <p className="text-xs text-slate-500 italic bg-[#14172b]/60 p-4 rounded-xl border border-[#23263f]">
                No incoming friend requests.
              </p>
            ) : (
              <div className="space-y-2">
                {incoming.map((r) => (
                  <div
                    key={r.id}
                    className="bg-[#14172b] border border-[#23263f] p-3.5 rounded-xl flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <AvatarWithFrame
                        avatarUrl={r.sender_avatar}
                        frameUrl={r.sender_frame_url}
                        username={r.sender_username}
                        alt={r.sender_display_name || r.sender_username}
                        className="w-10 h-10"
                        avatarClassName="border border-[#2e3252]"
                      />
                      <div className="min-w-0">
                        <button
                          onClick={() => onNavigate(`/u/${r.sender_username}`)}
                          className="font-semibold text-sm hover:brightness-125 bg-transparent border-0 p-0 cursor-pointer text-left truncate block max-w-full"
                        >
                          <TierUsername
                            name={r.sender_display_name || r.sender_username}
                            level={r.sender_level}
                            xp={r.sender_xp}
                            className="inline-block max-w-full truncate"
                          />
                        </button>
                        <p className="text-[11px] text-slate-500">Sent you a request</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => handleAccept(r.id)}
                        disabled={actionBusy === `req:${r.id}`}
                        className="flex items-center gap-1 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold cursor-pointer disabled:opacity-50"
                      >
                        {actionBusy === `req:${r.id}` ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <Check className="w-3.5 h-3.5" />
                        )}
                        Accept
                      </button>
                      <button
                        onClick={() => handleDecline(r.id)}
                        disabled={actionBusy === `req:${r.id}`}
                        className="p-1.5 rounded-lg bg-[#1c2038] hover:bg-rose-950/40 hover:text-rose-400 text-slate-400 cursor-pointer disabled:opacity-50"
                        title="Decline"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div>
            <h3 className="text-sm font-bold text-slate-300 uppercase tracking-wider mb-3">
              Sent ({outgoing.length})
            </h3>
            {outgoing.length === 0 ? (
              <p className="text-xs text-slate-500 italic bg-[#14172b]/60 p-4 rounded-xl border border-[#23263f]">
                No outgoing requests.
              </p>
            ) : (
              <div className="space-y-2">
                {outgoing.map((r) => (
                  <div
                    key={r.id}
                    className="bg-[#14172b] border border-[#23263f] p-3.5 rounded-xl flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <AvatarWithFrame
                        avatarUrl={r.receiver_avatar}
                        frameUrl={r.receiver_frame_url}
                        username={r.receiver_username}
                        alt={r.receiver_display_name || r.receiver_username}
                        className="w-10 h-10"
                        avatarClassName="border border-[#2e3252]"
                      />
                      <div className="min-w-0">
                        <button
                          onClick={() => onNavigate(`/u/${r.receiver_username}`)}
                          className="font-semibold text-sm hover:brightness-125 bg-transparent border-0 p-0 cursor-pointer text-left truncate block max-w-full"
                        >
                          <TierUsername
                            name={r.receiver_display_name || r.receiver_username}
                            level={r.receiver_level}
                            xp={r.receiver_xp}
                            className="inline-block max-w-full truncate"
                          />
                        </button>
                        <p className="text-[11px] text-slate-500">Pending approval</p>
                      </div>
                    </div>

                    <button
                      onClick={() => handleCancel(r.id)}
                      disabled={actionBusy === `req:${r.id}`}
                      className="text-xs text-slate-400 hover:text-rose-400 px-3 py-1.5 bg-[#1c2038] rounded-lg hover:bg-[#242a45] cursor-pointer disabled:opacity-50"
                    >
                      Cancel
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab: Search */}
      {!loading && activeTab === 'search' && (
        <div className="mt-6 space-y-4">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search users by username…"
              className="w-full bg-[#14172b] border border-[#23263f] rounded-xl pl-10 pr-10 py-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
            {searching && (
              <Loader2 className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 animate-spin" />
            )}
          </div>

          {searchError && (
            <p className="text-rose-400 text-xs">{searchError}</p>
          )}

          <div className="space-y-2 mt-4">
            {!searching && searchQuery.trim() && searchResults.length === 0 && !searchError && (
              <p className="text-slate-500 text-xs text-center py-6">
                No users found matching "{searchQuery}"
              </p>
            )}

            {searchResults.map((u) => {
              const isFriend = friendIds.has(String(u.id));
              const sent = outgoingIds.has(String(u.id));
              const received = incomingIds.has(String(u.id));
              return (
                <div
                  key={u.id}
                  className="bg-[#14172b] border border-[#23263f] p-4 rounded-xl flex items-center justify-between"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <AvatarWithFrame
                      avatarUrl={u.avatar}
                      frameUrl={u.profileFrameUrl}
                      username={u.username}
                      alt={u.displayName || u.username}
                      className="w-10 h-10"
                      avatarClassName="border border-[#2e3252]"
                    />
                    <div className="min-w-0">
                      <button
                        onClick={() => onNavigate(`/u/${u.username}`)}
                        className="font-semibold text-sm hover:brightness-125 bg-transparent border-0 p-0 cursor-pointer text-left truncate block max-w-full"
                      >
                        <TierUsername
                          name={u.displayName || u.username}
                          level={u.level}
                          xp={u.xp}
                          className="inline-block max-w-full truncate"
                        />
                      </button>
                      <p className="text-[11px] text-slate-500 truncate">@{u.username}</p>
                    </div>
                  </div>

                  <div className="shrink-0">
                    {isFriend && (
                      <span className="flex items-center gap-1 text-xs text-emerald-400 bg-emerald-950/40 px-2.5 py-1 rounded-lg border border-emerald-800/40">
                        <Check className="w-3.5 h-3.5" /> Friends
                      </span>
                    )}
                    {!isFriend && sent && (
                      <button
                        onClick={() => {
                          const row = outgoing.find((o) => String(o.receiver_id) === String(u.id));
                          if (row) handleCancel(row.id);
                        }}
                        disabled={actionBusy?.startsWith('req:')}
                        className="px-3 py-1.5 bg-[#1c2038] text-slate-400 hover:text-rose-400 rounded-lg text-xs cursor-pointer disabled:opacity-50"
                      >
                        Cancel request
                      </button>
                    )}
                    {!isFriend && received && (
                      <button
                        onClick={() => {
                          const row = incoming.find((i) => String(i.sender_id) === String(u.id));
                          if (row) handleAccept(row.id);
                        }}
                        disabled={actionBusy?.startsWith('req:')}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1c2038] hover:bg-[#242a45] text-slate-200 rounded-lg text-xs font-semibold border border-[#23263f] hover:border-[#2e3550] cursor-pointer disabled:opacity-50 transition-colors"
                      >
                        <Check className="w-3.5 h-3.5" />
                        Accept
                      </button>
                    )}
                    {!isFriend && !sent && !received && (
                      <button
                        onClick={() => handleSendRequest(u.username)}
                        disabled={actionBusy === u.username}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1c2038] hover:bg-[#242a45] text-slate-200 rounded-lg text-xs font-semibold border border-[#23263f] hover:border-[#2e3550] cursor-pointer disabled:opacity-50 transition-colors"
                      >
                        {actionBusy === u.username ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <UserPlus className="w-3.5 h-3.5" />
                        )}
                        Add Friend
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
      {confirmRemoveUsername && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-in fade-in duration-150"
          role="dialog"
          aria-modal="true"
          aria-label="Remove friend confirmation"
        >
          <div
            onClick={() => setConfirmRemoveUsername(null)}
            className="absolute inset-0 bg-black/70 backdrop-blur-sm"
          />
          <div className="relative w-full max-w-sm rounded-2xl bg-[#0f1122] border border-[#23263f] p-5 shadow-2xl animate-in fade-in zoom-in-95 duration-150">
            <h3 className="text-base font-bold text-white">Remove friend?</h3>
            <p className="mt-1.5 text-sm text-slate-400">
              Remove <span className="font-semibold text-slate-200">@{confirmRemoveUsername}</span> from your friends list?
            </p>
            <div className="mt-5 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setConfirmRemoveUsername(null)}
                className="px-3.5 py-2 rounded-xl bg-[#1a1d35] hover:bg-[#232645] text-xs font-semibold text-slate-200 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => executeRemoveFriend(confirmRemoveUsername)}
                className="px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-xs font-semibold text-white transition-colors cursor-pointer"
              >
                Remove
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};