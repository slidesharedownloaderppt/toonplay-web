import React, { useState, useMemo } from 'react';
import { Globe, ArrowLeft, ArrowRight, Search, Sparkles, Volume2, Radio } from 'lucide-react';
import { LANGUAGES_LIST } from '../components/LanguageGridSection.tsx';

interface LanguagesDirectoryPageProps {
  onSelectLanguage: (langCode: string) => void;
  onBackToHome: () => void;
  onNavigate: (path: string) => void;
}

const LANGUAGE_METADATA: Record<string, { desc: string; regions: string; audioTrack: string }> = {
  hindi: {
    desc: 'Extensive dubbing catalog featuring major shonen anime, movies, and weekly releases in high-fidelity Hindi audio.',
    regions: 'India, Global Diaspora',
    audioTrack: 'Stereo / 5.1 Surround',
  },
  telugu: {
    desc: 'Popular anime series and action-packed animated films expertly localized with Telugu audio voice acting.',
    regions: 'Andhra Pradesh, Telangana',
    audioTrack: 'Original Dubbed Track',
  },
  tamil: {
    desc: 'Dedicated regional dub tracks for fan-favorite anime, classic series, and modern weekly releases.',
    regions: 'Tamil Nadu, Sri Lanka, Singapore',
    audioTrack: 'Localized Voice Track',
  },
  malayalam: {
    desc: 'Carefully curated anime adaptations and family cartoons featuring Malayalam voice dubbing.',
    regions: 'Kerala, Gulf Region',
    audioTrack: 'Full Audio Track',
  },
  kannada: {
    desc: 'Growing library of animated series, popular shows, and feature movies dubbed in Kannada.',
    regions: 'Karnataka',
    audioTrack: 'Official Regional Dub',
  },
  bengali: {
    desc: 'Comprehensive selection of classic and contemporary anime dubbed in Bengali language.',
    regions: 'West Bengal, Bangladesh',
    audioTrack: 'Standard Audio Track',
  },
  english: {
    desc: 'Global standard dual-audio releases featuring acclaimed Western voice actor casts and studio dubs.',
    regions: 'Worldwide / International',
    audioTrack: 'Uncut English Audio',
  },
  japanese: {
    desc: 'Original Japanese broadcast voice acting (Seiyuu) with synchronized international subtitles.',
    regions: 'Japan / Global Release',
    audioTrack: 'Original Master Audio',
  },
  korean: {
    desc: 'High-energy Korean localized audio tracks and manhwa-adapted anime series releases.',
    regions: 'South Korea / Global',
    audioTrack: 'K-Dub Audio Track',
  },
};

export const LanguagesDirectoryPage: React.FC<LanguagesDirectoryPageProps> = ({
  onSelectLanguage,
  onBackToHome,
  onNavigate,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredLanguages = useMemo(() => {
    if (!searchQuery.trim()) return LANGUAGES_LIST;
    const q = searchQuery.toLowerCase();
    return LANGUAGES_LIST.filter(
      (l) =>
        l.name.toLowerCase().includes(q) ||
        l.native.toLowerCase().includes(q) ||
        l.code.toLowerCase().includes(q)
    );
  }, [searchQuery]);

  return (
    <div className="min-h-screen bg-[#0b0c16] text-slate-100 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">

        <div className="flex items-center justify-between gap-4">
          <button
            onClick={onBackToHome}
            className="flex items-center gap-2 text-xs font-mono text-slate-400 hover:text-white transition-colors cursor-pointer group"
          >
            <ArrowLeft className="w-4 h-4 text-indigo-400 group-hover:-translate-x-1 transition-transform" />
            <span>Back to Catalog</span>
          </button>
        </div>

        <div className="border-b border-[#1b1e33] pb-6 space-y-4">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
                  <Globe className="w-5 h-5" />
                </div>
                <div>
                  <h1 className="text-2xl sm:text-3xl font-semibold text-white tracking-tight">
                    Audio & Dubbed Languages
                  </h1>
                  <span className="text-xs font-mono text-indigo-400">
                    Multilingual International Directory
                  </span>
                </div>
              </div>
              <p className="text-xs sm:text-sm text-slate-400 max-w-2xl leading-relaxed pt-1">
                Explore anime series and animated feature films organized by localized audio dub tracks,
                regional language audio, and original studio voice casts.
              </p>
            </div>

            <div className="relative w-full md:w-72">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search languages by name..."
                className="w-full bg-[#111322] border border-[#232742] rounded-xl pl-9 pr-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
              />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {filteredLanguages.map((lang) => {
            const meta = LANGUAGE_METADATA[lang.code] || {
              desc: 'Localized series and film broadcasts in multiple audio configurations.',
              regions: 'Regional Broadcast',
              audioTrack: 'Original Dub',
            };

            return (
              <div
                key={lang.code}
                onClick={() => {
                  onSelectLanguage(lang.code);
                  onNavigate(`/language/${lang.code}`);
                }}
                className="group relative bg-[#0e101f] hover:bg-[#14172b] border border-[#1e2238] hover:border-indigo-500/50 rounded-2xl p-5 transition-all duration-200 cursor-pointer flex flex-col justify-between space-y-4 shadow-lg hover:shadow-indigo-600/10 hover:-translate-y-0.5"
              >
                <div className="space-y-3">

                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-serif text-slate-200 font-bold group-hover:text-white transition-colors">
                        {lang.native}
                      </span>
                      <span className="text-xs font-mono px-2 py-0.5 rounded-md bg-indigo-950/60 text-indigo-300 border border-indigo-800/40">
                        {lang.code.toUpperCase()}
                      </span>
                    </div>

                    <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-[#191c30] text-slate-300 border border-[#282c47]">
                      {lang.count}
                    </span>
                  </div>

                  <h3 className="text-lg font-semibold text-white tracking-tight group-hover:text-indigo-300 transition-colors">
                    {lang.name} Anime & Films
                  </h3>

                  <p className="text-xs text-slate-400 leading-relaxed line-clamp-3">
                    {meta.desc}
                  </p>
                </div>

                <div className="pt-3 border-t border-[#1b1e33] flex items-center justify-between text-[11px] font-mono text-slate-400">
                  <div className="flex items-center gap-1.5 text-slate-400">
                    <Volume2 className="w-3.5 h-3.5 text-indigo-400" />
                    <span className="truncate max-w-[150px]">{meta.audioTrack}</span>
                  </div>

                  <span className="flex items-center gap-1 text-indigo-400 group-hover:translate-x-1 transition-transform">
                    <span>Explore</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        <div className="bg-[#0e101f] border border-[#1e2238] rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2 text-indigo-400 text-xs font-mono uppercase tracking-wider">
              <Radio className="w-4 h-4 animate-pulse" />
              <span>Multilingual Engine</span>
            </div>
            <h3 className="text-base sm:text-lg font-semibold text-white">
              Continuous Weekly Dub Integration
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Our indexer continuously synchronizes fresh audio tracks as soon as regional dubbing studios release new episodes and movies.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => onNavigate('/category/anime')}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium rounded-xl shadow-lg shadow-indigo-600/20 transition-colors cursor-pointer"
            >
              Browse All Anime
            </button>
            <button
              onClick={() => onNavigate('/category/cartoon')}
              className="px-4 py-2 bg-[#14172b] hover:bg-[#1a1c36] border border-[#232742] text-slate-300 text-xs font-medium rounded-xl transition-colors cursor-pointer"
            >
              Browse Cartoons
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
