import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Download,
  ExternalLink,
  Send,
  Calendar,
  Languages,
  Tv,
  Film,
  ListVideo,
  ChevronDown,
} from 'lucide-react';
import { DownloadSeriesJson } from '../types';

interface Props {
  slug: string;
  onNavigate: (path: string) => void;
  onBackToHome: () => void;
  onDownloadsPageLoadingChange?: (loading: boolean) => void;
}

export const DownloadDetailPage: React.FC<Props> = ({
  slug,
  onNavigate,
  onBackToHome,
  onDownloadsPageLoadingChange,
}) => {
  const [data, setData] = useState<DownloadSeriesJson | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [openEpisodes, setOpenEpisodes] = useState<Set<number>>(new Set());

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    onDownloadsPageLoadingChange?.(true);

    fetch(`/downloads/${slug}.json`)
      .then((r) => {
        if (!r.ok) throw new Error(`Missing /downloads/${slug}.json`);
        return r.json();
      })
      .then((json) => { if (!cancelled) setData(json); })
      .catch((err) => { if (!cancelled) setError(err?.message || 'Failed to load.'); })
      .finally(() => {
        if (!cancelled) {
          setLoading(false);
          onDownloadsPageLoadingChange?.(false);
        }
      });

    return () => { cancelled = true; };
  }, [slug, onDownloadsPageLoadingChange]);

  const toggleEpisode = (ep: number) => {
    setOpenEpisodes((prev) => {
      const next = new Set(prev);
      if (next.has(ep)) next.delete(ep); else next.add(ep);
      return next;
    });
  };

  const expandAll = () => {
    if (!data) return;
    setOpenEpisodes(new Set(data.page.episodes.map((e) => e.episode)));
  };

  const collapseAll = () => setOpenEpisodes(new Set());

  // ---------- Error ----------
  if (error) {
    return (
      <div className="max-w-5xl mx-auto px-4 py-20 text-center">
        <div className="inline-block px-5 py-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-sm">
          {error}
        </div>
        <div className="mt-6">
          <button
            onClick={() => onNavigate('/downloads')}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold cursor-pointer"
          >
            Back to Downloads
          </button>
        </div>
      </div>
    );
  }

  // ---------- Inline skeleton ----------
  if (loading || !data) {
    return (
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Back button */}
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-[#121424] border border-[#23263d] animate-pulse" />
          <div className="w-24 h-3.5 rounded bg-[#1c2038] animate-pulse" />
        </div>

        {/* Hero skeleton */}
        <div className="rounded-2xl border border-[#22253c] bg-[#121424] overflow-hidden animate-pulse">
          <div className="flex flex-col sm:flex-row">
            <div className="mx-auto w-40 sm:mx-0 sm:w-56 md:w-64 shrink-0 aspect-[2/3] sm:aspect-auto sm:min-h-[20rem] bg-[#1c2038] rounded-xl sm:rounded-none mt-4 sm:mt-0" />
            <div className="flex-1 p-5 sm:p-6 space-y-4">
              <div className="w-20 h-5 rounded bg-[#1c2038]" />
              <div className="w-3/4 h-6 rounded bg-[#1c2038]" />
              <div className="space-y-2 pt-1">
                <div className="w-full h-3 rounded bg-[#1c2038]/70" />
                <div className="w-2/3 h-3 rounded bg-[#1c2038]/70" />
              </div>
              <div className="flex flex-wrap gap-2 pt-2">
                <div className="w-24 h-7 rounded-md bg-[#181a2e] border border-[#282b45]" />
                <div className="w-28 h-7 rounded-md bg-[#181a2e] border border-[#282b45]" />
                <div className="w-32 h-7 rounded-md bg-[#181a2e] border border-[#282b45]" />
              </div>
              <div className="flex flex-wrap gap-1.5 pt-1">
                <div className="w-14 h-5 rounded bg-[#181a2e]" />
                <div className="w-16 h-5 rounded bg-[#181a2e]" />
                <div className="w-14 h-5 rounded bg-[#181a2e]" />
                <div className="w-16 h-5 rounded bg-[#181a2e]" />
              </div>
            </div>
          </div>
        </div>

        {/* Telegram skeleton */}
        <div className="flex items-center justify-between gap-3 p-3 rounded-xl bg-[#121424] border border-[#22253c] animate-pulse">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-[#1c2038]" />
            <div className="space-y-1.5">
              <div className="w-32 h-3.5 rounded bg-[#1c2038]" />
              <div className="w-24 h-2.5 rounded bg-[#1c2038]/70" />
            </div>
          </div>
          <div className="w-4 h-4 rounded bg-[#1c2038]" />
        </div>

        {/* Episode list skeleton */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="w-32 h-4 rounded bg-[#1c2038] animate-pulse" />
            <div className="flex gap-2">
              <div className="w-20 h-7 rounded-md bg-[#121424] border border-[#23263d] animate-pulse" />
              <div className="w-20 h-7 rounded-md bg-[#121424] border border-[#23263d] animate-pulse" />
            </div>
          </div>
          {Array.from({ length: 4 }).map((_, i) => (
            <div
              key={i}
              className="rounded-xl border border-[#22253c] bg-[#121424] overflow-hidden animate-pulse"
            >
              <div className="w-full flex items-center justify-between gap-3 p-3.5">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-lg bg-[#181a2e] border border-[#282b45] shrink-0" />
                  <div className="space-y-1.5">
                    <div className="w-28 h-3.5 rounded bg-[#1c2038]" />
                    <div className="w-32 h-2.5 rounded bg-[#1c2038]/70" />
                  </div>
                </div>
                <div className="w-20 h-3 rounded bg-[#1c2038]/70" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  const { page, meta } = data;
  const allOpen = openEpisodes.size === page.episodes.length && page.episodes.length > 0;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Back button */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => onNavigate('/downloads')}
          className="p-2 rounded-xl bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] text-slate-300 hover:text-white transition-colors cursor-pointer"
          aria-label="Back to Downloads"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <span className="text-xs text-slate-400">Back to Downloads</span>
      </div>

      {/* ================= HERO BANNER ================= */}
      <div className="rounded-2xl border border-[#22253c] bg-[#121424] overflow-hidden shadow-lg shadow-black/30">
        <div className="flex flex-col sm:flex-row">
          {/* Poster */}
          <div className="relative mx-auto w-40 sm:mx-0 sm:w-56 md:w-64 shrink-0 aspect-[2/3] sm:aspect-auto sm:min-h-[20rem] bg-[#0d0e1b] overflow-hidden rounded-xl sm:rounded-none mt-4 sm:mt-0">
            {meta.image ? (
              <img
                src={meta.image}
                alt={meta.title}
                referrerPolicy="no-referrer"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).style.display = 'none';
                }}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                {meta.type === 'movie' ? (
                  <Film className="w-16 h-16 text-indigo-400/30" />
                ) : (
                  <Tv className="w-16 h-16 text-indigo-400/30" />
                )}
              </div>
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-[#0a0b16]/60 via-transparent to-transparent sm:bg-gradient-to-r sm:from-transparent sm:to-[#121424]/40 pointer-events-none" />
          </div>

          {/* Meta */}
          <div className="flex-1 p-5 sm:p-6 flex flex-col gap-3 min-w-0">
            {/* Type chip */}
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-indigo-600/15 border border-indigo-500/30 text-[11px] font-semibold text-indigo-300 uppercase tracking-wider">
                {meta.type === 'movie' ? (
                  <><Film className="w-3 h-3" /> Movie</>
                ) : (
                  <><Tv className="w-3 h-3" /> Series</>
                )}
              </span>
            </div>

            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-white tracking-tight leading-tight">
              {meta.title}
            </h1>

            <p className="text-sm text-slate-400 leading-relaxed">
              Download episodes in multiple qualities — 480p, 720p, 1080p, and 4K. All links
              verified and updated regularly.
            </p>

            {/* Stat chips */}
            <div className="flex flex-wrap items-center gap-2 pt-1">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md bg-[#181a2e] border border-[#282b45] text-[11px] text-slate-300">
                <ListVideo className="w-3.5 h-3.5 text-indigo-400" />
                {meta.type === 'movie' ? 'Movie' : `${meta.episodeCount} ${meta.episodeCount === 1 ? 'Episode' : 'Episodes'}`}
              </span>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md bg-[#181a2e] border border-[#282b45] text-[11px] text-slate-300">
                <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                Updated {meta.lastUploadDate}
              </span>
              {meta.languages && meta.languages.length > 0 && (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md bg-[#181a2e] border border-[#282b45] text-[11px] text-slate-300">
                  <Languages className="w-3.5 h-3.5 text-indigo-400" />
                  {meta.languages.length} audio
                </span>
              )}
            </div>

            {/* Language pills */}
            {meta.languages && meta.languages.length > 0 && (
              <div className="flex flex-wrap gap-1.5 pt-1">
                {meta.languages.map((lang) => (
                  <span
                    key={lang}
                    className="px-2 py-0.5 rounded bg-[#181a2e] border border-[#282b45] text-[10px] font-mono text-indigo-300"
                  >
                    {lang}
                  </span>
                ))}
              </div>
            )}

            {/* CTA */}
            <div className="flex flex-wrap gap-2 pt-2">
              <a
                href="#episode-list"
                onClick={(e) => {
                  e.preventDefault();
                  document.getElementById('episode-list')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                Browse Downloads
              </a>
              <a
                href="https://t.me/toonplay_official"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#181a2e] hover:bg-[#20233d] border border-[#282b45] hover:border-indigo-500 text-slate-200 hover:text-white text-xs font-semibold transition-colors"
              >
                <Send className="w-3.5 h-3.5" />
                Telegram
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Telegram banner */}
      <a
        href="https://t.me/toonplay_official"
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center justify-between gap-3 p-3 rounded-xl bg-indigo-950/30 border border-indigo-800/40 hover:bg-indigo-950/50 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center shrink-0">
            <Send className="w-4 h-4 text-indigo-300" />
          </div>
          <div>
            <div className="text-sm font-semibold text-indigo-200">Join Our Telegram</div>
            <div className="text-[11px] text-indigo-300/70">Get the latest updates!</div>
          </div>
        </div>
        <ExternalLink className="w-4 h-4 text-indigo-300 shrink-0" />
      </a>

      {/* Episode list */}
      <div id="episode-list" className="space-y-3 scroll-mt-20">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <ListVideo className="w-4 h-4 text-indigo-400" />
            <h2 className="text-sm font-semibold text-white tracking-tight">
              {meta.type === 'movie' ? 'Movie Download' : `Episodes (${page.episodes.length})`}
            </h2>
          </div>
          {page.episodes.length > 1 && (
            <div className="flex gap-2">
              <button
                onClick={allOpen ? collapseAll : expandAll}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] text-[11px] text-slate-300 hover:text-white transition-colors cursor-pointer"
              >
                <ChevronDown
                  className={`w-3 h-3 transition-transform ${allOpen ? 'rotate-180' : ''}`}
                />
                {allOpen ? 'Collapse all' : 'Expand all'}
              </button>
            </div>
          )}
        </div>

        {page.episodes.map((ep) => {
          const open = openEpisodes.has(ep.episode);
          return (
            <div key={ep.episode} className="rounded-xl border border-[#22253c] bg-[#121424] overflow-hidden">
              <button
                onClick={() => toggleEpisode(ep.episode)}
                className="w-full flex items-center justify-between gap-3 p-3.5 hover:bg-[#1a1d33] transition-colors cursor-pointer text-left"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-lg bg-[#181a2e] border border-[#282b45] flex items-center justify-center text-xs font-bold text-indigo-300 shrink-0">
                    {ep.episode}
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-slate-100">
                      {meta.type === 'movie' ? meta.title : `Episode ${ep.episode}`}
                    </div>
                    <div className="text-[11px] text-slate-500">Uploaded {ep.uploadDate}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-[10px] text-slate-500 font-mono">
                    {open ? '−' : '+'} {ep.qualities.length} qualities
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 text-slate-500 transition-transform ${open ? 'rotate-180' : ''}`}
                  />
                </div>
              </button>

              {open && (
                <div className="border-t border-[#22253c] p-3.5 space-y-2.5">
                  {ep.qualities.map((q, i) => (
                    <div key={i} className="rounded-lg bg-[#0d0e1b] border border-[#22253c] p-3">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-semibold text-indigo-300">{q.quality}</span>
                        <span className="text-[11px] text-slate-500 font-mono">{q.size}</span>
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {Object.entries(q.links).map(([name, url]) => (
                          <a
                            key={name}
                            href={url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-[#181a2e] hover:bg-indigo-600 border border-[#282b45] hover:border-indigo-500 text-[11px] text-slate-200 hover:text-white transition-colors"
                          >
                            <Download className="w-3 h-3" />
                            {name}
                          </a>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};