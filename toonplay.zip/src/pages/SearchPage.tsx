import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { Search, Film, Tv, ChevronLeft, ChevronRight, Loader2, ArrowLeft, Sparkles } from 'lucide-react';
import { AnimeCard } from '../components/AnimeCard.tsx';
import { UnifiedAnime } from '../types.ts';
import { searchCatalog, SearchApiResultItem as SearchItem } from '../api.ts';
import { updateMetadataForRoute } from '../metadata.ts';

interface SearchPageProps {
  initialQuery: string;
  onSelectAnime: (anime: UnifiedAnime) => void;
  onPlayAnime: (anime: UnifiedAnime) => void;
  watchlist: UnifiedAnime[];
  onToggleWatchlist: (anime: UnifiedAnime) => void;
  onBackToHome: () => void;
  onSearchPageLoadingChange?: (loading: boolean) => void;
}

const POPULAR_SEARCH_KEYWORDS = [
  'Naruto',
  'One Piece',
  'Dragon Ball',
  'Attack on Titan',
  'Demon Slayer',
  'Jujutsu Kaisen',
  'Solo Leveling',
  'Bleach',
  'Detective Conan',
  'Pokemon',
];

export const SearchPage: React.FC<SearchPageProps> = ({
  initialQuery,
  onSelectAnime,
  onPlayAnime,
  watchlist,
  onToggleWatchlist,
  onBackToHome,
  onSearchPageLoadingChange,
}) => {
  const getUrlParams = () => {
    const params = new URLSearchParams(window.location.search);
    const q = params.get('q') || initialQuery || '';
    const p = Math.max(1, parseInt(params.get('page') || '1', 10) || 1);
    const cat = (params.get('category') || params.get('type') || 'all') as 'all' | 'series' | 'movies';
    return { q, p, cat };
  };

  const initialParams = getUrlParams();
  const [query, setQuery] = useState(initialParams.q);
  const [activeQuery, setActiveQuery] = useState(initialParams.q);
  const [category, setCategory] = useState<'all' | 'series' | 'movies'>(initialParams.cat);
  const [currentPage, setCurrentPage] = useState<number>(initialParams.p);
  const [results, setResults] = useState<SearchItem[]>([]);
  const [hasNextPage, setHasNextPage] = useState<boolean>(false);
  const [knownTotalPages, setKnownTotalPages] = useState<number>(initialParams.p);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const searchRequestIdRef = useRef(0);
  const searchAbortRef = useRef<AbortController | null>(null);

  const watchlistIdSet = useMemo(
    () => new Set(watchlist.map((w) => w.id)),
    [watchlist]
  );

  const performSearch = useCallback(async (searchTerm: string, pageNumber: number) => {
    const requestId = ++searchRequestIdRef.current;
    searchAbortRef.current?.abort();
    const controller = new AbortController();
    searchAbortRef.current = controller;

    const trimmed = searchTerm.trim();
    if (!trimmed) {
      setResults([]);
      setHasNextPage(false);
      onSearchPageLoadingChange?.(false);
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);
    onSearchPageLoadingChange?.(true);

    try {
      const json = await searchCatalog(trimmed, pageNumber, controller.signal);

      if (requestId !== searchRequestIdRef.current) return;

      if (json && json.success && Array.isArray(json.data)) {
        setResults(json.data);
        const count = json.data.length;
        const apiTotalPages = json.pagination?.totalPages || 1;
        const hasMore = count >= 12;
        setHasNextPage(hasMore);

        setKnownTotalPages((prev) => {
          const calculated = Math.max(prev, pageNumber, apiTotalPages);
          return hasMore ? Math.max(calculated, pageNumber + 1) : Math.max(pageNumber, apiTotalPages);
        });
      } else {
        setResults([]);
        setHasNextPage(false);
      }
    } catch (err: any) {
      if (err?.name === 'AbortError' || controller.signal.aborted) return;
      if (requestId === searchRequestIdRef.current) {
        console.error('Search page error:', err);
        setErrorMessage('Unable to load search results. Please check your network or try again.');
      }
    } finally {
      if (requestId === searchRequestIdRef.current) {
        setIsLoading(false);
        onSearchPageLoadingChange?.(false);
      }
    }
  }, [onSearchPageLoadingChange]);

  useEffect(() => {
    return () => {
      searchAbortRef.current?.abort();
    };
  }, []);


  useEffect(() => {
    if (initialQuery !== undefined) {
      // Always restore the complete search state from the URL.
      const params = new URLSearchParams(window.location.search);

      const urlQuery = params.get('q') || initialQuery || '';
      const urlPage = Math.max(
        1,
        parseInt(params.get('page') || '1', 10) || 1
      );

      const urlCategory = (
        params.get('category') || params.get('type') || 'all'
      ) as 'all' | 'series' | 'movies';

      setQuery(urlQuery);
      setActiveQuery(urlQuery);
      setCurrentPage(urlPage);
      setCategory(urlCategory);
      setKnownTotalPages(urlPage);

      if (urlQuery.trim()) {
        performSearch(urlQuery.trim(), urlPage);
      } else {
        setResults([]);
        setHasNextPage(false);
        onSearchPageLoadingChange?.(false);
      }
    }
  }, [initialQuery, performSearch, onSearchPageLoadingChange]);
  
  // Sync search, category and pagination with browser Back/Forward
useEffect(() => {
  const handlePopState = () => {
    const params = new URLSearchParams(window.location.search);

    const urlQuery = params.get('q') || '';
    const pageParam = Number(params.get('page'));
    const categoryParam = params.get('category') || params.get('type');

    const urlPage =
      Number.isInteger(pageParam) && pageParam > 0
        ? pageParam
        : 1;

    const urlCategory =
      categoryParam === 'series' || categoryParam === 'movies'
        ? categoryParam
        : 'all';

    setQuery(urlQuery);
    setActiveQuery(urlQuery);
    setCategory(urlCategory);
    setCurrentPage(urlPage);
    setKnownTotalPages(urlPage);

    if (urlQuery.trim()) {
      performSearch(urlQuery.trim(), urlPage);
    } else {
      setResults([]);
      setHasNextPage(false);
      setErrorMessage(null);
      setIsLoading(false);
      onSearchPageLoadingChange?.(false);
    }
  };

  window.addEventListener('popstate', handlePopState);

  return () => {
    window.removeEventListener('popstate', handlePopState);
  };
}, [performSearch, onSearchPageLoadingChange]);

  const handlePageChange = (newPage: number) => {
    const targetPage = Math.max(1, newPage);
    setCurrentPage(targetPage);
    if (activeQuery.trim()) {
      performSearch(activeQuery.trim(), targetPage);
    }
    window.scrollTo(0, 0);
  };

  useEffect(() => {
    const params = new URLSearchParams();

    if (activeQuery.trim()) params.set('q', activeQuery.trim());
    if (category !== 'all') params.set('category', category);
    if (currentPage > 1) params.set('page', currentPage.toString());

    const queryStr = params.toString() ? `?${params.toString()}` : '';
    const newUrl = `/search${queryStr}`;
    const currentUrl = window.location.pathname + window.location.search;

    if (currentUrl !== newUrl) {
      window.history.pushState(null, '', newUrl);
    }

    updateMetadataForRoute('/search', {
      query: activeQuery.trim(),
      page: currentPage,
      subType: category,
    });
  }, [activeQuery, category, currentPage]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = query.trim();
    if (!trimmed) return;
    setActiveQuery(trimmed);
    setCurrentPage(1);
    setKnownTotalPages(1);
    performSearch(trimmed, 1);
  };

  const handleQuickKeyword = (kw: string) => {
    setQuery(kw);
    setActiveQuery(kw);
    setCurrentPage(1);
    setKnownTotalPages(1);
    performSearch(kw, 1);
  };

  const { seriesCount, movieCount } = useMemo(() => {
    let series = 0;
    let movies = 0;
    for (const item of results) {
      if (item.type === 'series') series++;
      else if (item.type === 'movie' || item.type === 'movies') movies++;
    }
    return { seriesCount: series, movieCount: movies };
  }, [results]);

  const filtered = useMemo(
    () =>
      results.filter((item) => {
        if (category === 'series') return item.type === 'series';
        if (category === 'movies') return item.type === 'movie' || item.type === 'movies';
        return true;
      }),
    [results, category]
  );

  const generatePageNumbers = () => {
    const pages: number[] = [];
    const maxVisible = Math.max(knownTotalPages, currentPage + (hasNextPage ? 1 : 0));
    const start = Math.max(1, currentPage - 2);
    const end = Math.min(maxVisible, start + 4);

    for (let i = start; i <= end; i++) {
      pages.push(i);
    }
    return pages;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1c1f36]">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToHome}
            className="p-2 rounded-xl bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] text-slate-300 hover:text-white transition-colors cursor-pointer"
            title="Back to Home"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h1 className="text-xl sm:text-2xl font-semibold text-white tracking-tight">
              Search Catalog
            </h1>
            <p className="text-xs text-slate-400 font-mono">
              {activeQuery ? (
                <>
                  Results for &ldquo;<span className="text-indigo-400">{activeQuery}</span>&rdquo; &bull; Page {currentPage}
                </>
              ) : (
                'Discover anime series, movies, and animated classics'
              )}
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="flex items-center gap-2 max-w-md w-full">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search anime and cartoon..."
              className="w-full pl-9 pr-3 py-2 text-xs text-white bg-[#121424] border border-[#23263d] focus:border-indigo-500 rounded-xl focus:outline-none placeholder:text-slate-500"
            />
          </div>
          <button
            type="submit"
            className="px-4 py-2 text-xs font-medium bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl transition-colors cursor-pointer shrink-0 shadow-sm shadow-indigo-500/20"
          >
            Search
          </button>
        </form>
      </div>

      {!activeQuery && (
        <div className="p-6 rounded-2xl bg-[#0f1120] border border-[#1c1f36] space-y-4">
          <div className="flex items-center gap-2 text-xs font-medium text-slate-300">
            <Sparkles className="w-4 h-4 text-indigo-400" />
            <span>Popular Searches</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {POPULAR_SEARCH_KEYWORDS.map((kw) => (
              <button
                key={kw}
                onClick={() => handleQuickKeyword(kw)}
                className="px-3 py-1.5 rounded-lg bg-[#14172b] hover:bg-indigo-600/20 border border-[#23263d] hover:border-indigo-500/40 text-xs text-slate-300 hover:text-white transition-all cursor-pointer"
              >
                {kw}
              </button>
            ))}
          </div>
        </div>
      )}

      {activeQuery && (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">

          <div className="flex items-center gap-1.5 p-1 bg-[#121424] border border-[#23263d] rounded-xl self-start sm:self-auto">
            <button
              onClick={() => setCategory('all')}
              className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                category === 'all'
                  ? 'bg-indigo-600 text-white font-medium shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              All Categories ({results.length})
            </button>
            <button
              onClick={() => setCategory('series')}
              className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer ${
                category === 'series'
                  ? 'bg-indigo-600 text-white font-medium shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Tv className="w-3.5 h-3.5" />
              <span>Series ({seriesCount})</span>
            </button>
            <button
              onClick={() => setCategory('movies')}
              className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer ${
                category === 'movies'
                  ? 'bg-indigo-600 text-white font-medium shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Film className="w-3.5 h-3.5" />
              <span>Movies ({movieCount})</span>
            </button>
          </div>

          <div className="flex items-center justify-between sm:justify-end gap-3 font-mono">
            <span className="text-slate-400">
              Showing {filtered.length} titles on page {currentPage}
            </span>

            <div className="flex items-center gap-1.5">
              <button
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage <= 1 || isLoading}
                className="p-1.5 rounded-lg bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] disabled:opacity-40 text-slate-300 cursor-pointer flex items-center gap-1 transition-colors"
                title="Previous Page"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
                <span className="hidden sm:inline text-[11px]">Prev</span>
              </button>
              <span className="px-2 py-1 rounded bg-[#0f1120] border border-[#1f2237] text-indigo-300 text-[11px]">
                Pg {currentPage}
              </span>
              <button
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={!hasNextPage || isLoading}
                className="p-1.5 rounded-lg bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] disabled:opacity-40 text-slate-300 cursor-pointer flex items-center gap-1 transition-colors"
                title="Next Page"
              >
                <span className="hidden sm:inline text-[11px]">Next</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {isLoading && (
        <div className="py-20 text-center space-y-2">
          <Loader2 className="w-6 h-6 text-indigo-400 animate-spin mx-auto" />
          <p className="text-xs font-mono text-indigo-300">Searching catalog for &ldquo;{activeQuery}&rdquo; (Page {currentPage})...</p>
        </div>
      )}

      {errorMessage && !isLoading && (
        <div className="p-4 rounded-xl bg-rose-950/20 border border-rose-900/40 text-center text-xs text-rose-300">
          {errorMessage}
        </div>
      )}

      {!isLoading && !errorMessage && filtered.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5 sm:gap-4.5">
          {filtered.map((item) => {
            const rawType = String(item.type || '').trim().toUpperCase();
            const lower = rawType.toLowerCase();
            const isMovieType = lower === 'movie' || lower === 'movies';

            const unified: UnifiedAnime = {
              id: item.id,
              subjectId: item.subjectId,
              title: item.title,
              image: item.image,
              type: isMovieType ? 'movie' : 'series',
              displayType: rawType || (isMovieType ? 'MOVIE' : 'SERIES'),
              anilistId: item.anilist_id,
              category: isMovieType ? 'movie' : 'series',
            };

            return (
              <AnimeCard
                key={item.id}
                anime={unified}
                onSelect={onSelectAnime}
                onPlay={onPlayAnime}
                isBookmarked={watchlistIdSet.has(item.id)}
                onToggleWatchlist={onToggleWatchlist}
              />
            );
          })}
        </div>
      )}

      {!isLoading && !errorMessage && results.length > 0 && filtered.length === 0 && (
        <div className="text-center py-16 text-slate-400 space-y-3 bg-[#0f1120] border border-[#1c1f36] rounded-2xl p-6">
          <p className="text-sm text-slate-300">
            No {category === 'series' ? 'series' : 'movies'} found on page {currentPage}
          </p>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Other media types exist on this page or try checking other pages in the catalog.
          </p>
          <div className="flex justify-center gap-2 pt-2">
            <button
              onClick={() => setCategory('all')}
              className="px-3 py-1.5 text-xs rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-medium cursor-pointer"
            >
              Show All Types
            </button>
            {hasNextPage && (
              <button
                onClick={() => handlePageChange(currentPage + 1)}
                className="px-3 py-1.5 text-xs rounded-lg bg-[#14172b] hover:bg-[#1c203b] border border-[#23263d] text-slate-300 hover:text-white cursor-pointer"
              >
                Check Next Page
              </button>
            )}
          </div>
        </div>
      )}

      {!isLoading && !errorMessage && activeQuery && results.length === 0 && (
        <div className="text-center py-20 text-slate-400 space-y-3">
          <Search className="w-8 h-8 text-indigo-500/40 mx-auto" />
          <p className="text-sm text-slate-300">No matching titles found for &ldquo;{activeQuery}&rdquo;</p>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Try searching with different keywords like Naruto, One Piece, Attack on Titan, Demon Slayer, etc.
          </p>
        </div>
      )}

      {!isLoading && activeQuery && (currentPage > 1 || hasNextPage) && (
        <div className="pt-6 border-t border-[#1c1f36] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono">
          <div className="text-slate-400">
            Page <span className="text-indigo-400 font-semibold">{currentPage}</span> of search results
          </div>

          <div className="flex items-center gap-1.5">

            <button
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage <= 1 || isLoading}
              className="px-3 py-1.5 rounded-lg bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] disabled:opacity-40 text-slate-300 cursor-pointer flex items-center gap-1 transition-colors"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              <span>Previous</span>
            </button>

            <div className="flex items-center gap-1">
              {generatePageNumbers().map((pageNum) => (
                <button
                  key={pageNum}
                  onClick={() => handlePageChange(pageNum)}
                  className={`w-7 h-7 rounded-lg text-xs font-medium transition-colors cursor-pointer flex items-center justify-center ${
                    pageNum === currentPage
                      ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                      : 'bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] text-slate-400 hover:text-white'
                  }`}
                >
                  {pageNum}
                </button>
              ))}
            </div>

            <button
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={!hasNextPage || isLoading}
              className="px-3 py-1.5 rounded-lg bg-[#121424] hover:bg-[#1a1d33] border border-[#23263d] disabled:opacity-40 text-slate-300 cursor-pointer flex items-center gap-1 transition-colors"
            >
              <span>Next</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
