import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Bookmark, ArrowLeft, Trash2, Film, Tv, Sparkles, Search, ChevronLeft, ChevronRight, AlertTriangle, X } from 'lucide-react';
import { AnimeCard } from '../components/AnimeCard.tsx';
import { UnifiedAnime } from '../types.ts';
import { updateMetadataForRoute } from '../metadata.ts';

interface WatchlistPageProps {
  watchlist: UnifiedAnime[];
  onToggleWatchlist: (anime: UnifiedAnime) => void;
  onSelectAnime: (anime: UnifiedAnime) => void;
  onPlayAnime: (anime: UnifiedAnime) => void;
  onClearWatchlist: () => void;
  onBackToHome: () => void;
  onNavigate: (path: string) => void;
}

const ITEMS_PER_PAGE = 12;

export const WatchlistPage: React.FC<WatchlistPageProps> = ({
  watchlist,
  onToggleWatchlist,
  onSelectAnime,
  onPlayAnime,
  onClearWatchlist,
  onBackToHome,
  onNavigate,
}) => {

  const searchParams = new URLSearchParams(window.location.search);
  const initialCategory = (searchParams.get('category') as 'all' | 'series' | 'movies') || 'all';
  const initialPage = parseInt(searchParams.get('page') || '1', 10) || 1;

  const [category, setCategory] = useState<'all' | 'series' | 'movies'>(
    ['all', 'series', 'movies'].includes(initialCategory) ? initialCategory : 'all'
  );
  const [page, setPage] = useState<number>(initialPage);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [showClearModal, setShowClearModal] = useState<boolean>(false);
  const skipNextUrlPushRef = useRef(false);
  
useEffect(() => {
  const handlePopState = () => {
    const params = new URLSearchParams(window.location.search);

    const categoryParam = params.get('category');
    const pageParam = Number(params.get('page'));

    setCategory(
      categoryParam === 'series' || categoryParam === 'movies'
        ? categoryParam
        : 'all'
    );

    setPage(
      Number.isInteger(pageParam) && pageParam > 0
        ? pageParam
        : 1
    );
  };

  window.addEventListener('popstate', handlePopState);

  return () => {
    window.removeEventListener('popstate', handlePopState);
  };
}, []);

  const handleCategoryChange = (cat: 'all' | 'series' | 'movies') => {
    setCategory(cat);
    setPage(1);
  };

  const filteredItems = useMemo(() => {
    return watchlist.filter((item) => {

      if (category === 'series' && item.type !== 'series') return false;
      if (category === 'movies' && item.type !== 'movie') return false;

      if (searchTerm.trim()) {
        const query = searchTerm.toLowerCase();
        return (
          item.title.toLowerCase().includes(query) ||
          item.id.toLowerCase().includes(query)
        );
      }
      return true;
    });
  }, [watchlist, category, searchTerm]);

  const totalPages = Math.max(1, Math.ceil(filteredItems.length / ITEMS_PER_PAGE));
  const currentPage = Math.min(page, totalPages);

  useEffect(() => {
  if (page > totalPages) return;
    const params = new URLSearchParams();

    if (category !== 'all') params.set('category', category);
    if (currentPage > 1) params.set('page', currentPage.toString());

    const queryStr = params.toString() ? `?${params.toString()}` : '';
    const newUrl = `/watchlist${queryStr}`;
    const currentUrl = window.location.pathname + window.location.search;

    if (skipNextUrlPushRef.current) {
      skipNextUrlPushRef.current = false;
      window.history.replaceState(null, '', newUrl);
    } else if (currentUrl !== newUrl) {
      window.history.pushState(null, '', newUrl);
    }

    updateMetadataForRoute('/watchlist', {
      subType: category,
      page: currentPage,
    });
  }, [category, currentPage, page, totalPages]);
  const paginatedItems = useMemo(() => {
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredItems.slice(start, start + ITEMS_PER_PAGE);
  }, [filteredItems, currentPage]);

useEffect(() => {
  if (page > totalPages) {
    skipNextUrlPushRef.current = true;
    setPage(totalPages);
  }
}, [page, totalPages]);

  const seriesCount = useMemo(() => watchlist.filter((x) => x.type === 'series').length, [watchlist]);
  const moviesCount = useMemo(() => watchlist.filter((x) => x.type === 'movie').length, [watchlist]);

  return (
    <div className="min-h-screen bg-[#0b0c16] text-slate-100 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-6">

        <div className="flex items-center justify-between gap-4">
          <button
            onClick={onBackToHome}
            className="flex items-center gap-2 text-xs font-mono text-slate-400 hover:text-white transition-colors cursor-pointer group"
          >
            <ArrowLeft className="w-4 h-4 text-indigo-400 group-hover:-translate-x-1 transition-transform" />
            <span>Back to Catalog</span>
          </button>

          {watchlist.length > 0 && (
            <button
              onClick={() => setShowClearModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono text-rose-400 hover:text-white bg-rose-950/30 hover:bg-rose-900/50 border border-rose-900/40 transition-colors cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear Watchlist</span>
            </button>
          )}
        </div>

        <div className="border-b border-[#1b1e33] pb-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
                  <Bookmark className="w-5 h-5 fill-indigo-400/20" />
                </div>
                <h1 className="text-2xl sm:text-3xl font-semibold text-white tracking-tight">
                  Saved Watchlist
                </h1>
              </div>
              <p className="text-xs sm:text-sm text-slate-400 max-w-xl">
                Personalized collection of anime series and movies bookmarked for immediate streaming.
              </p>
            </div>

            <div className="flex items-center gap-2 text-xs font-mono bg-[#111322] border border-[#232742] px-3.5 py-2 rounded-xl text-slate-300 self-start sm:self-auto">
              <span>Total: <strong className="text-indigo-400">{watchlist.length}</strong></span>
              <span className="text-slate-600">|</span>
              <span>Series: <strong className="text-slate-100">{seriesCount}</strong></span>
              <span className="text-slate-600">|</span>
              <span>Movies: <strong className="text-slate-100">{moviesCount}</strong></span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
            <div className="flex items-center gap-2">
              <button
                onClick={() => handleCategoryChange('all')}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-all ${
                  category === 'all'
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'bg-[#14172b] text-slate-400 hover:text-white border border-[#232742]'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>All Titles ({watchlist.length})</span>
              </button>
              <button
                onClick={() => handleCategoryChange('series')}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-all ${
                  category === 'series'
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'bg-[#14172b] text-slate-400 hover:text-white border border-[#232742]'
                }`}
              >
                <Tv className="w-3.5 h-3.5" />
                <span>Series ({seriesCount})</span>
              </button>
              <button
                onClick={() => handleCategoryChange('movies')}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-all ${
                  category === 'movies'
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'bg-[#14172b] text-slate-400 hover:text-white border border-[#232742]'
                }`}
              >
                <Film className="w-3.5 h-3.5" />
                <span>Movies ({moviesCount})</span>
              </button>
            </div>

            {watchlist.length > 0 && (
              <div className="relative sm:w-64">
                <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => {
                    setSearchTerm(e.target.value);
                    setPage(1);
                  }}
                  placeholder="Filter saved titles..."
                  className="w-full bg-[#111322] border border-[#232742] rounded-lg pl-8.5 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
                />
              </div>
            )}
          </div>
        </div>

        {watchlist.length === 0 ? (
          <div className="py-20 text-center space-y-4 max-w-md mx-auto">
            <div className="w-16 h-16 rounded-2xl bg-[#14172b] border border-[#232742] mx-auto flex items-center justify-center text-slate-600">
              <Bookmark className="w-8 h-8" />
            </div>
            <div className="space-y-1">
              <h3 className="text-base font-semibold text-white">Your Watchlist is Empty</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Explore the catalog and bookmark titles with the bookmark icon to create your personal streaming queue.
              </p>
            </div>
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={() => onNavigate('/category/anime')}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium rounded-xl shadow-lg shadow-indigo-600/20 transition-colors cursor-pointer"
              >
                Browse Anime Series
              </button>
              <button
                onClick={() => onNavigate('/category/cartoon')}
                className="px-4 py-2 bg-[#14172b] hover:bg-[#1a1c36] border border-[#232742] text-slate-200 text-xs font-medium rounded-xl transition-colors cursor-pointer"
              >
                Browse Cartoons
              </button>
            </div>
          </div>
        ) : filteredItems.length === 0 ? (
          <div className="py-16 text-center space-y-3">
            <p className="text-sm text-slate-400">No titles match your filter criteria.</p>
            <button
              onClick={() => {
                setCategory('all');
                setSearchTerm('');
              }}
              className="text-xs text-indigo-400 hover:text-indigo-300 underline cursor-pointer"
            >
              Reset filters
            </button>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4">
              {paginatedItems.map((anime) => (
                <AnimeCard
                  key={anime.id}
                  anime={anime}
                  onSelect={onSelectAnime}
                  onPlay={onPlayAnime}
                  isBookmarked={true}
                  onToggleWatchlist={onToggleWatchlist}
                />
              ))}
            </div>

            {totalPages > 1 && (
              <div className="flex items-center justify-center gap-3 pt-8 pb-4">
                <button
                  type="button"
                  onClick={() => {
                    setPage((p) => Math.max(1, p - 1));
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  disabled={currentPage <= 1}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-mono bg-[#14172b] border border-[#232742] text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-indigo-600 hover:text-white transition-colors cursor-pointer"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                  <span>Previous</span>
                </button>

                <div className="flex items-center gap-1">
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                    <button
                      key={p}
                      onClick={() => {
                        setPage(p);
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className={`w-7 h-7 rounded-lg text-xs font-mono flex items-center justify-center transition-colors cursor-pointer ${
                        currentPage === p
                          ? 'bg-indigo-600 text-white font-semibold'
                          : 'bg-[#14172b] text-slate-400 hover:text-white border border-[#232742]'
                      }`}
                    >
                      {p}
                    </button>
                  ))}
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setPage((p) => Math.min(totalPages, p + 1));
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  disabled={currentPage >= totalPages}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-mono bg-[#14172b] border border-[#232742] text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-indigo-600 hover:text-white transition-colors cursor-pointer"
                >
                  <span>Next</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </>
        )}
      </div>

      {showClearModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-[#111322] border border-[#272b47] rounded-2xl p-6 max-w-md w-full shadow-2xl text-left space-y-4 animate-in zoom-in-95 duration-200">
            <div className="flex items-start justify-between gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400 shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <button
                type="button"
                onClick={() => setShowClearModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-[#1a1c30] transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-1.5">
              <h3 className="text-lg font-semibold text-white">Clear entire watchlist?</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                This will remove all <strong className="text-slate-200">{watchlist.length}</strong> titles
                saved to your watchlist. This action cannot be reversed.
              </p>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2 border-t border-[#1a1d33]">
              <button
                type="button"
                onClick={() => setShowClearModal(false)}
                className="px-4 py-2 text-xs font-mono rounded-xl bg-[#181a2e] hover:bg-[#22253f] border border-[#262a4a] text-slate-300 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  onClearWatchlist();
                  setShowClearModal(false);
                }}
                className="flex items-center gap-1.5 px-4 py-2 text-xs font-mono rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-medium shadow-lg shadow-rose-600/30 transition-all cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Yes, Clear All</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
