import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import {
  ArrowLeft,
  Server,
  Volume2,
  RefreshCw,
  Maximize2,
  Minimize2,
  Bookmark,
  Check,
  Share2,
  ChevronLeft,
  ChevronRight,
  Tv,
  Film,
  Scissors,
  Sparkles,
  AlertCircle,
  Loader2,
  Play,
  List,
  LayoutGrid,
  Calendar,
  Clock,
  Radio,
  Tag,
  Search,
  Download,
  X,
} from 'lucide-react';
import {
  AnimeInfoData,
  AnimeWatchServer,
  AnimeSeasonItem,
  AnimeEpisodeItem,
  UnifiedAnime,
  StreamApiServer,
} from '../types.ts';
import {
  fetchAnimeInfo,
  fetchEpisodeExtract,
  fetchEpisodeExtractById,
  fetchRavokLanguages,
  fetchDownloadLinks,
  fetchLocalDownloadFile,
  fetchStreamServers,
  detectInfoSource,
  buildMovieboxStreamUrl,
  resolveMovieboxStreamUrlForLanguage,
  MOVIEBOX_API_BASE,
  type DownloadLink,
} from '../api.ts';
import { CustomPlayer, type MergedAudioOption } from '../components/CustomPlayer.tsx';
import { userApi } from '../lib/api.ts';
import { updateMetadataForRoute } from '../metadata.ts';
import { AnimeCard } from '../components/AnimeCard.tsx';

interface WatchPageProps {
  id: string;
  subjectId?: string;
  onNavigate: (path: string) => void;
  watchlist: UnifiedAnime[];
  onToggleWatchlist: (anime: UnifiedAnime) => void;
  onBackToHome: () => void;
  onWatchPageLoadingChange?: (loading: boolean) => void;
  onRecordHistory?: (
    anime: UnifiedAnime,
    context: {
      seasonNumber?: number;
      episodeNumber?: number;
      episodeId?: string;
      episodeTitle?: string;
      episodeImage?: string;
      lang?: string;
      server?: string;
      genres?: string[];
      totalEpisodesAvailable?: number;
    }
  ) => void;
  onWatchSessionStart?: (session: {
    cartoonId: string;
    cartoonTitle: string;
    cartoonImage: string;
    cartoonType: string;  
    serverType?: string;
    episodeId?: string;
    episodeNumber?: number;
    seasonNumber?: number;
    episodeTitle?: string;
    episodeImage?: string;
    genres?: string[];
    totalEpisodesAvailable?: number;
  }) => void;
  onEpisodeComplete?: (payload: {
    cartoonId: string;
    cartoonTitle: string;
    cartoonImage: string;
    cartoonType: string;   // same
    episodeId?: string;
    episodeNumber?: number;
    seasonNumber?: number;
    episodeTitle?: string;
    episodeImage?: string;
    server?: string;
    genres?: string[];
    totalEpisodesAvailable?: number;
    durationSeconds?: number;
    progressSeconds?: number;
  }) => void;
  isAuthenticated?: boolean;
  serverPrefs?: {
    autoPlay: boolean;
    autoNext: boolean;
    autoSkip: boolean;
  };
}

interface LanguageOption {
  code: string;
  name: string;
  audioKey?: string;
}

const ABYSS_NAME_MAP: Record<string, string> = {
  hin: 'Hindi',
  hindi: 'Hindi',
  eng: 'English',
  english: 'English',
  jpn: 'Japanese',
  jap: 'Japanese',
  japanese: 'Japanese',
  kor: 'Korean',
  korean: 'Korean',
  tam: 'Tamil',
  tamil: 'Tamil',
  tel: 'Telugu',
  telugu: 'Telugu',
  mal: 'Malayalam',
  malayalam: 'Malayalam',
  kan: 'Kannada',
  kannada: 'Kannada',
  ben: 'Bengali',
  bengali: 'Bengali',
};

const RAVOK_CODE_MAP: Record<string, string> = {
  hindi: 'hin',
  english: 'eng',
  japanese: 'jpn',
  korean: 'kor',
  tamil: 'tam',
  telugu: 'tel',
  malayalam: 'mal',
  kannada: 'kan',
  bengali: 'ben',
};

const STREAM_LANG_LABEL: Record<string, string> = {
  jap: 'Japanese', jpn: 'Japanese', japanese: 'Japanese',
  eng: 'English', english: 'English',
  hin: 'Hindi', hindi: 'Hindi',
  tam: 'Tamil', tamil: 'Tamil',
  tel: 'Telugu', telugu: 'Telugu',
  mal: 'Malayalam', malayalam: 'Malayalam',
  kan: 'Kannada', kannada: 'Kannada',
  ben: 'Bengali', bengali: 'Bengali',
  kor: 'Korean', korean: 'Korean',
};

// ---- FlixCloud resume-position persistence (guest + logged-in) ----
const FLIX_RESUME_PREFIX = 'toonplay_flix_progress_v1';

const makeFlixResumeKey = (opts: {
  animeId: string;
  season?: number | null;
  episode?: number | null;
  isMovie: boolean;
}) => {
  if (opts.isMovie) return `${FLIX_RESUME_PREFIX}:movie:${opts.animeId}`;
  return `${FLIX_RESUME_PREFIX}:series:${opts.animeId}:s${opts.season ?? 0}:e${opts.episode ?? 0}`;
};

const readFlixResume = (key: string): number => {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return 0;
    const parsed = JSON.parse(raw);
    const t = Number(parsed?.t);
    return Number.isFinite(t) && t > 0 ? Math.floor(t) : 0;
  } catch {
    return 0;
  }
};

const writeFlixResume = (key: string, t: number) => {
  try {
    localStorage.setItem(key, JSON.stringify({ t: Math.floor(t), updatedAt: Date.now() }));
  } catch {}
};

const clearFlixResume = (key: string) => {
  try {
    localStorage.removeItem(key);
  } catch {}
};

const canonicalLangCode = (lang: string): string => {
  const l = String(lang || '')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '')
    .slice(0, 8);
  if (l === 'jap' || l === 'ja' || l === 'japanese' || l === 'jpn') return 'jpn';
  return l;
};

const replaceWatchPageUrl = (
  state: any,
  title: string,
  url: string
): void => {
  if (!window.location.pathname.startsWith('/watch/')) return;

  window.history.replaceState(
    state ?? window.history.state,
    title,
    url
  );
};

const buildServerType = (serverName: string, lang: string): string | null => {
  const cleanName = String(serverName || '')
    .toLowerCase()
    .replace(/\s+/g, '')
    .replace(/[^a-z0-9-]/g, '');
  const cleanLang = canonicalLangCode(lang);
  if (!cleanName) return null;
  if (!cleanLang) return cleanName;
  return `${cleanName}-${cleanLang}`;
};

// 'hd1-jap' -> { serverKey: 'hd1', lang: 'jap' }
const parseServerType = (
  raw: string | null | undefined
): { serverKey: string; lang: string } | null => {
  if (!raw) return null;
  const s = String(raw).trim().toLowerCase();
  if (!s) return null;
  const dashIdx = s.lastIndexOf('-');
  if (dashIdx <= 0) return { serverKey: s, lang: '' };
  return { serverKey: s.slice(0, dashIdx), lang: s.slice(dashIdx + 1) };
};

interface MappedStreamServer {
  name: string;
  langUrls: Record<string, string>;
  defaultLang: string;
}

const mapStreamServers = (servers: StreamApiServer[]): MappedStreamServer[] => {
  const byName = new Map<string, MappedStreamServer>();
  for (const s of servers) {
    const name = String(s?.serverName || '').trim();
    const url = String(s?.dataLink || '').trim();
    const lang = canonicalLangCode(String(s?.dataType || '').trim());
    if (!name || !url) continue;
    const existing = byName.get(name);
    if (!existing) {
      byName.set(name, {
        name,
        langUrls: { [lang]: url },
        defaultLang: lang === 'jpn' ? lang : 'jpn',
      });
    } else {
      existing.langUrls[lang] = url;
      if (lang === 'jpn') existing.defaultLang = lang;
    }
  }
  return Array.from(byName.values());
};

const isCustomEpisodeId = (raw: string | null | undefined): boolean => {
  if (!raw) return false;
  const s = String(raw).trim().toLowerCase();
  return s.startsWith('custom/') || s.startsWith('/custom/');
};

const getSeasonAniListId = (
  anime: AnimeInfoData | null,
  seasonNumber: number,
  episodeNumber: number
): number | null => {
  if (!anime) return null;

  const seasonIds = anime.season_anilist_ids;

  // Preserve the existing single-AniList-ID format.
  if (!seasonIds || typeof seasonIds !== 'object') {
    const fallback = Number(anime.anilist_id);
    return Number.isFinite(fallback) && fallback > 0 ? fallback : null;
  }

  const seasonKey = String(seasonNumber);
  const seasonEntry = seasonIds[seasonKey];

  let selectedId =
    seasonEntry?.anilist_id != null && Number(seasonEntry.anilist_id) > 0
      ? Number(seasonEntry.anilist_id)
      : null;

  let selectedBoundary = 0;

  // Find the closest matching episode boundary in this season.
  for (const [key, entry] of Object.entries(seasonIds)) {
    const match = key.match(/^(\d+)x(\d+)$/);
    if (!match) continue;

    const entrySeason = Number(match[1]);
    const entryEpisode = Number(match[2]);
    const entryId = Number(entry?.anilist_id);

    if (
      entrySeason === seasonNumber &&
      entryEpisode <= episodeNumber &&
      entryEpisode > selectedBoundary &&
      Number.isFinite(entryId) &&
      entryId > 0
    ) {
      selectedBoundary = entryEpisode;
      selectedId = entryId;
    }
  }

  return selectedId;
};

const getSeasonAniListEpisodeNumber = (
  anime: AnimeInfoData | null,
  seasonNumber: number,
  episodeNumber: number
): number => {
  if (!anime?.season_anilist_ids) return episodeNumber;

  let selectedBoundary = 0;

  for (const key of Object.keys(anime.season_anilist_ids)) {
    const match = key.match(/^(\d+)x(\d+)$/);
    if (!match) continue;

    const entrySeason = Number(match[1]);
    const entryEpisode = Number(match[2]);

    if (
      entrySeason === seasonNumber &&
      entryEpisode <= episodeNumber &&
      entryEpisode > selectedBoundary
    ) {
      selectedBoundary = entryEpisode;
    }
  }

  return selectedBoundary > 0
    ? episodeNumber - selectedBoundary + 1
    : episodeNumber;
};

const buildEpisodeUrl = (
  seasonLink: string,
  episodeId: string | undefined,
  season: number,
  ep: number
): string => {
  if (seasonLink.startsWith('/api/')) return '';

  if (episodeId) {
    if (isCustomEpisodeId(episodeId)) return '';
    try {
      const base = new URL(seasonLink);
      const origin = base.origin;
      const cleanId = episodeId.replace(/^\/+/, '');
      return `${origin}/${cleanId}/`;
    } catch {
      return '';
    }
  }

  if (!seasonLink) return '';
  if (ep === 1) return seasonLink;
  return seasonLink.replace(new RegExp(`-${season}x1/?$`), `-${season}x${ep}/`);
};

interface SeasonDropdownItem {
  season: string;
  link: string;
  episodes?: AnimeEpisodeItem[];
}

const SeasonDropdown: React.FC<{
  seasons: SeasonDropdownItem[];
  current: number;
  onSelect: (seasonNumber: number, firstEpisode: number) => void;
}> = ({ seasons, current, onSelect }) => {
  const [open, setOpen] = useState(false);
  const wrapRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!open) return;
    const onDocClick = (e: MouseEvent) => {
      if (!wrapRef.current) return;
      if (!wrapRef.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    window.addEventListener('mousedown', onDocClick);
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('mousedown', onDocClick);
      window.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const currentSeason = seasons.find((s) => parseInt(s.season, 10) === current) || seasons[0];
  if (!currentSeason) return null;

  return (
    <div ref={wrapRef} className="relative w-full">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="w-full flex items-center justify-between gap-2 px-3 py-2 rounded-lg bg-[#14162a] border border-[#222540] hover:border-[#2a2d4a] text-left text-xs text-white transition-colors cursor-pointer"
      >
        <span className="min-w-0 flex-1">
          <span className="block text-[10px] uppercase tracking-wide text-slate-500 leading-none mb-0.5">
            Season
          </span>
          <span className="block truncate font-medium">
            Season {currentSeason.season}
            <span className="text-slate-400 font-normal">
              {' '}— {currentSeason.episodes?.length || 0} eps
            </span>
          </span>
        </span>
        <ChevronRight
          className={`w-3.5 h-3.5 text-slate-400 shrink-0 transition-transform ${
            open ? 'rotate-90' : ''
          }`}
        />
      </button>

      {open && (
        <div className="absolute left-0 right-0 top-full mt-1 z-30 max-h-64 overflow-y-auto thin-scrollbar rounded-lg border border-[#222540] bg-[#0d0f1e] shadow-2xl">
          {seasons.map((item) => {
            const sNum = parseInt(item.season, 10);
            const active = sNum === current;
            return (
              <button
                key={item.season}
                type="button"
                onClick={() => {
                  const firstEp = item.episodes?.[0]?.number || 1;
                  onSelect(sNum, firstEp);
                  setOpen(false);
                }}
                className={`w-full text-left px-3 py-2 text-xs transition-colors cursor-pointer flex items-center gap-2 ${
                  active
                    ? 'bg-indigo-600/20 text-indigo-300'
                    : 'text-slate-300 hover:bg-[#14162a] hover:text-white'
                }`}
              >
                <span className="min-w-0 flex-1 truncate">
                  <span className="block font-medium">Season {item.season}</span>
                  <span className="block text-[10px] text-slate-500 leading-tight">
                    {item.episodes?.length || 0} episodes
                  </span>
                </span>
                {active && <Check className="w-3 h-3 shrink-0" />}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
};

const extractMovieboxSubjectId = (data: any): string | undefined => {
  if (!data || typeof data !== 'object') return undefined;

  let found: string | undefined;

  const scan = (value: any): void => {
    if (found || !value || typeof value !== 'object') return;

    if (Array.isArray(value)) {
      value.forEach(scan);
      return;
    }

    if (typeof value.id === 'string') {
      const match = value.id.match(/^(\d+)&/);
      if (match) {
        found = match[1];
        return;
      }
    }

    if (typeof value.url === 'string') {
      const match = value.url.match(/[?&]subjectId=(\d+)/);
      if (match) {
        found = match[1];
        return;
      }
    }

    Object.values(value).forEach(scan);
  };

  scan(data);
  return found;
};

export const WatchPage: React.FC<WatchPageProps> = ({
  id,
  subjectId,
  onNavigate,
  watchlist,
  onToggleWatchlist,
  onBackToHome,
  onWatchPageLoadingChange,
  onRecordHistory,
  onWatchSessionStart,
  onEpisodeComplete,
  isAuthenticated,
  serverPrefs,
}) => {

  useEffect(() => {
    const scriptUrl = import.meta.env.VITE_POPUNDER_SCRIPT_URL;

    if (!scriptUrl) return;
    if (document.querySelector(`script[src="${scriptUrl}"]`)) return;

    const script = document.createElement('script');
    script.setAttribute('data-cfasync', 'false');
    script.src = scriptUrl;
    script.async = true;
    document.head.appendChild(script);
  }, []);

  const cleanSubjectId = String(subjectId || '').trim() || undefined;
  const [anime, setAnime] = useState<AnimeInfoData | null>(null);
  const animeRequestIdRef = useRef(0);
  const [isLoadingAnime, setIsLoadingAnime] = useState<boolean>(true);
  const [animeError, setAnimeError] = useState<string | null>(null);
  const [currentSeasonNumber, setCurrentSeasonNumber] = useState<number>(1);
  const [currentEpisodeNumber, setCurrentEpisodeNumber] = useState<number>(1);
  const [watchServers, setWatchServers] = useState<AnimeWatchServer[]>([]);
  const [streamServerMap, setStreamServerMap] = useState<Record<string, MappedStreamServer>>({});
  const [isLoadingExtract, setIsLoadingExtract] = useState<boolean>(false);
  const [extractError, setExtractError] = useState<string | null>(null);
  const [selectedServerKey, setSelectedServerKey] = useState<string>('multi-1');
  const [selectedLanguage, setSelectedLanguage] = useState<string>('');
  const [availableLanguages, setAvailableLanguages] = useState<LanguageOption[]>([]);
  const [movieboxMergedOptions, setMovieboxMergedOptions] = useState<MergedAudioOption[]>([]);
  const [movieboxActiveAudioKey, setMovieboxActiveAudioKey] = useState<string | null>(null);
  const movieboxAudioRestoreAttemptRef = useRef<string>('');
  const [isTheatreMode, setIsTheatreMode] = useState<boolean>(false);
  const [episodeViewMode, setEpisodeViewMode] = useState<'grid' | 'list'>('grid');
  const [reloadKey, setReloadKey] = useState<number>(0);
  const [copiedShare, setCopiedShare] = useState<boolean>(false);
  const [activeFeedback, setActiveFeedback] = useState<string | null>(null);
  const [isSwitchingLanguage, setIsSwitchingLanguage] = useState<boolean>(false);
  const [episodeSearch, setEpisodeSearch] = useState<string>('');
  const [isDownloadOpen, setIsDownloadOpen] = useState<boolean>(false);
  const [downloadLoading, setDownloadLoading] = useState<boolean>(false);
  const [downloadError, setDownloadError] = useState<string | null>(null);
  const [downloadLinks, setDownloadLinks] = useState<DownloadLink[]>([]);
  const downloadRequestIdRef = useRef<number>(0);
  const [flixStartAt, setFlixStartAt] = useState<number>(0);
  const [movieboxStreamUrl, setMovieboxStreamUrl] = useState<string>('');
  const [autoPlayEnabled, setAutoPlayEnabled] = useState<boolean>(() => {
    if (isAuthenticated && serverPrefs) return serverPrefs.autoPlay;
    try {
      const v = localStorage.getItem('toonplay_auto_play');
      return v === null ? true : v === 'true';
    } catch { return true; }
  });
  const [autoNextEnabled, setAutoNextEnabled] = useState<boolean>(() => {
    if (isAuthenticated && serverPrefs) return serverPrefs.autoNext;
    try {
      const v = localStorage.getItem('toonplay_auto_next');
      return v === null ? true : v === 'true';
    } catch { return true; }
  });
  const [autoSkipEnabled, setAutoSkipEnabled] = useState<boolean>(() => {
    if (isAuthenticated && serverPrefs) return serverPrefs.autoSkip;
    try {
      const v = localStorage.getItem('toonplay_auto_skip');
      return v === null ? true : v === 'true';
    } catch { return true; }
  });

  useEffect(() => {
    if (!isAuthenticated || !serverPrefs) return;
    setAutoPlayEnabled(serverPrefs.autoPlay);
    setAutoNextEnabled(serverPrefs.autoNext);
    setAutoSkipEnabled(serverPrefs.autoSkip);
    try {
      localStorage.setItem('toonplay_auto_play', String(serverPrefs.autoPlay));
      localStorage.setItem('toonplay_auto_next', String(serverPrefs.autoNext));
      localStorage.setItem('toonplay_auto_skip', String(serverPrefs.autoSkip));
    } catch {}
  }, [isAuthenticated, serverPrefs?.autoPlay, serverPrefs?.autoNext, serverPrefs?.autoSkip]);

  const handleToggleAutoPlay = useCallback(() => {
    const next = !autoPlayEnabled;
    setAutoPlayEnabled(next);
    try { localStorage.setItem('toonplay_auto_play', String(next)); } catch {}
    if (isAuthenticated) {
      userApi.updatePreferences({ auto_play: next }).catch(() => {});
    }
  }, [autoPlayEnabled, isAuthenticated]);

  const handleToggleAutoNext = useCallback(() => {
    const next = !autoNextEnabled;
    setAutoNextEnabled(next);
    try { localStorage.setItem('toonplay_auto_next', String(next)); } catch {}
    if (isAuthenticated) {
      userApi.updatePreferences({ auto_next: next }).catch(() => {});
    }
  }, [autoNextEnabled, isAuthenticated]);

  const handleToggleAutoSkip = useCallback(() => {
    const next = !autoSkipEnabled;
    setAutoSkipEnabled(next);
    try { localStorage.setItem('toonplay_auto_skip', String(next)); } catch {}
    if (isAuthenticated) {
      userApi.updatePreferences({ auto_skip: next }).catch(() => {});
    }
  }, [autoSkipEnabled, isAuthenticated]);

  const lastRecordedHistoryKeyRef = useRef<string>('');
  const autoNextGuardRef = useRef<string>('');

  const switchGuardRef = useRef<number>(0);
  const releaseSwitchGuard = useCallback((delayMs = 0) => {
    if (delayMs <= 0) {
      switchGuardRef.current = 0;
      return;
    }
    window.setTimeout(() => {
      switchGuardRef.current = 0;
    }, delayMs);
  }, []);

  const iframeRef = useRef<HTMLIFrameElement | null>(null);
  const langSpamIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const languageSwitchTimerRef = useRef<NodeJS.Timeout | null>(null);
  const lastPostedRef = useRef<{ lang: string; key: string } | null>(null);
  const flixResumeKeyRef = useRef<string>('');
  const flixLastSavedTRef = useRef<number>(0);
  const episodesContainerRef = useRef<HTMLDivElement | null>(null);
  const selectedLanguageRef = useRef(selectedLanguage);
  const availableLanguagesRef = useRef(availableLanguages);

  const isMovie = String(anime?.type ?? '').toLowerCase() === 'movie';

  const infoSource = useMemo(() => detectInfoSource(id), [id]);
  const isReanimeId = infoSource === 'reanime';
  const isMovieboxId = infoSource === 'moviebox';

  const hasRealSeasons =
    Array.isArray(anime?.seasonsList) &&
    anime.seasonsList.length > 0;
  const hasEpisodes =
    !isMovie &&
    Array.isArray(anime?.seasonsList) &&
    anime.seasonsList.some(
      (s) => Array.isArray(s.episodes) && s.episodes.length > 0
    );

  useEffect(() => {
    if (!isMovieboxId) return;

    const onAudioSelect = (ev: Event) => {
const detail = (ev as CustomEvent<{
  subjectId: string;
  detailPath: string;
  label: string;
  lanCode?: string;
}>).detail;

if (!detail?.subjectId || !detail?.detailPath) return;

const se = isMovie ? 0 : currentSeasonNumber;
const ep = isMovie ? 0 : currentEpisodeNumber;

const next = buildMovieboxStreamUrl(
  detail.subjectId,
  detail.detailPath,
  se,
  ep
);

if (detail.lanCode) {
  const language = canonicalLangCode(detail.lanCode);

  try {
    localStorage.setItem(`toonplay_moviebox_audio:${id}`, language);
  } catch {}

  setSelectedLanguage(language);

  const params = new URLSearchParams(window.location.search);
  params.set('lang', language);

  replaceWatchPageUrl(
    null,
    '',
    `${window.location.pathname}?${params.toString()}`
  );
}

setMovieboxActiveAudioKey(null);

setMovieboxStreamUrl(next);
setReloadKey((k) => k + 1);
    };

const onAudioOptions = (ev: Event) => {
  const detail = (ev as CustomEvent<{
    options: MergedAudioOption[];
    activeLabel: string | null;
    activeAudioKey: string | null;
  }>).detail;

  const opts = detail?.options || [];
  const activeKey = detail?.activeAudioKey || null;

  setMovieboxMergedOptions(opts);
  setMovieboxActiveAudioKey(activeKey);

  const langs: LanguageOption[] = opts.map((o) => ({
    code: o.lanCode || '',
    name: o.label || 'Audio',
    audioKey: o.audioKey,
  }));

  setAvailableLanguages(langs);

// Restore the previously selected Moviebox audio language.
// This runs when a title is opened from History or Continue Watching.
const activeOption = activeKey
  ? opts.find((o) => o.audioKey === activeKey)
  : null;

let savedLanguage = '';

try {
  savedLanguage =
    localStorage.getItem(`toonplay_moviebox_audio:${id}`) || '';
} catch {}

const urlLanguage = new URLSearchParams(window.location.search).get('lang') || '';
const preferredLanguage = canonicalLangCode(savedLanguage || urlLanguage);

const activeLanguage = activeOption?.lanCode
  ? canonicalLangCode(activeOption.lanCode)
  : '';

if (preferredLanguage && activeLanguage !== preferredLanguage) {
  const restoreToken = `${id}:${preferredLanguage}`;

  if (movieboxAudioRestoreAttemptRef.current !== restoreToken) {
    const target =
      opts.find(
        (o) =>
          o.kind === 'outer' &&
          canonicalLangCode(o.lanCode || '') === preferredLanguage
      ) ||
      opts.find(
        (o) =>
          o.kind === 'in-manifest' &&
          canonicalLangCode(o.lanCode || '') === preferredLanguage
      );

    if (target) {
      movieboxAudioRestoreAttemptRef.current = restoreToken;

      if (
        target.kind === 'outer' &&
        target.subjectId &&
        target.detailPath
      ) {
        window.dispatchEvent(
          new CustomEvent('toonplay:moviebox-audio-select', {
            detail: {
              subjectId: target.subjectId,
              detailPath: target.detailPath,
              label: target.label,
              lanCode: target.lanCode,
            },
          })
        );
      } else if (
        target.kind === 'in-manifest' &&
        typeof target.trackIndex === 'number'
      ) {
        window.dispatchEvent(
          new CustomEvent('toonplay:moviebox-in-manifest-audio', {
            detail: {
              trackIndex: target.trackIndex,
              label: target.label,
            },
          })
        );
      }

      return;
    }
  }
}

if (activeOption?.lanCode) {
  const language = canonicalLangCode(activeOption.lanCode);
  setSelectedLanguage(language);

  const params = new URLSearchParams(window.location.search);
  params.set('lang', language);

  replaceWatchPageUrl(
    null,
    '',
    `${window.location.pathname}?${params.toString()}`
  );
}
};

const onAudioUserSelected = (ev: Event) => {
  const detail = (ev as CustomEvent<{ lanCode?: string }>).detail;

  if (!detail?.lanCode) return;

  try {
    localStorage.setItem(
      `toonplay_moviebox_audio:${id}`,
      canonicalLangCode(detail.lanCode)
    );
  } catch {}
};

window.addEventListener(
  'toonplay:moviebox-audio-user-selected',
  onAudioUserSelected
);

    window.addEventListener('toonplay:moviebox-audio-select', onAudioSelect);
    window.addEventListener('toonplay:moviebox-audio-options', onAudioOptions);
    return () => {
window.removeEventListener('toonplay:moviebox-audio-select', onAudioSelect);
window.removeEventListener('toonplay:moviebox-audio-options', onAudioOptions);
window.removeEventListener(
  'toonplay:moviebox-audio-user-selected',
  onAudioUserSelected
);
    };
  }, [isMovieboxId, isMovie, currentSeasonNumber, currentEpisodeNumber, id]);

  const isFlixCloud = (url: string) =>
    String(url || '').toLowerCase().includes('flixcloud.');

  const flixCloudSupportsGetTime = (url: string) =>
    isFlixCloud(url);

  const buildFlixCloudUrl = useCallback(
    (rawUrl: string, opts: { autoPlay: boolean; autoSkip: boolean; startAt?: number }) => {
      try {
        const url = new URL(rawUrl);
        if (opts.autoPlay) url.searchParams.set('autoPlay', 'true');
        if (opts.autoSkip) {
          url.searchParams.set('skI', 'true');
          url.searchParams.set('skO', 'true');
        }
        if (opts.startAt && opts.startAt > 0) {
          url.searchParams.set('start_at', String(Math.floor(opts.startAt)));
        }
        return url.toString();
      } catch {
        return rawUrl;
      }
    },
    []
  );

  const parseUrlParams = useCallback(() => {
    const searchParams = new URLSearchParams(window.location.search);
    const rawServer = searchParams.get('server') || 'multi-1';
    const langParam = searchParams.get('lang') || '';
    const seasonRaw = searchParams.get('season');
    const epRaw = searchParams.get('ep');

    setSelectedServerKey(rawServer);
    if (langParam) setSelectedLanguage(canonicalLangCode(langParam));
    if (seasonRaw != null) {
      const seasonParam = parseInt(seasonRaw, 10);
      if (!isNaN(seasonParam) && seasonParam >= 1) setCurrentSeasonNumber(seasonParam);
    }
    if (epRaw != null) {
      const epParam = parseInt(epRaw, 10);
      if (!isNaN(epParam) && epParam >= 1) setCurrentEpisodeNumber(epParam);
    }
  }, []);

  useEffect(() => {
    parseUrlParams();
  }, [parseUrlParams]);

  const updateUrl = useCallback(
    (opts: { server?: string; lang?: string; season?: number; ep?: number }) => {
      const currentParams = new URLSearchParams(window.location.search);

      const serverVal = opts.server !== undefined ? opts.server : currentParams.get('server') || selectedServerKey;
      const langVal = opts.lang !== undefined ? opts.lang : currentParams.get('lang') || selectedLanguage;
      const seasonVal = opts.season !== undefined ? opts.season : currentSeasonNumber;
      const epVal = opts.ep !== undefined ? opts.ep : currentEpisodeNumber;

      const newParams = new URLSearchParams();
      if (hasRealSeasons) {
        newParams.set('season', String(seasonVal));
      }
      if (hasEpisodes) {
        newParams.set('ep', String(epVal));
      }
      newParams.set('server', serverVal);
      newParams.set('lang', langVal);

      const anilistFromUrl = currentParams.get('anilistid');

      const hasSeasonAniListMap =
        !isReanimeId &&
        !isMovieboxId &&
        anime?.season_anilist_ids &&
        Object.keys(anime.season_anilist_ids).length > 0;

      let anilistToUse: string | null = null;

      if (hasSeasonAniListMap) {
        const resolvedId = getSeasonAniListId(
          anime,
          isMovie ? 1 : seasonVal,
          isMovie ? 1 : epVal
        );

        anilistToUse = resolvedId ? String(resolvedId) : null;
      } else {
        const anilistFromAnime =
          anime?.anilist_id != null && Number(anime.anilist_id) > 0
            ? String(anime.anilist_id)
            : null;

        anilistToUse = anilistFromUrl || anilistFromAnime;
      }

      if (anilistToUse) {
        newParams.set('anilistid', anilistToUse);
      }

      const newRelativePath = `${window.location.pathname}?${newParams.toString()}`;
      replaceWatchPageUrl(null, '', newRelativePath);

      if (opts.server !== undefined) setSelectedServerKey(opts.server);
      if (opts.lang !== undefined) setSelectedLanguage(opts.lang);
      if (opts.season !== undefined) setCurrentSeasonNumber(opts.season);
      if (opts.ep !== undefined) setCurrentEpisodeNumber(opts.ep);
    },
    [
      isMovie,
      isReanimeId,
      isMovieboxId,
      selectedServerKey,
      selectedLanguage,
      currentSeasonNumber,
      currentEpisodeNumber,
      anime,
      hasRealSeasons,
      hasEpisodes,
    ]
  );

const loadAnime = useCallback(async () => {
  if (!id) return;

  const requestId = ++animeRequestIdRef.current;

  setAnime(null);
  setIsLoadingAnime(true);
  setAnimeError(null);
    onWatchPageLoadingChange?.(true);

    const isLocalId = /^(anime|movies?|series)[-_]/i.test(id);
    const looksReanime = !isLocalId;

    const urlAnilistRaw = new URLSearchParams(window.location.search).get('anilistid');
    const urlAnilist =
      urlAnilistRaw && Number(urlAnilistRaw) > 0 ? Number(urlAnilistRaw) : null;

    try {
      let res = await fetchAnimeInfo(id, isLocalId ? null : urlAnilist, cleanSubjectId);
if (
  isLocalId &&
  res?.success &&
  res.anime &&
  (!res.anime.watchServers || res.anime.watchServers.length === 0)
) {
  const responseAnilist =
    res.anime.anilist_id != null && Number(res.anime.anilist_id) > 0
      ? Number(res.anime.anilist_id)
      : null;
  const retryAnilist = responseAnilist ?? urlAnilist;

  if (retryAnilist != null && retryAnilist > 0) {
    const retry = await fetchAnimeInfo(id, retryAnilist, cleanSubjectId);
    if (retry?.success && retry.anime) res = retry;
  }
}
      if (
        !isLocalId &&
        res?.success &&
        res.anime &&
        (!res.anime.seasonsList || res.anime.seasonsList.length === 0)
      ) {
        const responseAnilist =
          res.anime.anilist_id != null && Number(res.anime.anilist_id) > 0
            ? Number(res.anime.anilist_id)
            : null;
        const retryAnilist = responseAnilist ?? urlAnilist;

        if (
          retryAnilist != null &&
          retryAnilist > 0 &&
          retryAnilist !== urlAnilist
        ) {
          const retry = await fetchAnimeInfo(id, retryAnilist, cleanSubjectId);
          if (retry?.success && retry.anime) res = retry;
        }
      }

if (requestId !== animeRequestIdRef.current) return;

if (res && res.success && res.anime) {
  setAnime(res.anime);
        updateMetadataForRoute(window.location.pathname, {
          animeTitle: res.anime.title,
          animeType: String(res.anime.type || '').trim().toUpperCase(),
          animeImage: res.anime.backdrop || res.anime.image,
        });
      } else {
        throw new Error('Title details not found');
      }
    } catch (err: any) {
      setAnimeError(err?.message || 'Failed to load title stream information');
} finally {
  if (requestId === animeRequestIdRef.current) {
    setIsLoadingAnime(false);
    onWatchPageLoadingChange?.(false);
  }
}
  }, [id, onWatchPageLoadingChange, cleanSubjectId]);

useEffect(() => {
  loadAnime();

  return () => {
    animeRequestIdRef.current += 1;
  };
}, [loadAnime]);

  useEffect(() => {
    if (!anime) return;

    const params = new URLSearchParams(window.location.search);
    const urlAnilist = params.get('anilistid');

    const hasSeasonAniListMap =
      !isReanimeId &&
      !isMovieboxId &&
      anime.season_anilist_ids &&
      Object.keys(anime.season_anilist_ids).length > 0;

    if (hasSeasonAniListMap) {
      const hasExplicitSeasonAndEpisode =
        params.has('season') && params.has('ep');

      // Only resolve a multi-season ID when the URL specifies
      // the requested season and episode.
      if (!hasExplicitSeasonAndEpisode) return;

      const season = Number(params.get('season'));
      const episode = Number(params.get('ep'));

      if (
        !Number.isInteger(season) ||
        season < 1 ||
        !Number.isInteger(episode) ||
        episode < 1
      ) {
        return;
      }

      const resolvedId = getSeasonAniListId(anime, season, episode);

      if (resolvedId) {
        params.set('anilistid', String(resolvedId));
        replaceWatchPageUrl(
          null,
          '',
          `${window.location.pathname}?${params.toString()}`
        );
      }

      return;
    }

    // Preserve existing single-ID behaviour.
    if (urlAnilist) return;
    if (anime.anilist_id == null || Number(anime.anilist_id) <= 0) return;

    params.set('anilistid', String(anime.anilist_id));

    replaceWatchPageUrl(
      null,
      '',
      `${window.location.pathname}?${params.toString()}`
    );
  }, [anime, isReanimeId, isMovieboxId]);

  const activeSeason: AnimeSeasonItem | undefined = useMemo(() => {
    if (!anime?.seasonsList || anime.seasonsList.length === 0) return undefined;
    return (
      anime.seasonsList.find((s) => parseInt(s.season, 10) === currentSeasonNumber) ||
      anime.seasonsList[0]
    );
  }, [anime, currentSeasonNumber]);

  const activeEpisode: AnimeEpisodeItem | undefined = useMemo(() => {
    if (!activeSeason?.episodes || activeSeason.episodes.length === 0) return undefined;
    return (
      activeSeason.episodes.find((e) => e.number === currentEpisodeNumber) ||
      activeSeason.episodes[0]
    );
  }, [activeSeason, currentEpisodeNumber]);

  // Sync FlixCloud resume key + start_at whenever episode/movie context changes.
  // Default is 0; if a saved watch time exists, it becomes the iframe's start_at.
  useEffect(() => {
    if (!anime) {
      flixResumeKeyRef.current = '';
      flixLastSavedTRef.current = 0;
      setFlixStartAt(0);
      return;
    }
    const seasonNum = hasRealSeasons
      ? parseInt(String(activeSeason?.season), 10) || 1
      : null;
    const epNum = isMovie ? null : activeEpisode?.number ?? currentEpisodeNumber ?? null;

    const key = makeFlixResumeKey({
      animeId: anime.id,
      season: seasonNum,
      episode: epNum,
      isMovie,
    });
    flixResumeKeyRef.current = key;
    flixLastSavedTRef.current = 0;
    setFlixStartAt(readFlixResume(key));
  }, [
    anime?.id,
    activeSeason?.season,
    activeEpisode?.number,
    currentEpisodeNumber,
    isMovie,
    hasRealSeasons,
  ]);

  const loadServersForCurrentContext = useCallback(async () => {
    if (!anime) return;

    setIsLoadingExtract(true);
    setExtractError(null);
    setWatchServers([]);
    setStreamServerMap({});

    if (isMovieboxId) {
if (isMovie) {
  const srv = anime.watchServers?.[0];
  if (srv?.url) {
    const serverName = 'Multi';
    const key = buildServerType(serverName, '') || 'multi';

    setWatchServers([{ name: serverName, url: srv.url }]);
    setStreamServerMap({
      [key]: {
        name: serverName,
        langUrls: { '': srv.url },
        defaultLang: '',
      },
    });
    setSelectedServerKey(key);
    setSelectedLanguage('');
        const full = srv.url.startsWith('http')
      ? srv.url
      : `${MOVIEBOX_API_BASE}${srv.url}`;

    const requestedLanguage =
      new URLSearchParams(window.location.search).get('lang') || '';

    const resolvedUrl = await resolveMovieboxStreamUrlForLanguage(
      full,
      requestedLanguage
    );

    setMovieboxStreamUrl(resolvedUrl);
    setIsLoadingExtract(false);
    return;
  }
        setExtractError('No stream mirror available for this movie.');
        setIsLoadingExtract(false);
        return;
      }
      if (!activeEpisode) {
        setExtractError('No episode available.');
        setIsLoadingExtract(false);
        return;
      }

const episodeStreamUrl =
  activeEpisode?.id
    ? `/api/stream?subjectId=${activeEpisode.id}`
    : activeSeason?.link || '';


if (episodeStreamUrl) {
  const serverName = 'Multi';
  const key = buildServerType(serverName, '') || 'multi';

  setWatchServers([{ name: serverName, url: episodeStreamUrl }]);
  setStreamServerMap({
    [key]: {
      name: serverName,
      langUrls: { '': episodeStreamUrl },
      defaultLang: '',
    },
  });
  setSelectedServerKey(key);
  setSelectedLanguage('');

        const full = episodeStreamUrl.startsWith('http')
          ? episodeStreamUrl
          : `${MOVIEBOX_API_BASE}${episodeStreamUrl}`;

        const requestedLanguage =
          new URLSearchParams(window.location.search).get('lang') || '';

        const resolvedUrl = await resolveMovieboxStreamUrlForLanguage(
          full,
          requestedLanguage
        );

        setMovieboxStreamUrl(resolvedUrl);
        setIsLoadingExtract(false);
        return;
      }

      setExtractError('No stream mirror available for this episode.');
      setIsLoadingExtract(false);
      return;
    }

    const requestedSeason =
      parseInt(String(activeSeason?.season), 10) || currentSeasonNumber || 1;

    const requestedEpisode =
      activeEpisode?.number ?? currentEpisodeNumber ?? 1;

    const anilistId =
      !isMovieboxId
        ? getSeasonAniListId(
            anime,
            isMovie ? 1 : requestedSeason,
            isMovie ? 1 : requestedEpisode
          )
        : (
            anime.anilist_id != null && Number(anime.anilist_id) > 0
              ? Number(anime.anilist_id)
              : null
          );

    const fallbackEpisodeNumber =
      !isMovie && !isMovieboxId
        ? getSeasonAniListEpisodeNumber(
            anime,
            requestedSeason,
            requestedEpisode
          )
        : 1;

const applyStreamServers = (mapped: MappedStreamServer[]) => {
  const newWatchServers: AnimeWatchServer[] = mapped.map((m) => {
    const preferredLang =
      m.langUrls['jpn'] ? 'jpn'
      : Object.keys(m.langUrls)[0];
    return { name: m.name, url: m.langUrls[preferredLang], lang: preferredLang };
  });

  const mapByKey: Record<string, MappedStreamServer> = {};
  mapped.forEach((m) => {
    const langKeys = Object.keys(m.langUrls);
    if (langKeys.length === 0) {
      const composite = buildServerType(m.name, '');
      if (composite) mapByKey[composite] = m;
      return;
    }
    langKeys.forEach((langCode) => {
      const composite = buildServerType(m.name, langCode);
      if (composite) mapByKey[composite] = m;
    });
  });

  setStreamServerMap(mapByKey);
  setWatchServers(newWatchServers);

  const urlServer = new URLSearchParams(window.location.search).get('server') || '';
  const urlIsComposite = urlServer && !/^multi-\d+$/i.test(urlServer);

  if (!urlIsComposite && mapped.length > 0) {
    const firstLang =
      mapped[0].langUrls['jpn'] ? 'jpn'
      : Object.keys(mapped[0].langUrls)[0];
    const firstKey = buildServerType(mapped[0].name, firstLang);
    if (firstKey) {
      setSelectedServerKey(firstKey);
      if (firstLang) setSelectedLanguage(firstLang);
      const params = new URLSearchParams(window.location.search);
      params.set('server', firstKey);
      if (firstLang) params.set('lang', firstLang);
const selectedAniListId =
  !isMovieboxId
    ? getSeasonAniListId(
        anime,
        isMovie ? 1 : requestedSeason,
        isMovie ? 1 : requestedEpisode
      )
    : (
        anime?.anilist_id != null && Number(anime.anilist_id) > 0
          ? Number(anime.anilist_id)
          : null
      );

      if (selectedAniListId) {
        params.set('anilistid', String(selectedAniListId));
      }
      replaceWatchPageUrl(null, '', `${window.location.pathname}?${params.toString()}`);
    }
  }
};

    if (isMovie) {
      if (
        !isReanimeId &&
        anime.watchServers &&
        anime.watchServers.length > 0
      ) {
        setWatchServers(anime.watchServers);
        setIsLoadingExtract(false);
        return;
      }
      if (anilistId) {
        try {
          const streamRes = await fetchStreamServers(anilistId, 1);
          if (
            streamRes?.success &&
            Array.isArray(streamRes.servers) &&
            streamRes.servers.length > 0
          ) {
            const mapped = mapStreamServers(streamRes.servers);
            if (mapped.length > 0) {
              applyStreamServers(mapped);
              setIsLoadingExtract(false);
              return;
            }
          }
        } catch { /* fall through */ }
      }
      setExtractError('No stream mirrors available for this movie.');
      setIsLoadingExtract(false);
      return;
    }

    // ── SERIES ──
    if (!activeEpisode) {
      setExtractError('No episode available.');
      setIsLoadingExtract(false);
      return;
    }

    // 1. Try extract (episodeId or season.link present)
    //    SKIP ENTIRELY for reanime ids — reanime always uses /api/stream.
    const hasEpId = Boolean(activeEpisode.id);
    const hasSeasonLink = Boolean(activeSeason?.link);

    if (!isReanimeId && (hasEpId || hasSeasonLink)) {
if (isCustomEpisodeId(activeEpisode.id)) {
  try {
    const extractRes = await fetchEpisodeExtractById(activeEpisode.id!);
    if (extractRes?.success && extractRes.data?.watchServers?.length) {
      const servers = extractRes.data.watchServers;
      const allMega = servers.every(
        (s) => s?.url && String(s.url).toLowerCase().includes('mega')
      );

      if (!allMega) {
        setWatchServers(servers);
        setIsLoadingExtract(false);
        return;
      }

      if (anilistId) {
      } else {
        setWatchServers(servers);
        setIsLoadingExtract(false);
        return;
      }
    }
  } catch { /* fall through to /api/stream */ }
} else {
  // ── Legacy IDs → build a URL and use ?url= ──
  const episodeUrl = buildEpisodeUrl(
    activeSeason?.link || '',
    activeEpisode.id || undefined,
    parseInt(String(activeSeason?.season), 10) || 1,
    activeEpisode.number
  );
  if (episodeUrl) {
    try {
      const extractRes = await fetchEpisodeExtract(episodeUrl);
      if (extractRes?.success && extractRes.data?.watchServers?.length) {
        const servers = extractRes.data.watchServers;

        // Only skip extract if EVERY server is mega-hosted.
        const allMega = servers.every(
          (s) => s?.url && String(s.url).toLowerCase().includes('mega')
        );

        if (!allMega) {
          setWatchServers(servers);
          setIsLoadingExtract(false);
          return;
        }

        if (anilistId) {
          // fall through to /api/stream
        } else {
          setWatchServers(servers);
          setIsLoadingExtract(false);
          return;
        }
      }
    } catch { /* fall through to /api/stream */ }
  }
}
    }

    // 2. Fallback: /api/stream (only when anilist_id present)
    if (anilistId) {
      try {
        const streamRes = await fetchStreamServers(
          anilistId,
          fallbackEpisodeNumber
        );
        if (
          streamRes?.success &&
          Array.isArray(streamRes.servers) &&
          streamRes.servers.length > 0
        ) {
          const mapped = mapStreamServers(streamRes.servers);
          if (mapped.length > 0) {
            applyStreamServers(mapped);
            setIsLoadingExtract(false);
            return;
          }
        }
      } catch { /* fall through */ }
    }

    setExtractError('No stream mirrors available for this episode.');
    setIsLoadingExtract(false);
  }, [
    anime,
    isMovie,
    isMovieboxId,
    isReanimeId,
    activeSeason,
    activeEpisode,
    currentSeasonNumber,
    currentEpisodeNumber,
  ]);

  useEffect(() => {
    if (anime) {
      loadServersForCurrentContext();
    }
  }, [anime, loadServersForCurrentContext]);

const serverIndex = useMemo(() => {
  if (watchServers.length === 0) return 0;

  const parsed = parseServerType(selectedServerKey);
  const targetBase = parsed?.serverKey || selectedServerKey;

  const idx = watchServers.findIndex((s) => {
    const base = buildServerType(s.name || '', '');
    return base === targetBase;
  });

  return idx >= 0 ? idx : 0;
}, [selectedServerKey, watchServers]);

  const activeServer: AnimeWatchServer | undefined = watchServers[serverIndex] || watchServers[0];

useEffect(() => {
  if (switchGuardRef.current > 0) return;
  if (watchServers.length === 0) return;
  const urlServer = new URLSearchParams(window.location.search).get('server') || '';
  if (!urlServer) return;

  // Legacy bookmark? Ignore bare multi-N — no longer produced.
  if (/^multi-\d+$/i.test(urlServer)) return;

  const parsed = parseServerType(urlServer);
  if (!parsed?.serverKey) return;

  const idx = watchServers.findIndex((s) => {
    const base = buildServerType(s.name || '', '');
    return base === parsed.serverKey;
  });

  if (idx >= 0) {
    // Reconstruct the exact composite for this slot
    const name = watchServers[idx].name || '';
    const lang = parsed.lang || watchServers[idx].lang || '';
    const composite = buildServerType(name, lang) || urlServer;
    if (composite !== selectedServerKey) setSelectedServerKey(composite);
    if (parsed.lang && parsed.lang !== selectedLanguage) setSelectedLanguage(parsed.lang);

    // Also swap the URL for this slot to the correct lang URL
    const entry = streamServerMap[urlServer] || streamServerMap[composite];
    if (entry) {
      const langCode = (parsed.lang || '').toLowerCase();
      const targetUrl =
        entry.langUrls[langCode] ||
        entry.langUrls[parsed.lang] ||
        entry.langUrls[Object.keys(entry.langUrls)[0]];
      if (targetUrl) {
        setWatchServers((prev) => {
          const cur = prev[idx];
          const nextLang = langCode || cur?.lang;
          if (cur && cur.url === targetUrl && cur.lang === nextLang) return prev;
          return prev.map((s, i) =>
            i === idx
              ? { ...s, url: targetUrl, lang: nextLang }
              : s
          );
        });
      }
    }
  }
}, [watchServers, streamServerMap]);

const currentServerType = useMemo(() => {
  if (!selectedServerKey) return null;
  const parsed = parseServerType(selectedServerKey);
  if (!parsed?.serverKey) return null;
  const lang = selectedLanguage || parsed.lang || '';
  return buildServerType(parsed.serverKey, lang) || selectedServerKey;
}, [selectedServerKey, selectedLanguage]);

  const decodeAbyssLanguages = useCallback((urlStr: string): LanguageOption[] => {
    try {
      const parsedUrl = new URL(urlStr);
      const dataParam = parsedUrl.searchParams.get('data');
      if (!dataParam) return [];

      const rawJson = atob(decodeURIComponent(dataParam));
      const parsed = JSON.parse(rawJson);

      if (Array.isArray(parsed)) {
        return parsed
          .filter((item) => item && typeof item.language === 'string')
          .map((item) => {
            const clean = item.language.trim();
            const lower = clean.toLowerCase();
            const code = canonicalLangCode(RAVOK_CODE_MAP[lower] || lower.slice(0, 3));
            return { code, name: clean };
          });
      }
      return [];
    } catch {
      return [];
    }
  }, []);

const loadServerLanguages = useCallback(async () => {
  if (isMovieboxId) return;
  if (switchGuardRef.current > 0) return;
    if (!activeServer?.url) {
      setAvailableLanguages([]);
      return;
    }

    let streamEntry = streamServerMap[selectedServerKey];
    if (!streamEntry) {
      const parsedSel = parseServerType(selectedServerKey);
      const targetBase =
        parsedSel?.serverKey ||
        buildServerType(activeServer?.name || '', '') ||
        '';
      if (targetBase) {
        for (const [k, v] of Object.entries(streamServerMap)) {
          const parsedK = parseServerType(k);
          if (parsedK?.serverKey === targetBase) {
            streamEntry = v;
            break;
          }
        }
      }
    }
    if (!streamEntry && Object.keys(streamServerMap).length > 0) {
      streamEntry = Object.values(streamServerMap)[0];
    }
    if (streamEntry) {
      const langs: LanguageOption[] = Object.keys(streamEntry.langUrls).map((code) => ({
        code,
        name: STREAM_LANG_LABEL[code] || code.toUpperCase(),
      }));
      setAvailableLanguages(langs);
      if (langs.length > 0) {
        const hasCurrent = langs.some(
          (l) =>
            l.code.toLowerCase() === selectedLanguage.toLowerCase() ||
            l.name.toLowerCase() === selectedLanguage.toLowerCase()
        );
if (!hasCurrent) {
  const jap = langs.find((l) => l.code === 'jpn');
  const def = jap || langs[0];

  const newServerKey = buildServerType(
    activeServer?.name || '',
    def.code
  );

  setSelectedLanguage(def.code);

  if (newServerKey) {
    setSelectedServerKey(newServerKey);
    updateUrl({
      server: newServerKey,
      lang: def.code,
    });
  } else {
    updateUrl({ lang: def.code });
  }
}
      }
      return;
    }

    const rawUrl = activeServer.url;
    const isAbyss = rawUrl.toLowerCase().includes('animesalt');
    const isRavok = rawUrl.includes('/video/');
    const isMega =
      rawUrl.toLowerCase().includes('megaplay') ||
      rawUrl.toLowerCase().includes('megacloud');

    if (isMega && !isAbyss && !isRavok) {
      const megaLang = /\/dub\/?$/i.test(rawUrl) ? 'eng' : 'jpn';
      const megaLangLabel = megaLang === 'eng' ? 'English' : 'Japanese';

      setAvailableLanguages([{ code: megaLang, name: megaLangLabel }]);

      const currentLower = selectedLanguage.toLowerCase();
      if (currentLower !== megaLang) {
        setSelectedLanguage(megaLang);
        updateUrl({ lang: megaLang });
      }
      return;
    }

    if (isAbyss) {
      const langs = decodeAbyssLanguages(rawUrl);
      setAvailableLanguages(langs);

      if (langs.length > 0) {
        const hasCurrent = langs.some(
          (l) =>
            l.code.toLowerCase() === selectedLanguage.toLowerCase() ||
            l.name.toLowerCase() === selectedLanguage.toLowerCase()
        );

        if (!hasCurrent) {
          const hindiMatch = langs.find((l) => l.name.toLowerCase() === 'hindi');
          const defaultOpt = hindiMatch || langs[0];
          setSelectedLanguage(defaultOpt.code);
          updateUrl({ lang: defaultOpt.code });
        }
      }
    } else if (isRavok) {
      const match = rawUrl.match(/\/video\/([a-zA-Z0-9_-]+)/);
      const videoId = match ? match[1] : '';

      if (videoId) {
        const res = await fetchRavokLanguages(videoId);
        const rawTracks = res.tracks || [
          { code: 'hin', name: 'Hindi' },
          { code: 'eng', name: 'English' },
          { code: 'jpn', name: 'Japanese' },
        ];
        const tracks = rawTracks.map((t) => ({
          code: canonicalLangCode(t.code),
          name: t.name,
        }));
        setAvailableLanguages(tracks);

        const hasCurrent = tracks.some(
          (t) =>
            t.code.toLowerCase() === selectedLanguage.toLowerCase() ||
            t.name.toLowerCase() === selectedLanguage.toLowerCase()
        );

        if (!hasCurrent && tracks.length > 0) {
          const hindiMatch = tracks.find(
            (t) => t.code === 'hin' || t.name.toLowerCase() === 'hindi'
          );
          const defaultOpt = hindiMatch || tracks[0];
          setSelectedLanguage(defaultOpt.code);
          updateUrl({ lang: defaultOpt.code });
        }
      } else {
        setAvailableLanguages([
          { code: 'hin', name: 'Hindi' },
          { code: 'eng', name: 'English' },
          { code: 'jpn', name: 'Japanese' },
        ]);
      }
    } else {
      setAvailableLanguages([
        { code: 'hin', name: 'Hindi' },
        { code: 'eng', name: 'English' },
        { code: 'jpn', name: 'Japanese' },
      ]);
    }
  }, [isMovieboxId, activeServer, selectedLanguage, decodeAbyssLanguages, updateUrl, streamServerMap, selectedServerKey]);

useEffect(() => {
  if (switchGuardRef.current > 0) return;
  loadServerLanguages();
}, [loadServerLanguages, isSwitchingLanguage]);
  
useEffect(() => {
  if (switchGuardRef.current > 0) return;
  if (!anime) return;

  if (isMovie) {
    if (watchServers.length === 0) return;

    const langVal = selectedLanguage || availableLanguages[0]?.code || '';
    if (!langVal) return; 

    const activeSrv = watchServers[serverIndex];
    if (!activeSrv) return;

    const composite = buildServerType(activeSrv.name || '', langVal);
    if (!composite) return;

    const currentParams = new URLSearchParams(window.location.search);

    if (currentParams.get('season')) {
      currentParams.delete('season');
    }

    const alreadySynced =
      currentParams.get('server') === composite &&
      currentParams.get('lang') === langVal;

    if (alreadySynced) {
      if (selectedServerKey !== composite) setSelectedServerKey(composite);
      if (selectedLanguage !== langVal) setSelectedLanguage(langVal);
      return;
    }

    currentParams.set('server', composite);
    currentParams.set('lang', langVal);

    const anilist =
      anime.anilist_id != null && Number(anime.anilist_id) > 0
        ? String(anime.anilist_id)
        : null;
    if (anilist) currentParams.set('anilistid', anilist);

    replaceWatchPageUrl(
      null,
      '',
      `${window.location.pathname}?${currentParams.toString()}`
    );

    if (selectedServerKey !== composite) setSelectedServerKey(composite);
    if (selectedLanguage !== langVal) setSelectedLanguage(langVal);
    return;
  }

  if (!hasRealSeasons) {
    const currentParams = new URLSearchParams(window.location.search);
    if (currentParams.get('season')) {
      currentParams.delete('season');
      const anilist =
        anime.anilist_id != null && Number(anime.anilist_id) > 0
          ? String(anime.anilist_id)
          : null;
      if (anilist) currentParams.set('anilistid', anilist);
      replaceWatchPageUrl(
        null,
        '',
        `${window.location.pathname}?${currentParams.toString()}`
      );
    }
    // MovieBox: still write server + lang so the URL reflects the selected audio.
    if (isMovieboxId && selectedLanguage) {
      const params = new URLSearchParams(window.location.search);
      params.delete('season');
      params.delete('ep');
      params.set('server', selectedServerKey || 'moviebox');
      params.set('lang', selectedLanguage);
      if (
        params.get('server') !== new URLSearchParams(window.location.search).get('server') ||
        params.get('lang') !== new URLSearchParams(window.location.search).get('lang')
      ) {
        replaceWatchPageUrl(
          null,
          '',
          `${window.location.pathname}?${params.toString()}`
        );
      }
    }
    return;
  }
  if (!activeSeason || !activeEpisode) return;
  if (watchServers.length === 0) return;

  const seasonVal = parseInt(activeSeason.season, 10) || 1;
  const epVal = activeEpisode.number || 1;
  const langVal = selectedLanguage || availableLanguages[0]?.code || '';

  const activeSrv = watchServers[serverIndex];
  if (!activeSrv) return;

  const composite = buildServerType(activeSrv.name || '', langVal);
  if (!composite) return;

  const currentParams = new URLSearchParams(window.location.search);
  const alreadySynced =
    currentParams.get('season') === String(seasonVal) &&
    currentParams.get('ep') === String(epVal) &&
    currentParams.get('server') === composite &&
    (langVal === '' || currentParams.get('lang') === langVal);

  if (alreadySynced) return;

  const params = new URLSearchParams(window.location.search);
  if (!isMovie) {
    params.set('season', String(seasonVal));
    params.set('ep', String(epVal));
  }
  params.set('server', composite);
  params.set('lang', langVal);

  const anilist =
    anime.anilist_id != null && Number(anime.anilist_id) > 0
      ? String(anime.anilist_id)
      : null;
  if (anilist) params.set('anilistid', anilist);

  replaceWatchPageUrl(null, '', `${window.location.pathname}?${params.toString()}`);

  if (selectedServerKey !== composite) setSelectedServerKey(composite);
  if (langVal && selectedLanguage !== langVal) setSelectedLanguage(langVal);
}, [
  anime,
  activeSeason,
  activeEpisode,
  selectedLanguage,
  availableLanguages,
  selectedServerKey,
  serverIndex,
  watchServers,
  isMovie,
  hasRealSeasons,
  isReanimeId,
]);

  useEffect(() => {
    if (!anime || !onRecordHistory) return;

    const langVal = selectedLanguage || availableLanguages[0]?.code || undefined;
    const serverVal = currentServerType || selectedServerKey || '';

    if (isMovie) {
      const dedupeKey = `m|${anime.id}|${langVal || ''}|${serverVal}`;
      if (lastRecordedHistoryKeyRef.current === dedupeKey) return;
      lastRecordedHistoryKeyRef.current = dedupeKey;

      onRecordHistory(
        {
          id: anime.id,
          title: anime.title,
          image: anime.image,
          backdrop: anime.backdrop || anime.image,
          type: 'movie',
          displayType: String(anime.type || 'MOVIE').trim().toUpperCase(),
          overview: anime.overview,
          year: anime.year,
          anilistId:
            anime.anilist_id != null && Number(anime.anilist_id) > 0
              ? Number(anime.anilist_id)
              : undefined,
          tmdbId:
            anime.tmdb_id != null && Number(anime.tmdb_id) > 0
              ? Number(anime.tmdb_id)
              : undefined,
subjectId:
  cleanSubjectId ||
  (anime as any).subjectId ||
  extractMovieboxSubjectId(anime),
          category: 'movie',
        },
        { lang: langVal, server: currentServerType || selectedServerKey }
      );
      return;
    }

    if (!hasRealSeasons) {
      // Reanime / no-season titles: record the episode, but never a season.
      const reanimeEpisodeNum =
        Number.isFinite(activeEpisode?.number as number) &&
        (activeEpisode?.number as number) > 0
          ? (activeEpisode!.number as number)
          : undefined;
      const dedupeKey = `r|${anime.id}|${reanimeEpisodeNum ?? ''}|${activeEpisode?.id || ''}|${langVal || ''}|${serverVal}`;
      if (lastRecordedHistoryKeyRef.current === dedupeKey) return;
      lastRecordedHistoryKeyRef.current = dedupeKey;

      onRecordHistory(
        {
          id: anime.id,
          title: anime.title,
          image: anime.image,
          backdrop: anime.backdrop || anime.image,
          type: 'series',
          displayType: String(anime.type || 'SERIES').trim().toUpperCase(),
          overview: anime.overview,
          year: anime.year,
          anilistId:
            anime.anilist_id != null && Number(anime.anilist_id) > 0
              ? Number(anime.anilist_id)
              : undefined,
          tmdbId:
            anime.tmdb_id != null && Number(anime.tmdb_id) > 0
              ? Number(anime.tmdb_id)
              : undefined,
subjectId:
  cleanSubjectId ||
  (anime as any).subjectId ||
  extractMovieboxSubjectId(anime),
          category: 'series',
        },
        {
          seasonNumber: undefined,
          episodeNumber: reanimeEpisodeNum,
          episodeId: activeEpisode?.id || undefined,
          episodeTitle: activeEpisode?.title,
          episodeImage: activeEpisode?.image,
          lang: langVal,
          server: currentServerType || selectedServerKey,
        }
      );
      return;
    }

    if (!activeSeason || !activeEpisode) return;

    const rawSeasonNum = Number(activeSeason.season);
    const seasonNum =
      Number.isFinite(rawSeasonNum) && rawSeasonNum > 0
        ? rawSeasonNum
        : undefined;

    const episodeNum =
      Number.isFinite(activeEpisode.number) && activeEpisode.number > 0
        ? activeEpisode.number
        : undefined;

    const dedupeKey = `s|${anime.id}|${seasonNum ?? ''}|${episodeNum ?? ''}|${activeEpisode.id || ''}|${langVal || ''}|${serverVal}`;
    if (lastRecordedHistoryKeyRef.current === dedupeKey) return;
    lastRecordedHistoryKeyRef.current = dedupeKey;

    onRecordHistory(
      {
        id: anime.id,
        title: anime.title,
        image: anime.image,
        backdrop: anime.backdrop || anime.image,
        type: 'series',
        displayType: String(anime.type || 'SERIES').trim().toUpperCase(),
        overview: anime.overview,
        year: anime.year,
        anilistId:
          anime.anilist_id != null && Number(anime.anilist_id) > 0
            ? Number(anime.anilist_id)
            : undefined,
        tmdbId:
          anime.tmdb_id != null && Number(anime.tmdb_id) > 0
            ? Number(anime.tmdb_id)
            : undefined,
subjectId:
  cleanSubjectId ||
  (anime as any).subjectId ||
  extractMovieboxSubjectId(anime),
        category: 'series',
      },
      {
        seasonNumber: seasonNum,
        episodeNumber: episodeNum,
        episodeId: activeEpisode.id || undefined,
        episodeTitle: activeEpisode.title,
        episodeImage: activeEpisode.image,
        lang: langVal,
        server: currentServerType || selectedServerKey,
      }
    );
  }, [
    anime,
    activeSeason,
    activeEpisode,
    selectedLanguage,
    availableLanguages,
    selectedServerKey,
    currentServerType,
    onRecordHistory,
    hasRealSeasons,
  ]);

  const playerIframeSrc = useMemo(() => {
    if (!activeServer?.url) return '';
    if (isMovieboxId) return '';

    const rawUrl = activeServer.url;

    if (rawUrl.toLowerCase().includes('animesalt')) {
      return `https://animesalt.streamindia.co.in/abyss?url=${encodeURIComponent(rawUrl)}`;
    }

    if (isFlixCloud(rawUrl)) {
      return buildFlixCloudUrl(rawUrl, {
        autoPlay: autoPlayEnabled,
        autoSkip: autoSkipEnabled,
        startAt: flixStartAt,
      });
    }

    return rawUrl;
  }, [
    activeServer,
    isMovieboxId,
    autoPlayEnabled,
    autoSkipEnabled,
    flixStartAt,
    buildFlixCloudUrl,
  ]);

  const downloadApiId = useMemo(() => {
    if (!anime) return '';
    if (isMovieboxId) return '';          
    if (isMovie) return anime.id;
    return activeEpisode?.id || '';
  }, [anime?.id, isMovie, isMovieboxId, activeEpisode?.id]);

  useEffect(() => {
    if (!isDownloadOpen) return;
    if (!anime) return;

    const reqId = ++downloadRequestIdRef.current;
    setDownloadLoading(true);
    setDownloadError(null);
    setDownloadLinks([]);

    const notAvailableMsg = isMovie
      ? 'No download mirrors available for this movie.'
      : 'No download mirrors available for this episode.';

    const seasonNum = currentSeasonNumber || 1;
    const epNum = activeEpisode?.number ?? currentEpisodeNumber ?? 1;
    const customId =
  isCustomEpisodeId(activeEpisode?.id) ||
  isCustomEpisodeId(anime.id);

    (async () => {
     if (customId) {
  setDownloadLinks([]);
  setDownloadError(
    'Please use the Download icon inside the video player to download this video.'
  );
  setDownloadLoading(false);
  return;
}

if (isReanimeId) {
  setDownloadLinks([]);
  setDownloadError(notAvailableMsg);
  setDownloadLoading(false);
  return;
}
      if (anime.id) {
        const localFile = await fetchLocalDownloadFile(anime.id);
        if (reqId !== downloadRequestIdRef.current) return;

        if (localFile) {
          const seasonObj = localFile.seasons.find(
            (s) => Number(s.season) === Number(seasonNum)
          );
          const epObj = seasonObj?.episodes?.find(
            (e) => Number(e.episode) === Number(epNum)
          );

          if (epObj && epObj.sources?.length) {
            const mapped: DownloadLink[] = epObj.sources
              .filter((s) => s && s.url)
              .map((s) => ({
                server: 'Mega',
                lang: 'Multi-Audio',
                quality: s.quality || 'Auto',
                link: s.url,
              }));

            if (mapped.length > 0) {
              setDownloadLinks(mapped);
              setDownloadLoading(false);
              return;
            }
          }
        }
      }

      // ── Path C: non-custom ids → legacy /toonplay/download API ──
      if (!downloadApiId) {
        if (reqId !== downloadRequestIdRef.current) return;
        setDownloadLinks([]);
        setDownloadError(notAvailableMsg);
        setDownloadLoading(false);
        return;
      }

      try {
        const res = await fetchDownloadLinks(downloadApiId);
        if (reqId !== downloadRequestIdRef.current) return;
if (res?.success && Array.isArray(res.downloads) && res.downloads.length > 0) {
  setDownloadLinks(res.downloads);
} else {
  setDownloadLinks([]);

  const isAbyssPlayer = String(activeServer?.url || '')
    .toLowerCase()
    .includes('animesalt');

  setDownloadError(
    isAbyssPlayer
      ? 'Please use the Download icon inside the video player to download this video.'
      : notAvailableMsg
  );
}
      } catch (err: any) {
        if (reqId !== downloadRequestIdRef.current) return;
        setDownloadError(err?.message || 'Failed to load download links.');
      } finally {
        if (reqId !== downloadRequestIdRef.current) return;
        setDownloadLoading(false);
      }
    })();
  }, [
    isDownloadOpen,
    downloadApiId,
    isMovie,
    isReanimeId,
    anime?.id,
    currentSeasonNumber,
    currentEpisodeNumber,
    activeEpisode?.id,
    activeEpisode?.number,
    activeServer?.url,
  ]);

  useEffect(() => {
    if (!anime || !onWatchSessionStart) return;
    if (!activeServer?.url) return;
    if (isLoadingExtract) return; 

    const totalEpisodesAvailable =
      anime.seasonsList?.reduce(
        (sum, s) => sum + (s.episodes?.length || 0),
        0
      ) || (isMovie ? 1 : 0);

    onWatchSessionStart({
      cartoonId: anime.id,
      cartoonTitle: anime.title,
      cartoonImage: anime.image,
      cartoonType:
       String(anime.type || '').trim().toUpperCase() || (isMovie ? 'MOVIE' : 'SERIES'),
      serverType: currentServerType || undefined,
      episodeId: isMovie ? 'movie' : activeEpisode?.id,
      episodeNumber: isMovie ? undefined : activeEpisode?.number,
      seasonNumber: isMovie
        ? undefined
        : hasRealSeasons
        ? parseInt(String(activeSeason?.season), 10) || 1
        : undefined,
      episodeTitle: isMovie ? undefined : activeEpisode?.title,
      episodeImage: isMovie ? undefined : activeEpisode?.image,
      genres: anime.genres,
      totalEpisodesAvailable,
    });
  }, [
    anime?.id,
    activeEpisode?.id,
    activeServer?.url,
    isLoadingExtract,
    currentServerType,
    hasRealSeasons,
  ]);

  const postAudioLanguageCommand = useCallback(
    (langIdentifier: string) => {
      const getTargetIframe = (): HTMLIFrameElement | null => {
        return (
          iframeRef.current ||
          (document.getElementById('watchpage-active-iframe') as HTMLIFrameElement | null)
        );
      };

      if (!activeServer?.url) return;
      const rawUrl = activeServer.url;
      const isAbyss = rawUrl.toLowerCase().includes('animesalt');
      const isRavok = rawUrl.includes('/video/');
      const norm = langIdentifier.trim().toLowerCase();
      const iframeKey = `${playerIframeSrc}-${reloadKey}`;
      if (
        lastPostedRef.current &&
        lastPostedRef.current.lang === norm &&
        lastPostedRef.current.key === iframeKey
      ) {
        return;
      }
      lastPostedRef.current = { lang: norm, key: iframeKey };

      if (langSpamIntervalRef.current) {
        clearInterval(langSpamIntervalRef.current);
        langSpamIntervalRef.current = null;
      }

      if (isAbyss) {
        const normalized = langIdentifier.trim().toLowerCase();
        const mappedName =
          ABYSS_NAME_MAP[normalized] ||
          availableLanguages.find(
            (l) => l.code.toLowerCase() === normalized || l.name.toLowerCase() === normalized
          )?.name ||
          (langIdentifier.charAt(0).toUpperCase() + langIdentifier.slice(1));

        const frame = getTargetIframe();
        if (frame?.contentWindow) {
          try {
            frame.contentWindow.postMessage({ type: 'changeLanguage', language: mappedName }, '*');
          } catch {}
        }
      } else if (isRavok) {
        const normalized = langIdentifier.trim().toLowerCase();
        let code = RAVOK_CODE_MAP[normalized] || normalized;
        const matched = availableLanguages.find(
          (l) => l.code.toLowerCase() === normalized || l.name.toLowerCase() === normalized
        );
        if (matched) code = matched.code;

        const ravokPayloads = [{ audioLanguage: code }, { language: code }, { audio: code }];

        const sendRavok = () => {
          const frame = getTargetIframe();
          if (!frame?.contentWindow) return;
          try {
            ravokPayloads.forEach((payload) => {
              frame.contentWindow?.postMessage(payload, '*');
            });
          } catch {}
        };

        sendRavok();

        let attempts = 0;
        langSpamIntervalRef.current = setInterval(() => {
          attempts++;
          sendRavok();
          if (attempts >= 12 && langSpamIntervalRef.current) {
            clearInterval(langSpamIntervalRef.current);
            langSpamIntervalRef.current = null;
          }
        }, 750);
      }
    },
    [activeServer, availableLanguages, reloadKey, playerIframeSrc]
  );

const handleSelectLanguage = (langOpt: LanguageOption) => {
  // Atomically commit the switch; suppress cascading effects for the window.
  switchGuardRef.current += 1;
  if (languageSwitchTimerRef.current) clearTimeout(languageSwitchTimerRef.current);
  setIsSwitchingLanguage(true);

  const finishSwitch = () => {
    languageSwitchTimerRef.current = setTimeout(() => {
      setIsSwitchingLanguage(false);
      releaseSwitchGuard();
    }, 450);
  };

if (isMovieboxId) {
  if (langOpt.code) {
    try {
      localStorage.setItem(
        `toonplay_moviebox_audio:${id}`,
        canonicalLangCode(langOpt.code)
      );
    } catch {}
  }

  const match = movieboxMergedOptions.find(
    (o) => o.audioKey === langOpt.audioKey
  );

  if (match) {
    if (match.kind === 'outer' && match.subjectId && match.detailPath) {
      window.dispatchEvent(
        new CustomEvent('toonplay:moviebox-audio-select', {
          detail: {
            subjectId: match.subjectId,
            detailPath: match.detailPath,
            label: match.label,
            lanCode: match.lanCode,
          },
        })
      );
    } else if (
      match.kind === 'in-manifest' &&
      typeof match.trackIndex === 'number'
    ) {
      window.dispatchEvent(
        new CustomEvent('toonplay:moviebox-in-manifest-audio', {
          detail: {
            trackIndex: match.trackIndex,
            label: match.label,
          },
        })
      );
    }
  }

  finishSwitch();
  return;
}

  let streamEntry = streamServerMap[selectedServerKey];
  if (!streamEntry) {
    const activeBase = buildServerType(activeServer?.name || '', '');
    if (activeBase) {
      for (const [k, v] of Object.entries(streamServerMap)) {
        const parsedK = parseServerType(k);
        if (parsedK?.serverKey === activeBase) {
          streamEntry = v;
          break;
        }
      }
    }
  }
  if (!streamEntry) {
    const parsedSel = parseServerType(selectedServerKey);
    if (parsedSel?.serverKey) {
      for (const [k, v] of Object.entries(streamServerMap)) {
        const parsedK = parseServerType(k);
        if (parsedK?.serverKey === parsedSel.serverKey) {
          streamEntry = v;
          break;
        }
      }
    }
  }
  if (!streamEntry && Object.keys(streamServerMap).length > 0) {
    streamEntry = Object.values(streamServerMap)[0];
  }

  if (streamEntry) {
    const targetUrl =
      streamEntry.langUrls[langOpt.code.toLowerCase()] ||
      streamEntry.langUrls[langOpt.code];

    if (targetUrl) {
      const composite = buildServerType(streamEntry.name, langOpt.code);
      const lowerLang = canonicalLangCode(langOpt.code);

      // Commit all state updates in one frame — no double-set via updateUrl.
      setWatchServers((prev) =>
        prev.map((s, idx) =>
          idx === serverIndex
            ? { ...s, url: targetUrl, lang: lowerLang }
            : s
        )
      );
      if (composite) setSelectedServerKey(composite);
      setSelectedLanguage(lowerLang);

      const params = new URLSearchParams(window.location.search);
      if (hasRealSeasons) {
        params.set('season', String(currentSeasonNumber));
      }
      if (hasEpisodes) {
        params.set('ep', String(currentEpisodeNumber));
      }
      if (composite) params.set('server', composite);
      params.set('lang', lowerLang);
      const anilist =
        anime?.anilist_id != null && Number(anime.anilist_id) > 0
          ? String(anime.anilist_id)
          : null;
      if (anilist) params.set('anilistid', anilist);
      replaceWatchPageUrl(
        null,
        '',
        `${window.location.pathname}?${params.toString()}`
      );

      setReloadKey((k) => k + 1);
      setActiveFeedback(`Switched audio to ${langOpt.name}`);
      setTimeout(() => setActiveFeedback(null), 2500);
      finishSwitch();
      return;
    }
  }

// Legacy path — update language and server composite key.
const lowerLang = canonicalLangCode(langOpt.code);

const parsedServer = parseServerType(selectedServerKey);
const currentLang = canonicalLangCode(
  selectedLanguage || parsedServer?.lang || ''
);

// Only remove the suffix if it matches the currently selected language.
const hasLanguageSuffix =
  /^[a-z]{2,3}$/i.test(parsedServer?.lang || '') &&
  parsedServer?.lang === currentLang;

const serverBase = hasLanguageSuffix
  ? parsedServer!.serverKey
  : selectedServerKey;

const composite = serverBase
  ? buildServerType(serverBase, lowerLang) || selectedServerKey
  : selectedServerKey;

setSelectedLanguage(lowerLang);
if (composite) setSelectedServerKey(composite);

const params = new URLSearchParams(window.location.search);

if (hasRealSeasons) {
  params.set('season', String(currentSeasonNumber));
}
if (hasEpisodes) {
  params.set('ep', String(currentEpisodeNumber));
}

params.set('lang', lowerLang);
if (composite) params.set('server', composite);
  const anilist =
    anime?.anilist_id != null && Number(anime.anilist_id) > 0
      ? String(anime.anilist_id)
      : null;
  if (anilist) params.set('anilistid', anilist);
  replaceWatchPageUrl(
    null,
    '',
    `${window.location.pathname}?${params.toString()}`
  );

  setReloadKey((k) => k + 1);
  setActiveFeedback(`Switched audio to ${langOpt.name}`);
  setTimeout(() => setActiveFeedback(null), 2500);
  finishSwitch();
};

  useEffect(() => {
    selectedLanguageRef.current = selectedLanguage;
  }, [selectedLanguage]);

  useEffect(() => {
    autoNextGuardRef.current = '';
  }, [selectedServerKey]);

  useEffect(() => {
    availableLanguagesRef.current = availableLanguages;
  }, [availableLanguages]);

  const estimatedEpisodeDurationSeconds = useMemo(() => {
    if (!anime) return 0;
    if (isMovie) {
      if (anime.duration) {
        const m = String(anime.duration).match(/(\d+)\s*h(?:\s*(\d+)\s*m)?/i);
        if (m) {
          const hrs = parseInt(m[1], 10) || 0;
          const mins = parseInt(m[2] || '0', 10) || 0;
          return hrs * 3600 + mins * 60;
        }
        const minsOnly = String(anime.duration).match(/(\d+)\s*m/i);
        if (minsOnly) return (parseInt(minsOnly[1], 10) || 0) * 60;
      }
      return 5400;
    }
    const epDur = (anime as any).episodeDuration;
    if (epDur) {
      const m = String(epDur).match(/(\d+)\s*m/i);
      if (m) return (parseInt(m[1], 10) || 0) * 60;
    }
    return 24 * 60;
  }, [anime, isMovie]);

  const visibleSecondsRef = useRef<number>(0);
  const visibleSinceRef = useRef<number | null>(null);
  const episodeCompletedRef = useRef<boolean>(false);
  const completeFiredForEpisodeRef = useRef<string>('');

  const flushVisibleTime = useCallback(() => {
    if (visibleSinceRef.current !== null) {
      const delta = (Date.now() - visibleSinceRef.current) / 1000;
      visibleSecondsRef.current += Math.max(0, delta);
      visibleSinceRef.current = null;
    }
  }, []);

  const resumeVisibleTime = useCallback(() => {
    if (visibleSinceRef.current === null && document.visibilityState === 'visible') {
      visibleSinceRef.current = Date.now();
    }
  }, []);

  const fireEpisodeComplete = useCallback(
    (opts?: { force?: boolean; progressSeconds?: number }) => {
      if (!anime || !onEpisodeComplete) return;

      const sessionKey = isMovie ? anime.id : `${anime.id}:${activeEpisode?.id}`;
      if (!opts?.force && completeFiredForEpisodeRef.current === sessionKey) return;
      completeFiredForEpisodeRef.current = sessionKey;

      const totalEpisodesAvailable =
        anime.seasonsList?.reduce((sum, s) => sum + (s.episodes?.length || 0), 0) ||
        (isMovie ? 1 : 0);

      onEpisodeComplete({
        cartoonId: anime.id,
        cartoonTitle: anime.title,
        cartoonImage: anime.image,
        cartoonType:
         String(anime.type || '').trim().toUpperCase() || (isMovie ? 'MOVIE' : 'SERIES'),
        episodeId: isMovie ? 'movie' : activeEpisode?.id,
        episodeNumber: isMovie ? undefined : activeEpisode?.number,
        seasonNumber: isMovie
          ? undefined
          : hasRealSeasons
          ? parseInt(String(activeSeason?.season), 10) || 1
          : undefined,
        episodeTitle: isMovie ? undefined : activeEpisode?.title,
        episodeImage: isMovie ? undefined : activeEpisode?.image,
        server: currentServerType || selectedServerKey,
        genres: anime.genres,
        totalEpisodesAvailable,
        durationSeconds: estimatedEpisodeDurationSeconds,
        progressSeconds: opts?.progressSeconds ?? estimatedEpisodeDurationSeconds,
      });
    },
    [
      anime,
      activeEpisode,
      activeSeason,
      isMovie,
      onEpisodeComplete,
      selectedServerKey,
      currentServerType,
      estimatedEpisodeDurationSeconds,
    ]
  );

  useEffect(() => {
    visibleSecondsRef.current = 0;
    visibleSinceRef.current = document.visibilityState === 'visible' ? Date.now() : null;
    episodeCompletedRef.current = false;
    completeFiredForEpisodeRef.current = '';
  }, [anime?.id, activeEpisode?.id]);

  useEffect(() => {
    const onVis = () => {
      if (document.visibilityState === 'hidden') {
        flushVisibleTime();
      } else {
        resumeVisibleTime();
      }
    };
    document.addEventListener('visibilitychange', onVis);
    return () => {
      document.removeEventListener('visibilitychange', onVis);
      flushVisibleTime();
    };
  }, [flushVisibleTime, resumeVisibleTime]);

  // Flush FlixCloud resume time on tab hide / page unload.
  useEffect(() => {
    const flushFlixProgress = () => {
      const key = flixResumeKeyRef.current;
      if (!key) return;
      const t = flixLastSavedTRef.current;
      if (t > 0) writeFlixResume(key, Math.floor(t));
    };

    const onHide = () => {
      if (document.visibilityState === 'hidden') flushFlixProgress();
    };

    document.addEventListener('visibilitychange', onHide);
    window.addEventListener('pagehide', flushFlixProgress);
    return () => {
      document.removeEventListener('visibilitychange', onHide);
      window.removeEventListener('pagehide', flushFlixProgress);
      flushFlixProgress();
    };
  }, []);

  useEffect(() => {
    if (!anime) return;
    const rawUrl = activeServer?.url || '';
    const isAbyss = rawUrl.toLowerCase().includes('animesalt');
    if (!isAbyss) return;
    if (estimatedEpisodeDurationSeconds <= 0) return;

    const threshold = estimatedEpisodeDurationSeconds * 0.88;

    const tick = () => {
      if (episodeCompletedRef.current) return;
      flushVisibleTime();
      if (visibleSecondsRef.current >= threshold) {
        episodeCompletedRef.current = true;
        fireEpisodeComplete({ progressSeconds: Math.floor(visibleSecondsRef.current) });
      } else {
        resumeVisibleTime();
      }
    };

    const interval = window.setInterval(tick, 5000);
    return () => window.clearInterval(interval);
  }, [
    anime,
    activeServer?.url,
    estimatedEpisodeDurationSeconds,
    flushVisibleTime,
    resumeVisibleTime,
    fireEpisodeComplete,
  ]);

  const handleIframeLoad = () => {
    const target = selectedLanguageRef.current || availableLanguagesRef.current[0]?.code || 'hin';
    postAudioLanguageCommand(target);
  };

  useEffect(() => {
    const url = activeServer?.url || '';
    const isAbyss = url.toLowerCase().includes('animesalt');
    const isRavok = url.includes('/video/');
    const isMega = url.toLowerCase().includes('megaplay') || url.toLowerCase().includes('megacloud');
    const isFlix = isFlixCloud(url);
    if (isAbyss) return;
    if (isFlix) return;  
    if (!isRavok && !isMega) return;

    let attempts = 0;
    let intervalId: number | undefined;
    let completed = false;

    const getIframe = () =>
      document.getElementById('watchpage-active-iframe') as HTMLIFrameElement | null;

    const sendCommands = () => {
      const frame = getIframe();
      if (!frame?.contentWindow) return;

      if (isMega) {
        try {
          frame.contentWindow.postMessage(
            JSON.stringify({ cmd: 'SKP_DATA', auto: autoSkipEnabled }),
            '*'
          );
        } catch {}
      }

      if (isRavok) {
        try {
          frame.contentWindow.postMessage(
            { autoSkip: { intro: autoSkipEnabled, outro: autoSkipEnabled } },
            '*'
          );
        } catch {}
      }

      try {
        frame.contentWindow.postMessage({ autoPlay: autoPlayEnabled }, '*');
      } catch {}
    };

    const onMessage = (e: MessageEvent) => {
      const frame = getIframe();
      if (!frame || e.source !== frame.contentWindow) return;
      let data: any = e.data;
      if (typeof data === 'string') {
        try { data = JSON.parse(data); } catch { /* keep string */ }
      }

      let isEnded = false;

      if (isRavok && data === 'video_playback_completed') isEnded = true;
      if (isRavok && data?.event === 'complete') isEnded = true;

      if (isMega) {
        if (data?.event === 'complete' || data?.event === 'ended') isEnded = true;
        if (data?.playerStatus === 'ended' || data?.status === 'ended') isEnded = true;
        if (
          (data?.type === 'watching-log' || data?.event === 'time') &&
          Number.isFinite(Number(data?.currentTime ?? data?.time)) &&
          Number.isFinite(Number(data?.duration)) &&
          Number(data.duration) > 0 &&
          Number(data.currentTime ?? data.time) >= Number(data.duration) - 1.5
        ) isEnded = true;
      }

      if (isEnded) {
        const guard = `${id}:${currentSeasonNumber}:${currentEpisodeNumber}`;
        if (autoNextGuardRef.current === guard) return;
        autoNextGuardRef.current = guard;
        fireEpisodeComplete({ force: true });
        if (autoNextEnabled && !completed) {
          completed = true;
          handleNextEpisode();
        }
      }
    };

    window.addEventListener('message', onMessage);

    const startDelay = window.setTimeout(() => {
      sendCommands();
      intervalId = window.setInterval(() => {
        attempts++;
        sendCommands();
        if (attempts >= 12 && intervalId) window.clearInterval(intervalId);
      }, 1000);
    }, 1000);

    return () => {
      window.clearTimeout(startDelay);
      if (intervalId) window.clearInterval(intervalId);
      window.removeEventListener('message', onMessage);
    };
  }, [
    activeServer?.url,
    autoPlayEnabled,
    autoNextEnabled,
    autoSkipEnabled,
    currentSeasonNumber,
    currentEpisodeNumber,
    id,
    fireEpisodeComplete,
  ]);

  useEffect(() => {
    const url = activeServer?.url || '';
    if (!flixCloudSupportsGetTime(url)) return;

    let pollInterval: number | undefined;
    let startDelay: number | undefined;
    let completed = false;

    const getIframe = () =>
      document.getElementById('watchpage-active-iframe') as HTMLIFrameElement | null;

    const getOrigin = (): string | null => {
      try {
        const frame = getIframe();
        const src = frame?.src || url;
        return new URL(src, window.location.href).origin;
      } catch {
        return null;
      }
    };

    const requestStatus = () => {
      const frame = getIframe();
      const origin = getOrigin();
      if (!frame?.contentWindow || !origin) return;
      try {
        frame.contentWindow.postMessage({ command: 'getTime' }, origin);
      } catch {}
    };

    const onFlixMessage = (event: MessageEvent) => {
      const frame = getIframe();
      if (!frame || event.source !== frame.contentWindow) return;

      const origin = getOrigin();
      if (!origin || event.origin !== origin) return;

      let data: any = event.data;
      if (typeof data === 'string') {
        try { data = JSON.parse(data); } catch { return; }
      }
      if (!data) return;

      const ct = Number(data.currentTime ?? data.time);
      const dur = Number(data.duration);

      // Persist current position (throttled ≥5s change) for resume via &start_at
      const resumeKey = flixResumeKeyRef.current;
      if (
        resumeKey &&
        Number.isFinite(ct) &&
        ct > 0 &&
        (!Number.isFinite(dur) || ct < dur - 5) &&
        Math.abs(ct - flixLastSavedTRef.current) >= 5
      ) {
        flixLastSavedTRef.current = ct;
        writeFlixResume(resumeKey, Math.floor(ct));
      }

      let isEnded = false;
      const status = data.playerStatus ?? data.status;
      if (
        status === 'ended' ||
        status === 'complete' ||
        status === 'completed'
      ) {
        isEnded = true;
      }
      if (
        Number.isFinite(ct) &&
        Number.isFinite(dur) &&
        dur > 0 &&
        ct >= dur - 1.5
      ) {
        isEnded = true;
      }

      if (!isEnded) return;

      // Episode finished → clear saved progress so a rewatch starts at 0
      if (resumeKey) {
        clearFlixResume(resumeKey);
        setFlixStartAt(0);
      }

      const guard = `${id}:${currentSeasonNumber}:${currentEpisodeNumber}`;
      if (autoNextGuardRef.current === guard) return;
      autoNextGuardRef.current = guard;
      fireEpisodeComplete({ force: true });
      if (autoNextEnabled && !completed) {
        completed = true;
        handleNextEpisode();
      }
    };

    window.addEventListener('message', onFlixMessage);

    startDelay = window.setTimeout(() => {
      requestStatus();
      pollInterval = window.setInterval(requestStatus, 500);
    }, 1000);

    return () => {
      if (startDelay) window.clearTimeout(startDelay);
      if (pollInterval) window.clearInterval(pollInterval);
      window.removeEventListener('message', onFlixMessage);
    };
  }, [
    activeServer?.url,
    autoNextEnabled,
    currentSeasonNumber,
    currentEpisodeNumber,
    id,
    fireEpisodeComplete,
  ]);


  useEffect(() => {
    return () => {
      if (langSpamIntervalRef.current) clearInterval(langSpamIntervalRef.current);
      if (languageSwitchTimerRef.current) clearTimeout(languageSwitchTimerRef.current);
    };
  }, []);

  const handleShare = async () => {
    const url = window.location.href;
    const shareData = {
      title: anime?.title ? `Watch ${anime.title} - ToonPlay` : 'ToonPlay',
      text: anime?.overview || anime?.title || 'Watch now on ToonPlay',
      url,
    };

    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share(shareData);
        return;
      } catch (err: any) {
        if (err?.name === 'AbortError') return;
      }
    }

    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(url);
      } else {
        const input = document.createElement('input');
        input.value = url;
        document.body.appendChild(input);
        input.select();
        document.execCommand('copy');
        document.body.removeChild(input);
      }
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 2400);
    } catch {}
  };

  const toUnified = useCallback((): UnifiedAnime | null => {
    if (!anime) return null;
    const isMovieType = String(anime.type || '').toLowerCase() === 'movie';
    return {
      id: anime.id,
      title: anime.title,
      image: anime.image,
      backdrop: anime.backdrop || anime.image,
      type: isMovieType ? 'movie' : 'series',
      displayType:
       String(anime.type || '').trim().toUpperCase() || (isMovieType ? 'MOVIE' : 'SERIES'),
      overview: anime.overview,
      year: anime.year,
      season: activeSeason ? `Season ${activeSeason.season}` : undefined,
      episodes: activeEpisode ? `Ep ${activeEpisode.number}` : undefined,
      server: currentServerType || selectedServerKey,
      lang: selectedLanguage || undefined,
      anilistId:
        anime.anilist_id != null && Number(anime.anilist_id) > 0
          ? Number(anime.anilist_id)
          : undefined,
      tmdbId:
        anime.tmdb_id != null && Number(anime.tmdb_id) > 0
          ? Number(anime.tmdb_id)
          : undefined,
      subjectId:
  cleanSubjectId ||
  (anime as any).subjectId ||
  extractMovieboxSubjectId(anime),
      category: isMovieType ? 'movie' : 'series',
    };
  }, [anime, activeSeason, activeEpisode, currentServerType, selectedServerKey, selectedLanguage]);

  const watchlistIdSet = useMemo(
    () => new Set(watchlist.map((w) => w.id)),
    [watchlist]
  );

  const isBookmarked = anime ? watchlistIdSet.has(anime.id) : false;

  const handleToggleWatchlistClick = () => {
    const unified = toUnified();
    if (unified) onToggleWatchlist(unified);
  };

  const handleNextEpisode = () => {
    if (!activeSeason?.episodes) return;
    const nextEp = activeSeason.episodes.find((e) => e.number === currentEpisodeNumber + 1);
    if (nextEp) {
      updateUrl({ ep: nextEp.number });
    } else if (anime?.seasonsList) {
      const nextSeason = anime.seasonsList.find(
        (s) => parseInt(s.season, 10) === currentSeasonNumber + 1
      );
      if (nextSeason && nextSeason.episodes && nextSeason.episodes.length > 0) {
        updateUrl({ season: parseInt(nextSeason.season, 10), ep: nextSeason.episodes[0].number });
      }
    }
  };

  const handlePrevEpisode = () => {
    if (!activeSeason?.episodes) return;
    const prevEp = activeSeason.episodes.find((e) => e.number === currentEpisodeNumber - 1);
    if (prevEp) {
      updateUrl({ ep: prevEp.number });
    }
  };

  const handleRecommendationClick = (recId: string) => {
    onNavigate(`/watch/${recId}`);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useEffect(() => {
    setEpisodeSearch('');
    autoNextGuardRef.current = '';
  }, [currentSeasonNumber, id, currentEpisodeNumber]);

  const filteredEpisodes = useMemo(() => {
    if (!activeSeason?.episodes) return [];
    const q = episodeSearch.trim();
    if (!q) return activeSeason.episodes;
    const n = parseInt(q, 10);
    if (!isNaN(n)) return activeSeason.episodes.filter((e) => e.number === n);
    const lower = q.toLowerCase();
    return activeSeason.episodes.filter((e) =>
      (e.title || '').toLowerCase().includes(lower)
    );
  }, [activeSeason, episodeSearch]);

  const totalEpisodesInSeason = activeSeason?.episodes?.length || 0;
  const hasNextEp = currentEpisodeNumber < totalEpisodesInSeason;
  const hasPrevEp = currentEpisodeNumber > 1;

  if (isLoadingAnime) {
    return (
      <div className="min-h-[75vh] flex flex-col items-center justify-center p-6 text-center">
        <Loader2 className="w-10 h-10 text-indigo-500 animate-spin mb-4" />
        <h2 className="text-lg font-medium text-white mb-1">Loading Player Stream...</h2>
        <p className="text-xs text-slate-400">Connecting to secure multi-source mirrors</p>
      </div>
    );
  }

  if (animeError || !anime) {
    return (
      <div className="max-w-xl mx-auto my-20 p-8 rounded-2xl bg-[#111322] border border-[#262944] text-center">
        <AlertCircle className="w-12 h-12 text-rose-400 mx-auto mb-4" />
        <h2 className="text-xl font-semibold text-white mb-2">Stream Unavailable</h2>
        <p className="text-xs sm:text-sm text-slate-400 mb-6 leading-relaxed">
          {animeError || 'The requested stream could not be loaded.'}
        </p>
        <button
          onClick={onBackToHome}
          className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs sm:text-sm font-medium transition-colors cursor-pointer"
        >
          Return to Home
        </button>
      </div>
    );
  }

  const showSidebar = hasEpisodes;

  return (
    <div className="min-h-screen bg-[#0b0c16] text-slate-100 pb-20 selection:bg-indigo-600 selection:text-white">
      <header className="border-b border-[#181a2e] bg-[#0b0c16]/95 backdrop-blur-md sticky top-16 z-30">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-2.5 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 overflow-hidden">
            <button
              onClick={() => {
                const resolvedId =
                  (anime as any).id ||
                  (anime as any).anime_id ||
                  (anime as any).reanime_id ||
                  id;
                if (resolvedId) onNavigate(`/info/${resolvedId}`);
              }}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#16182c] border border-transparent hover:border-[#282b46] transition-colors shrink-0 cursor-pointer flex items-center gap-1.5 text-xs font-medium"
              title="Back to Details"
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="hidden sm:inline">Details</span>
            </button>

            <span aria-hidden="true" className="text-slate-700 hidden sm:inline">|</span>

            <div className="flex items-center gap-2 overflow-hidden">
              <span className="font-semibold text-white truncate text-xs sm:text-sm max-w-[150px] sm:max-w-xs md:max-w-md">
                {anime.title}
              </span>

              {!isMovie && activeEpisode && (
                <div className="flex items-center gap-1 shrink-0">
                  <span className="px-2 py-0.5 rounded-md bg-indigo-950/90 border border-indigo-700/60 text-indigo-300 font-mono text-[10px] sm:text-[11px] font-semibold">
                    {hasRealSeasons
                      ? `S${currentSeasonNumber} : EP${currentEpisodeNumber}`
                      : `EP${currentEpisodeNumber}`}
                  </span>
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {activeFeedback && (
              <span className="hidden md:inline-flex text-[11px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/60">
                {activeFeedback}
              </span>
            )}

            <button
              onClick={handleToggleWatchlistClick}
              title={isBookmarked ? 'In Watchlist' : 'Add to Watchlist'}
              className={`p-2 rounded-lg border text-xs transition-colors cursor-pointer flex items-center gap-1.5 ${
                isBookmarked
                  ? 'bg-emerald-950/40 text-emerald-300 border-emerald-700/60'
                  : 'bg-[#121426] hover:bg-[#1a1d35] text-slate-300 hover:text-white border-[#22253d]'
              }`}
            >
              {isBookmarked ? <Check className="w-4 h-4 text-emerald-400" /> : <Bookmark className="w-4 h-4" />}
              <span className="hidden md:inline text-xs">{isBookmarked ? 'Saved' : 'Watchlist'}</span>
            </button>

            <button
              onClick={() => setIsDownloadOpen(true)}
              title="Download Episode"
              className="p-2 rounded-lg bg-[#121426] hover:bg-[#1a1d35] border border-[#22253d] text-slate-300 hover:text-white transition-colors cursor-pointer flex items-center gap-1.5 text-xs"
            >
              <Download className="w-4 h-4" />
              <span className="hidden md:inline">Download</span>
            </button>

            <button
              onClick={handleShare}
              title="Share Stream Link"
              className="p-2 rounded-lg bg-[#121426] hover:bg-[#1a1d35] border border-[#22253d] text-slate-300 hover:text-white transition-colors cursor-pointer flex items-center gap-1.5 text-xs"
            >
              <Share2 className="w-4 h-4" />
              <span className="hidden md:inline">{copiedShare ? 'Copied!' : 'Share'}</span>
            </button>

            <button
              onClick={() => setIsTheatreMode(!isTheatreMode)}
              title={isTheatreMode ? 'Exit Cinema View' : 'Cinema View'}
              className={`p-2 rounded-lg border text-slate-300 hover:text-white transition-colors hidden lg:flex items-center gap-1.5 text-xs cursor-pointer ${
                isTheatreMode
                  ? 'bg-indigo-600 border-indigo-500 text-white'
                  : 'bg-[#121426] hover:bg-[#1a1d35] border-[#22253d]'
              }`}
            >
              {isTheatreMode ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              <span>{isTheatreMode ? 'Standard' : 'Cinema'}</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-8 pt-4">
        <div
          className={`grid gap-4 lg:gap-6 ${
            !showSidebar || isTheatreMode
              ? 'grid-cols-1'
              : 'grid-cols-1 lg:grid-cols-[minmax(0,1fr)_340px] 2xl:grid-cols-[minmax(0,1fr)_380px] lg:grid-rows-[auto_auto]'
          }`}
        >
          <div className="min-w-0 lg:col-start-1 lg:row-start-1">
            <div className="relative rounded-2xl overflow-hidden bg-black border border-[#1d2036] shadow-2xl shadow-black/80">
              <div className={`relative w-full bg-[#04050b] overflow-hidden flex items-center justify-center ${
                isTheatreMode
                  ? 'aspect-video max-h-[calc(100vh-140px)]'
                  : 'aspect-video max-h-[calc(100vh-260px)] lg:max-h-[min(calc(100vh-260px),calc((100vw-420px)*9/16))]'
              }`}>
                {isLoadingExtract ? (
                  <div className="flex flex-col items-center justify-center p-6 text-center">
                    <Loader2 className="w-10 h-10 text-indigo-500 animate-spin mb-3" />
                    <span className="text-sm font-medium text-white mb-1">Connecting Stream Mirror...</span>
                    <span className="text-xs text-slate-400 font-mono">Loading episode stream source</span>
                  </div>
                ) : extractError ? (
                  <div className="flex flex-col items-center justify-center p-6 text-center max-w-md">
                    <AlertCircle className="w-10 h-10 text-rose-400 mb-2" />
                    <span className="text-sm font-medium text-white mb-1">Streaming Notice</span>
                    <span className="text-xs text-slate-400 mb-4">{extractError}</span>
                    <button
                      onClick={loadServersForCurrentContext}
                      className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-medium text-white cursor-pointer"
                    >
                      Retry Connection
                    </button>
                  </div>
                ) : isMovieboxId && movieboxStreamUrl ? (
                  <>
                    <CustomPlayer
                      key={`${movieboxStreamUrl}-${reloadKey}`}
                      streamUrl={movieboxStreamUrl}
                      autoPlay={autoPlayEnabled}
                      startAt={flixStartAt}
                      onReady={(dur) => {
                        if (dur > 0 && estimatedEpisodeDurationSeconds === 0) {
                          // duration hint if anime meta lacks it
                        }
                      }}
                      onProgress={(ct) => {
                        const key = flixResumeKeyRef.current;
                        if (!key) return;
                        if (Math.abs(ct - flixLastSavedTRef.current) >= 5) {
                          flixLastSavedTRef.current = ct;
                          writeFlixResume(key, Math.floor(ct));
                        }
                      }}
                      onEnded={() => {
                        const resumeKey = flixResumeKeyRef.current;
                        if (resumeKey) {
                          clearFlixResume(resumeKey);
                          setFlixStartAt(0);
                        }
                        const guard = `${id}:${currentSeasonNumber}:${currentEpisodeNumber}`;
                        if (autoNextGuardRef.current !== guard) {
                          autoNextGuardRef.current = guard;
                          fireEpisodeComplete({ force: true });
                          if (autoNextEnabled) handleNextEpisode();
                        }
                      }}
                      onError={(msg) => {
                        setExtractError(msg);
                      }}
                    />
                  </>
                ) : playerIframeSrc ? (
                  <>
                    <iframe
                      key={`${playerIframeSrc}-${reloadKey}`}
                      ref={iframeRef}
                      id="watchpage-active-iframe"
                      src={playerIframeSrc}
                      title={`${anime.title} Player`}
                      allow="autoplay; fullscreen; encrypted-media; picture-in-picture"
                      allowFullScreen
                      onLoad={handleIframeLoad}
                      {...(playerIframeSrc.includes('/video/')
                        ? { sandbox: 'allow-scripts allow-same-origin allow-presentation allow-forms' }
                        : {})}
                      className="w-full h-full border-0 bg-black"
                    />
                    {isSwitchingLanguage && (
                      <div className="absolute inset-0 z-10 flex flex-col items-center justify-center p-6 text-center bg-black/85 backdrop-blur-sm pointer-events-none">
                        <Loader2 className="w-10 h-10 text-indigo-500 animate-spin mb-3" />
                        <span className="text-sm font-medium text-white mb-1">Switching audio track...</span>
                        <span className="text-xs text-slate-400 font-mono">Reloading player with new language</span>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="flex flex-col items-center justify-center p-6 text-center">
                    <AlertCircle className="w-10 h-10 text-amber-400 mb-2" />
                    <span className="text-xs text-slate-400">No active streaming server link found.</span>
                  </div>
                )}
              </div>

              <div className="p-3 sm:p-4 bg-[#0d0f1e] border-t border-[#1a1d35] flex flex-col gap-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <div className="flex items-center gap-1.5 text-xs text-slate-400 mr-1 shrink-0">
                      <Server className="w-3.5 h-3.5 text-indigo-400" />
                      <span className="font-mono text-[11px] uppercase tracking-wider font-semibold">Server:</span>
                    </div>

                    <div className="flex flex-wrap items-center gap-1.5">
{watchServers.length > 0 ? (
  watchServers.map((srv, idx) => {
    const composite =
      buildServerType(srv.name || '', selectedLanguage || srv.lang || '') ||
      '';
    const isSelected = selectedServerKey === composite;

    return (
<button
  key={composite || `srv-${idx}`}
  onClick={() => {
    if (!composite) return;
    const parsed = parseServerType(composite);
    const targetBase = parsed?.serverKey || '';
    const targetLang = canonicalLangCode(parsed?.lang || selectedLanguage || 'jpn');

    // Find the map entry for this server+lang so we can swap the iframe URL
    // atomically (same as handleSelectLanguage).
    let entry: MappedStreamServer | undefined;
    for (const [, v] of Object.entries(streamServerMap)) {
      if (
        buildServerType(v.name || '', '') === targetBase &&
        v.langUrls[targetLang]
      ) {
        entry = v;
        break;
      }
    }
    const targetUrl = entry?.langUrls[targetLang];

switchGuardRef.current += 1;
setIsSwitchingLanguage(true);

if (languageSwitchTimerRef.current) {
  clearTimeout(languageSwitchTimerRef.current);
}

    if (targetUrl) {
      setWatchServers((prev) =>
        prev.map((s, i) =>
          i === idx ? { ...s, url: targetUrl, lang: targetLang } : s
        )
      );
    }
    setSelectedServerKey(composite);
    setSelectedLanguage(targetLang);
    setReloadKey((k) => k + 1);

    // Write URL directly
    const params = new URLSearchParams(window.location.search);
    if (hasRealSeasons) {
      params.set('season', String(currentSeasonNumber));
    }
    if (hasEpisodes) {
      params.set('ep', String(currentEpisodeNumber));
    }
    params.set('server', composite);
    params.set('lang', targetLang);
    const anilist =
      anime?.anilist_id != null && Number(anime.anilist_id) > 0
        ? String(anime.anilist_id)
        : null;
    if (anilist) params.set('anilistid', anilist);
    replaceWatchPageUrl(
      null,
      '',
      `${window.location.pathname}?${params.toString()}`
    );

languageSwitchTimerRef.current = setTimeout(() => {
  releaseSwitchGuard();
  setIsSwitchingLanguage(false);
}, 450);
  }}
        className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all duration-200 cursor-pointer flex items-center gap-1.5 ${
          isSelected
            ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 ring-1 ring-indigo-400'
            : 'bg-[#14162a] hover:bg-[#1c1f38] text-slate-300 border border-[#222540]'
        }`}
      >
        <Sparkles className="w-3 h-3 text-amber-300" />
        <span>{srv.name || `Server ${idx + 1}`}</span>
      </button>
    );
  })
) : (
  <span className="text-xs text-slate-400 font-mono bg-[#14162a] px-3 py-1 rounded-lg border border-[#222540]">
    Server 1
  </span>
)}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                    {!isMovie && (
                      <div className="flex items-center gap-1 bg-[#14162a] p-1 rounded-xl border border-[#222540]">
                        <button
                          onClick={handlePrevEpisode}
                          disabled={!hasPrevEp}
                          className="px-2 py-1 rounded-lg hover:bg-[#1e213d] text-slate-300 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed transition-colors flex items-center gap-1 text-xs"
                          title="Previous Episode"
                        >
                          <ChevronLeft className="w-3.5 h-3.5" />
                          <span className="hidden sm:inline">Prev</span>
                        </button>
                        <span aria-hidden="true" className="text-slate-700">|</span>
                        <button
                          onClick={handleNextEpisode}
                          disabled={!hasNextEp}
                          className="px-2 py-1 rounded-lg hover:bg-[#1e213d] text-slate-300 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed transition-colors flex items-center gap-1 text-xs"
                          title="Next Episode"
                        >
                          <span className="hidden sm:inline">Next</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}

                    <div className="flex items-center gap-1 bg-[#14162a] p-1 rounded-xl border border-[#222540]">
                      <button
                        type="button"
                        onClick={handleToggleAutoPlay}
                        title={autoPlayEnabled ? 'Auto Play: ON' : 'Auto Play: OFF'}
                        className={`px-2 py-1 rounded-lg transition-colors flex items-center gap-1 text-[11px] font-medium cursor-pointer ${
                          autoPlayEnabled
                            ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                            : 'text-slate-400 hover:text-white hover:bg-[#1e213d]'
                        }`}
                      >
                        <Play className={`w-3 h-3 ${autoPlayEnabled ? 'fill-white' : ''}`} />
                        <span className="hidden min-[480px]:inline">Auto Play</span>
                        <span className="min-[480px]:hidden">AP</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleToggleAutoNext}
                        title={autoNextEnabled ? 'Auto Next: ON' : 'Auto Next: OFF'}
                        className={`px-2 py-1 rounded-lg transition-colors flex items-center gap-1 text-[11px] font-medium cursor-pointer ${
                          autoNextEnabled
                            ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                            : 'text-slate-400 hover:text-white hover:bg-[#1e213d]'
                        }`}
                      >
                        <ChevronRight className="w-3 h-3" />
                        <span className="hidden min-[480px]:inline">Auto Next</span>
                        <span className="min-[480px]:hidden">AN</span>
                      </button>

                      <button
                        type="button"
                        disabled={isMovieboxId}
                        onClick={handleToggleAutoSkip}
                        title={
                          isMovieboxId
                            ? 'Auto Skip not available for this source'
                            : autoSkipEnabled
                            ? 'Auto Skip: ON'
                            : 'Auto Skip: OFF'
                        }
                        className={`px-2 py-1 rounded-lg transition-colors flex items-center gap-1 text-[11px] font-medium ${
                          isMovieboxId
                            ? 'text-slate-600 cursor-not-allowed'
                            : autoSkipEnabled
                            ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30 cursor-pointer'
                            : 'text-slate-400 hover:text-white hover:bg-[#1e213d] cursor-pointer'
                        }`}
                      >
                        <Scissors className="w-3 h-3" />
                        <span className="hidden min-[480px]:inline">Auto Skip</span>
                        <span className="min-[480px]:hidden">AS</span>
                      </button>
                    </div>

                    <button
                      onClick={() => setReloadKey((k) => k + 1)}
                      title="Reload video stream"
                      className="hidden min-[360px]:flex p-2 rounded-xl bg-[#14162a] hover:bg-[#1e213d] border border-[#222540] text-slate-300 hover:text-white transition-colors cursor-pointer"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="pt-2.5 border-t border-[#17192e] flex flex-wrap items-center gap-2">
                  <div className="flex items-center gap-1.5 text-xs text-slate-400 mr-1 shrink-0">
                    <Volume2 className="w-3.5 h-3.5 text-indigo-400" />
                    <span className="font-mono text-[11px] uppercase tracking-wider font-semibold">Audio Track:</span>
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5">
                    {availableLanguages.length > 0 ? (
availableLanguages.map((langOpt) => {
  const isSelected = isMovieboxId
    ? Boolean(
        langOpt.audioKey &&
        movieboxActiveAudioKey === langOpt.audioKey
      )
    : (
        selectedLanguage.toLowerCase() === langOpt.code.toLowerCase() ||
        selectedLanguage.toLowerCase() === langOpt.name.toLowerCase()
      );

  return (
    <button
      key={langOpt.audioKey || langOpt.code}
                            onClick={() => handleSelectLanguage(langOpt)}
                            className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all duration-200 cursor-pointer flex items-center gap-1.5 ${
                              isSelected
                                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 ring-1 ring-indigo-400'
                                : 'bg-[#14162a] hover:bg-[#1c1f38] text-slate-300 border border-[#222540]'
                            }`}
                          >
                            <Radio className={`w-3 h-3 ${isSelected ? 'text-emerald-300 animate-pulse' : 'text-slate-500'}`} />
                            <span>{langOpt.name}</span>
                          </button>
                        );
                      })
                    ) : (
                      <span className="text-xs text-slate-400 font-mono bg-[#14162a] px-3 py-1 rounded-lg border border-[#222540]">
                        Default Audio
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {showSidebar && !isTheatreMode && (
            <aside className="flex flex-col gap-4 order-2 lg:order-none lg:col-start-2 lg:row-start-1 lg:row-span-2">
              <div className="p-4 rounded-2xl bg-[#0f1122] border border-[#1e213d] flex flex-col h-full max-h-[750px]">
                <div className="pb-3 border-b border-[#1b1e36] flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Tv className="w-4 h-4 text-indigo-400" />
                    <span className="text-sm font-semibold text-white tracking-tight">Episodes</span>
                  </div>

                  <div className="flex items-center bg-[#14162a] p-0.5 rounded-lg border border-[#222540]">
                    <button
                      onClick={() => setEpisodeViewMode('grid')}
                      title="Compact Grid"
                      className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                        episodeViewMode === 'grid' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <LayoutGrid className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setEpisodeViewMode('list')}
                      title="List View"
                      className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                        episodeViewMode === 'list' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <List className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {hasRealSeasons && anime.seasonsList && anime.seasonsList.length > 1 && (
                  <div className="py-3 border-b border-[#1b1e36]">
                    <SeasonDropdown
                      seasons={anime.seasonsList.map((s) => ({
                        ...s,
                        link: s.link ?? '',
                      }))}
                      current={currentSeasonNumber}
                      onSelect={(sNum, firstEp) => updateUrl({ season: sNum, ep: firstEp })}
                    />
                  </div>
                )}

                <div className="pt-3 pb-2">
                  <div className="relative">
                    <Search className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500" />
                    <input
                      type="text"
                      placeholder="Search episode…"
                      value={episodeSearch}
                      onChange={(e) => setEpisodeSearch(e.target.value)}
                      className="w-full bg-[#14162a] border border-[#222540] rounded-lg py-2 pl-8 pr-3 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-500/60 transition-colors"
                    />
                  </div>
                </div>

                <div
                  ref={episodesContainerRef}
                  className="flex-1 overflow-y-auto thin-scrollbar pt-1 pr-1 space-y-1.5 min-h-[300px]"
                >
                  {filteredEpisodes.length === 0 && episodeSearch.trim() ? (
                    <div className="p-6 text-center text-xs text-slate-400">
                      No episodes match "{episodeSearch}".
                    </div>
                  ) : activeSeason?.episodes && activeSeason.episodes.length > 0 ? (
                    episodeViewMode === 'grid' ? (
                      <div className="grid grid-cols-[repeat(auto-fill,minmax(2.75rem,1fr))] gap-2">
                        {filteredEpisodes.map((ep) => {
                          const isCurrent = ep.number === currentEpisodeNumber;
                          return (
                            <button
                              key={ep.number}
                              onClick={() => updateUrl({ ep: ep.number })}
                              title={ep.title || `Episode ${ep.number}`}
                              className={`tp-cv-episode-tile aspect-square w-full rounded-xl text-xs font-mono font-medium transition-all duration-200 flex flex-col items-center justify-center cursor-pointer select-none border relative overflow-hidden ${
                                isCurrent
                                  ? 'bg-indigo-600 border-indigo-400 text-white shadow-lg shadow-indigo-600/40 ring-2 ring-indigo-400/50'
                                  : 'bg-[#14162a] hover:bg-[#1c1f38] border-[#222540] text-slate-300 hover:text-white hover:border-indigo-500/50'
                              }`}
                            >
                              <span className={`text-[9px] leading-none ${isCurrent ? 'text-indigo-200 font-semibold' : 'text-slate-400'}`}>
                                EP
                              </span>
                              <span className="text-xs font-bold tabular-nums leading-tight">{ep.number}</span>
                              {isCurrent && (
                                <span className="absolute bottom-0.5 w-1 h-1 rounded-full bg-emerald-400 animate-ping" />
                              )}
                            </button>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="space-y-1.5">
                        {filteredEpisodes.map((ep) => {
                          const isCurrent = ep.number === currentEpisodeNumber;
                          return (
                            <button
                              key={ep.number}
                              onClick={() => updateUrl({ ep: ep.number })}
                              className={`tp-cv-episode-row w-full p-2.5 rounded-xl text-left text-xs transition-all duration-150 flex items-center justify-between gap-3 cursor-pointer border ${
                                isCurrent
                                  ? 'bg-indigo-600 border-indigo-400 text-white shadow-md shadow-indigo-600/30'
                                  : 'bg-[#14162a] hover:bg-[#1c1f38] border-[#222540] text-slate-300 hover:text-white'
                              }`}
                            >
                              <div className="flex items-center gap-2.5 overflow-hidden min-w-0">
<div className="relative shrink-0 h-11 w-20 rounded-md overflow-hidden bg-[#0d0e1b] border border-[#222540]">
  {ep.image ? (
    <img
      src={ep.image}
      alt={`Episode ${ep.number}`}
      loading="lazy"
      referrerPolicy="no-referrer"
      onError={(e) => {
        const img = e.currentTarget;
        if (img.dataset.fb === '1') return;
        img.dataset.fb = '1';
        const showPoster = anime.image || anime.backdrop || '';
        if (showPoster) {
          img.src = showPoster;
          return;
        }
        img.style.display = 'none';
        const fb = img.nextElementSibling as HTMLElement | null;
        if (fb) fb.style.display = 'flex';
      }}
      className="w-full h-full object-cover"
    />
  ) : null}
  <div
    className="absolute inset-0 flex-col items-center justify-center bg-gradient-to-br from-[#181a33] to-[#0c0d18]"
    style={{ display: ep.image ? 'none' : 'flex' }}
  >
    <Tv className="w-4 h-4 text-indigo-400/70" />
  </div>
  <span className="absolute bottom-0 left-0 px-1 py-px bg-black/75 text-[9px] font-mono font-bold text-white tabular-nums leading-none rounded-tr-md">
    EP {ep.number}
  </span>
</div>
                                <span className="truncate font-medium min-w-0">
                                  {ep.title || `Episode ${ep.number}`}
                                </span>
                              </div>

                              {isCurrent ? (
                                <span className="flex items-center gap-1 text-[11px] font-mono text-emerald-300 shrink-0">
                                  <Play className="w-3 h-3 fill-current" />
                                  <span>Playing</span>
                                </span>
                              ) : (
                                <Play className="w-3.5 h-3.5 text-slate-500 shrink-0 opacity-0" />
                              )}
                            </button>
                          );
                        })}
                      </div>
                    )
                  ) : (
                    <div className="p-6 text-center text-xs text-slate-400">
                      No episodes listed for this season.
                    </div>
                  )}
                </div>
              </div>
            </aside>
          )}

          <div
            className={`order-3 lg:order-none lg:col-start-1 lg:row-start-2 p-4 sm:p-6 rounded-2xl bg-[#0f1122] border border-[#1e213d] flex flex-col sm:flex-row gap-5 items-start ${
              isTheatreMode ? 'hidden' : ''
            }`}
          >
<div className="w-24 sm:w-28 shrink-0 aspect-[3/4] rounded-xl overflow-hidden bg-[#16182c] border border-[#262947] relative shadow-lg">
  {anime.image ? (
    <img
      src={anime.image}
      alt={anime.title}
      referrerPolicy="no-referrer"
      onError={(e) => {
        const img = e.currentTarget;
        img.style.display = 'none';
        const fb = img.nextElementSibling as HTMLElement | null;
        if (fb) fb.style.display = 'flex';
      }}
      className="w-full h-full object-cover"
    />
  ) : null}
  <div
    className="w-full h-full flex-col items-center justify-center p-1.5 text-center bg-gradient-to-br from-[#181a33] to-[#0c0d18]"
    style={{ display: anime.image ? 'none' : 'flex' }}
  >
    {isMovie ? (
      <Film className="w-6 h-6 text-indigo-400 mb-1" />
    ) : (
      <Tv className="w-6 h-6 text-indigo-400 mb-1" />
    )}
    <span className="text-[10px] text-indigo-200 line-clamp-2 leading-tight">
      {anime.title}
    </span>
  </div>
</div>

              <div className="flex-1 space-y-2.5">
                <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-indigo-300">
                  <span className="px-2 py-0.5 rounded bg-indigo-950 border border-indigo-700/60 uppercase text-[10px] font-semibold text-indigo-200">
                    {isMovie ? 'FEATURE FILM' : 'ANIMATED SERIES'}
                  </span>
                  {anime.year && (
                    <>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span className="text-slate-300 tabular-nums flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-indigo-400" />
                        {anime.year}
                      </span>
                    </>
                  )}
                  {isMovie && anime.duration && (
                    <>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span className="text-slate-300 flex items-center gap-1">
                        <Clock className="w-3 h-3 text-indigo-400" />
                        {anime.duration}
                      </span>
                    </>
                  )}
                  {!isMovie && anime.seasons && (
                    <>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span className="text-slate-300">{anime.seasons} Seasons</span>
                    </>
                  )}
                  {!isMovie && anime.episodes && (
                    <>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span className="text-slate-300">{anime.episodes} Episodes</span>
                    </>
                  )}
                </div>

                <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight leading-snug">
                  {anime.title}
                </h1>

                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal line-clamp-3">
                  {anime.overview || 'Streaming in high definition with multi-source server options.'}
                </p>

                {anime.genres && anime.genres.length > 0 && (
                  <div className="pt-1 flex flex-wrap gap-1.5">
                    {anime.genres.map((g) => (
                      <span
                        key={g}
                        className="px-2.5 py-0.5 rounded-md bg-[#16182c] border border-[#252844] text-[11px] text-slate-300"
                      >
                        {g}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
        </div>

        {!isTheatreMode && anime.recommendations && anime.recommendations.length > 0 && (
          <section className="mt-10 pt-6 border-t border-[#1b1e33] space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs font-mono text-indigo-400 mb-0.5">Recommended Titles</div>
                <h2 className="text-lg sm:text-xl font-semibold text-white tracking-tight flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>More Like This</span>
                </h2>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5 sm:gap-4.5">
              {anime.recommendations
                .filter((rec) => rec.id !== anime.id)
                .map((rec) => {
                  const isMovieRec =
                    /^(movies?|film)[-_]/i.test(rec.id);
const unifiedRec: UnifiedAnime = {
  id: rec.id,
  title: rec.title,
  image: rec.image,
  type: isMovieRec ? 'movie' : 'series',
  displayType: isMovieRec ? 'MOVIE' : 'SERIES',
  category: isMovieRec ? 'movie' : 'series',
};
                  return (
                    <AnimeCard
                      key={rec.id}
                      anime={unifiedRec}
                      onSelect={(a) => {
                        onNavigate(`/info/${a.id}`);
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      onPlay={(a) => handleRecommendationClick(a.id)}
                      isBookmarked={watchlistIdSet.has(rec.id)}
                      onToggleWatchlist={onToggleWatchlist}
                    />
                  );
                })}
            </div>
          </section>
        )}
      </main>

      {/* Download Modal */}
      <div
        className={`fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 transition-opacity duration-300 ${
          isDownloadOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
        aria-hidden={!isDownloadOpen}
      >
        <div
          onClick={() => setIsDownloadOpen(false)}
          className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        />

        <div
          role="dialog"
          aria-modal="true"
          aria-label="Download episode"
          className={`relative w-full max-w-lg rounded-2xl bg-[#0f1122] border border-[#1e213d] shadow-2xl shadow-black/80 transition-all duration-300 ${
            isDownloadOpen
              ? 'opacity-100 translate-y-0 scale-100'
              : 'opacity-0 translate-y-4 scale-95'
          }`}
        >
          <div className="flex items-center justify-between gap-3 px-4 py-3 border-b border-[#1b1e36]">
            <div className="flex items-center gap-2 min-w-0">
              <Download className="w-4 h-4 text-indigo-400 shrink-0" />
              <div className="min-w-0">
                <h3 className="text-sm font-semibold text-white truncate">
                  Download {isMovie ? 'Movie' : 'Episode'}
                </h3>
                <p className="text-[11px] text-slate-400 truncate">
                  {isMovie
                    ? anime.title
                    : hasRealSeasons
                    ? `${anime.title} • S${currentSeasonNumber} E${currentEpisodeNumber}`
                    : `${anime.title} • EP${currentEpisodeNumber}`}
                </p>
              </div>
            </div>
            <button
              onClick={() => setIsDownloadOpen(false)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#1a1d35] transition-colors cursor-pointer shrink-0"
              title="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="p-4 max-h-[60vh] overflow-y-auto thin-scrollbar">
            {downloadLoading ? (
              <div className="space-y-2">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div
                    key={i}
                    className="h-14 rounded-xl bg-[#14162a] border border-[#222540] overflow-hidden relative"
                  >
                    <div className="absolute inset-0 -translate-x-full animate-[shimmer_1.4s_infinite] bg-gradient-to-r from-transparent via-[#1e213d]/70 to-transparent" />
                  </div>
                ))}
              </div>
            ) : downloadError ? (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <AlertCircle className="w-8 h-8 text-rose-400 mb-2" />
                <p className="text-xs text-slate-400">{downloadError}</p>
              </div>
            ) : downloadLinks.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <AlertCircle className="w-8 h-8 text-amber-400 mb-2" />
                <p className="text-xs text-slate-400">
                  {isMovie
                    ? 'No download links available for this movie.'
                    : 'No download links available for this episode.'}
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {downloadLinks.map((dl, idx) => (
                  <button
                    key={`${dl.server}-${dl.quality}-${idx}`}
                    type="button"
                    onClick={() =>
                      window.open(dl.link, '_blank', 'noopener,noreferrer')
                    }
                    className="group w-full text-left flex items-center justify-between gap-3 p-3 rounded-xl bg-[#14162a] hover:bg-[#1c1f38] border border-[#222540] hover:border-indigo-500/50 transition-colors cursor-pointer"
                  >
                    <div className="min-w-0 flex items-center gap-3">
                      <div className="shrink-0 w-9 h-9 rounded-lg bg-[#1a1d35] border border-[#2a2d4a] flex items-center justify-center">
                        <Download className="w-4 h-4 text-slate-300" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-semibold text-white truncate">
                          {dl.quality}
                        </div>
                        <div className="text-[11px] text-slate-400 truncate">
                          {dl.server} · {dl.lang}
                        </div>
                      </div>
                    </div>
                    <span
                      className="shrink-0 p-2 rounded-lg text-slate-400 group-hover:text-white group-hover:bg-[#1e213d] transition-colors"
                      aria-hidden="true"
                    >
                      <Download className="w-4 h-4" />
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};