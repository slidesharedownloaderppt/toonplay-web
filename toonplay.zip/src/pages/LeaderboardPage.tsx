import React, { useEffect, useMemo, useState } from 'react';
import { Trophy } from 'lucide-react';
import { userApi } from '../lib/api';
import { AvatarWithFrame } from '../components/profile/AvatarWithFrame';
import { TierUsername } from '../components/profile/TierUsername';

interface LeaderboardEntry {
  rank: number;
  id: number;
  username: string;
  display_name: string;
  avatar_url: string;
  profile_frame_url?: string | null;
  level: number;
  xp: number;
}

interface Props {
  onNavigate: (path: string) => void;
  onBackToHome: () => void;
  onLeaderboardPageLoadingChange?: (loading: boolean) => void;
}

const PODIUM_META = [
  {
    rank: 1,
    borderClass: 'border-[1.5px] md:border-[3px] border-yellow-500',
    gradientClass: 'from-[#14172b] to-yellow-900/20',
    glowClass: 'shadow-[0_0_20px_rgba(234,179,8,0.15)] md:shadow-[0_0_50px_rgba(234,179,8,0.15)]',
    avatarBorderClass: 'border-yellow-500 shadow-[0_0_10px_rgba(234,179,8,0.4)] md:shadow-[0_0_20px_rgba(234,179,8,0.4)]',
    xpTextClass: 'text-yellow-500',
    orderClass: 'order-2',
    scaleClass: 'scale-105 md:scale-110',
    zClass: 'z-30',
    frameUrl: 'https://animerulz.watch/profile-icons/first_place.webp',
  },
  {
    rank: 2,
    borderClass: 'border-[1.5px] md:border-[2px] border-slate-300',
    gradientClass: 'from-[#14172b] to-slate-700/20',
    glowClass: 'shadow-[0_0_10px_rgba(148,163,184,0.15)] md:shadow-[0_0_30px_rgba(148,163,184,0.15)]',
    avatarBorderClass: 'border-slate-300 shadow-[0_0_5px_rgba(148,163,184,0.3)] md:shadow-[0_0_15px_rgba(148,163,184,0.3)]',
    xpTextClass: 'text-slate-200',
    orderClass: 'order-1',
    scaleClass: 'scale-[0.90] md:scale-[0.95]',
    zClass: 'z-20',
    frameUrl: 'https://animerulz.watch/profile-icons/second_place.webp',
  },
  {
    rank: 3,
    borderClass: 'border-[1.5px] md:border-[2px] border-amber-700',
    gradientClass: 'from-[#14172b] to-amber-900/20',
    glowClass: 'shadow-[0_0_10px_rgba(180,83,9,0.15)] md:shadow-[0_0_30px_rgba(180,83,9,0.15)]',
    avatarBorderClass: 'border-amber-700 shadow-[0_0_5px_rgba(180,83,9,0.3)] md:shadow-[0_0_15px_rgba(180,83,9,0.3)]',
    xpTextClass: 'text-amber-500',
    orderClass: 'order-3',
    scaleClass: 'scale-[0.75] md:scale-[0.80]',
    zClass: 'z-10',
    frameUrl: 'https://animerulz.watch/profile-icons/third_place.webp',
  },
];

function formatXp(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return String(n);
}

function formatXpLong(n: number): string {
  return n.toLocaleString('en-US');
}

export const LeaderboardPage: React.FC<Props> = ({
  onNavigate,
  onBackToHome,
  onLeaderboardPageLoadingChange,
}) => {
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    onLeaderboardPageLoadingChange?.(true);

    userApi
      .leaderboard(10)
      .then((res) => {
        if (cancelled) return;
        setEntries(res.entries || []);
      })
      .catch((err: any) => {
        if (!cancelled) setError(err?.message || 'Failed to load leaderboard');
      })
      .finally(() => {
        if (!cancelled) {
          setLoading(false);
          onLeaderboardPageLoadingChange?.(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [onLeaderboardPageLoadingChange]);

  const podium = useMemo(() => entries.slice(0, 3), [entries]);
  const contenders = useMemo(() => entries.slice(3, 10), [entries]);

  if (loading) return null;

  return (
    <div className="text-slate-100 pt-6 sm:pt-10 md:pt-20 pb-32 font-sans overflow-x-hidden relative">
      {/* Background layers — site theme, behind everything so App footer stays visible */}
      <div className="fixed inset-0 pointer-events-none -z-10">
        <div className="absolute inset-0 bg-[radial-gradient(120%_75%_at_50%_0%,#16182c_0%,#0f1122_45%,#0b0c16_100%)]" />
        <div
          className="absolute inset-0 opacity-[0.07] mix-blend-screen"
          style={{
            backgroundImage:
              "url('https://www.transparenttextures.com/patterns/stardust.png')",
          }}
        />
      </div>

      {/* HALL OF FAME watermark */}
      <div className="fixed inset-0 flex items-center justify-center pointer-events-none z-0 opacity-[0.03] overflow-hidden">
        <h1 className="text-[5.5rem] sm:text-[10rem] md:text-[15rem] font-black italic tracking-tighter uppercase whitespace-normal md:whitespace-nowrap leading-[0.85] md:leading-none text-center -skew-x-[15deg] px-4 md:px-0">
          HALL OF FAME
        </h1>
      </div>

      <div className="w-full max-w-[1800px] mx-auto px-4 xl:px-8 relative z-10 flex flex-col items-center gap-4 sm:gap-6 md:gap-8">
        {/* Error */}
        {error && !loading && (
          <div className="py-32 text-center max-w-md">
            <div className="p-4 rounded-xl bg-rose-950/30 border border-rose-900/40 text-rose-300 text-sm">
              {error}
            </div>
          </div>
        )}

        {/* Empty */}
        {!loading && !error && entries.length === 0 && (
          <div className="py-32 text-center">
            <Trophy className="w-12 h-12 text-slate-700 mx-auto mb-4" />
            <p className="text-sm text-slate-400">No players yet.</p>
          </div>
        )}

        {!loading && !error && entries.length > 0 && (
          <>
            {/* Podium — Top 3 */}
            <div className="flex xl:flex flex-1 flex-col items-center w-full max-w-[1000px]">
              <div className="mb-6 sm:mb-10 md:mb-16 text-center">
                <h1 className="text-2xl sm:text-4xl md:text-5xl font-black italic text-white drop-shadow-[0_0_20px_rgba(255,255,255,0.2)] tracking-widest uppercase">
                  Global Ranking
                </h1>
                <div className="mt-1 sm:mt-2 text-[10px] sm:text-xs md:text-sm font-mono uppercase tracking-widest text-slate-400">
                  Top 10 · All Time
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 sm:gap-3 md:gap-6 w-full max-w-3xl mx-auto mb-8 sm:mb-10 md:mb-16 px-2 sm:px-3 md:px-0">
                {[podium[1], podium[0], podium[2]].map((entry) => {
                  if (!entry) return null;
                  const meta = PODIUM_META[entry.rank - 1];
                  if (!meta) return null;

                  return (
                    <div
                      key={entry.id}
                      className={`flex flex-col justify-end h-full transform origin-bottom ${meta.orderClass} ${meta.scaleClass} ${meta.zClass}`}
                    >
                      <div
                        className={`relative group rounded-xl md:rounded-2xl overflow-hidden flex flex-col items-center justify-start py-2 sm:py-3 md:py-4 px-1 md:px-6 transition duration-500 hover:scale-[1.03] hover:-translate-y-2 h-fit min-h-0 bg-gradient-to-b ${meta.borderClass} ${meta.gradientClass} ${meta.glowClass}`}
                      >
                        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-[3rem] sm:text-[4rem] md:text-[10rem] font-black italic text-white/[0.04] pointer-events-none select-none">
                          {entry.rank}
                        </div>

                        <div className="relative z-10 w-full flex flex-col items-center justify-start md:pt-2">
                          <div className="relative w-14 h-20 sm:w-28 sm:h-28 md:w-28 md:h-40 shrink-0 mt-1 md:mt-0">
                            <div className="absolute top-3 md:top-6 left-1/2 -translate-x-1/2 z-10">
                              <AvatarWithFrame
                                avatarUrl={entry.avatar_url}
                                frameUrl={entry.profile_frame_url}
                                username={entry.username}
                                alt={entry.display_name || entry.username}
                                className="size-14 md:size-28"
                                avatarClassName="border-0"
                              />
                            </div>

                            <img
                              src={meta.frameUrl}
                              alt=""
                              aria-hidden="true"
                              className="absolute top-0 left-1/2 -translate-x-1/2 w-20 h-20 sm:w-28 sm:h-28 md:w-40 md:h-40 max-w-none object-contain pointer-events-none select-none z-30"
                              onError={(e) => {
                                e.currentTarget.style.display = 'none';
                              }}
                            />
                          </div>

                          <div className="flex flex-col items-center w-full min-w-0 mt-2 gap-2">
                            {/* ONLY the name is clickable */}
                            <button
                              type="button"
                              onClick={() => onNavigate(`/u/${entry.username}`)}
                              className="text-[10px] sm:text-sm md:text-xl font-black italic text-center truncate leading-[1.15] w-full mb-1 uppercase tracking-wider cursor-pointer bg-transparent border-0 p-0 hover:brightness-125 transition-[filter,color]"
                            >
                              <TierUsername
                                name={entry.display_name || entry.username}
                                level={entry.level}
                                xp={entry.xp}
                                className="inline-block max-w-full truncate"
                              />
                            </button>

                            <div className="bg-[#0f1122]/80 backdrop-blur-md rounded md:rounded-xl px-1.5 py-2 md:px-4 md:py-3 border border-[#222540] flex flex-col items-center mt-0 group-hover:bg-[#16182c]/90 transition-colors w-full shrink-0">
                              <span className="text-[6px] md:text-[10px] font-black italic uppercase tracking-widest text-white/40 mb-0 md:mb-1">
                                Total XP
                              </span>
                              <span
                                className={`text-sm font-black italic tracking-tighter drop-shadow-md md:hidden ${meta.xpTextClass}`}
                              >
                                {formatXp(entry.xp)}
                              </span>
                              <span
                                className={`text-3xl font-black italic tracking-tighter drop-shadow-md hidden md:block ${meta.xpTextClass}`}
                              >
                                {formatXpLong(entry.xp)}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Contenders list — ranks 4-10 */}
              <div className="flex-1 flex flex-col w-full max-w-4xl mx-auto pt-8 border-t border-[#23263f] relative">
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#0b0c16] px-4 text-xs font-mono tracking-[0.3em] uppercase text-slate-500">
                  THE CONTENDERS
                </div>

                {/* Column headers */}
                <div className="flex items-center gap-1 w-full h-8 md:h-10 mb-2 pr-1 md:pr-2">
                  <div className="w-8 md:w-16" />
                  <div className="flex-1" />
                  <div className="w-24 md:w-36 text-center">
                    <span className="font-black text-sm md:text-2xl text-white drop-shadow-md italic">
                      XP
                    </span>
                  </div>
                  <div className="w-12 md:w-20 text-center">
                    <span className="font-black text-sm md:text-2xl text-slate-400 drop-shadow-md italic">
                      LVL
                    </span>
                  </div>
                </div>

                <div className="flex flex-col gap-1.5 md:gap-2">
                  {contenders.map((entry) => (
                    <button
                      key={entry.id}
                      type="button"
                      onClick={() => onNavigate(`/u/${entry.username}`)}
                      className="flex items-stretch gap-1 w-full h-12 md:h-14 group hover:scale-[1.01] transition-transform duration-200 cursor-pointer bg-transparent border-0 p-0 text-left"
                    >
                      <div className="w-8 md:w-16 flex items-center justify-center">
                        <span className="font-black text-lg md:text-3xl italic text-white drop-shadow-lg opacity-80">
                          {entry.rank}
                        </span>
                      </div>

                      <div className="flex-1 min-w-0 bg-[#14172b] flex items-center -skew-x-[15deg] px-3 md:px-6 shadow-lg border-l-2 md:border-l-[6px] border-[#23263f] hover:border-indigo-500/50 transition-colors">
                        <div className="flex items-center gap-2.5 md:gap-4 skew-x-[15deg] w-full min-w-0">
                          <AvatarWithFrame
                            avatarUrl={entry.avatar_url}
                            frameUrl={entry.profile_frame_url}
                            username={entry.username}
                            alt={entry.display_name || entry.username}
                            className="size-7 md:size-9"
                            avatarClassName="border border-[#2e3252]"
                          />
                          {/* Name — whole card is now clickable */}
                          <TierUsername
                            name={entry.display_name || entry.username}
                            level={entry.level}
                            xp={entry.xp}
                            className="flex-1 min-w-0 font-black text-xs md:text-xl uppercase tracking-widest truncate text-left group-hover:brightness-125 transition-[filter,color]"
                          />
                        </div>
                      </div>

                      <div className="w-24 md:w-36 flex items-center justify-center -skew-x-[15deg] shrink-0 grow-0 basis-[6rem] md:basis-[9rem] bg-slate-100 text-[#0b0c16] px-1">
                        <span className="font-black text-xs md:text-2xl skew-x-[15deg] tracking-tighter drop-shadow-sm truncate">
                          {formatXpLong(entry.xp)}
                        </span>
                      </div>

                      <div className="w-12 md:w-20 bg-[#16182c] flex items-center justify-center -skew-x-[15deg] shrink-0 grow-0 basis-[3rem] md:basis-[5rem] border-r-2 md:border-r-[6px] border-[#23263f]">
                        <span className="font-black text-xs md:text-xl text-slate-200 skew-x-[15deg]">
                          {entry.level}
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};