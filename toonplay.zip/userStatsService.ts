import { query, queryOne } from './db';
import { computeShowProgress } from './src/lib/mostWatchedProgress';

export interface MostWatchedShow {
  cartoon_id: string;
  cartoon_title: string;
  cartoon_image: string;
  episodes_watched: number;
  episodes_completed_30d: number;
  episodes_completed_total: number;
  total_episodes_available: number;
  progress_percentage: number | null;
  completed: number;
  last_completed_at: string | null;
  period_days: number;
}

export interface SqlExecutor {
  query: <T = any>(sql: string, params?: any[]) => Promise<T[]>;
  queryOne: <T = any>(sql: string, params?: any[]) => Promise<T | null>;
}

const defaultExecutor: SqlExecutor = {
  query,
  queryOne,
};

/**
 * Authoritative SQL for "Shows Watched":
 * Counts distinct shows (cartoon_id) for which the user has completed at least
 * ONE episode in `user_episode_completions`.
 */
export const SHOWS_WATCHED_SQL = `
  SELECT COUNT(DISTINCT cartoon_id) AS shows_watched
  FROM user_episode_completions
  WHERE user_id = ?
`.trim();

/**
 * Authoritative SQL for "Most Watched (Last N Days)":
 * 1. Filters `user_episode_completions` by `user_id` and `completed_at >= DATE_SUB(NOW(), INTERVAL ? DAY)`.
 * 2. Deduplicates completed episodes via `COUNT(DISTINCT episode_id)` grouped strictly by `cartoon_id`.
 * 3. Excludes shows with 0 completed episodes during the period (`HAVING COUNT(DISTINCT episode_id) > 0`).
 * 4. Joins `user_anime_stats` and `watch_history` for title/artwork metadata without join fan-out.
 * 5. Ranks by completed episode count DESC, breaking ties by most recent completion timestamp DESC.
 */
export const MOST_WATCHED_WINDOW_SQL = `
  SELECT
    c.cartoon_id,
    COALESCE(
      NULLIF(MAX(uas.cartoon_title), ''),
      NULLIF(MAX(wh.cartoon_title), ''),
      c.cartoon_id
    ) AS cartoon_title,
    COALESCE(
      NULLIF(MAX(uas.cartoon_image), ''),
      NULLIF(MAX(wh.cartoon_image), ''),
      ''
    ) AS cartoon_image,
    c.episodes_watched,
    COALESCE(MAX(all_c.episodes_completed_total), c.episodes_watched) AS episodes_completed_total,
    COALESCE(MAX(uas.total_episodes_available), 0) AS total_episodes_available,
    COALESCE(MAX(uas.completed), 0) AS completed,
    c.last_completed_at
  FROM (
    SELECT
      cartoon_id,
      COUNT(DISTINCT episode_id) AS episodes_watched,
      MAX(completed_at) AS last_completed_at
    FROM user_episode_completions
    WHERE user_id = ?
      AND completed_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
    GROUP BY cartoon_id
    HAVING COUNT(DISTINCT episode_id) > 0
  ) c
  LEFT JOIN (
    SELECT
      cartoon_id,
      COUNT(DISTINCT episode_id) AS episodes_completed_total
    FROM user_episode_completions
    WHERE user_id = ?
    GROUP BY cartoon_id
  ) all_c
    ON all_c.cartoon_id = c.cartoon_id
  LEFT JOIN user_anime_stats uas
    ON uas.user_id = ? AND uas.cartoon_id = c.cartoon_id
  LEFT JOIN watch_history wh
    ON wh.user_id = ? AND wh.cartoon_id = c.cartoon_id
  GROUP BY c.cartoon_id, c.episodes_watched, c.last_completed_at
  ORDER BY c.episodes_watched DESC, c.last_completed_at DESC
  LIMIT ?
`.trim();

/**
 * Returns the exact number of distinct shows for which `userId` has completed
 * at least one episode.
 */
export async function getShowsWatchedCount(
  userId: number,
  executor: SqlExecutor = defaultExecutor
): Promise<number> {
  const cleanId = Number(userId);
  if (!Number.isFinite(cleanId) || cleanId <= 0) return 0;

  const row = await executor.queryOne<{ shows_watched: number }>(SHOWS_WATCHED_SQL, [cleanId]);
  return Math.max(0, Number(row?.shows_watched || 0));
}

/**
 * Batched lookup of Shows Watched counts for multiple users in a single SQL query
 * (avoids N+1 queries on leaderboard and user directory endpoints).
 */
export async function getShowsWatchedMap(
  userIds: number[],
  executor: SqlExecutor = defaultExecutor
): Promise<Map<number, number>> {
  const uniqueIds = Array.from(
    new Set(userIds.map((id) => Number(id)).filter((id) => Number.isFinite(id) && id > 0))
  );
  const result = new Map<number, number>();
  if (uniqueIds.length === 0) return result;

  const placeholders = uniqueIds.map(() => '?').join(', ');
  const sql = `
    SELECT user_id, COUNT(DISTINCT cartoon_id) AS shows_watched
    FROM user_episode_completions
    WHERE user_id IN (${placeholders})
    GROUP BY user_id
  `.trim();

  const rows = await executor.query<{ user_id: number; shows_watched: number }>(sql, uniqueIds);
  for (const row of rows) {
    result.set(Number(row.user_id), Math.max(0, Number(row.shows_watched || 0)));
  }
  return result;
}

/**
 * Returns the user's genuinely most-watched shows during the last `days` days
 * (default 30 days), ranked by distinct completed episodes DESC, then most
 * recent completion timestamp DESC.
 */
export async function getMostWatchedShows(
  userId: number,
  options: { days?: number; limit?: number } = {},
  executor: SqlExecutor = defaultExecutor
): Promise<MostWatchedShow[]> {
  const cleanId = Number(userId);
  if (!Number.isFinite(cleanId) || cleanId <= 0) return [];

  const days = Math.min(365, Math.max(1, Math.floor(Number(options.days ?? 30))));
  const limit = Math.min(50, Math.max(1, Math.floor(Number(options.limit ?? 5))));

  const rows = await executor.query<any>(MOST_WATCHED_WINDOW_SQL, [
    cleanId,
    days,
    cleanId,
    cleanId,
    cleanId,
    limit,
  ]);

  return rows
    .map((r): MostWatchedShow => {
      const count30d = Math.max(0, Number(r.episodes_watched || 0));
      const countTotal = Math.max(count30d, Number(r.episodes_completed_total ?? count30d));
      const totalAvailable = Math.max(0, Number(r.total_episodes_available || 0));
      const progress = computeShowProgress(countTotal, totalAvailable);
      return {
        cartoon_id: String(r.cartoon_id),
        cartoon_title: String(r.cartoon_title || r.cartoon_id),
        cartoon_image: String(r.cartoon_image || ''),
        episodes_watched: count30d,
        episodes_completed_30d: count30d,
        episodes_completed_total: progress.watchedEpisodes,
        total_episodes_available: progress.totalEpisodes,
        progress_percentage: progress.progressPercentage,
        completed: progress.hasTotalEpisodes
          ? progress.isCompleted
            ? 1
            : 0
          : Number(r.completed || 0) === 1
          ? 1
          : 0,
        last_completed_at: r.last_completed_at ? String(r.last_completed_at) : null,
        period_days: days,
      };
    })
    .filter((item) => item.episodes_watched > 0);
}

/**
 * Atomically records an episode completion inside an active transaction.
 * Returns `true` ONLY if this is the first completion of `(userId, cartoonId, episodeId)`,
 * ensuring duplicate or concurrent completion events never inflate statistics or
 * overwrite the original `completed_at` timestamp.
 */
export async function recordEpisodeCompletionAtomic(
  conn: { execute: (sql: string, params?: any[]) => Promise<any> },
  args: {
    userId: number;
    cartoonId: string;
    episodeId: string;
    seasonNumber: number | null;
    episodeNumber: number | null;
  }
): Promise<boolean> {
  const [existingRows] = await conn.execute(
    'SELECT id FROM user_episode_completions WHERE user_id = ? AND cartoon_id = ? AND episode_id = ? LIMIT 1',
    [args.userId, args.cartoonId, args.episodeId]
  );
  if (Array.isArray(existingRows) && existingRows.length > 0) {
    return false;
  }

  const [insertResult] = await conn.execute(
    `INSERT IGNORE INTO user_episode_completions (user_id, cartoon_id, episode_id, season_number, episode_number)
     VALUES (?, ?, ?, ?, ?)`,
    [args.userId, args.cartoonId, args.episodeId, args.seasonNumber, args.episodeNumber]
  );

  return Number((insertResult as any)?.affectedRows || 0) === 1;
}

/**
 * Recomputes and syncs the cached `users.total_anime_watched` column from the
 * authoritative `user_episode_completions` table inside an active transaction.
 */
export async function syncUserShowsWatchedColumn(
  conn: { execute: (sql: string, params?: any[]) => Promise<any> },
  userId: number
): Promise<number> {
  const [rows] = await conn.execute(SHOWS_WATCHED_SQL, [userId]);
  const count = Math.max(0, Number((rows as any[])?.[0]?.shows_watched || 0));

  await conn.execute(
    `UPDATE users
       SET total_anime_watched = ?,
           updated_at = NOW()
     WHERE id = ?`,
    [count, userId]
  );

  return count;
}
