import express, { Request, Response, NextFunction } from 'express';
import compression from 'compression';
import fs from 'fs';
import fsp from 'fs/promises';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import bcrypt from 'bcrypt';
import { OAuth2Client } from 'google-auth-library';
import { pool, query, queryOne, execute, transaction, pingDb } from './db';
import { sendOtpEmail } from './mailer';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.set('trust proxy', 1);
const PORT = Number(process.env.PORT || 3000);
const isProd = process.env.NODE_ENV === 'production';
const rawCorsOrigin = (process.env.CORS_ORIGIN || '*').trim();
const allowedCorsOrigins =
  rawCorsOrigin === '*'
    ? null
    : rawCorsOrigin
        .split(',')
        .map((o) => o.trim().replace(/^["']|["']$/g, '').replace(/\/+$/, ''))
        .filter(Boolean);
const BCRYPT_ROUNDS = Number(process.env.BCRYPT_ROUNDS || 10);
const OTP_TTL_MINUTES = Number(process.env.OTP_TTL_MINUTES || 10);
const RESET_TOKEN_TTL_MINUTES = Number(process.env.RESET_TOKEN_TTL_MINUTES || 30);
const OTP_MAX_ATTEMPTS = Number(process.env.OTP_MAX_ATTEMPTS || 5);
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID || '';

const googleClient = GOOGLE_CLIENT_ID ? new OAuth2Client(GOOGLE_CLIENT_ID) : null;

app.set('etag', 'strong');
app.use(compression({ threshold: 1024 }));
app.use((req: Request, res: Response, next: NextFunction) => {
  if (!allowedCorsOrigins || allowedCorsOrigins.length === 0) {
    res.header('Access-Control-Allow-Origin', '*');
  } else {
    const reqOrigin = typeof req.headers.origin === 'string' ? req.headers.origin.replace(/\/+$/, '') : '';
    const matched = reqOrigin && allowedCorsOrigins.includes(reqOrigin) ? reqOrigin : allowedCorsOrigins[0];
    res.header('Access-Control-Allow-Origin', matched);
    res.header('Vary', 'Origin');
  }
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization, x-auth-token');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(204);
  }
  next();
});

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

const CONTACTS_DIR = path.resolve(__dirname, 'contacts');
const DMCA_DIR = path.resolve(__dirname, 'dmca');
const CACHE_DIR = path.resolve(__dirname, 'cache');

if (!fs.existsSync(CONTACTS_DIR)) {
  fs.mkdirSync(CONTACTS_DIR, { recursive: true });
}
if (!fs.existsSync(DMCA_DIR)) {
  fs.mkdirSync(DMCA_DIR, { recursive: true });
}
if (!fs.existsSync(CACHE_DIR)) {
  fs.mkdirSync(CACHE_DIR, { recursive: true });
}

function sanitizeSlug(str: string): string {
  return (
    str
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .slice(0, 45) || 'general'
  );
}

function validateUsername(raw: string): { ok: true; value: string } | { ok: false; error: string } {
  const trimmed = String(raw || '').trim();
  if (!trimmed) return { ok: false, error: 'Username is required.' };
  if (trimmed.length < 3) return { ok: false, error: 'Username must be at least 3 characters.' };
  if (trimmed.length > 30) return { ok: false, error: 'Username must be 30 characters or fewer.' };
  if (!/^[a-zA-Z0-9_]+$/.test(trimmed)) {
    return {
      ok: false,
      error: 'Username may only contain letters, numbers, and underscores (no spaces or symbols).',
    };
  }
  return { ok: true, value: trimmed.toLowerCase() };
}

function sanitizeCacheKey(key: string): string {
  return key.replace(/[^a-zA-Z0-9._-]+/g, '_').slice(0, 180);
}

const MEMORY_CACHE_MAX = 500;
const memoryCache = new Map<string, any>();

function setMemoryCache(key: string, data: any): void {
  if (memoryCache.has(key)) memoryCache.delete(key);
  memoryCache.set(key, data);
  if (memoryCache.size > MEMORY_CACHE_MAX) {
    const oldestKey = memoryCache.keys().next().value;
    if (oldestKey !== undefined) memoryCache.delete(oldestKey);
  }
}

async function readCache(key: string): Promise<any | null> {
  try {
    const safeKey = sanitizeCacheKey(key);
    if (!safeKey) return null;
    if (memoryCache.has(safeKey)) {
      const val = memoryCache.get(safeKey);
      memoryCache.delete(safeKey);
      memoryCache.set(safeKey, val);
      return val;
    }
    const filePath = path.join(CACHE_DIR, `${safeKey}.json`);
    const raw = await fsp.readFile(filePath, 'utf-8');
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    setMemoryCache(safeKey, parsed);
    return parsed;
  } catch {
    return null;
  }
}

function writeCache(key: string, data: any): void {
  const safeKey = sanitizeCacheKey(key);
  if (!safeKey) return;
  setMemoryCache(safeKey, data);
  const filePath = path.join(CACHE_DIR, `${safeKey}.json`);
  void fsp.writeFile(filePath, JSON.stringify(data), 'utf-8').catch((err) => {
    console.warn('[Cache] Failed to write cache file:', err);
  });
}

function generateSecureToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

function generateOtpCode(): string {
  return String(crypto.randomInt(100000, 1000000));
}

function calculateLevel(xp: number): number {
  if (xp <= 0) return 1;
  return Math.floor(Math.sqrt(xp / 100)) + 1;
}

async function recordUniqueCartoonOpen(conn: any, userId: number, cartoonId: string): Promise<boolean> {
  const id = String(cartoonId || '').trim();
  if (!id) return false;

  const [result] = await conn.execute(
    `INSERT IGNORE INTO user_unique_cartoons (user_id, cartoon_id, first_seen)
     VALUES (?, ?, NOW())`,
    [userId, id]
  );

  const inserted = (result as any).affectedRows === 1;
  if (inserted) {
    await conn.execute(
      `UPDATE users
         SET total_anime_watched = total_anime_watched + 1,
             updated_at = NOW()
       WHERE id = ?`,
      [userId]
    );
  }
  return inserted;
}

// ───────────────────────── Streak helpers ─────────────────────────

function toYmd(d: any): string | null {
  if (!d) return null;
  try {
    return new Date(d).toISOString().slice(0, 10);
  } catch {
    return null;
  }
}

function todayYmd(): string {
  return new Date().toISOString().slice(0, 10);
}

/**
 * Recompute current + best streak from user_daily_activity (source of truth),
 * then persist them into users.
 * Must be called inside a transaction, AFTER today's activity row is upserted.
 */
async function recomputeAndPersistStreaks(
  conn: any,
  userId: number
): Promise<{ current: number; best: number; lastActive: string | null }> {
  const [rows] = await conn.execute(
    `SELECT activity_date
       FROM user_daily_activity
      WHERE user_id = ? AND episodes_watched > 0
      ORDER BY activity_date DESC
      LIMIT 3650`,
    [userId]
  );
  const days: string[] = (rows as any[])
    .map((r) => toYmd(r.activity_date))
    .filter(Boolean) as string[];

  if (days.length === 0) {
    await conn.execute(
      `UPDATE users
          SET current_streak_days = 0,
              best_streak_days = 0,
              last_active_date = NULL,
              updated_at = NOW()
        WHERE id = ?`,
      [userId]
    );
    return { current: 0, best: 0, lastActive: null };
  }

  const today = todayYmd();
  const yesterday = new Date(Date.now() - 86_400_000).toISOString().slice(0, 10);
  const lastActive = days[0];

  // Best streak = longest consecutive run anywhere.
  let best = 1;
  let run = 1;
  for (let i = 1; i < days.length; i++) {
    const prev = new Date(days[i - 1]).getTime();
    const cur = new Date(days[i]).getTime();
    if (Math.round((prev - cur) / 86_400_000) === 1) run += 1;
    else run = 1;
    if (run > best) best = run;
  }

  // Current streak = trailing run ending today or yesterday; else 0.
  let current = 0;
  if (lastActive === today || lastActive === yesterday) {
    let trail = 1;
    for (let i = 1; i < days.length; i++) {
      const prev = new Date(days[i - 1]).getTime();
      const cur = new Date(days[i]).getTime();
      if (Math.round((prev - cur) / 86_400_000) === 1) trail += 1;
      else break;
    }
    current = trail;
  }

  if (best < current) best = current;

  await conn.execute(
    `UPDATE users
        SET current_streak_days = ?,
            best_streak_days = ?,
            last_active_date = ?,
            updated_at = NOW()
      WHERE id = ?`,
    [current, best, lastActive, userId]
  );

  return { current, best, lastActive };
}

/**
 * Display-time decay. If the user's last active day is older than yesterday,
 * the current streak is broken → 0. Never writes to DB.
 */
function effectiveStreak(user: any): { current: number; best: number } {
  const rawCur = Math.max(0, Number(user?.current_streak_days || 0));
  const rawBest = Math.max(0, Number(user?.best_streak_days || 0));
  const last = toYmd(user?.last_active_date);
  if (!last) return { current: 0, best: rawBest };

  const t = todayYmd();
  const y = new Date(Date.now() - 86_400_000).toISOString().slice(0, 10);

  if (last === t || last === y) {
    return { current: rawCur, best: Math.max(rawBest, rawCur) };
  }
  return { current: 0, best: rawBest };
}

function sanitizeUser(user: any) {
  if (!user) return null;
  const clone = { ...user };
  delete clone.password;
  delete clone.reset_otp;
  delete clone.reset_otp_expires;
  delete clone.reset_token;
  delete clone.reset_token_expires;
  delete clone.reset_otp_attempts;
  delete clone.token;
  return clone;
}

interface AuthenticatedRequest extends Request {
  user?: any;
}

const AUTH_CACHE_TTL_MS = 20_000;
const AUTH_CACHE_MAX = 2000;
const authTokenCache = new Map<string, { user: any; expiresAt: number }>();
const userIdToAuthToken = new Map<number, string>();

function cacheAuthUser(token: string, user: any): void {
  if (!token || !user?.id) return;
  const oldToken = userIdToAuthToken.get(Number(user.id));
  if (oldToken && oldToken !== token) authTokenCache.delete(oldToken);
  if (authTokenCache.size >= AUTH_CACHE_MAX) {
    const oldestKey = authTokenCache.keys().next().value;
    if (oldestKey !== undefined) authTokenCache.delete(oldestKey);
  }
  authTokenCache.set(token, { user, expiresAt: Date.now() + AUTH_CACHE_TTL_MS });
  userIdToAuthToken.set(Number(user.id), token);
}

function invalidateUserAuthCache(userId?: number | null, token?: string | null): void {
  if (token) authTokenCache.delete(token);
  if (userId != null) {
    const idNum = Number(userId);
    const existingToken = userIdToAuthToken.get(idNum);
    if (existingToken) {
      authTokenCache.delete(existingToken);
      userIdToAuthToken.delete(idNum);
    }
  }
}

function extractRequestToken(req: Request): string {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.substring(7).trim();
  }
  if (req.headers['x-auth-token']) {
    return String(req.headers['x-auth-token']).trim();
  }
  if (req.query.token) {
    return String(req.query.token).trim();
  }
  return '';
}

async function resolveUserByToken(token: string): Promise<any | null> {
  if (!token) return null;
  const cached = authTokenCache.get(token);
  if (cached && cached.expiresAt > Date.now()) {
    return cached.user;
  }
  if (cached) authTokenCache.delete(token);
  const user = await queryOne('SELECT * FROM users WHERE token = ?', [token]);
  if (user) cacheAuthUser(token, user);
  return user || null;
}

async function authenticateToken(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  res.setHeader('Cache-Control', 'private, no-store');
  try {
    const token = extractRequestToken(req);

    if (!token) {
      return res.status(401).json({ success: false, error: 'Unauthorized: missing token' });
    }

    const user = await resolveUserByToken(token);
    if (!user) {
      return res.status(401).json({ success: false, error: 'Unauthorized: invalid or expired token' });
    }

    req.user = user;
    next();
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Authentication error' });
  }
}

async function optionalAuthenticateToken(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  try {
    const token = extractRequestToken(req);

    if (token) {
      res.setHeader('Cache-Control', 'private, no-store');
      const user = await resolveUserByToken(token);
      if (user) {
        req.user = user;
      }
    }
    next();
  } catch {
    next();
  }
}

app.get('/api/health', async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  const dbConnected = await pingDb();
  res.json({
    success: true,
    status: 'ok',
    timestamp: new Date().toISOString(),
    database: dbConnected ? 'connected' : 'disconnected',
  });
});

app.get('/api/config/public', (_req, res) => {
  res.setHeader('Cache-Control', 'public, max-age=300');
  res.json({
    success: true,
    googleClientId: process.env.GOOGLE_CLIENT_ID || '',
  });
});

app.post('/api/contact', async (req, res) => {
  try {
    const { name, email, subject, category, message } = req.body;
    if (!name || !email || !message) {
      return res.status(400).json({
        success: false,
        error: 'Name, email, and message are required fields.',
      });
    }

    const now = new Date();
    const dateStr = now.toISOString().slice(0, 10);
    const timestamp = now.getTime();
    const id = `contact_${timestamp}_${Math.random().toString(36).substring(2, 7)}`;

    const nameSlug = sanitizeSlug(String(name));
    const subjectSlug = sanitizeSlug(String(subject || category || 'inquiry'));

    const fileName = `contact_${dateStr}_${nameSlug}_${subjectSlug}_${timestamp}.json`;
    const fullPath = path.join(CONTACTS_DIR, fileName);

    const record = {
      id,
      fileName,
      relativeFolder: 'contacts',
      fullPath: `contacts/${fileName}`,
      submittedAt: now.toISOString(),
      recipientEmail: 'dm.toonplay@proton.me',
      category: String(category || 'general').trim(),
      subject: String(subject || 'General Inquiry').trim(),
      sender: {
        name: String(name).trim(),
        email: String(email).trim(),
      },
      message: String(message).trim(),
      metadata: {
        ip: req.ip || req.headers['x-forwarded-for'] || 'client',
        userAgent: req.headers['user-agent'] || 'unknown',
        status: 'pending_review',
      },
    };

    await fsp.writeFile(fullPath, JSON.stringify(record, null, 2), 'utf-8');
    return res.status(201).json({
      success: true,
      message: 'Contact inquiry saved successfully to contacts directory.',
      fileName,
      filePath: `contacts/${fileName}`,
      record,
    });
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      error: error?.message || 'Failed to save contact inquiry to disk.',
    });
  }
});

app.post('/api/dmca', async (req, res) => {
  try {
    const {
      ownerName,
      email,
      copyrightWork,
      infringingUrls,
      goodFaithStatement,
      accuracyStatement,
    } = req.body;

    if (!ownerName || !email || !copyrightWork || !infringingUrls) {
      return res.status(400).json({
        success: false,
        error: 'Owner name, official email, copyrighted work, and infringing URLs are required.',
      });
    }

    const now = new Date();
    const dateStr = now.toISOString().slice(0, 10);
    const timestamp = now.getTime();
    const id = `dmca_${timestamp}_${Math.random().toString(36).substring(2, 7)}`;

    const workSlug = sanitizeSlug(String(copyrightWork));
    const ownerSlug = sanitizeSlug(String(ownerName));

    const fileName = `dmca_${dateStr}_${workSlug}_${ownerSlug}_${timestamp}.json`;
    const fullPath = path.join(DMCA_DIR, fileName);

    const record = {
      id,
      fileName,
      relativeFolder: 'dmca',
      fullPath: `dmca/${fileName}`,
      submittedAt: now.toISOString(),
      officialNoticeRecipient: 'dm.toonplay@proton.me',
      takedownDetails: {
        copyrightOwnerOrAgent: String(ownerName).trim(),
        officialEmail: String(email).trim(),
        copyrightedWorkClaimed: String(copyrightWork).trim(),
        infringingUrls: String(infringingUrls).trim(),
      },
      legalAffirmations: {
        goodFaithStatement: Boolean(goodFaithStatement),
        accuracyStatementUnderPenaltyOfPerjury: Boolean(accuracyStatement),
      },
      metadata: {
        ip: req.ip || req.headers['x-forwarded-for'] || 'client',
        userAgent: req.headers['user-agent'] || 'unknown',
        status: 'pending_investigation_and_removal',
      },
    };

    await fsp.writeFile(fullPath, JSON.stringify(record, null, 2), 'utf-8');
    return res.status(201).json({
      success: true,
      message: 'DMCA notice saved successfully to dmca directory.',
      fileName,
      filePath: `dmca/${fileName}`,
      record,
    });
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      error: error?.message || 'Failed to save DMCA notice to disk.',
    });
  }
});

app.get('/api/inquiries', async (req, res) => {
  try {
    const [contactList, dmcaList] = await Promise.all([
      fsp.readdir(CONTACTS_DIR).catch(() => []),
      fsp.readdir(DMCA_DIR).catch(() => []),
    ]);
    const contactFiles = contactList.filter((f) => f.endsWith('.json'));
    const dmcaFiles = dmcaList.filter((f) => f.endsWith('.json'));

    return res.json({
      success: true,
      contactsDirectory: 'contacts/',
      dmcaDirectory: 'dmca/',
      contactsCount: contactFiles.length,
      dmcaCount: dmcaFiles.length,
      contacts: contactFiles,
      dmca: dmcaFiles,
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/ravok-languages', async (req, res) => {
  const videoId = String(req.query.id || '').trim();
  if (!videoId) {
    return res.status(400).json({ success: false, error: 'Video ID is required' });
  }
  res.setHeader('Cache-Control', 'public, max-age=86400, stale-while-revalidate=604800');
  const defaultTracks = [
    { code: 'hin', name: 'Hindi' },
    { code: 'eng', name: 'English' },
    { code: 'jpn', name: 'Japanese' },
  ];
  const cacheKey = `ravok-lang_${videoId}`;
  const cached = await readCache(cacheKey);
  if (cached && Array.isArray(cached.tracks)) {
    return res.json({ success: true, tracks: cached.tracks, cached: true });
  }

  try {
    const pageUrl = `https://ravok.buzz/video/${videoId}`;
    const apiUrl = `https://ravok.buzz/player/index.php?data=${videoId}&do=getVideo`;

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 6000);

    const postResponse = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Referer': pageUrl,
        'X-Requested-With': 'XMLHttpRequest',
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({ hash: videoId, r: pageUrl }).toString(),
      signal: controller.signal,
    });

    clearTimeout(timeout);

    if (!postResponse.ok) {
      writeCache(cacheKey, { tracks: defaultTracks, source: 'fallback' });
      return res.json({ success: true, tracks: defaultTracks });
    }

    const data: any = await postResponse.json();
    const manifestUrl = data?.videoSource;
    if (!manifestUrl) {
      writeCache(cacheKey, { tracks: defaultTracks, source: 'fallback' });
      return res.json({ success: true, tracks: defaultTracks });
    }

    const manifestController = new AbortController();
    const manifestTimeout = setTimeout(() => manifestController.abort(), 6000);

    const manifestRes = await fetch(manifestUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Referer': apiUrl,
      },
      signal: manifestController.signal,
    });

    clearTimeout(manifestTimeout);

    if (!manifestRes.ok) {
      writeCache(cacheKey, { tracks: defaultTracks, source: 'fallback' });
      return res.json({ success: true, tracks: defaultTracks });
    }

    const manifestText = await manifestRes.text();
    const tracks: Array<{ code: string; name: string }> = [];
    const seen = new Set<string>();

    const audioLineRegex = /^#EXT-X-MEDIA:[^\n]*TYPE=AUDIO[^\n]*$/gm;
    let lineMatch: RegExpExecArray | null;
    while ((lineMatch = audioLineRegex.exec(manifestText)) !== null) {
      const line = lineMatch[0];
      const langMatch = line.match(/LANGUAGE="([^"]+)"/i);
      const nameMatch = line.match(/NAME="([^"]+)"/i);
      const code = langMatch?.[1]?.trim().toLowerCase();
      const name = nameMatch?.[1]?.trim() || code;
      if (code && name && !seen.has(code)) {
        seen.add(code);
        tracks.push({ code, name });
      }
    }

    const CODE_NORMALIZE: Record<string, string> = {
      hi: 'hin',
      en: 'eng',
      ja: 'jpn',
      ko: 'kor',
      ta: 'tam',
      te: 'tel',
      ml: 'mal',
      kn: 'kan',
      bn: 'ben',
    };

    for (const t of tracks) {
      if (CODE_NORMALIZE[t.code]) t.code = CODE_NORMALIZE[t.code];
    }

    if (tracks.length === 0) {
      writeCache(cacheKey, { tracks: defaultTracks, source: 'fallback' });
      return res.json({ success: true, tracks: defaultTracks });
    }

    writeCache(cacheKey, { tracks, source: 'extracted' });
    return res.json({ success: true, tracks });
  } catch {
    writeCache(cacheKey, { tracks: defaultTracks, source: 'fallback' });
    return res.json({ success: true, tracks: defaultTracks });
  }
});

app.post('/api/auth/register', async (req, res) => {
  try {
    const { username, email, password, display_name, avatar_url } = req.body;
    if (!email || !password) {
      return res.status(400).json({ success: false, error: 'Email and password are required.' });
    }

    const unameCheck = validateUsername(username);
    if (!unameCheck.ok) {
      return res.status(400).json({ success: false, error: unameCheck.error });
    }
    const trimmedUsername = unameCheck.value;
    const trimmedEmail = String(email).trim().toLowerCase();

    const existingUser = await queryOne(
      'SELECT id, username, email FROM users WHERE username = ? OR email = ? LIMIT 1',
      [trimmedUsername, trimmedEmail]
    );

    if (existingUser) {
      if (existingUser.username.toLowerCase() === trimmedUsername.toLowerCase()) {
        return res.status(409).json({ success: false, error: 'Username is already taken.' });
      }
      return res.status(409).json({ success: false, error: 'Email address is already registered.' });
    }

    const hashedPassword = await bcrypt.hash(password, BCRYPT_ROUNDS);
    const sessionToken = generateSecureToken();
    const displayName = display_name ? String(display_name).trim() : trimmedUsername;
    const avatar = avatar_url ? String(avatar_url).trim() : `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(trimmedUsername)}`;

    const result = await execute(
      `INSERT INTO users (
        username, display_name, email, password, token, avatar_url,
        level, xp, joined_at, total_episodes_watched,
        total_anime_watched, completed_anime, best_streak_days, current_streak_days,
        last_active_date, show_watchlist, show_history, show_stats,
        auto_play, auto_next, auto_skip, reset_otp_attempts
      ) VALUES (?, ?, ?, ?, ?, ?, 1, 0, NOW(), 0, 0, 0, 0, 0, CURRENT_DATE(), 1, 1, 1, 1, 1, 1, 0)`,
      [trimmedUsername, displayName, trimmedEmail, hashedPassword, sessionToken, avatar]
    );

    const newUser = await queryOne('SELECT * FROM users WHERE id = ?', [result.insertId]);
    return res.status(201).json({
      success: true,
      message: 'Account registered successfully.',
      token: sessionToken,
      user: sanitizeUser(newUser),
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Registration failed.' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { usernameOrEmail, username, email, password } = req.body;
    const identifier = String(usernameOrEmail || username || email || '').trim();
    if (!identifier || !password) {
      return res.status(400).json({ success: false, error: 'Username/Email and password are required.' });
    }

    const user = await queryOne(
      'SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1',
      [identifier, identifier.toLowerCase()]
    );

    if (!user) {
      return res.status(401).json({ success: false, error: 'Invalid credentials.' });
    }

    const match = await bcrypt.compare(password, user.password);
    if (!match) {
      return res.status(401).json({ success: false, error: 'Invalid credentials.' });
    }

    const newToken = generateSecureToken();
    await execute('UPDATE users SET token = ?, updated_at = NOW() WHERE id = ?', [newToken, user.id]);
    user.token = newToken;
    invalidateUserAuthCache(user.id);
    cacheAuthUser(newToken, user);

    return res.json({
      success: true,
      message: 'Logged in successfully.',
      token: newToken,
      user: sanitizeUser(user),
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Login failed.' });
  }
});

app.get('/api/auth/me', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const historyCount = await queryOne<{ total: number }>(
      'SELECT COUNT(DISTINCT cartoon_id) as total FROM watch_history WHERE user_id = ?',
      [req.user.id]
    );
    const user = sanitizeUser(req.user);
    user.watching = historyCount?.total || 0;
    const s = effectiveStreak(req.user);
    user.current_streak_days = s.current;
    user.best_streak_days = s.best;
    return res.json({ success: true, user });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to fetch user.' });
  }
});

app.post('/api/auth/logout', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    await execute('UPDATE users SET token = NULL WHERE id = ?', [req.user.id]);
    invalidateUserAuthCache(req.user.id, req.user.token);
    return res.json({ success: true, message: 'Logged out successfully.' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Logout failed.' });
  }
});

app.delete('/api/auth/delete-account', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { password, confirm } = req.body || {};

    const user = await queryOne(
      'SELECT id, password, google_id FROM users WHERE id = ? LIMIT 1',
      [req.user.id]
    );
    if (!user) {
      return res.status(404).json({ success: false, error: 'Account not found.' });
    }

    const isGoogleUser = Boolean(user.google_id);

    if (isGoogleUser) {
      if (String(confirm || '').trim().toUpperCase() !== 'DELETE') {
        return res.status(400).json({
          success: false,
          error: 'Type DELETE to confirm account removal.',
        });
      }
    } else {
      if (!password) {
        return res.status(400).json({ success: false, error: 'Password confirmation is required.' });
      }
      const match = await bcrypt.compare(String(password), user.password);
      if (!match) {
        return res.status(401).json({ success: false, error: 'Incorrect password.' });
      }
    }

    await execute('DELETE FROM users WHERE id = ?', [req.user.id]);
    invalidateUserAuthCache(req.user.id, req.user.token);

    return res.json({
      success: true,
      message: 'Account deleted permanently.',
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Account deletion failed.' });
  }
});

app.post('/api/auth/google', async (req, res) => {
  try {
    const { idToken, credential, google_id, email, name, avatar_url } = req.body;
    let verifiedGoogleId = google_id ? String(google_id).trim() : '';
    let verifiedEmail = email ? String(email).trim().toLowerCase() : '';
    let verifiedName = name ? String(name).trim() : '';
    let verifiedAvatar = avatar_url ? String(avatar_url).trim() : '';

    const tokenToVerify = credential || idToken;
    if (tokenToVerify && googleClient && GOOGLE_CLIENT_ID) {
      try {
        const ticket = await googleClient.verifyIdToken({
          idToken: tokenToVerify,
          audience: GOOGLE_CLIENT_ID,
        });
        const payload = ticket.getPayload();
        if (payload) {
          verifiedGoogleId = payload.sub;
          verifiedEmail = payload.email?.toLowerCase() || verifiedEmail;
          verifiedName = payload.name || payload.given_name || verifiedName;
          verifiedAvatar = payload.picture || verifiedAvatar;
        }
      } catch {
        if (!verifiedEmail && !verifiedGoogleId) {
          return res.status(400).json({ success: false, error: 'Invalid Google ID token.' });
        }
      }
    }

    if (!verifiedEmail && !verifiedGoogleId) {
      return res.status(400).json({ success: false, error: 'Google authentication details missing.' });
    }

    let user = null;
    if (verifiedGoogleId) {
      user = await queryOne('SELECT * FROM users WHERE google_id = ? LIMIT 1', [verifiedGoogleId]);
    }
    if (!user && verifiedEmail) {
      user = await queryOne('SELECT * FROM users WHERE email = ? LIMIT 1', [verifiedEmail]);
    }

    const sessionToken = generateSecureToken();

    if (user) {
      await execute(
        'UPDATE users SET token = ?, google_id = COALESCE(google_id, ?), avatar_url = COALESCE(avatar_url, ?), updated_at = NOW() WHERE id = ?',
        [sessionToken, verifiedGoogleId || null, verifiedAvatar || null, user.id]
      );
      invalidateUserAuthCache(user.id);
      const updatedUser = await queryOne('SELECT * FROM users WHERE id = ?', [user.id]);
      if (updatedUser) cacheAuthUser(sessionToken, updatedUser);
      return res.json({
        success: true,
        token: sessionToken,
        user: sanitizeUser(updatedUser),
      });
    }

    const baseUsername = verifiedEmail ? verifiedEmail.split('@')[0].replace(/[^a-zA-Z0-9_]/g, '').slice(0, 30) : `user_${Date.now()}`;
    let finalUsername = baseUsername || `user_${Date.now().toString(36)}`;

    const checkExistingName = await queryOne('SELECT id FROM users WHERE username = ?', [finalUsername]);
    if (checkExistingName) {
      finalUsername = `${finalUsername}_${Math.floor(Math.random() * 9000 + 1000)}`;
    }

    const randomPassword = await bcrypt.hash(generateSecureToken(), BCRYPT_ROUNDS);
    const result = await execute(
      `INSERT INTO users (
        username, display_name, email, password, token, avatar_url, google_id,
        level, xp, joined_at, total_episodes_watched,
        total_anime_watched, completed_anime, best_streak_days, current_streak_days,
        last_active_date, show_watchlist, show_history, show_stats,
        auto_play, auto_next, auto_skip, reset_otp_attempts
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 1, 0, NOW(), 0, 0, 0, 0, 0, CURRENT_DATE(), 1, 1, 1, 1, 1, 1, 0)`,
      [
        finalUsername,
        verifiedName || finalUsername,
        verifiedEmail || `${finalUsername}@toonplay.local`,
        randomPassword,
        sessionToken,
        verifiedAvatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(finalUsername)}`,
        verifiedGoogleId || null,
      ]
    );

    const newUser = await queryOne('SELECT * FROM users WHERE id = ?', [result.insertId]);
    return res.status(201).json({
      success: true,
      message: 'User registered via Google.',
      token: sessionToken,
      user: sanitizeUser(newUser),
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Google authentication failed.' });
  }
});

app.post('/api/auth/forgot-password', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ success: false, error: 'Email is required.' });
    }

    const user = await queryOne('SELECT * FROM users WHERE email = ? LIMIT 1', [String(email).trim().toLowerCase()]);
    if (!user) {
      return res.json({
        success: true,
        message: 'If the email exists, a password reset OTP has been sent.',
      });
    }

    const otp = generateOtpCode();
    const expires = new Date(Date.now() + OTP_TTL_MINUTES * 60 * 1000);

    await execute(
      'UPDATE users SET reset_otp = ?, reset_otp_expires = ?, reset_otp_attempts = 0 WHERE id = ?',
      [otp, expires, user.id]
    );

    try {
      await sendOtpEmail({
        to: user.email,
        username: user.display_name || user.username,
        otp,
      });
    } catch (mailErr) {
      console.error('[Mailer Error] Failed to send OTP email:', mailErr);
    }

    return res.json({
      success: true,
      message: 'If the email exists, a password reset OTP has been sent.',
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Forgot password request failed.' });
  }
});

app.post('/api/auth/verify-otp', async (req, res) => {
  try {
    const { email, otp } = req.body;
    if (!email || !otp) {
      return res.status(400).json({ success: false, error: 'Email and OTP code are required.' });
    }

    const user = await queryOne('SELECT * FROM users WHERE email = ? LIMIT 1', [String(email).trim().toLowerCase()]);
    if (!user) {
      return res.status(400).json({ success: false, error: 'Invalid or expired OTP.' });
    }

    if (user.reset_otp_attempts >= OTP_MAX_ATTEMPTS) {
      return res.status(429).json({ success: false, error: 'Maximum OTP verification attempts exceeded. Please request a new code.' });
    }

    if (!user.reset_otp || !user.reset_otp_expires) {
      return res.status(400).json({ success: false, error: 'No active OTP request found.' });
    }

    const now = new Date();
    const expiry = new Date(user.reset_otp_expires);
    if (now > expiry) {
      return res.status(400).json({ success: false, error: 'OTP has expired. Please request a new code.' });
    }

    if (String(user.reset_otp).trim() !== String(otp).trim()) {
      await execute('UPDATE users SET reset_otp_attempts = reset_otp_attempts + 1 WHERE id = ?', [user.id]);
      return res.status(400).json({ success: false, error: 'Incorrect OTP code.' });
    }

    const resetToken = generateSecureToken();
    const resetExpires = new Date(Date.now() + RESET_TOKEN_TTL_MINUTES * 60 * 1000);

    await execute(
      'UPDATE users SET reset_otp = NULL, reset_otp_expires = NULL, reset_otp_attempts = 0, reset_token = ?, reset_token_expires = ? WHERE id = ?',
      [resetToken, resetExpires, user.id]
    );

    return res.json({
      success: true,
      message: 'OTP verified successfully.',
      resetToken,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'OTP verification failed.' });
  }
});

app.post('/api/auth/reset-password', async (req, res) => {
  try {
    const { email, resetToken, newPassword } = req.body;
    if (!email || !resetToken || !newPassword) {
      return res.status(400).json({ success: false, error: 'Email, reset token, and new password are required.' });
    }

    if (String(newPassword).length < 6) {
      return res.status(400).json({ success: false, error: 'Password must be at least 6 characters long.' });
    }

    const user = await queryOne(
      'SELECT * FROM users WHERE email = ? AND reset_token = ? LIMIT 1',
      [String(email).trim().toLowerCase(), String(resetToken).trim()]
    );

    if (!user) {
      return res.status(400).json({ success: false, error: 'Invalid or expired password reset token.' });
    }

    const now = new Date();
    const expiry = new Date(user.reset_token_expires);
    if (now > expiry) {
      return res.status(400).json({ success: false, error: 'Password reset token has expired.' });
    }

    const hashedPassword = await bcrypt.hash(newPassword, BCRYPT_ROUNDS);
    const newSessionToken = generateSecureToken();

    await execute(
      'UPDATE users SET password = ?, token = ?, reset_token = NULL, reset_token_expires = NULL, updated_at = NOW() WHERE id = ?',
      [hashedPassword, newSessionToken, user.id]
    );
    invalidateUserAuthCache(user.id);

    return res.json({
      success: true,
      message: 'Password reset successfully. You are now logged in.',
      token: newSessionToken,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to reset password.' });
  }
});

app.get('/api/users/profile', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const historyCount = await queryOne<{ total: number }>(
      'SELECT COUNT(DISTINCT cartoon_id) as total FROM watch_history WHERE user_id = ?',
      [req.user.id]
    );
    const user = sanitizeUser(req.user);
    user.watching = historyCount?.total || 0;
    const s = effectiveStreak(req.user);
    user.current_streak_days = s.current;
    user.best_streak_days = s.best;
    return res.json({ success: true, user });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to fetch profile.' });
  }
});

app.put('/api/users/profile', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { display_name, avatar_url, bio, username } = req.body;
    const updates: string[] = [];
    const params: any[] = [];

    if (username !== undefined) {
      const unameCheck = validateUsername(username);
      if (!unameCheck.ok) {
        return res.status(400).json({ success: false, error: unameCheck.error });
      }
      const cleanUsername = unameCheck.value;
      if (cleanUsername !== req.user.username) {
        const clash = await queryOne<{ id: number }>(
          'SELECT id FROM users WHERE username = ? AND id <> ? LIMIT 1',
          [cleanUsername, req.user.id]
        );
        if (clash) {
          return res.status(409).json({ success: false, error: 'Username already taken.' });
        }
        updates.push('username = ?');
        params.push(cleanUsername);
      }
    }

    if (display_name !== undefined) {
      updates.push('display_name = ?');
      params.push(String(display_name).trim());
    }
    if (avatar_url !== undefined) {
      updates.push('avatar_url = ?');
      params.push(String(avatar_url).trim());
    }
    if (bio !== undefined) {
      updates.push('bio = ?');
      params.push(String(bio).trim());
    }

    if (updates.length === 0) {
      return res.status(400).json({ success: false, error: 'No fields provided to update.' });
    }

    updates.push('updated_at = NOW()');
    params.push(req.user.id);

    await execute(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`, params);
    invalidateUserAuthCache(req.user.id, req.user.token);
    const updatedUser = await queryOne('SELECT * FROM users WHERE id = ?', [req.user.id]);
    if (updatedUser && req.user.token) cacheAuthUser(req.user.token, updatedUser);

    return res.json({
      success: true,
      message: 'Profile updated successfully.',
      user: sanitizeUser(updatedUser),
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to update profile.' });
  }
});

app.put('/api/users/preferences', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const {
      show_watchlist,
      show_history,
      show_stats,
      auto_play,
      auto_next,
      auto_skip,
    } = req.body;

    const updates: string[] = [];
    const params: any[] = [];

    if (show_watchlist !== undefined) {
      updates.push('show_watchlist = ?');
      params.push(show_watchlist ? 1 : 0);
    }
    if (show_history !== undefined) {
      updates.push('show_history = ?');
      params.push(show_history ? 1 : 0);
    }
    if (show_stats !== undefined) {
      updates.push('show_stats = ?');
      params.push(show_stats ? 1 : 0);
    }
    if (auto_play !== undefined) {
      updates.push('auto_play = ?');
      params.push(auto_play ? 1 : 0);
    }
    if (auto_next !== undefined) {
      updates.push('auto_next = ?');
      params.push(auto_next ? 1 : 0);
    }
    if (auto_skip !== undefined) {
      updates.push('auto_skip = ?');
      params.push(auto_skip ? 1 : 0);
    }

    if (updates.length === 0) {
      return res.status(400).json({ success: false, error: 'No preferences provided to update.' });
    }

    updates.push('updated_at = NOW()');
    params.push(req.user.id);

    await execute(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`, params);
    invalidateUserAuthCache(req.user.id, req.user.token);
    const updatedUser = await queryOne('SELECT * FROM users WHERE id = ?', [req.user.id]);
    if (updatedUser && req.user.token) cacheAuthUser(req.user.token, updatedUser);

    return res.json({
      success: true,
      message: 'Preferences saved successfully.',
      preferences: {
        show_watchlist: Boolean(updatedUser.show_watchlist),
        show_history: Boolean(updatedUser.show_history),
        show_stats: Boolean(updatedUser.show_stats),
        auto_play: Boolean(updatedUser.auto_play),
        auto_next: Boolean(updatedUser.auto_next),
        auto_skip: Boolean(updatedUser.auto_skip),
      },
      user: sanitizeUser(updatedUser),
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to update preferences.' });
  }
});

app.put('/api/users/password', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ success: false, error: 'Current password and new password are required.' });
    }
    if (String(newPassword).length < 6) {
      return res.status(400).json({ success: false, error: 'New password must be at least 6 characters long.' });
    }

    const user = await queryOne('SELECT password FROM users WHERE id = ?', [req.user.id]);
    const match = await bcrypt.compare(currentPassword, user.password);
    if (!match) {
      return res.status(400).json({ success: false, error: 'Current password does not match.' });
    }

    const hashed = await bcrypt.hash(newPassword, BCRYPT_ROUNDS);
    await execute('UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?', [hashed, req.user.id]);
    invalidateUserAuthCache(req.user.id, req.user.token);

    return res.json({ success: true, message: 'Password changed successfully.' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to change password.' });
  }
});


app.get(
  '/api/users/:username',
  optionalAuthenticateToken,
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const targetUsername = String(req.params.username || '').trim().toLowerCase();

      if (!targetUsername) {
        return res.status(400).json({
          success: false,
          error: 'Username is required.',
        });
      }
      const user = await queryOne(
        `SELECT
          id,
          username,
          display_name,
          avatar_url,
          bio,
          joined_at,
          level,
          xp,
          total_episodes_watched,
          total_anime_watched,
          completed_anime,
          current_streak_days,
          best_streak_days,
          last_active_date,
          show_watchlist,
          show_stats,
          show_history
        FROM users
        WHERE username = ?
        LIMIT 1`,
        [targetUsername]
      );

      if (!user) {
        return res.status(404).json({
          success: false,
          error: 'User not found.',
        });
      }

      const isOwner = Boolean(req.user && req.user.id === user.id);

      const [
        historyCount,
        topGenres,
        recentAnime,
        watchlistPreview,
        historyPreview,
      ] = await Promise.all([
        queryOne<{ total: number }>(
          `SELECT COUNT(*) AS total
           FROM watch_history
           WHERE user_id = ?`,
          [user.id]
        ),

        isOwner || user.show_stats
          ? query(
              `SELECT genre, episodes_watched
               FROM user_genre_stats
               WHERE user_id = ?
               ORDER BY episodes_watched DESC`,
              [user.id]
            )
          : Promise.resolve(null),

        isOwner || user.show_stats
          ? query(
              `SELECT
                cartoon_id,
                cartoon_title,
                cartoon_image,
                episodes_watched,
                total_episodes_available,
                completed,
                last_watched
               FROM user_anime_stats
               WHERE user_id = ?
               ORDER BY last_watched DESC
               LIMIT 6`,
              [user.id]
            )
          : Promise.resolve(null),

        isOwner || user.show_watchlist
          ? query(
              `SELECT
                cartoon_id,
                cartoon_title,
                cartoon_image,
                cartoon_type,
                added_at
               FROM watchlist
               WHERE user_id = ?
               ORDER BY added_at DESC
               LIMIT 10`,
              [user.id]
            )
          : Promise.resolve(null),

        isOwner || user.show_history
          ? query(
              `SELECT
                cartoon_id,
                cartoon_title,
                cartoon_image,
                cartoon_type,
                episode_id,
                episode_number,
                season_number,
                episode_title,
                progress_seconds,
                duration_seconds,
                last_watched
               FROM watch_history
               WHERE user_id = ?
               ORDER BY last_watched DESC
               LIMIT 10`,
              [user.id]
            )
          : Promise.resolve(null),
      ]);

      const eff = effectiveStreak(user);

      const publicProfile: any = {
        id: user.id,
        username: user.username,
        display_name: user.display_name,
        avatar_url: user.avatar_url,
        bio: user.bio,
        joined_at: user.joined_at,
        level: user.level,
        xp: user.xp,
        total_episodes_watched: user.total_episodes_watched,
        total_anime_watched: user.total_anime_watched,
        watching: Number(historyCount?.total || 0),
        completed_anime: user.completed_anime,
        best_streak_days: eff.best,
        current_streak_days: eff.current,
        show_watchlist: user.show_watchlist,
        show_stats: user.show_stats,
        show_history: user.show_history,
      };

      if (isOwner || user.show_stats) {
        publicProfile.stats = {
          topGenres: topGenres || [],
          recentAnime: recentAnime || [],
        };
      }

      if (isOwner || user.show_watchlist) {
        publicProfile.watchlist = watchlistPreview || [];
      }

      if (isOwner || user.show_history) {
        publicProfile.history = historyPreview || [];
      }

      return res.json({
        success: true,
        profile: publicProfile,
      });
    } catch (err: any) {
      console.error('[User Profile API] Error:', err);

      return res.status(500).json({
        success: false,
        error: err.message || 'Failed to fetch user profile.',
      });
    }
  }
);

app.get(
  '/api/users/:username/activity',
  optionalAuthenticateToken,
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const targetUsername = req.params.username;
      const days = Math.min(365, Math.max(1, Number(req.query.days || 30)));

      const targetUser = await queryOne<{ id: number; show_stats: number }>(
        'SELECT id, show_stats FROM users WHERE username = ? LIMIT 1',
        [targetUsername]
      );

      if (!targetUser) {
        return res.status(404).json({ success: false, error: 'User not found.' });
      }

      const isOwner = req.user && req.user.id === targetUser.id;

      if (!isOwner && !targetUser.show_stats) {
        return res.json({ success: true, days, activities: [], hidden: true });
      }

      const activities = await query(
        'SELECT activity_date, episodes_watched, xp_earned FROM user_daily_activity WHERE user_id = ? AND activity_date >= DATE_SUB(CURRENT_DATE(), INTERVAL ? DAY) ORDER BY activity_date ASC',
        [targetUser.id, days]
      );

      return res.json({ success: true, days, activities });
    } catch (err: any) {
      return res.status(500).json({ success: false, error: err.message || 'Failed to fetch activity.' });
    }
  }
);

app.get('/api/leaderboard', async (req, res) => {
  try {
    const limit = Math.min(50, Math.max(1, Number(req.query.limit || 10)));

    const rows = await query<any>(
      `SELECT id, username, display_name, avatar_url, level, xp, total_episodes_watched, total_anime_watched, completed_anime, current_streak_days, best_streak_days, last_active_date, joined_at, show_stats
       FROM users
       ORDER BY xp DESC, id ASC
       LIMIT ?`,
      [limit]
    );

    const entries = rows.map((u, index) => {
      const es = effectiveStreak(u);
      return {
        rank: index + 1,
        id: u.id,
        username: u.username,
        display_name: u.display_name,
        avatar_url: u.avatar_url,
        level: Number(u.level || 1),
        xp: Number(u.xp || 0),
        total_episodes_watched: Number(u.total_episodes_watched || 0),
        total_anime_watched: Number(u.total_anime_watched || 0),
        completed_anime: Number(u.completed_anime || 0),
        current_streak_days: es.current,
        joined_at: u.joined_at,
        stats_hidden: Number(u.show_stats) === 0,
      };
    });

    return res.json({ success: true, entries, count: entries.length });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to fetch leaderboard.' });
  }
});

app.get('/api/users', async (req, res) => {
  try {
    const page = Math.max(1, Number(req.query.page || 1));
    const limit = Math.min(100, Math.max(1, Number(req.query.limit || 20)));
    const offset = (page - 1) * limit;

    const [rows, countResult] = await Promise.all([
      query<any>(
        'SELECT id, username, display_name, avatar_url, level, xp, total_episodes_watched, total_anime_watched, completed_anime, current_streak_days, best_streak_days, last_active_date, joined_at, show_stats FROM users ORDER BY xp DESC LIMIT ? OFFSET ?',
        [limit, offset]
      ),
      queryOne<{ value: number }>(
        "SELECT value FROM stats_counters WHERE name = 'users_total'"
      ),
    ]);

    const users = rows.map((u) => {
      const es = effectiveStreak(u);
      const visible = u.show_stats;
      delete u.show_stats;
      if (visible) return { ...u, current_streak_days: es.current };
      return {
        id: u.id,
        username: u.username,
        display_name: u.display_name,
        avatar_url: u.avatar_url,
        joined_at: u.joined_at,
        stats_hidden: true,
      };
    });

    const total = Number(countResult?.value || 0);

    return res.json({
      success: true,
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit),
      users,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to list users.' });
  }
});

app.get('/api/watchlist', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const page = Math.max(1, Number(req.query.page || 1));
    const limit = Math.min(100, Math.max(1, Number(req.query.limit || 50)));
    const offset = (page - 1) * limit;
    const type = req.query.type ? String(req.query.type).trim() : null;

    let sql = 'SELECT * FROM watchlist WHERE user_id = ?';
    const params: any[] = [req.user.id];

    if (type) {
      sql += ' AND LOWER(cartoon_type) = ?';
      params.push(String(type).trim().toLowerCase());
    }

    sql += ' ORDER BY added_at DESC LIMIT ? OFFSET ?';
    params.push(limit, offset);

    const countSql = type
      ? 'SELECT COUNT(*) as total FROM watchlist WHERE user_id = ? AND LOWER(cartoon_type) = ?'
      : 'SELECT COUNT(*) as total FROM watchlist WHERE user_id = ?';
    const countParams = type ? [req.user.id, String(type).trim().toLowerCase()] : [req.user.id];

    const [items, countRow] = await Promise.all([
      query(sql, params),
      queryOne<{ total: number }>(countSql, countParams),
    ]);

    return res.json({
      success: true,
      total: countRow?.total || 0,
      page,
      limit,
      items,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to fetch watchlist.' });
  }
});

app.get('/api/watchlist/check/:cartoonId', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const item = await queryOne(
      'SELECT id, added_at, subject_id FROM watchlist WHERE user_id = ? AND cartoon_id = ? LIMIT 1',
      [req.user.id, req.params.cartoonId]
    );
    return res.json({
      success: true,
      inWatchlist: Boolean(item),
      item: item || null,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to check watchlist status.' });
  }
});

app.post('/api/watchlist', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const {
  cartoon_id,
  cartoon_title,
  cartoon_image,
  cartoon_type,
  anilist_id,
  tmdb_id,
  subject_id,
} = req.body;
    if (!cartoon_id || !cartoon_title || !cartoon_type) {
      return res.status(400).json({ success: false, error: 'cartoon_id, cartoon_title, and cartoon_type are required.' });
    }

const type = cartoon_type
  ? String(cartoon_type).trim().toUpperCase()
  : 'SERIES';
    const anilistIdVal =
      anilist_id !== undefined && anilist_id !== null && Number(anilist_id) > 0
        ? Number(anilist_id)
        : null;
    const tmdbIdVal =
      tmdb_id !== undefined && tmdb_id !== null && Number(tmdb_id) > 0
        ? Number(tmdb_id)
        : null;
const subjectIdVal =
  subject_id != null && String(subject_id).trim()
    ? String(subject_id).trim()
    : null;
await execute(
  `INSERT INTO watchlist (
    user_id,
    cartoon_id,
    cartoon_title,
    cartoon_image,
    cartoon_type,
    anilist_id,
    tmdb_id,
    subject_id,
    added_at
  )
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
  ON DUPLICATE KEY UPDATE
    cartoon_title = VALUES(cartoon_title),
    cartoon_image = VALUES(cartoon_image),
    cartoon_type = VALUES(cartoon_type),
    anilist_id = VALUES(anilist_id),
    tmdb_id = COALESCE(VALUES(tmdb_id), tmdb_id),
    subject_id = COALESCE(VALUES(subject_id), subject_id),
    added_at = NOW()`,
  [
    req.user.id,
    String(cartoon_id).trim(),
    String(cartoon_title).trim(),
    cartoon_image || null,
    type,
    anilistIdVal,
    tmdbIdVal,
    subjectIdVal,
  ]
);

    const saved = await queryOne('SELECT * FROM watchlist WHERE user_id = ? AND cartoon_id = ?', [req.user.id, cartoon_id]);
    return res.status(201).json({
      success: true,
      message: 'Item added to watchlist.',
      item: saved,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to save to watchlist.' });
  }
});

app.delete('/api/watchlist/:cartoonId', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const result = await execute(
      'DELETE FROM watchlist WHERE user_id = ? AND cartoon_id = ?',
      [req.user.id, req.params.cartoonId]
    );
    return res.json({
      success: true,
      message: 'Item removed from watchlist.',
      affectedRows: result.affectedRows,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to remove from watchlist.' });
  }
});

app.delete('/api/watchlist', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const result = await execute('DELETE FROM watchlist WHERE user_id = ?', [req.user.id]);
    return res.json({
      success: true,
      message: 'Watchlist cleared.',
      deletedCount: result.affectedRows,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to clear watchlist.' });
  }
});

app.get('/api/history', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const page = Math.max(1, Number(req.query.page || 1));
    const limit = Math.min(100, Math.max(1, Number(req.query.limit || 50)));
    const offset = (page - 1) * limit;

    const [items, countRow] = await Promise.all([
      query(
        'SELECT * FROM watch_history WHERE user_id = ? ORDER BY last_watched DESC LIMIT ? OFFSET ?',
        [req.user.id, limit, offset]
      ),
      queryOne<{ total: number }>(
        'SELECT COUNT(*) as total FROM watch_history WHERE user_id = ?',
        [req.user.id]
      ),
    ]);

    return res.json({
      success: true,
      total: countRow?.total || 0,
      page,
      limit,
      items,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to fetch watch history.' });
  }
});

app.get('/api/history/:cartoonId', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const items = await query(
      'SELECT * FROM watch_history WHERE user_id = ? AND cartoon_id = ? ORDER BY last_watched DESC',
      [req.user.id, req.params.cartoonId]
    );
    return res.json({
      success: true,
      latest: items[0] || null,
      history: items,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to fetch cartoon watch history.' });
  }
});

app.post('/api/history', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const {
      cartoon_id,
      cartoon_title,
      cartoon_image,
      cartoon_type,
      episode_id,
      episode_number,
      season_number,
      episode_title,
      episode_image,
      progress_seconds,
      duration_seconds,
      server_type,
      anilist_id,
      tmdb_id,
      subject_id,
    } = req.body;

    if (!cartoon_id || !cartoon_title) {
      return res.status(400).json({ success: false, error: 'cartoon_id and cartoon_title are required.' });
    }

const type = cartoon_type
  ? String(cartoon_type).trim().toUpperCase()
  : 'SERIES';
    const anilistIdVal =
      anilist_id !== undefined && anilist_id !== null && Number(anilist_id) > 0
        ? Number(anilist_id)
        : null;
    const tmdbIdVal =
      tmdb_id !== undefined && tmdb_id !== null && Number(tmdb_id) > 0
        ? Number(tmdb_id)
        : null;
    const subjectIdVal = subject_id
  ? String(subject_id).trim() || null
  : null;
    const epId = String(type).toLowerCase() === 'movie' ? 'movie' : (episode_id ? String(episode_id).trim() : null);
    const epNum = episode_number !== undefined && episode_number !== null ? Number(episode_number) : null;
    const sNum = season_number !== undefined && season_number !== null ? Number(season_number) : null;
    const prog = Math.max(0, Number(progress_seconds || 0));
    const dur = Math.max(0, Number(duration_seconds || 0));
const srv = server_type
  ? String(server_type).trim().toLowerCase().slice(0, 64) || null
  : null;

    await transaction(async (conn) => {
      await conn.execute(
        `INSERT INTO watch_history (
user_id, cartoon_id, cartoon_title, cartoon_image, cartoon_type,
anilist_id, tmdb_id, subject_id,
episode_id, episode_number, season_number, episode_title, episode_image,
progress_seconds, duration_seconds, server_type, last_watched
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ON DUPLICATE KEY UPDATE
          cartoon_title = VALUES(cartoon_title),
          cartoon_image = VALUES(cartoon_image),
          cartoon_type = VALUES(cartoon_type),
          anilist_id = COALESCE(VALUES(anilist_id), anilist_id),
          tmdb_id = COALESCE(VALUES(tmdb_id), tmdb_id),
          subject_id = COALESCE(VALUES(subject_id), subject_id),
          episode_id = VALUES(episode_id),
          episode_number = VALUES(episode_number),
          season_number = VALUES(season_number),
          episode_title = VALUES(episode_title),
          episode_image = VALUES(episode_image),
          progress_seconds = VALUES(progress_seconds),
          duration_seconds = VALUES(duration_seconds),
          server_type = VALUES(server_type),
          last_watched = NOW()`,
        [
          req.user.id,
          String(cartoon_id).trim(),
          String(cartoon_title).trim(),
          cartoon_image || null,
          type,
          anilistIdVal,
          tmdbIdVal,
          subjectIdVal,
          epId,
          epNum,
          sNum,
          episode_title || null,
          episode_image || null,
          prog,
          dur,
          srv,
        ]
      );

      await recordUniqueCartoonOpen(conn, req.user.id, String(cartoon_id).trim());
    });

    const record = await queryOne(
      'SELECT * FROM watch_history WHERE user_id = ? AND cartoon_id = ? LIMIT 1',
      [req.user.id, cartoon_id]
    );

    return res.status(200).json({
      success: true,
      message: 'Watch progress saved.',
      record,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to save watch history.' });
  }
});

app.delete('/api/history/cartoon/:cartoonId', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const result = await execute(
      'DELETE FROM watch_history WHERE user_id = ? AND cartoon_id = ?',
      [req.user.id, req.params.cartoonId]
    );
    return res.json({
      success: true,
      message: 'History deleted for cartoon.',
      affectedRows: result.affectedRows,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to delete cartoon history.' });
  }
});

app.delete('/api/history/:id', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const result = await execute(
      'DELETE FROM watch_history WHERE id = ? AND user_id = ?',
      [req.params.id, req.user.id]
    );
    return res.json({
      success: true,
      message: 'History entry deleted.',
      affectedRows: result.affectedRows,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to delete history item.' });
  }
});

app.delete('/api/history', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const result = await execute('DELETE FROM watch_history WHERE user_id = ?', [req.user.id]);
    return res.json({
      success: true,
      message: 'All watch history cleared.',
      deletedCount: result.affectedRows,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to clear watch history.' });
  }
});

app.get('/api/stats/anime', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const stats = await query(
      'SELECT * FROM user_anime_stats WHERE user_id = ? ORDER BY last_watched DESC',
      [req.user.id]
    );
    return res.json({ success: true, count: stats.length, stats });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to fetch anime stats.' });
  }
});

app.get('/api/stats/anime/:cartoonId', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const stat = await queryOne(
      'SELECT * FROM user_anime_stats WHERE user_id = ? AND cartoon_id = ? LIMIT 1',
      [req.user.id, req.params.cartoonId]
    );
    return res.json({ success: true, stat: stat || null });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to fetch anime stat.' });
  }
});

app.post('/api/stats/anime', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const {
      cartoon_id,
      cartoon_title,
      cartoon_image,
      total_episodes_available,
      episodes_watched,
      completed,
      genres,
    } = req.body;

    if (!cartoon_id || !cartoon_title) {
      return res.status(400).json({ success: false, error: 'cartoon_id and cartoon_title are required.' });
    }

    const totalAvail = Math.max(0, Number(total_episodes_available || 0));
    const watched = Math.max(0, Number(episodes_watched || 0));
    const isCompleted = Boolean(completed) || (totalAvail > 0 && watched >= totalAvail);
    const genreStr = Array.isArray(genres) ? genres.join(', ') : genres ? String(genres).trim() : null;

    await execute(
      `INSERT INTO user_anime_stats (
        user_id, cartoon_id, cartoon_title, cartoon_image,
        total_episodes_available, episodes_watched, completed,
        first_watched, last_watched, genres
      ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW(), ?)
      ON DUPLICATE KEY UPDATE
        cartoon_title = VALUES(cartoon_title),
        cartoon_image = COALESCE(VALUES(cartoon_image), cartoon_image),
        total_episodes_available = VALUES(total_episodes_available),
        episodes_watched = VALUES(episodes_watched),
        completed = VALUES(completed),
        last_watched = NOW(),
        genres = COALESCE(VALUES(genres), genres)`,
      [
        req.user.id,
        String(cartoon_id).trim(),
        String(cartoon_title).trim(),
        cartoon_image || null,
        totalAvail,
        watched,
        isCompleted ? 1 : 0,
        genreStr,
      ]
    );

    const saved = await queryOne(
      'SELECT * FROM user_anime_stats WHERE user_id = ? AND cartoon_id = ?',
      [req.user.id, cartoon_id]
    );

    return res.json({ success: true, stat: saved });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to update anime stats.' });
  }
});

app.put('/api/stats/anime/:cartoonId', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { episodes_watched, total_episodes_available, completed } = req.body;
    const updates: string[] = ['last_watched = NOW()'];
    const params: any[] = [];

    if (episodes_watched !== undefined) {
      updates.push('episodes_watched = ?');
      params.push(Math.max(0, Number(episodes_watched)));
    }
    if (total_episodes_available !== undefined) {
      updates.push('total_episodes_available = ?');
      params.push(Math.max(0, Number(total_episodes_available)));
    }
    if (completed !== undefined) {
      updates.push('completed = ?');
      params.push(completed ? 1 : 0);
    }

    params.push(req.user.id, req.params.cartoonId);

    await execute(
      `UPDATE user_anime_stats SET ${updates.join(', ')} WHERE user_id = ? AND cartoon_id = ?`,
      params
    );

    const updated = await queryOne(
      'SELECT * FROM user_anime_stats WHERE user_id = ? AND cartoon_id = ?',
      [req.user.id, req.params.cartoonId]
    );

    return res.json({ success: true, stat: updated });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to update anime stat.' });
  }
});

app.delete('/api/stats/anime/:cartoonId', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const result = await execute(
      'DELETE FROM user_anime_stats WHERE user_id = ? AND cartoon_id = ?',
      [req.user.id, req.params.cartoonId]
    );
    return res.json({ success: true, message: 'Anime stat deleted.', affectedRows: result.affectedRows });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to delete anime stat.' });
  }
});

app.get('/api/stats/daily-activity', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const days = Math.min(365, Math.max(1, Number(req.query.days || 30)));
    const activities = await query(
      'SELECT * FROM user_daily_activity WHERE user_id = ? AND activity_date >= DATE_SUB(CURRENT_DATE(), INTERVAL ? DAY) ORDER BY activity_date ASC',
      [req.user.id, days]
    );
    return res.json({ success: true, days, activities });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to fetch daily activity.' });
  }
});

app.post('/api/stats/daily-activity', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { activity_date, episodes_watched, xp_earned } = req.body;
    const targetDate = activity_date ? String(activity_date).slice(0, 10) : new Date().toISOString().slice(0, 10);
    const eps = Math.max(0, Number(episodes_watched || 0));
    const xp = Math.max(0, Number(xp_earned || 0));

    await execute(
      `INSERT INTO user_daily_activity (user_id, activity_date, episodes_watched, xp_earned)
       VALUES (?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE
         episodes_watched = episodes_watched + VALUES(episodes_watched),
         xp_earned = xp_earned + VALUES(xp_earned)`,
      [req.user.id, targetDate, eps, xp]
    );

    const saved = await queryOne(
      'SELECT * FROM user_daily_activity WHERE user_id = ? AND activity_date = ?',
      [req.user.id, targetDate]
    );

    return res.json({ success: true, activity: saved });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to record daily activity.' });
  }
});

app.get('/api/stats/genres', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const genres = await query(
      'SELECT * FROM user_genre_stats WHERE user_id = ? ORDER BY episodes_watched DESC',
      [req.user.id]
    );
    return res.json({ success: true, genres });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to fetch genre stats.' });
  }
});

app.post('/api/stats/genres', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { genre, episodes_watched } = req.body;
    if (!genre) {
      return res.status(400).json({ success: false, error: 'Genre name is required.' });
    }

    const cleanGenre = String(genre).trim();
    const count = Math.max(1, Number(episodes_watched || 1));

    await execute(
      `INSERT INTO user_genre_stats (user_id, genre, episodes_watched)
       VALUES (?, ?, ?)
       ON DUPLICATE KEY UPDATE
         episodes_watched = episodes_watched + VALUES(episodes_watched)`,
      [req.user.id, cleanGenre, count]
    );

    const saved = await queryOne(
      'SELECT * FROM user_genre_stats WHERE user_id = ? AND genre = ?',
      [req.user.id, cleanGenre]
    );

    return res.json({ success: true, genreStat: saved });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to save genre stat.' });
  }
});

app.get('/api/stats/summary', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const [user, topGenres, recentActivity, watchlistCount, historyCount] = await Promise.all([
      queryOne('SELECT * FROM users WHERE id = ?', [req.user.id]),
      query(
        'SELECT genre, episodes_watched FROM user_genre_stats WHERE user_id = ? ORDER BY episodes_watched DESC LIMIT 8',
        [req.user.id]
      ),
      query(
        'SELECT activity_date, episodes_watched, xp_earned FROM user_daily_activity WHERE user_id = ? AND activity_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 14 DAY) ORDER BY activity_date ASC',
        [req.user.id]
      ),
      queryOne<{ total: number }>(
        'SELECT COUNT(*) as total FROM watchlist WHERE user_id = ?',
        [req.user.id]
      ),
      queryOne<{ total: number }>(
        'SELECT COUNT(*) as total FROM watch_history WHERE user_id = ?',
        [req.user.id]
      ),
    ]);

    const eff = effectiveStreak(user);

    return res.json({
      success: true,
      summary: {
        userId: user.id,
        username: user.username,
        displayName: user.display_name,
        avatarUrl: user.avatar_url,
        level: user.level,
        xp: user.xp,
        totalEpisodesWatched: user.total_episodes_watched,
        totalAnimeWatched: user.total_anime_watched,
        completedAnime: user.completed_anime,
        currentStreakDays: eff.current,
        bestStreakDays: eff.best,
        lastActiveDate: user.last_active_date,
        watchlistCount: watchlistCount?.total || 0,
        historyCount: historyCount?.total || 0,
        topGenres,
        recentActivity,
      },
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to fetch summary stats.' });
  }
});

app.post('/api/watch/progress', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const {
      cartoon_id,
      cartoon_title,
      cartoon_image,
      cartoon_type,
      episode_id,
      episode_number,
      season_number,
      episode_title,
      episode_image,
      progress_seconds,
      duration_seconds,
      server_type,
      added_seconds,
      genres,
      total_episodes_available,
      anilist_id,
      tmdb_id,
    } = req.body;

    if (!cartoon_id || !cartoon_title) {
      return res.status(400).json({ success: false, error: 'cartoon_id and cartoon_title are required.' });
    }

    const userId = req.user.id;
const type = cartoon_type
  ? String(cartoon_type).trim().toUpperCase()
  : 'SERIES';
    const anilistIdVal =
      anilist_id !== undefined && anilist_id !== null && Number(anilist_id) > 0
        ? Number(anilist_id)
        : null;
    const tmdbIdVal =
      tmdb_id !== undefined && tmdb_id !== null && Number(tmdb_id) > 0
        ? Number(tmdb_id)
        : null;
    const epId = String(type).toLowerCase() === 'movie' ? 'movie' : (episode_id ? String(episode_id).trim() : null);
    const epNum = episode_number !== undefined && episode_number !== null ? Number(episode_number) : null;
    const sNum = season_number !== undefined && season_number !== null ? Number(season_number) : null;
    const prog = Math.max(0, Number(progress_seconds || 0));
    const dur = Math.max(0, Number(duration_seconds || 0));
    const srv = server_type
      ? String(server_type).trim().toLowerCase().slice(0, 64) || null
      : null;
    const deltaSeconds = Math.max(0, Math.min(7200, Number(added_seconds || (dur > 0 && prog >= dur * 0.9 ? dur : 0))));
    const deltaMinutes = Math.floor(deltaSeconds / 60);
    const isEpisodeFinished = dur > 0 && prog >= dur * 0.88;

    const priorCompletion = await queryOne<{ id: number }>(
      'SELECT id FROM user_episode_completions WHERE user_id = ? AND cartoon_id = ? AND episode_id = ? LIMIT 1',
      [userId, String(cartoon_id).trim(), epId ?? 'movie']
    );
    const wasFinished = !!priorCompletion;
    const firstCompletion = isEpisodeFinished && !wasFinished;

    await transaction(async (conn) => {
      await conn.execute(
        `INSERT INTO watch_history (
          user_id, cartoon_id, cartoon_title, cartoon_image, cartoon_type, anilist_id, tmdb_id,
          episode_id, episode_number, season_number, episode_title, episode_image,
          progress_seconds, duration_seconds, server_type, last_watched
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ON DUPLICATE KEY UPDATE
          cartoon_title = VALUES(cartoon_title),
          cartoon_image = VALUES(cartoon_image),
          cartoon_type = VALUES(cartoon_type),
          anilist_id = COALESCE(VALUES(anilist_id), anilist_id),
          tmdb_id = COALESCE(VALUES(tmdb_id), tmdb_id),
          episode_id = VALUES(episode_id),
          episode_number = VALUES(episode_number),
          season_number = VALUES(season_number),
          episode_title = VALUES(episode_title),
          episode_image = VALUES(episode_image),
          progress_seconds = VALUES(progress_seconds),
          duration_seconds = VALUES(duration_seconds),
          server_type = VALUES(server_type),
          last_watched = NOW()`,
        [
          userId,
          String(cartoon_id).trim(),
          String(cartoon_title).trim(),
          cartoon_image || null,
          type,
          anilistIdVal,
          tmdbIdVal,
          epId,
          epNum,
          sNum,
          episode_title || null,
          episode_image || null,
          prog,
          dur,
          srv,
        ]
      );

      await recordUniqueCartoonOpen(conn, userId, String(cartoon_id).trim());

      const genreStr = Array.isArray(genres) ? genres.join(', ') : genres ? String(genres).trim() : null;
      const totalAvail = Math.max(0, Number(total_episodes_available || 0));

      await conn.execute(
        `INSERT INTO user_anime_stats (
          user_id, cartoon_id, cartoon_title, cartoon_image,
          total_episodes_available, episodes_watched, completed,
          first_watched, last_watched, genres
        ) VALUES (?, ?, ?, ?, ?, ?, 0, NOW(), NOW(), ?)
        ON DUPLICATE KEY UPDATE
          cartoon_title = VALUES(cartoon_title),
          cartoon_image = COALESCE(VALUES(cartoon_image), cartoon_image),
          total_episodes_available = CASE WHEN VALUES(total_episodes_available) > 0 THEN VALUES(total_episodes_available) ELSE total_episodes_available END,
          episodes_watched = episodes_watched + (CASE WHEN ? = 1 THEN 1 ELSE 0 END),
          completed = CASE WHEN total_episodes_available > 0 AND (episodes_watched + (CASE WHEN ? = 1 THEN 1 ELSE 0 END)) >= total_episodes_available THEN 1 ELSE completed END,
          last_watched = NOW(),
          genres = COALESCE(VALUES(genres), genres)`,
        [
          userId,
          String(cartoon_id).trim(),
          String(cartoon_title).trim(),
          cartoon_image || null,
          totalAvail,
          firstCompletion ? 1 : 0,
          genreStr,
          firstCompletion ? 1 : 0,
          firstCompletion ? 1 : 0,
        ]
      );

      const todayStr = new Date().toISOString().slice(0, 10);
      const earnedXp = Math.max(5, (firstCompletion ? 25 : 0) + Math.min(30, Math.floor(deltaMinutes / 2)));

      await conn.execute(
        `INSERT INTO user_daily_activity (user_id, activity_date, episodes_watched, xp_earned)
         VALUES (?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           episodes_watched = episodes_watched + VALUES(episodes_watched),
           xp_earned = xp_earned + VALUES(xp_earned)`,
        [userId, todayStr, firstCompletion ? 1 : 0, earnedXp]
      );
      
    if (firstCompletion) {
        await conn.execute(
          `INSERT INTO user_episode_completions (user_id, cartoon_id, episode_id, season_number, episode_number)
           VALUES (?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE completed_at = completed_at`,
          [userId, String(cartoon_id).trim(), epId ?? 'movie', sNum, epNum]
        );
      }

if (genres && firstCompletion) {
  const genreList = Array.isArray(genres)
    ? genres
    : String(genres).split(',').map((g) => g.trim());

  for (const g of genreList) {
    if (!g) continue;

    await conn.execute(
      `INSERT INTO user_genre_stats (user_id, genre, episodes_watched)
       VALUES (?, ?, 1)
       ON DUPLICATE KEY UPDATE
         episodes_watched = episodes_watched + 1`,
      [userId, g.trim()]
    );
  }
}

      const [userRows] = await conn.execute(
        'SELECT level, xp, total_episodes_watched, completed_anime FROM users WHERE id = ?',
        [userId]
      );
      const currentUser = (userRows as any[])[0];

      if (currentUser) {
        const newXp = (currentUser.xp || 0) + earnedXp;
        const newTotalEpisodes = (currentUser.total_episodes_watched || 0) + (firstCompletion ? 1 : 0);
        const newLevel = calculateLevel(newXp);

        const [distinctAnimeRows] = await conn.execute(
          'SELECT COALESCE(SUM(CASE WHEN completed = 1 THEN 1 ELSE 0 END), 0) as completed_anime FROM user_anime_stats WHERE user_id = ?',
          [userId]
        );
        const distData = (distinctAnimeRows as any[])[0] || {};

        await conn.execute(
          `UPDATE users SET
            xp = ?,
            level = ?,
            total_episodes_watched = ?,
            completed_anime = ?,
            updated_at = NOW()
          WHERE id = ?`,
          [
            newXp,
            newLevel,
            newTotalEpisodes,
            distData.completed_anime || currentUser.completed_anime || 0,
            userId,
          ]
        );
if (firstCompletion) {
  await recomputeAndPersistStreaks(conn, userId);
}
      }
    });

    invalidateUserAuthCache(userId, req.user.token);
    const updatedUser = await queryOne('SELECT * FROM users WHERE id = ?', [userId]);
    if (updatedUser && req.user.token) cacheAuthUser(req.user.token, updatedUser);
    return res.json({
      success: true,
      message: 'Watch progress and gamification synced successfully.',
      user: sanitizeUser(updatedUser),
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to sync watch progress.' });
  }
});

app.post('/api/watch/complete', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const {
      cartoon_id,
      cartoon_title,
      cartoon_image,
      cartoon_type,
      episode_id,
      episode_number,
      season_number,
      episode_title,
      episode_image,
      server_type,
      genres,
      total_episodes_available,
      duration_seconds,
      progress_seconds,
      anilist_id,
      tmdb_id,
    } = req.body;

    if (!cartoon_id || !cartoon_title) {
      return res.status(400).json({ success: false, error: 'cartoon_id and cartoon_title are required.' });
    }

    const userId = req.user.id;
const type = cartoon_type
  ? String(cartoon_type).trim().toUpperCase()
  : 'SERIES';
    const anilistIdVal =
      anilist_id !== undefined && anilist_id !== null && Number(anilist_id) > 0
        ? Number(anilist_id)
        : null;
    const tmdbIdVal =
      tmdb_id !== undefined && tmdb_id !== null && Number(tmdb_id) > 0
        ? Number(tmdb_id)
        : null;
    const epId = String(type).toLowerCase() === 'movie' ? 'movie' : (episode_id ? String(episode_id).trim() : null);
    const epNum = episode_number !== undefined && episode_number !== null ? Number(episode_number) : null;
    const sNum = season_number !== undefined && season_number !== null ? Number(season_number) : null;
    const dur = Math.max(0, Number(duration_seconds || 0));
    const prog = Math.max(0, Number(progress_seconds || dur));
    const srv = server_type
      ? String(server_type).trim().toLowerCase().slice(0, 64) || null
      : null;

    const priorCompletion = await queryOne<{ id: number }>(
      'SELECT id FROM user_episode_completions WHERE user_id = ? AND cartoon_id = ? AND episode_id = ? LIMIT 1',
      [userId, String(cartoon_id).trim(), epId ?? 'movie']
    );
    const firstCompletion = !priorCompletion;

    await transaction(async (conn) => {
      await conn.execute(
        `INSERT INTO watch_history (
          user_id, cartoon_id, cartoon_title, cartoon_image, cartoon_type, anilist_id, tmdb_id,
          episode_id, episode_number, season_number, episode_title, episode_image,
          progress_seconds, duration_seconds, server_type, last_watched
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ON DUPLICATE KEY UPDATE
          cartoon_title = VALUES(cartoon_title),
          cartoon_image = VALUES(cartoon_image),
          cartoon_type = VALUES(cartoon_type),
          anilist_id = COALESCE(VALUES(anilist_id), anilist_id),
          tmdb_id = COALESCE(VALUES(tmdb_id), tmdb_id),
          episode_id = VALUES(episode_id),
          episode_number = VALUES(episode_number),
          season_number = VALUES(season_number),
          episode_title = VALUES(episode_title),
          episode_image = VALUES(episode_image),
          progress_seconds = VALUES(progress_seconds),
          duration_seconds = VALUES(duration_seconds),
          server_type = VALUES(server_type),
          last_watched = NOW()`,
        [
          userId,
          String(cartoon_id).trim(),
          String(cartoon_title).trim(),
          cartoon_image || null,
          type,
          anilistIdVal,
          tmdbIdVal,
          epId,
          epNum,
          sNum,
          episode_title || null,
          episode_image || null,
          prog,
          dur,
          srv,
        ]
      );

      await recordUniqueCartoonOpen(conn, userId, String(cartoon_id).trim());

      const genreStr = Array.isArray(genres) ? genres.join(', ') : genres ? String(genres).trim() : null;
      const totalAvail = Math.max(0, Number(total_episodes_available || 0));

      await conn.execute(
        `INSERT INTO user_anime_stats (
          user_id, cartoon_id, cartoon_title, cartoon_image,
          total_episodes_available, episodes_watched, completed,
          first_watched, last_watched, genres
        ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW(), ?)
        ON DUPLICATE KEY UPDATE
          cartoon_title = VALUES(cartoon_title),
          cartoon_image = COALESCE(VALUES(cartoon_image), cartoon_image),
          total_episodes_available = CASE WHEN VALUES(total_episodes_available) > 0 THEN VALUES(total_episodes_available) ELSE total_episodes_available END,
          episodes_watched = episodes_watched + (CASE WHEN ? = 1 THEN 1 ELSE 0 END),
          completed = CASE WHEN total_episodes_available > 0 AND (episodes_watched + (CASE WHEN ? = 1 THEN 1 ELSE 0 END)) >= total_episodes_available THEN 1 ELSE completed END,
          last_watched = NOW(),
          genres = COALESCE(VALUES(genres), genres)`,
        [
          userId,
          String(cartoon_id).trim(),
          String(cartoon_title).trim(),
          cartoon_image || null,
          totalAvail,
          firstCompletion ? 1 : 0,
          firstCompletion && totalAvail > 0 && totalAvail <= 1 ? 1 : 0,
          genreStr,
          firstCompletion ? 1 : 0,
          firstCompletion ? 1 : 0,
        ]
      );

      const todayStr = new Date().toISOString().slice(0, 10);
      const earnedXp = firstCompletion ? 25 : 0;

      if (earnedXp > 0 || firstCompletion) {
        await conn.execute(
          `INSERT INTO user_daily_activity (user_id, activity_date, episodes_watched, xp_earned)
           VALUES (?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE
             episodes_watched = episodes_watched + VALUES(episodes_watched),
             xp_earned = xp_earned + VALUES(xp_earned)`,
          [userId, todayStr, firstCompletion ? 1 : 0, earnedXp]
        );
      }
      
    if (firstCompletion) {
        await conn.execute(
          `INSERT INTO user_episode_completions (user_id, cartoon_id, episode_id, season_number, episode_number)
           VALUES (?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE completed_at = completed_at`,
          [userId, String(cartoon_id).trim(), epId ?? 'movie', sNum, epNum]
        );
      }

      if (genres && firstCompletion) {
        const genreList = Array.isArray(genres) ? genres : String(genres).split(',').map((g) => g.trim());
        for (const g of genreList) {
          if (!g) continue;
          await conn.execute(
            `INSERT INTO user_genre_stats (user_id, genre, episodes_watched)
             VALUES (?, ?, 1)
             ON DUPLICATE KEY UPDATE
               episodes_watched = episodes_watched + 1`,
            [userId, g.trim()]
          );
        }
      }

      const [userRows] = await conn.execute(
        'SELECT level, xp, total_episodes_watched, completed_anime FROM users WHERE id = ?',
        [userId]
      );
      const currentUser = (userRows as any[])[0];

      if (currentUser) {
        const newXp = (currentUser.xp || 0) + earnedXp;
        const newTotalEpisodes = (currentUser.total_episodes_watched || 0) + (firstCompletion ? 1 : 0);
        const newLevel = calculateLevel(newXp);

        const [distinctAnimeRows] = await conn.execute(
          'SELECT COALESCE(SUM(CASE WHEN completed = 1 THEN 1 ELSE 0 END), 0) as completed_anime FROM user_anime_stats WHERE user_id = ?',
          [userId]
        );
        const distData = (distinctAnimeRows as any[])[0] || {};

        await conn.execute(
          `UPDATE users SET
            xp = ?,
            level = ?,
            total_episodes_watched = ?,
            completed_anime = ?,
            updated_at = NOW()
          WHERE id = ?`,
          [
            newXp,
            newLevel,
            newTotalEpisodes,
            distData.completed_anime || currentUser.completed_anime || 0,
            userId,
          ]
        );
if (firstCompletion) {
  await recomputeAndPersistStreaks(conn, userId);
}
      }
    });

    invalidateUserAuthCache(userId, req.user.token);
    const updatedUser = await queryOne('SELECT * FROM users WHERE id = ?', [userId]);
    if (updatedUser && req.user.token) cacheAuthUser(req.user.token, updatedUser);
    return res.json({
      success: true,
      firstCompletion,
      message: firstCompletion ? 'Episode marked complete.' : 'Already completed.',
      user: sanitizeUser(updatedUser),
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to mark episode complete.' });
  }
});


app.get(
  '/api/friends/status/:targetUsername',
  authenticateToken,
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const me = req.user;
      const targetUsername = String(req.params.targetUsername || '').trim().toLowerCase();
      if (!targetUsername) {
        return res.status(400).json({ success: false, error: 'Target username is required.' });
      }

      const target = await queryOne<{ id: number; username: string }>(
        'SELECT id, username FROM users WHERE username = ? LIMIT 1',
        [targetUsername]
      );
      if (!target) {
        return res.status(404).json({ success: false, error: 'User not found.' });
      }

      if (target.id === me.id) {
        const countRow = await queryOne<{ total: number }>(
          'SELECT COUNT(*) as total FROM friends WHERE user_id = ?',
          [me.id]
        );
        return res.json({
          success: true,
          status: 'self',
          friendsCount: countRow?.total || 0,
        });
      }

      const [friendRow, sentReq, recvReq, countRow] = await Promise.all([
        queryOne<{ id: number }>(
          'SELECT id FROM friends WHERE user_id = ? AND friend_id = ? LIMIT 1',
          [me.id, String(target.id)]
        ),
        queryOne<{ id: string }>(
          `SELECT id FROM friend_requests
           WHERE sender_id = ? AND receiver_id = ? AND status = 'pending'
           LIMIT 1`,
          [String(me.id), String(target.id)]
        ),
        queryOne<{ id: string }>(
          `SELECT id FROM friend_requests
           WHERE sender_id = ? AND receiver_id = ? AND status = 'pending'
           LIMIT 1`,
          [String(target.id), String(me.id)]
        ),
        queryOne<{ total: number }>(
          'SELECT COUNT(*) as total FROM friends WHERE user_id = ?',
          [target.id]
        ),
      ]);

      let status: 'self' | 'friends' | 'pending_sent' | 'pending_received' | 'none' = 'none';
      let requestId: string | undefined;

      if (friendRow) status = 'friends';
      else if (sentReq) {
        status = 'pending_sent';
        requestId = sentReq.id;
      } else if (recvReq) {
        status = 'pending_received';
        requestId = recvReq.id;
      }

      return res.json({
        success: true,
        status,
        friendsCount: countRow?.total || 0,
        requestId,
      });
    } catch (err: any) {
      return res.status(500).json({ success: false, error: err.message || 'Failed to fetch friend status.' });
    }
  }
);

// POST /api/friends/request  { targetUsername }
app.post(
  '/api/friends/request',
  authenticateToken,
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const me = req.user;
      const targetUsername = String(req.body?.targetUsername || '').trim().toLowerCase();
      if (!targetUsername) {
        return res.status(400).json({ success: false, error: 'targetUsername is required.' });
      }

      const target = await queryOne<{ id: number; username: string; avatar_url: string; display_name: string }>(
        'SELECT id, username, avatar_url, display_name FROM users WHERE username = ? LIMIT 1',
        [targetUsername]
      );
      if (!target) {
        return res.status(404).json({ success: false, error: 'User not found.' });
      }
      if (target.id === me.id) {
        return res.status(400).json({ success: false, error: 'You cannot add yourself as a friend.' });
      }

      const existingFriend = await queryOne<{ id: number }>(
        'SELECT id FROM friends WHERE user_id = ? AND friend_id = ? LIMIT 1',
        [me.id, String(target.id)]
      );
      if (existingFriend) {
        return res.json({ success: true, message: 'Already friends.', status: 'friends' });
      }

      // If they already sent me a pending request → accept it instead
      const incoming = await queryOne<{ id: string; status: string }>(
        `SELECT id, status FROM friend_requests
         WHERE sender_id = ? AND receiver_id = ?
         ORDER BY (status = 'pending') DESC, updated_at DESC
         LIMIT 1`,
        [String(target.id), String(me.id)]
      );

      if (incoming && incoming.status === 'pending') {
        await transaction(async (conn) => {
          await conn.execute(
            `UPDATE friend_requests SET status = 'accepted', updated_at = NOW() WHERE id = ?`,
            [incoming.id]
          );
          await conn.execute(
            `INSERT INTO friends (user_id, friend_id, friend_username, friend_avatar, created_at)
             VALUES (?, ?, ?, ?, NOW())
             ON DUPLICATE KEY UPDATE friend_username = VALUES(friend_username), friend_avatar = VALUES(friend_avatar)`,
            [String(me.id), String(target.id), target.username, target.avatar_url || '']
          );
          await conn.execute(
            `INSERT INTO friends (user_id, friend_id, friend_username, friend_avatar, created_at)
             VALUES (?, ?, ?, ?, NOW())
             ON DUPLICATE KEY UPDATE friend_username = VALUES(friend_username), friend_avatar = VALUES(friend_avatar)`,
            [String(target.id), String(me.id), me.username, me.avatar_url || '']
          );
        });
        return res.json({ success: true, message: 'Friend request accepted.', status: 'friends' });
      }

      // Already sent a request? Check any status — pending wins, otherwise reuse cancelled/declined row.
      const existingSent = await queryOne<{ id: string; status: string }>(
        `SELECT id, status FROM friend_requests
         WHERE sender_id = ? AND receiver_id = ?
         ORDER BY (status = 'pending') DESC, updated_at DESC
         LIMIT 1`,
        [String(me.id), String(target.id)]
      );
      if (existingSent && existingSent.status === 'pending') {
        return res.json({ success: true, message: 'Request already pending.', status: 'pending_sent' });
      }
      if (existingSent) {
        await execute(
          `UPDATE friend_requests
           SET status = 'pending',
               sender_username = ?,
               sender_avatar = ?,
               receiver_username = ?,
               receiver_avatar = ?,
               updated_at = NOW()
           WHERE id = ?`,
          [
            me.username,
            me.avatar_url || '',
            target.username,
            target.avatar_url || '',
            existingSent.id,
          ]
        );
        return res.json({ success: true, message: 'Friend request sent.', status: 'pending_sent' });
      }

      const requestId = `req_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

      await execute(
        `INSERT INTO friend_requests
          (id, sender_id, sender_username, sender_avatar, receiver_id, receiver_username, receiver_avatar, status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', NOW(), NOW())`,
        [
          requestId,
          String(me.id),
          me.username,
          me.avatar_url || '',
          String(target.id),
          target.username,
          target.avatar_url || '',
        ]
      );

      return res.json({ success: true, message: 'Friend request sent.', status: 'pending_sent' });
    } catch (err: any) {
      return res.status(500).json({ success: false, error: err.message || 'Failed to send friend request.' });
    }
  }
);

// POST /api/friends/request/:id  { action: 'accept' | 'decline' | 'cancel' }
app.post(
  '/api/friends/request/:id',
  authenticateToken,
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const me = req.user;
      const requestId = String(req.params.id || '').trim();
      const action = String(req.body?.action || '').toLowerCase();

      if (!requestId) {
        return res.status(400).json({ success: false, error: 'requestId is required.' });
      }
      if (!['accept', 'decline', 'cancel'].includes(action)) {
        return res.status(400).json({ success: false, error: 'Invalid action.' });
      }

      const reqRow = await queryOne<{
        id: string;
        sender_id: string;
        receiver_id: string;
        status: string;
      }>('SELECT id, sender_id, receiver_id, status FROM friend_requests WHERE id = ? LIMIT 1', [requestId]);

      if (!reqRow) {
        return res.status(404).json({ success: false, error: 'Request not found.' });
      }
      if (reqRow.status !== 'pending') {
        return res.status(400).json({ success: false, error: 'Request is no longer pending.' });
      }

      const isReceiver = reqRow.receiver_id === String(me.id);
      const isSender = reqRow.sender_id === String(me.id);

      if (action === 'cancel' && !isSender) {
        return res.status(403).json({ success: false, error: 'Only the sender can cancel.' });
      }
      if ((action === 'accept' || action === 'decline') && !isReceiver) {
        return res.status(403).json({ success: false, error: 'Only the receiver can respond.' });
      }

      if (action === 'cancel') {
        await execute(`UPDATE friend_requests SET status = 'cancelled', updated_at = NOW() WHERE id = ?`, [requestId]);
        return res.json({ success: true, message: 'Request cancelled.' });
      }

      if (action === 'decline') {
        await execute(`UPDATE friend_requests SET status = 'declined', updated_at = NOW() WHERE id = ?`, [requestId]);
        return res.json({ success: true, message: 'Request declined.' });
      }

      // accept
      const sender = await queryOne<{ id: number; username: string; avatar_url: string }>(
        'SELECT id, username, avatar_url FROM users WHERE id = ? LIMIT 1',
        [reqRow.sender_id]
      );
      if (!sender) {
        return res.status(404).json({ success: false, error: 'Sender not found.' });
      }

      await transaction(async (conn) => {
        await conn.execute(
          `UPDATE friend_requests SET status = 'accepted', updated_at = NOW() WHERE id = ?`,
          [requestId]
        );
        await conn.execute(
          `INSERT INTO friends (user_id, friend_id, friend_username, friend_avatar, created_at)
           VALUES (?, ?, ?, ?, NOW())
           ON DUPLICATE KEY UPDATE friend_username = VALUES(friend_username), friend_avatar = VALUES(friend_avatar)`,
          [String(me.id), String(sender.id), sender.username, sender.avatar_url || '']
        );
        await conn.execute(
          `INSERT INTO friends (user_id, friend_id, friend_username, friend_avatar, created_at)
           VALUES (?, ?, ?, ?, NOW())
           ON DUPLICATE KEY UPDATE friend_username = VALUES(friend_username), friend_avatar = VALUES(friend_avatar)`,
          [String(sender.id), String(me.id), me.username, me.avatar_url || '']
        );
      });

      return res.json({ success: true, message: 'Friend request accepted.' });
    } catch (err: any) {
      return res.status(500).json({ success: false, error: err.message || 'Failed to respond to friend request.' });
    }
  }
);

// DELETE /api/friends/:targetUsername
app.delete(
  '/api/friends/:targetUsername',
  authenticateToken,
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const me = req.user;
      const targetUsername = String(req.params.targetUsername || '').trim().toLowerCase();

      const target = await queryOne<{ id: number }>(
        'SELECT id FROM users WHERE username = ? LIMIT 1',
        [targetUsername]
      );
      if (!target) {
        return res.status(404).json({ success: false, error: 'User not found.' });
      }

      await transaction(async (conn) => {
        await conn.execute(
          'DELETE FROM friends WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)',
          [String(me.id), String(target.id), String(target.id), String(me.id)]
        );
        await conn.execute(
          `UPDATE friend_requests SET status = 'cancelled', updated_at = NOW()
           WHERE status = 'pending'
             AND ((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?))`,
          [String(me.id), String(target.id), String(target.id), String(me.id)]
        );
      });

      return res.json({ success: true, message: 'Friend removed.' });
    } catch (err: any) {
      return res.status(500).json({ success: false, error: err.message || 'Failed to remove friend.' });
    }
  }
);

// GET /api/friends
app.get('/api/friends', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const me = req.user;

    const [friends, incomingRequests, outgoingRequests] = await Promise.all([
      query<any>(
        `SELECT f.friend_id as id, f.friend_username as username, f.friend_avatar as avatar, f.created_at
         FROM friends f
         WHERE f.user_id = ?
         ORDER BY f.created_at DESC`,
        [String(me.id)]
      ),
      query<any>(
        `SELECT id, sender_id, sender_username, sender_avatar, created_at
         FROM friend_requests
         WHERE receiver_id = ? AND status = 'pending'
         ORDER BY created_at DESC`,
        [String(me.id)]
      ),
      query<any>(
        `SELECT id, receiver_id, receiver_username, receiver_avatar, created_at
         FROM friend_requests
         WHERE sender_id = ? AND status = 'pending'
         ORDER BY created_at DESC`,
        [String(me.id)]
      ),
    ]);

    return res.json({
      success: true,
      friends,
      incomingRequests,
      outgoingRequests,
      totalFriends: friends.length,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to fetch friends.' });
  }
});

// GET /api/friends/search?q=
app.get('/api/friends/search', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const me = req.user;
    const q = String(req.query.q || '').trim().toLowerCase();
    if (!q) {
      return res.json({ success: true, users: [] });
    }

    const rows = await query<any>(
      `SELECT id, username, display_name, avatar_url, level
       FROM users
       WHERE id <> ? AND (LOWER(username) LIKE ? OR LOWER(display_name) LIKE ?)
       ORDER BY xp DESC
       LIMIT 20`,
      [me.id, `%${q}%`, `%${q}%`]
    );

    const users = rows.map((u) => ({
      id: String(u.id),
      username: u.username,
      displayName: u.display_name,
      avatar: u.avatar_url,
      level: Number(u.level || 1),
    }));

    return res.json({ success: true, users });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to search users.' });
  }
});

async function startServer() {
  if (!isProd) {
    app.use('/images', (req, res, next) => {
      res.setHeader('Cache-Control', 'public, max-age=86400, stale-while-revalidate=604800');
      next();
    });
    app.use(['/downloads', '/download'], (req, res, next) => {
      if (req.path.endsWith('.json')) {
        res.setHeader('Cache-Control', 'public, max-age=3600, stale-while-revalidate=86400');
      }
      next();
    });
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(
      express.static(distDir, {
        etag: true,
        lastModified: true,
        setHeaders: (res, filePath) => {
          const normalized = filePath.replace(/\\/g, '/');
          if (normalized.endsWith('/index.html')) {
            res.setHeader('Cache-Control', 'no-cache');
          } else if (normalized.includes('/assets/')) {
            res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
          } else if (
            normalized.includes('/images/') ||
            normalized.includes('/downloads/') ||
            normalized.includes('/download/')
          ) {
            res.setHeader('Cache-Control', 'public, max-age=86400, stale-while-revalidate=604800');
          } else {
            res.setHeader('Cache-Control', 'public, max-age=3600');
          }
        },
      })
    );
    app.get('*', (req, res) => {
      res.setHeader('Cache-Control', 'no-cache');
      res.sendFile(path.resolve(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Server] ToonPlay Full-Stack Server running at http://0.0.0.0:${PORT}`);
    console.log(`[Server] Contact inquiries destination: ${CONTACTS_DIR}`);
    console.log(`[Server] DMCA notices destination: ${DMCA_DIR}`);
    console.log(`[Server] Language cache destination: ${CACHE_DIR}`);
  });
}

startServer();
