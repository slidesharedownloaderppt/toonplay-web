import type { OAuth2Client } from 'google-auth-library';

export interface GoogleAuthRequestBody {
  idToken?: unknown;
  credential?: unknown;
  accessToken?: unknown;
}

export interface VerifiedGoogleIdentity {
  googleId: string;
  email: string;
  emailVerified: boolean;
  name: string;
  avatarUrl: string;
  authMethod: 'id_token' | 'access_token';
}

export class GoogleAuthError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.name = 'GoogleAuthError';
    this.status = status;
  }
}

export interface GoogleVerifierDeps {
  clientId: string;
  googleClient: Pick<OAuth2Client, 'verifyIdToken' | 'getTokenInfo'> | null;
  fetchImpl?: typeof fetch;
}

const GOOGLE_USERINFO_URL = 'https://www.googleapis.com/oauth2/v3/userinfo';
const USERINFO_TIMEOUT_MS = 10_000;

function normalizeString(value: unknown): string {
  return typeof value === 'string' ? value.trim() : '';
}

/**
 * Verifies a Google authentication credential (either a Google ID token from GSI
 * or an OAuth2 access token from google.accounts.oauth2.initTokenClient).
 *
 * Security invariants:
 * - Never trusts unverified client-supplied email/google_id fields.
 * - Verifies token audience (`aud`) matches this application's GOOGLE_CLIENT_ID.
 * - For access tokens, cross-checks `sub` between tokeninfo and Google's userinfo endpoint.
 */
export async function verifyGoogleCredential(
  body: GoogleAuthRequestBody | null | undefined,
  deps: GoogleVerifierDeps
): Promise<VerifiedGoogleIdentity> {
  const clientId = normalizeString(deps.clientId);
  if (!clientId || !deps.googleClient) {
    throw new GoogleAuthError(503, 'Google sign-in is not configured on the server.');
  }

  const idToken = normalizeString(body?.credential) || normalizeString(body?.idToken);
  const accessToken = normalizeString(body?.accessToken);

  if (!idToken && !accessToken) {
    throw new GoogleAuthError(400, 'Google authentication token is required.');
  }

  if (idToken) {
    try {
      const ticket = await deps.googleClient.verifyIdToken({
        idToken,
        audience: clientId,
      });
      const payload = ticket.getPayload();
      const googleId = normalizeString(payload?.sub);
      if (!payload || !googleId) {
        throw new GoogleAuthError(400, 'Invalid Google ID token.');
      }

      return {
        googleId,
        email: normalizeString(payload.email).toLowerCase(),
        emailVerified: Boolean(payload.email_verified),
        name: normalizeString(payload.name) || normalizeString(payload.given_name),
        avatarUrl: normalizeString(payload.picture),
        authMethod: 'id_token',
      };
    } catch (err) {
      if (err instanceof GoogleAuthError) throw err;
      throw new GoogleAuthError(400, 'Invalid or expired Google ID token.');
    }
  }

  // Verify OAuth2 access token audience & expiry via Google tokeninfo, then fetch verified profile.
  let tokenInfo: Awaited<ReturnType<OAuth2Client['getTokenInfo']>>;
  try {
    tokenInfo = await deps.googleClient.getTokenInfo(accessToken);
  } catch {
    throw new GoogleAuthError(400, 'Invalid or expired Google access token.');
  }

  const tokenAudience = normalizeString(tokenInfo?.aud);
  if (!tokenAudience || tokenAudience !== clientId) {
    throw new GoogleAuthError(400, 'Google access token audience mismatch.');
  }

  if (typeof tokenInfo.expiry_date === 'number' && tokenInfo.expiry_date <= Date.now()) {
    throw new GoogleAuthError(400, 'Google access token has expired.');
  }

  const fetchFn = deps.fetchImpl ?? fetch;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), USERINFO_TIMEOUT_MS);

  let userinfo: Record<string, unknown>;
  try {
    const res = await fetchFn(GOOGLE_USERINFO_URL, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        Accept: 'application/json',
      },
      signal: controller.signal,
    });
    if (!res.ok) {
      throw new GoogleAuthError(400, 'Unable to verify Google account profile.');
    }
    userinfo = (await res.json()) as Record<string, unknown>;
  } catch (err) {
    if (err instanceof GoogleAuthError) throw err;
    throw new GoogleAuthError(400, 'Unable to verify Google account profile.');
  } finally {
    clearTimeout(timeout);
  }

  const googleId = normalizeString(userinfo?.sub);
  const tokenSub = normalizeString(tokenInfo?.sub);
  if (!googleId || (tokenSub && tokenSub !== googleId)) {
    throw new GoogleAuthError(400, 'Invalid Google account identity.');
  }

  const email = (normalizeString(userinfo?.email) || normalizeString(tokenInfo?.email)).toLowerCase();
  const rawEmailVerified =
    userinfo?.email_verified !== undefined ? userinfo.email_verified : tokenInfo?.email_verified;

  return {
    googleId,
    email,
    emailVerified: rawEmailVerified === true || rawEmailVerified === 'true',
    name: normalizeString(userinfo?.name) || normalizeString(userinfo?.given_name),
    avatarUrl: normalizeString(userinfo?.picture),
    authMethod: 'access_token',
  };
}
