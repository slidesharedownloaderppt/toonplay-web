export const DEFAULT_PROFILE_BANNER_URL =
  'https://artworks.thetvdb.com/banners/v4/series/81797/backgrounds/6082a16f1aa8f.jpg';

export const PROFILE_FRAMES_REPO = 'Nyyrox/SillyTavern-AvatarDecorations-CSS';
export const PROFILE_FRAMES_COMMIT = 'c63faa39f5c863da5bfaa9a642720b50283de090';
export const PROFILE_FRAMES_DIR = 'dc-decorations';
export const PROFILE_FRAMES_CDN_PREFIX =
  `https://cdn.jsdelivr.net/gh/${PROFILE_FRAMES_REPO}@${PROFILE_FRAMES_COMMIT}/${PROFILE_FRAMES_DIR}/`;

/**
 * Complete enumerated catalog of all 65 animated PNG avatar decorations in
 * Nyyrox/SillyTavern-AvatarDecorations-CSS@c63faa39f5c863da5bfaa9a642720b50283de090/dc-decorations.
 * Exact upstream filenames (including case, spaces, hyphens, and apostrophes) are preserved.
 */
export const PROFILE_FRAME_FILENAMES: readonly string[] = [
  // 1 — Anime (13)
  '1_Angry.png',
  '1_In-Love.png',
  '1_Radiating-Energy.png',
  '1_Shocked.png',
  '1_Soul-Leaving-Body.png',
  '1_Starry-Eyed.png',
  '1_Sweat-Drops.png',
  '1_cat-ears.png',
  '1_dismay.png',
  '1_heartbloom.png',
  '1_in-tears.png',
  '1_ki-energy.png',
  '1_rage.png',
  // 2 — Cyberpunk (4)
  '2_Cybernetic.png',
  '2_Digital Sunrise.png',
  '2_Glitch.png',
  '2_Implant.png',
  // 3 — DISXCORE (3)
  '3_DISXCORE Headset.png',
  '3_Futuristic UI.png',
  '3_Smoke.png',
  // 4 — Fantasy (8)
  '4_Defensive Shield.png',
  '4_Fairy Sprites.png',
  '4_Flaming Sword.png',
  '4_GLowing Runes.png',
  '4_Magical Potion.png',
  '4_Skull Medallion.png',
  '4_Treasure and Key.png',
  "4_Wizard's Staff.png",
  // 5 — Lunar New Year (6)
  "5_Dragon's Smile.png",
  '5_Fan Fluorish.png',
  '5_Firecrackers.png',
  '5_Koi Pond.png',
  '5_Lucky Envelopes.png',
  '5_Lunar Lanterns.png',
  // 6 — Elements (6)
  '6_Air.png',
  '6_Balance.png',
  '6_Earth.png',
  '6_Fire.png',
  '6_Lightning.png',
  '6_Water.png',
  // 7 — Lofi Vibes (6)
  '7_Chromawave.png',
  '7_Cozy-Cat.png',
  '7_Cozy-Headphones.png',
  '7_Doodling.png',
  '7_Oasis.png',
  '7_Rainy-Mood.png',
  // 8 — Valorant (5)
  '8_a-hint-of-clove.png',
  '8_blade-storm.png',
  '8_frag-out.png',
  '8_omens-cowl.png',
  '8_reynas-leer.png',
  // 9 — Springtoons (6)
  '9_butterflies.png',
  '9_dandelion-duo.png',
  '9_honeyblossom.png',
  '9_hug-the-rainbow.png',
  '9_strawberry-vine.png',
  '9_the-petal-pack.png',
  // 10 — Galaxy (6)
  '10_Astronaut-Helmet.png',
  '10_Black-Hole.png',
  '10_Constellations.png',
  '10_Solar-Orbit.png',
  '10_Stardust.png',
  '10_UFO.png',
  // 11 — Gyoko (2)
  '11_Gyoko-Green.png',
  '11_Gyoko-Pink.png',
];

export interface SharedFrameCatalogItem {
  id: string;
  name: string;
  category: string;
  url: string;
  filename: string;
}

export interface SharedFrameCatalogCategory {
  label: string;
  frames: SharedFrameCatalogItem[];
}

const FRAME_GROUP_LABELS: Record<string, string> = {
  '1': 'Anime',
  '2': 'Cyberpunk',
  '3': 'DISXCORE',
  '4': 'Fantasy',
  '5': 'Lunar New Year',
  '6': 'Elements',
  '7': 'Lofi Vibes',
  '8': 'Valorant',
  '9': 'Springtoons',
  '10': 'Galaxy',
  '11': 'Gyoko',
};

const FRAME_UPPERCASE_WORDS = new Set(['DISXCORE', 'UI', 'UFO']);
const FRAME_LOWERCASE_WORDS = new Set(['and', 'of', 'the', 'a']);

function formatFrameWord(word: string, index: number): string {
  const upper = word.toUpperCase();
  if (FRAME_UPPERCASE_WORDS.has(upper)) return upper;
  const lower = word.toLowerCase();
  if (lower === 'glowing') return 'Glowing';
  if (lower === 'fluorish') return 'Flourish';
  if (lower === 'omens') return "Omen's";
  if (lower === 'reynas') return "Reyna's";
  if (index > 0 && FRAME_LOWERCASE_WORDS.has(lower)) return lower;
  return lower.charAt(0).toUpperCase() + lower.slice(1);
}

export function buildProfileFrameCdnUrl(filename: string): string {
  const clean = String(filename || '').trim().replace(/^\/+/, '');
  return `${PROFILE_FRAMES_CDN_PREFIX}${encodeURIComponent(clean)}`;
}

export function buildProfileFrameCatalog(): {
  categories: SharedFrameCatalogCategory[];
  all: SharedFrameCatalogItem[];
} {
  const seenUrls = new Set<string>();
  const all: SharedFrameCatalogItem[] = [];
  const categoryMap = new Map<string, SharedFrameCatalogItem[]>();

  for (const filename of PROFILE_FRAME_FILENAMES) {
    const url = buildProfileFrameCdnUrl(filename);
    if (!url || seenUrls.has(url)) continue;
    seenUrls.add(url);

    const cleanFile = filename.split('/').pop() || filename;
    const stem = cleanFile.replace(/\.(webp|png|gif|apng|svg)$/i, '');
    const prefixMatch = stem.match(/^(\d+)[-_](.+)$/);
    const groupNum = prefixMatch ? prefixMatch[1] : '';
    const rawName = prefixMatch ? prefixMatch[2] : stem;

    const name =
      rawName
        .split(/[-_\s]+/)
        .filter(Boolean)
        .map((word, idx) => formatFrameWord(word, idx))
        .join(' ') || cleanFile;

    const category = groupNum ? FRAME_GROUP_LABELS[groupNum] || `Collection ${groupNum}` : 'Frames';
    const item: SharedFrameCatalogItem = { id: stem, name, category, url, filename };
    all.push(item);

    let bucket = categoryMap.get(category);
    if (!bucket) {
      bucket = [];
      categoryMap.set(category, bucket);
    }
    bucket.push(item);
  }

  const categories: SharedFrameCatalogCategory[] = Array.from(categoryMap.entries())
    .filter(([, frames]) => frames.length > 0)
    .map(([label, frames]) => ({ label, frames }));

  return { categories, all };
}

export const TRUSTED_AVATAR_HOSTS = new Set<string>([
  'animerulz.watch',
  'anime-lok-assets.pages.dev',
  'api.dicebear.com',
  'lh3.googleusercontent.com',
]);

export const TRUSTED_BANNER_HOSTS = new Set<string>([
  'artworks.thetvdb.com',
  'animerulz.watch',
  'anime-lok-assets.pages.dev',
]);

export const TRUSTED_FRAME_HOSTS = new Set<string>(['cdn.jsdelivr.net']);

const MAX_URL_LENGTH = 1000;

function isPrivateOrLoopbackHost(hostname: string): boolean {
  const h = hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (
    h === 'localhost' ||
    h === '0.0.0.0' ||
    h === '::1' ||
    h.endsWith('.local') ||
    h.endsWith('.internal')
  ) {
    return true;
  }
  if (/^127\./.test(h)) return true;
  if (/^10\./.test(h)) return true;
  if (/^192\.168\./.test(h)) return true;
  if (/^169\.254\./.test(h)) return true;
  if (/^172\.(1[6-9]|2\d|3[01])\./.test(h)) return true;
  return false;
}

export interface UrlValidationResult {
  ok: boolean;
  value: string | null;
  error?: string;
}

function parseSafeHttpUrl(
  raw: string
): { ok: true; url: URL; normalized: string } | { ok: false; error: string } {
  const trimmed = raw.trim();
  if (trimmed.length > MAX_URL_LENGTH) {
    return { ok: false, error: 'URL exceeds maximum length.' };
  }

  let parsed: URL;
  try {
    parsed = new URL(trimmed);
  } catch {
    return { ok: false, error: 'Invalid URL format.' };
  }

  if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
    return { ok: false, error: 'Only HTTP/HTTPS image URLs are allowed.' };
  }

  if (parsed.username || parsed.password) {
    return { ok: false, error: 'Credentials are not allowed in asset URLs.' };
  }

  if (isPrivateOrLoopbackHost(parsed.hostname)) {
    return { ok: false, error: 'Private or local network URLs are not allowed.' };
  }

  return { ok: true, url: parsed, normalized: parsed.toString() };
}

/**
 * Validates an avatar URL. Preserves existing custom URL support while blocking
 * unsafe protocols, credentials, and private/loopback hosts.
 */
export function validateAvatarUrl(input: unknown): UrlValidationResult {
  if (input === null || input === '') {
    return { ok: true, value: null };
  }
  const str = String(input).trim();
  if (!str) return { ok: true, value: null };

  if (str.startsWith('/profile-icons/')) {
    return { ok: true, value: `https://animerulz.watch${str}` };
  }

  const parsed = parseSafeHttpUrl(str);
  if (!parsed.ok) return { ok: false, value: null, error: parsed.error };
  return { ok: true, value: parsed.normalized };
}

/**
 * Validates a profile banner URL against trusted banner asset origins.
 * `null` or empty string clears the custom banner (restoring the default banner).
 */
export function validateBannerUrl(input: unknown): UrlValidationResult {
  if (input === null || input === '') {
    return { ok: true, value: null };
  }
  const str = String(input).trim();
  if (!str) return { ok: true, value: null };

  const parsed = parseSafeHttpUrl(str);
  if (!parsed.ok) return { ok: false, value: null, error: parsed.error };

  if (parsed.url.protocol !== 'https:') {
    return { ok: false, value: null, error: 'Banner URL must use HTTPS.' };
  }

  const host = parsed.url.hostname.toLowerCase();
  if (!TRUSTED_BANNER_HOSTS.has(host)) {
    return {
      ok: false,
      value: null,
      error: 'Banner URL must come from a trusted banner source.',
    };
  }

  return { ok: true, value: parsed.normalized };
}

/**
 * Checks whether a frame URL belongs to the authoritative pinned jsDelivr
 * dc-decorations collection (rejecting legacy animerulz.watch/frames URLs).
 */
export function isAuthoritativeFrameUrl(input: unknown): boolean {
  const str = String(input || '').trim();
  if (!str) return false;
  if (!str.startsWith(PROFILE_FRAMES_CDN_PREFIX)) return false;

  const parsed = parseSafeHttpUrl(str);
  if (!parsed.ok || parsed.url.protocol !== 'https:') return false;
  if (!TRUSTED_FRAME_HOSTS.has(parsed.url.hostname.toLowerCase())) return false;
  if (parsed.url.search || parsed.url.hash) return false;

  const rest = parsed.normalized.slice(PROFILE_FRAMES_CDN_PREFIX.length);
  if (!rest || rest.includes('/') || rest.includes('..')) return false;
  return /\.(png|webp|gif|apng)$/i.test(rest);
}

/**
 * Gracefully strips invalid or legacy frame URLs (e.g. old animerulz.watch/frames/*)
 * when reading stored user profiles, returning null so normal avatars render cleanly.
 */
export function sanitizeStoredFrameUrl(input: unknown): string | null {
  const str = String(input || '').trim();
  if (!str) return null;
  return isAuthoritativeFrameUrl(str) ? str : null;
}

/**
 * Validates a profile frame URL against the authoritative pinned jsDelivr
 * SillyTavern-AvatarDecorations-CSS dc-decorations source.
 * `null` or empty string removes the active profile frame.
 */
export function validateFrameUrl(input: unknown): UrlValidationResult {
  if (input === null || input === '') {
    return { ok: true, value: null };
  }
  const str = String(input).trim();
  if (!str) return { ok: true, value: null };

  const parsed = parseSafeHttpUrl(str);
  if (!parsed.ok) return { ok: false, value: null, error: parsed.error };

  if (parsed.url.protocol !== 'https:') {
    return { ok: false, value: null, error: 'Frame URL must use HTTPS.' };
  }

  if (!isAuthoritativeFrameUrl(parsed.normalized)) {
    return {
      ok: false,
      value: null,
      error: 'Frame URL must come from the authorized profile frames collection.',
    };
  }

  return { ok: true, value: parsed.normalized };
}
