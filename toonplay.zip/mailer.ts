import nodemailer from 'nodemailer';
import dotenv from 'dotenv';

dotenv.config();

const {
  SMTP_HOST = 'smtp-relay.brevo.com',
  SMTP_PORT = '587',
  SMTP_SECURE,
  SMTP_USER = '',
  SMTP_PASS = '',
  SMTP_FROM_EMAIL = 'support@streamindia.co.in',
  SMTP_FROM_NAME = 'ToonPlay Support',
  APP_URL = 'https://toonplay.in',
  OTP_TTL_MINUTES = '10',
} = process.env;

const SITE_NAME = 'ToonPlay';
const SITE_URL = (APP_URL || 'https://toonplay.in').replace(/\/+$/, '');
const OTP_TTL = Number(OTP_TTL_MINUTES) || 10;
const parsedPort = Number(SMTP_PORT) || 587;
const useSecureSmtp =
  typeof SMTP_SECURE === 'string' && SMTP_SECURE.trim() !== ''
    ? SMTP_SECURE.trim().toLowerCase() === 'true'
    : parsedPort === 465;

export const mailer = nodemailer.createTransport({
  host: SMTP_HOST,
  port: parsedPort,
  secure: useSecureSmtp,
  auth: { user: SMTP_USER, pass: SMTP_PASS },
});

export async function sendOtpEmail(args: {
  to: string;
  username: string;
  otp: string;
}) {
  const year = new Date().getFullYear();
  const displayName = args.username || args.to.split('@')[0];

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="x-apple-disable-message-reformatting" />
  <meta name="color-scheme" content="light only" />
  <title>${SITE_NAME} Password Reset</title>
  <style>
    body, table, td, a { -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; }
    table, td { mso-table-lspace: 0pt; mso-table-rspace: 0pt; }
    img { -ms-interpolation-mode: bicubic; border: 0; outline: none; text-decoration: none; }
    a { text-decoration: none; }
    @media only screen and (max-width: 600px) {
      .wrapper { width: 100% !important; padding: 0 16px !important; }
      .content { padding: 32px 20px !important; }
      .otp-box { font-size: 28px !important; letter-spacing: 6px !important; padding: 14px 24px !important; }
      .h1 { font-size: 22px !important; line-height: 30px !important; }
      .body-text { font-size: 15px !important; line-height: 24px !important; }
      .footer-text { font-size: 12px !important; }
    }
  </style>
</head>
<body style="margin:0; padding:0; background-color:#f5f5f7; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">

  <div style="display:none; font-size:1px; color:#f5f5f7; line-height:1px; max-height:0; max-width:0; opacity:0; overflow:hidden;">
    Your ${SITE_NAME} password reset code is ${args.otp}. Valid for ${OTP_TTL} minutes.
  </div>

  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#f5f5f7;">
    <tr>
      <td align="center" style="padding: 40px 16px;">
        <table role="presentation" class="wrapper" width="600" cellpadding="0" cellspacing="0" border="0" style="max-width:600px; width:100%; background-color:#ffffff; border-radius:12px; border:1px solid #e5e7eb;">

          <tr>
            <td style="padding: 32px 40px 8px 40px;">
              <p style="margin:0; font-size:14px; font-weight:600; letter-spacing:0.5px; color:#111827; text-transform:uppercase;">
                ${SITE_NAME}
              </p>
            </td>
          </tr>

          <tr>
            <td class="content" style="padding: 8px 40px 0 40px;">
              <h1 class="h1" style="margin:0 0 12px 0; font-size:24px; line-height:32px; font-weight:600; color:#111827;">
                Reset your password
              </h1>
              <p class="body-text" style="margin:0; font-size:15px; line-height:24px; color:#4b5563;">
                Hi ${displayName}, we received a request to reset the password for your ${SITE_NAME} account. Use the code below to continue.
              </p>
            </td>
          </tr>

          <tr>
            <td align="center" style="padding: 32px 40px 8px 40px;">
              <div class="otp-box" style="display:inline-block; font-size:32px; font-weight:600; letter-spacing:8px; color:#111827; background-color:#f3f4f6; border:1px solid #e5e7eb; border-radius:10px; padding:16px 28px;">
                ${args.otp}
              </div>
            </td>
          </tr>

          <tr>
            <td align="center" style="padding: 8px 40px 0 40px;">
              <p style="margin:0; font-size:13px; line-height:20px; color:#6b7280;">
                This code expires in <strong style="color:#111827;">${OTP_TTL} minutes</strong>.
              </p>
            </td>
          </tr>

          <tr>
            <td style="padding: 32px 40px 0 40px;">
              <div style="height:1px; background-color:#e5e7eb; line-height:1px; font-size:0;">&nbsp;</div>
            </td>
          </tr>

          <tr>
            <td class="content" style="padding: 20px 40px 0 40px;">
              <p class="body-text" style="margin:0; font-size:14px; line-height:22px; color:#6b7280;">
                If you didn't request this, you can safely ignore this email — your password won't change.
              </p>
            </td>
          </tr>

          <tr>
            <td class="content" style="padding: 20px 40px 32px 40px;">
              <p class="body-text" style="margin:0; font-size:14px; line-height:22px; color:#6b7280;">
                Thanks,<br/>
                <span style="color:#111827; font-weight:500;">The ${SITE_NAME} Team</span>
              </p>
            </td>
          </tr>

          <tr>
            <td style="padding: 20px 40px 28px 40px; border-top:1px solid #e5e7eb; background-color:#fafafa; border-radius:0 0 12px 12px;">
              <p class="footer-text" style="margin:0; font-size:12px; line-height:18px; color:#9ca3af; text-align:center;">
                &copy; ${year} ${SITE_NAME} &middot;
                <a href="${SITE_URL}" style="color:#6b7280; text-decoration:underline;">${SITE_URL.replace(/^https?:\/\//, '')}</a>
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;

  return mailer.sendMail({
    from: `"${SMTP_FROM_NAME}" <${SMTP_FROM_EMAIL}>`,
    to: args.to,
    subject: `${SITE_NAME} password reset code: ${args.otp}`,
    html,
    text:
      `Hi ${displayName},\n\n` +
      `We received a request to reset your ${SITE_NAME} password.\n\n` +
      `Your reset code is: ${args.otp}\n\n` +
      `This code expires in ${OTP_TTL} minutes.\n\n` +
      `If you didn't request this, you can safely ignore this email — your password won't change.\n\n` +
      `Thanks,\nThe ${SITE_NAME} Team\n${SITE_URL}`,
  });
}